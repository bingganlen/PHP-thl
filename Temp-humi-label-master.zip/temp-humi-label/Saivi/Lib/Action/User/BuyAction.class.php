<?php
class BuyAction extends UserAction{
	public function select(){
		$db=M('compinfo');
                $where['id']=session('uid');
                $res=$db->where($where)->find();
                if($res){
                        $this->assign('list',$res);
                        $this->display();
                }else{
                        $this->display();
		}
	}
	public function del(){
		$id=$this->_get('id');
		$db=M('compinfo');
		$where['id']=$id;
		$res=$db->where($where)->delete();
		if($res){
						$this->redirect(U('Buy/select'));
                       // $this->success('取消成功',U('Buy/select'));
                }else{
                        $this->error('取消失败');
                }
	}
	public function add(){
	
		$select=$this->_get('select');
		$this->assign('select',$select);
		$db=M('compinfo');
		$where['id']=session('uid');
		$res=$db->where($where)->find();
		if($res){
			$this->assign('list',$res);
			$this->display('info');
		}else{
			$this->display();
		}
	}
	public function register(){
		$stmp['id']=session('uid');
		$dir=getcwd().'/compUpload/'.session('uid');
		$dh=opendir($dir);
while ($file=readdir($dh)) {
    if($file!="." && $file!="..") {
      $fullpath=$dir."/".$file;
      if(!is_dir($fullpath)) {
          unlink($fullpath);
      }
    }
  }
		$stmp['compName']=$this->_post('compName');
		$stmp['address']=$this->_post('address');
		$stmp['tel']=$this->_post('tel');
		$stmp['compNum']=$this->_post('compNum');
		//$stmp['compImg']=$this->_post('compImg');
		$stmp['sfzName']=$this->_post('sfzName');
		$stmp['sfzNum']=$this->_post('sfzNum');
		$stmp['date']=date('Y-m-d H:i:s',time());
		$stmp['buy1']=0;
                $stmp['buy2']=0;
		$res=M('users')->where(array('id'=>session('uid')))->find();
		$stmp['user']=$res['username'];
		$select=$this->_get('select');
		if($select==0)
			$stmp['buy1']=1;
		else if($select==1)
			$stmp['buy2']=1;
		else{
			$stmp['buy1']=1;
			$stmp['buy2']=1;
		}
		//$stmp['sfzImg']=$this->_post('sfzImg');
		$a=$this->up();
		$stmp['compImg']=$a[0]['savepath'].'s_'.$a[0]['savename'];
		$stmp['sfzImg']=$a[1]['savepath'].'s_'.$a[1]['savename'];
		//$this->assign('aa',var_dump($a[0]));
		$db=M('compinfo');
		$db->add($stmp);
		
                //$this->assign('select',$select);
		//$this->assign('aa',var_dump($stmp));
		$this->redirect(U('Buy/dow',array('select'=>$select)));
		//$this->success('保存成功',U('Buy/dow',array('select'=>$select)));
	}
	public function dow(){
		$select=$this->_get('select');
		$this->assign('select',$select);
		$db=M('compinfo');
		$where['id']=session('uid');
		$res=$db->where($where)->find();
		$this->assign('list',$res);
		$this->display();
	}

	public function htup(){
		$index=$this->_get('index');
		$a=$this->up();
                $stmp['ht'.$index]=$a[0]['savepath'].'s_'.$a[0]['savename'];
		$db=M('compinfo');
		$where['id']=session('uid');
		$res=$db->where($where)->data($stmp)->save();
		if($res)
                	$this->success('上传成功');
		else
			$this->error('上传失败');
	}

	public function up(){
		$upload=new UploadFile();
		$upload->savePath='./compUpload/'.session('uid').'/';
		$upload->Rule=uniqid;
		$upload->uploadReplace=false;
		$upload->thumb=true;
		$upload->thumbMaxWidth='800,900';
		$upload->thumbMaxHeight='600,700';
		$upload->thumbPrefix='s_';
		$upload->thumbRemoveOrigin=1;

		if($upload->upload()){
			$info=$upload->getUploadFileInfo();
			return $info;
		}else{
			$this->error($upload->getErrorMsg());
		}
	}
}
?>
