<?php 
class NoticeAction extends UserAction{
    public function _initialize() {
        parent::_initialize();
    }

    public function index(){
     
     $token=$_GET['token'];
     $db=M('Wa_notice');
     $res=$db->where(array('Ftoken'=>$token))->find();
     $this->assign('list',$res);
      $this->display();
    }

    public function setdo(){
      $db=M('Wa_notice');
      $token=$_GET['token'];
      $body=$_POST['body'];
      if(!empty($_POST['show'])){
          $show=$_POST['show'];
      }else{
            $show=0;
      }
     

      $res=$db->where(array('Ftoken'=>$token))->find();
      if($res){
        $rs=$db->where(array('Ftoken'=>$token))->save(array('Fbody'=>$body,'Fshow'=>$show));
        if($rs){
            $this->success('更新成功');
        }
      }else{
        $rs=$db->add(array('Fbody'=>$body,'Fshow'=>$show,'Ftoken'=>$token));
        if($rs){
            $this->success('更新成功');
        }
      }
    }
}


?>