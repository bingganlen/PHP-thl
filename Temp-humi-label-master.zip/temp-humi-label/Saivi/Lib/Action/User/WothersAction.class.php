<?php
class WothersAction extends UserAction{
    public $token;

    public function _initialize() {
        parent::_initialize();
        // $this->canUseFunction('shop');
        // $this->assign('userinfo',session('userinfo'));
        // $this->assign('isDining', 0);
    }
    
    /**
     * 分类列表
     */
    public function index() {
        $set = M('Wa_sytset');
        $where=array('Ftoken'=>session('token'));
        if(IS_POST){
           $data['Freward']= $_POST['Freward'];
           $data['Fsend']= $_POST['Fsend'];
           // $data['Flasttime']=time();

           $id=$set->where($where)->save($data);
            if($id){
                $this->success("添加成功");
            }else{
                $this->redirect('index',array('token'=>session('token')));
            }
        }else{
            $res=$set->where($where)->find();
            if(!empty($res)){
                $this->assign('res',$res);
            }
        }
        $this->display('index',array('token'=>session('token')));       
    }
}
?>