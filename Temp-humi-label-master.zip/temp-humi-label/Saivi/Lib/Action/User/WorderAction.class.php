<?php 
class WorderAction extends UserAction{
    public function _initialize() {
        parent::_initialize();
    }

    public function index(){
        $db=M('Wa_orders');
        
        $token=$_GET['token'];
        $count= $db->where(array('Ftoken'=>$token, 'Fstatus'=>array('neq', '0')))->count();
        $Page = new Page($count,10);       
        $res=$db->field('o.Fid,o.Forderid,o.Fordertime,o.Ftotal,o.Fstatus,o.Fusers,o.Faddress,w.Fname, o.Fticket')->table('tp_wa_orders o')->where("o.Ftoken='$token' and Fstatus != 0")->join('tp_wa_workers w on o.Fworkerid=w.Fid', 'left')->limit($Page->firstRow.','.$Page->listRows)->order('o.Fordertime desc')->select();
       //echo $db->getLastSql();
              $show       = $Page->show();

        $this->assign('count', $count);
        $this->assign('list',$res);
        $this->assign('page',$show);
        $this->display();
    }

    public function indexsr(){
        $db=M('Wa_orders');
        $count= $db->where(array('Ftoken'=>$_GET["token"], 'Fstatus'=>array('neq', '0')))->count();
        $this->assign('count', $count);
        
        if(IS_POST){
         $token=empty($_POST['token']) ? '' :trim($_POST['token']);
        $Fusers=empty($_POST['Fusers']) ? '' :trim($_POST['Fusers']);
        $Forderid=empty($_POST['Forderid']) ? '' :trim($_POST['Forderid']);
        $Fstatus=empty($_POST['Fstatus'])? -1:trim($_POST['Fstatus']);
        $starttime=empty($_POST['starttime'])? 0:strtotime(trim($_POST['starttime']));
        $endtime=empty($_POST['endtime'])? time():strtotime(trim($_POST['endtime']));
         $this->assign('starttime',$_POST['starttime']);
        $this->assign('endtime',$_POST['endtime']);
       }else{

        $token=empty($_GET['token']) ? '' :trim($_GET['token']);
        $Fusers=empty($_GET['Fusers']) ? '' :trim($_GET['Fusers']);
        $Forderid=empty($_GET['Forderid']) ? '' :trim($_GET['Forderid']);
        $Fstatus=empty($_GET['Fstatus'])? -1:trim($_GET['Fstatus']);
        $starttime=empty($_GET['starttime'])? 0:strtotime(trim($_GET['starttime']));
        $endtime=empty($_GET['endtime'])? time():strtotime(trim($_GET['endtime']));
         $this->assign('starttime',$_GET['starttime']);
        $this->assign('endtime',$_GET['endtime']);
       }
        $where=array();
        $where2=array();

      
            $where['Ftoken']=array('eq',$token);
            $where2['tp_wa_orders.Ftoken']=array('eq',$token);
        
       $endtime=$endtime+3600*24;
        if($Fusers){
            $where['Fusers']=array('like',"%$Fusers%");
            $where2['tp_wa_orders.Fusers']=array('like',"%$Fusers%");
        }

        if($Forderid){

            $where['Forderid']=array('eq',$Forderid);
            $where2['tp_wa_orders.Forderid']=array('eq',$Forderid);
        }

        if($Fstatus!=-1){
            $where['Fstatus']=array('eq',$Fstatus);
            $where2['tp_wa_orders.Fstatus']=array('eq',$Fstatus);  
        }else{
             $where['Fstatus']=array('neq',0);
            $where2['tp_wa_orders.Fstatus']=array('neq',0);  
        }

            $where['Fordertime']=array(array('gt',$starttime),array('lt',$endtime));
            $where2['tp_wa_orders.Fordertime']=array(array('gt',$starttime),array('lt',$endtime));
    
      
        $count= $db->where($where)->count();
    
        $Page = new Page($count,10);
        $res=$db->join('tp_wa_workers on tp_wa_orders.Fworkerid=tp_wa_workers.Fid')->where($where2)->field('tp_wa_orders.*,tp_wa_workers.Fname as Fname ')->limit($Page->firstRow.','.$Page->listRows)->order('tp_wa_orders.Fordertime desc')->select();

        
        $show       = $Page->show();
        $this->assign('Forderid',$Forderid);
        $this->assign('Fusers',$Fusers);
        $this->assign('Fstatus',$Fstatus);
     
        $this->assign('list',$res);
        $this->assign('page',$show);
        $this->display('index');
    }

    public function status(){

        $fid=$_GET['Fid'];
        $status=$_GET['status'];
        $token=$_GET['token'];


        $db=M('Wa_orders');
        $data=array('Fstatus'=>$status);
        $res=$db->where(array('Fid'=>$fid,'Ftoken'=>$token))->save($data);
        if($res){
	   if($status === '0'){
		$sql = 'DELETE FROM tp_wa_integration WHERE Forderid = '.$fid;
		M()->query($sql);
	   }
           $this->redirect('Worder/index',array('token'=>$token));
        }else{
            $this->error('更新失败');
        }

    }

    public function send_work(){
        $Forderid=$_GET['Forderid'];
        $token=$_GET['token'];
        $db=M('Wa_workers');
        $list=$db->where(array('Ftoken'=>$token))->select();
        $this->assign('list',$list);
        $this->assign('orderid',$Forderid);
        $this->display();
    }

    public function send_work2(){
         $Forderid=$_GET['Forderid'];
        $token=$_GET['token'];
        $db=M('Wa_orders');
        $res=$db->field('Ftype,Fpaytype')->where(array('Fid'=>$Forderid))->find();
        $this->assign('orderid',$Forderid);
        $this->assign('res',$res);
        $this->display();
    }

    public function sendworkdo(){
        $token=$_GET['token'];
        $workerid=$_POST['workerid'];
        $orderid=$_POST['orderid'];
      
        if($workerid==-1){
           echo '请选择送水工';
           exit;
        }
        $dbw=M('Wa_workers');
        $tphone=$dbw->field('Fphone')->where(array('Fid'=>$workerid))->find();
        $Fphone=$tphone['Fphone'];
        $db=M('Wa_orders');
        $res=$db->where(array('Fid'=>array('in', split(',', $orderid)),'Ftoken'=>$token))->save(array('Fworkerid'=>$workerid,'Fphone'=>$Fphone,'Fstatus'=>2,'Flast_time'=>time()));
        
        if($res){
          // $url='http://www.eyuanonline.com:3000/water/'.$token.'/'.$workerid;
           $url=C('my_api').$token.'/'.$workerid;
         //$url='api.fangweihao.com:3000/water/'.$token.'/0';
          $rest=url_get($url,$data);
           //$this->redirect('Worder/send_work',array('token'=>$token));
            $this->success('分配成功');

        }else{
             $this->error('失败');
        }
    }

      public function sendworkdo2(){
        $Fid=$_POST['orderid'];
        $pay=$_POST['pay'];
        if($pay==0){
            $data=array('Fstatus'=>3,'Ftype'=>0,'Fpaytype'=>0);
        }elseif ($pay==1) {
          $data=array('Fstatus'=>3,'Ftype'=>1,'Fpaytype'=>0);
        }else{
             $data=array('Fstatus'=>3,'Ftype'=>1,'Fpaytype'=>1);
        }
       
        $db=M(Wa_orders);
        $res=$db->where(array('Fid'=>$Fid))->save($data);
        if($res){
		$system = M('wa_system')->where(array('Ftoken'=>'all'))->find();
		if($system['Fintegration']){
			$sql = 'INSERT INTO tp_wa_integration SELECT 
	NULL,
	b.Fgoodsid, 
	c.Fintegration*b.Fnum,
	a.Ftoken,
	a.Fusers,
	unix_timestamp(now()),
	a.Fid 
FROM tp_wa_orders a
LEFT JOIN tp_wa_ordergoods b
ON b.Forderid = a.Forderid
LEFT JOIN tp_wa_system c
ON c.Ftoken = "all"
WHERE a.Fid = "'.$_POST['orderid'].'"';
			M()->query($sql);
		}
		//var_dump($res);exit();
            $this->success('分配成功');
        }else{
            $this->error('失败');
        }

      }

    public function orderfino(){

      $order=M('Wa_orders');
      $worker=M('Wa_workers');
      $ordergood=M('Wa_ordergoods');
      $orderid=$_GET['Fid'];
      $orderinfos=$order->where(array('Fid'=>$orderid))->find();
      
      $workers=$worker->where(array('Fid'=>$orderinfos['Fworkerid']))->find();
      
      $ordergoodinfo=$ordergood->where(array('Foid'=>$orderid))->find();
     
      $this->assign('ordergoodinfo',$ordergoodinfo);
      $this->assign('orderinfos',$orderinfos);
      $this->assign('workers',$workers);
      $this->display();
    }

    //统计奖励

    public function rewardlist(){
       $db= M(Wa_orders);
       $token=$_GET['token'];
       $count= $db->where(array('Ftoken'=>$token,'Frid'=>1,'tFstatus'=>3))->count();
       $Page = new Page($count,10);
       $res=$db->join('tp_wa_ordergoods on tp_wa_orders.Fid=tp_wa_ordergoods.Foid')->where(array('tp_wa_orders.Ftoken'=>$token,'tp_wa_orders.Frid'=>1,'tp_wa_orders.Fstatus'=>3))->field('tp_wa_orders.*,tp_wa_ordergoods.Fprice as Fprice ')->limit($Page->firstRow.','.$Page->listRows)->order('tp_wa_orders.Fordertime desc')->select();

        $show       = $Page->show();
        $this->assign('list',$res);
        $this->assign('page',$show);
        $this->display();
    }

    public function ordertimes(){
      $db=M('wxuser');
      $token=session('token');

      $res=$db->field('Fordertimes')->where(array('token'=>$token))->find();
      $this->assign('ordertims',$res);
      $this->display();
    }

    public function ordertimesdo(){
        $db=M('wxuser');
        $token=session('token');
        $ordertimes=$_POST['ordertimes'];
        $res=$db->where(array('token'=>$token))->save(array('Fordertimes'=>$ordertimes));
        if($res){
            $this->success('设置成功');
        }else{
            $this->error('失败');
        }
    }

}

?>
