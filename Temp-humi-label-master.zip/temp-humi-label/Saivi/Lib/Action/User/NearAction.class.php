<?php 
class NearAction extends UserAction{
    public function _initialize() {
        parent::_initialize();
    }

    public function index(){
      if($_GET){
        $data['token']=$_GET['token'];
        $type=isset($_GET['type'])?$_GET['type']:0;
        $data['type']=$type;
        $res=M('wa_near')->where($data)->find();

        if($type=='1'){
          $catname='清洁';
        }elseif($type=='2'){
          $catname='干洗';
        }elseif($type=='3'){
          $catname='其他';
        }else{
          $catname='回收';
        }

        $this->assign('catname',$catname);
        $this->assign('type',$type);
        $this->assign('res',$res);
      }
        $this->display();
      
    }




// 订单列表
    public function orderlist(){
      $nearorder=M('wa_nearorder');
      $data=array();
      if($_GET['token']){
        $token=$_GET['token'];
      }else{
        $token=session('token');
      }
      $data['token']=$token;

    if($_POST){
      if($_POST['token']== $token){
        $starttime=!empty($_POST['starttime'])? strtotime($_POST['starttime']) :0;
        $endtime=!empty($_POST['endtime'])? strtotime($_POST['endtime']) :0;
        if($starttime !='0' && $endtime != '0'){
          $data['createtime']=array('egt',$starttime);
          $data['createtime']=array('elt',$endtime);
          $this->assign('starttime',$starttime);
          $this->assign('endtime',$endtime);
        }  
        if($_POST['type']){
          $data['type']=$_POST['type'];
          $this->assign('type',$_POST['type']);
        }  
        if($_POST['status']){
          $data['status']=$_POST['status'];
          $this->assign('status',$_POST['status']);
        }

      }
      
    }


      $count= $nearorder->where($data)->count();   
      $Page = new Page($count,10); 

      $orderinfos=$nearorder->where($data)->order("id desc")->select();

      $show = $Page->show();
      $this->assign('page',$show);

      $this->assign('orderinfos',$orderinfos);
      $this->display();
    }

 


 public function info(){
  if($_POST){
    $data['token']=$_POST['Ftoken'];
    $data['type']=$_POST['type'];
    $data['status']=$_POST['Fstatus'];
    $data['name']=$_POST['Fname'];
    $data['phone']=$_POST['Fphone'];
    $data['pwd']=$_POST['Fpwd'];
    $data['des']=$_POST['body'];
    $data['createtime']=time();
    $type=isset($_POST['type'])?$_POST['type']:0;

    $data1['token']=$_POST['Ftoken'];
    $data1['type']=$_POST['type'];
    $res=M('wa_near')->where($data1)->find();
    if($res){
      $id=M('wa_near')->where($data1)->save($data);
    }else{
      $id=M('wa_near')->data($data)->add();
    }
    if($id){
        $this->success("提交成功");
    }else{
        $this->redirect('Near/index',array('token'=>session('token')));
    }
    $this->assign('type',$type);
  }

}





}

?>