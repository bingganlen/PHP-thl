<?php
class StoreAction extends UserAction{
	public $token;
	public $product_model;
	public $product_cat_model;
	public function _initialize() {
		parent::_initialize();
		//$this->canUseFunction('shop');
		$this->assign('userinfo',session('userinfo'));
		$this->assign('isDining', 0);
		
//var_dump($_SESSION);exit();
	}
	
	/**
	 * 分类列表
	 */
	public function index() {
        
		$data = M('Product_cat');
		$where = array('token' => session('token'));
        if (IS_POST) {
            $key = $this->_post('searchkey');
            if(empty($key)){
                $this->error("关键词不能为空");
            }

            $map['token'] = $this->get('token'); 
            $map['name|des'] = array('like',"%$key%"); 
            $list = $data->where($map)->select(); 
            $count      = $data->where($map)->count();       
            $Page       = new Page($count,10);
        	$show       = $Page->show();
        } else {
        	$count      = $data->where($where)->count();
        	$Page       = new Page($count,10);
        	$show       = $Page->show();
        	$list = $data->where($where)->order('dining')->limit($Page->firstRow.','.$Page->listRows)->select();
        }
		$this->assign('page',$show);		
		$this->assign('list',$list);
		if ($parentid){
			$parentCat = $data->where(array('id'=>$parentid))->find();
		}
		$this->assign('parentCat',$parentCat);
		$this->assign('parentid',$parentid);
		$this->display();		
	}

	public function endqrcode(){
		$id=$_GET['qrcode'];
		$order=$_GET['order'];
		$num=$_GET['batch'];
		$token=$_GET['token'];
		$prid=$_GET['prid'];
		if($order==''){
			$gt='egt';
			//$order='desc';
		}else{
			$gt='elt';
			//$order='';
		}
		$data=M('qrcode');
		$where=array('token'=>$token,'product_id'=>$prid,'id'=>array($gt,$id));
		$dd=$data->where($where)->order('id '.$order)->limit($num)->select();
		$this->assign('aa',$dd[$num-1]['id']);
		$this->display();
	}

	public function lock(){
		$prid=$_GET['prid'];
		$token=$_GET['token'];
		$index=$_GET['index'];
		$data=M('qrcode');
		$d['lock']=$index;
		$st=$data->where(array('token'=>$token,'id'=>$prid))->data($d)->save();
		if($st)
			$this->success('更新成功');
		else
			$this->error('更新失败');
	}

	public function postbin(){
		$prid=$_GET['prid'];
                $token=$_GET['token'];
		$id=$_POST;
		foreach($id as $t){
			if($str!="")
				$str=$str."or";
			$str=$str." id='".$t."' ";
		}
		$data['product_id']=$prid;
		$where="token='".$token."' and (".$str.")";
		$qrcode=M('qrcode');
		$res=$qrcode->where($where)->data($data)->save();
		if($res)
			$this->success('绑定成功，共绑定'.$res.'条');
		$this->error('绑定失败');

		//$this->error($qrcode->getLastSql());
	}

        public function unbinqr(){
		$index=$_GET['index'];
		$id=$_GET['prid'];
		$token=$_GET['token'];

		if($index==0){
			$data['product_id']=0;
			$data['distributor_token']=array('exp','null');
			$data['distributor_product_id']=0;
			$where=array('token'=>$token,'product_id'=>$id,'lock'=>0);
		}else if($index==1){
			$data['distributor_token']=array('exp','null');
			$data['distributor_product_id']=0;
			$where=array('token'=>$token,'product_id'=>0,'lock'=>0);
		}else if($index==3){
			$data['distributor_token']=array('exp','null');
			$data['distributor_product_id']=0;
                        $where=array('id'=>$id,'lock'=>0);
		}else if($index==4){
                        $data['distributor_token']=array('exp','null');
			$data['distributor_product_id']=0;
                        $where=array('token'=>$token,'product_id'=>$id,'lock'=>0);
                }
		$data['remark1']='0';
		$data['remark2']="";
		$data['lastCheckTime']="";
		$data['isSall']=0;
		$qrcode=M('qrcode');
		$num=$qrcode->where($where)->data($data)->save();
		$this->success('解绑成功，已解绑'.$num.'条');
	}

	public function selectProduct(){
		$product = M('product');
                $where = array('token' => $this->_get('wxuser'));
                $product_list = $product->where($where)->select();
                $this->assign('product',$product_list);
		$this->display();
	}

	public function echart(){
		$wxuser = M('wxuser');
		$where = array('uid' => session('uid'));
		$wxuser_list = $wxuser->where($where)->select();
		$this->assign('wxuser',$wxuser_list);

		$product_id=$this->_get('goods');
		$token=$this->_get('shop');
		$st=$this->_get('st');
		$e=$this->_get('e');

		$data=M();
		$sql="SELECT date,sum(qrcode_count) qrcode,sum(unqrcode_count) unqrcode,sum(buy_count) buy,sum(shop_count) shop FROM tp_qrcode_info WHERE date>='".$st."' and date<='".$e."' and id=".$product_id." and token='".$token."' group by date order by date";
		try{
                        $res=$data->query($sql);
                }catch(Exception $e){
                }
		$d=array();
		$qrcode=array();
		$unqrcode=array();
		$buy=array();
		$shop=array();
		for($i=0;$i<count($res);$i++){
    //date("Y-m-d",strtotime("-2 day",strtotime($st)));
			array_push($d,$res[$i]['date']);
			array_push($qrcode,$res[$i]['qrcode']);
                        array_push($unqrcode,$res[$i]['unqrcode']);
                        array_push($buy,$res[$i]['buy']);
                        array_push($shop,$res[$i]['shop']);
		}
		$this->assign('now',date('y-m-d',time()));
		$this->assign('qrcode',json_encode($qrcode));
                $this->assign('unqrcode',json_encode($unqrcode));
                $this->assign('buy',json_encode($buy));
                $this->assign('shop',json_encode($shop));
                $this->assign('d',json_encode($d));
                $this->assign('zt',date("Y-m-d",strtotime("-1 day",time())));
                $this->assign('zw',date("Y-m-d",strtotime("-7 day",time())));
                $this->assign('zm',date("Y-m-d",strtotime("-30 day",time())));

		$dis=$this->_get('dis');
		$db=M('distributor');
		$where=array('shop_token'=>$this->_get('token'));
		$res=$db->where($where)->select();
		$this->assign('dislist',$res);
		//$this->assign('aa',var_dump($res));
		
		if($dis==-1){
			$dis=$token;
			
		}
		$data=M();
                $sql="SELECT date,sum(buy_count) count FROM tp_buyinfo WHERE date>='".$st."' and date<='".$e."' and shop_product_id=".$product_id." and token='".$dis."' group by date order by date";
                //$this->assign('aa',$sql);
		try{
                        $res=$data->query($sql);
                }catch(Exception $e){
                }
		$disd=array();
		$disnum=array();
		for($i=0;$i<count($res);$i++){
			array_push($disd,$res[$i]['date']);
			array_push($disnum,$res[$i]['count']);
		}
		$this->assign('disd',json_encode($disd));
		$this->assign('disnum',json_encode($disnum));
		$this->display();
	}
	
	public function qrcode2() {
                $Dao = M('distributor');
                $map['shop_token'] = $this->get('token');
                $list = $Dao->where($map)->select();
                $this->assign('list',$list);
                $this->display();
        }

	public function ftoken() {
                header("Content-Type:text/html; charset=utf-8");
                $Dao = D('qrcode');
                $ffs=$this->_get('ffs');
                $fnum=$this->_get('batch');
		$token=$this->get('token');
		$index=$this->_get('index');
		$prid=$this->_get('prid');
		$catid=$this->_get('catid');

		$res=M('product')->where(array('id'=>$prid))->find();
		$dis_catid=M('product_cat')->where(array('shop_id'=>$catid,'shop_token'=>$token,'token'=>$ffs))->find();
		$res=M('product')->where(array('token'=>$ffs,'name'=>$res['name'],'catid'=>$dis_catid['id']))->find();
		if($res==false){
			$this->error('该分销商没有此产品');
		}
		$d['distributor_product_id']=$res['id'];

		if($index=='un'){
			$where02 = array('token' => $token,'product_id' => $prid);
                        $where02['distributor_token']=array('exp',' is NULL');
		}else{
			$where02 = array('token' => $token,'product_id' => 0);
        		$where02['distributor_token']=array('exp',' is NULL');
		}
                $d['distributor_token'] = $ffs;
		$d['distributor_data'] = date('Y-m-d H:i:s',time());

		$start = $this->_get('start');
		
		if($start!=""){
         		$where02['id']=array('egt',$start);
               		$where01=array('token'=> $token,'product_id' => $prid,'id'=>$start);
			$where01['distributor_token']=array('exp',' is NULL');
               		$res=$Dao->where($where01)->count();
               		if($res==0){
               		        $this->error("非法操作，没有该起始id，或该二维码id已使用");
               		}//else{
               		//      $res=$data->where($where)->count();
               		//      $this->error($res);
               		//}
	        }
                $result =  $Dao->where($where02)->order('id')->limit($fnum)->save($d);

                if($result !== false){
	                $this->success('新增成功');

                                        }
                //$data["name"] = $name;
                //$value=$Dao->add($data);
                //$this->assign('name',$value);
                $this->error('操作失败');
        }

        public function addtoken() {
                header("Content-Type:text/html; charset=utf-8");
                $Dao = M('distributor');
                $name=$this->_post('name');
                $token=$this->_post('token');
                $shop_token=$this->get('token');
                $data["name"] = $name;
                $data["token"] = $token;
                $data["shop_token"] = $shop_token;
		$data['date']= date('Y-m-d H:i:s',time());
                $value=$Dao->add($data);
                $this->assign('name',$value);
                $this->success('新增成功');
        }        
        
	public function qrcode() {
		$data = M('Product_cat');
		$where = array('token' => session('token'));
        if (IS_POST) {
            $key = $this->_post('searchkey');
            if(empty($key)){
                $this->error("关键词不能为空");
            }

            $map['token'] = $this->get('token'); 
            $map['name|des'] = array('like',"%$key%"); 
            $list = $data->where($map)->select(); 
            $count      = $data->where($map)->count();       
            $Page       = new Page($count,20);
        	$show       = $Page->show();
        } else {
        	$count      = $data->where($where)->count();
        	$Page       = new Page($count,20);
        	$show       = $Page->show();
        	$list = $data->where($where)->limit($Page->firstRow.','.$Page->listRows)->select();
        }
		$this->assign('page',$show);		
		$this->assign('list',$list);
		if ($parentid){
			$parentCat = $data->where(array('id'=>$parentid))->find();
		}





		$this->assign('parentCat',$parentCat);
		$this->assign('parentid',$parentid);

		$this->display();		
	}

	public function batchqrcode(){

        //$stu = M ('Qrcode');
        //$where01=array('token'=>session('token'));
        //$arr = $stu ->where($where01)-> select();
        //exportexcel($arr,array('id','账户','密码','昵称'),'文件名!');

		$num = $this->_get('batch');
        //$num = $_GET['batch'];
        //$num = 2;
		$prid = $this->_get('prid');
		$start= $this->_get('start');
		$date=$this->_get('date');
        $data = D('qrcode');

        //$data01 = M('qrcode');
       // $where01=array('token'=>session('token'),'product_id' => $prid);
        //$arr = $data01->select();
       //exportexcel($arr,array('id'),'二维码产品绑定');

            $where=array('token'=>session('token'));
			$check=$data->where($where)->find();
			if($check==false)$this->error('非法操作');
			$d['product_id'] = $prid;
			$d['VD']=$date;
			
			$where=array('token'=>session('token'),'product_id' => '0');
			//$condition['product_id'] ='0';
		if($start!=""){
        	        $where['id']=array('egt',$start);
        	        $where02=array('token'=>session('token'),'product_id' => '0','id'=>$start);
        	        $res=$data->where($where02)->count();
        	        if($res==0){
        	                $this->error("非法操作，没有该起始id，或该二维码id已使用");
        	        }//else{
	                //      $res=$data->where($where)->count();
                	//      $this->error($res);
        	        //}
	        }

			$result =  $data->where($where)->order('id')->limit($num)->save($d);
             // echo $data->getLastSql();
             // exit;

					if($result !== false){
						$this->success('新增成功');

					}else{
						$this->assign('id',$prid);
						$this->assign('token',$token);
						$this->assign('catid',$prid);	
						$this->display('bindqr');
					}

	}


	public function bindqr() {
   
		$data = M('qrcode');
		$prid = $this->_get('id'); 
		$catid = $this->_get('catid'); 

		$refa=$this->_get('refa');
		$this->assign('refa',$refa);
		$where = array('token' => session('token'),'product_id'=>0);
        if (IS_POST) {
            // $key = $this->_post('searchkey');
            // if(empty($key)){
            //     $this->error("关键词不能为空");
            // }

            $map['token'] = $this->get('token'); 
            //$map['name|des'] = array('like',"%$key%"); 
			$map['product_id'] = "0"; 
            $list = $data->where($map)->select(); 
            $count      = $data->where($map)->count();       
            $Page       = new Page($count,10);
        	$show       = $Page->show();
        } else {
		$rewhere="";
		if($refa==1){
			$where['underQrcode']='';
			$rewhere=' and underQrcode=""';
		}else if($refa==2){
			$where['underQrcode']=array('neq','');
			$rewhere=' and underQrcode!=""';
        	}
		$count      = $data->where($where)->count();
        	$Page       = new Page($count,10);
        	$show       = $Page->show();
		$list = $data->join('tp_distributor on tp_qrcode.distributor_token=tp_distributor.token')->where("tp_qrcode.product_id=0 and tp_qrcode.token='".$this->get('token')."'".$rewhere)->field('tp_qrcode.*,tp_distributor.name as distributor_name')->order('tp_qrcode.id')->limit($Page->firstRow.','.$Page->listRows)->select();
        	//$list = $data->where($where)->limit($Page->firstRow.','.$Page->listRows)->select();
		//$this->assign('sql',$data->getLastSql());
        }

        $data01 = M('qrcode');
        $where01 = array('token' => session('token'),'product_id' => $prid);
        $qrnumber      = $data01->where($where01)->count();
        $where01 = array('token' => session('token'),'product_id' => 0);
        $unqrnumber      = $data01->where($where01)->count();

	$where01=array('token'=>session('token'));
	$all = $data01->where($where01)->count();
	$where02 = array('token' => session('token'),'product_id' => 0);
	$where02['distributor_token']=array('exp',' is NULL');
	$disnumber      = $data01->where($where02)->count();
	$this->assign('disnumber',$disnumber);
        $batch = 1;
		$this->assign('ffs',$unqrnumber-$disnumber);
		$this->assign('all',$all);
		$this->assign('unqrnumber',$unqrnumber);
		$this->assign('page',$show);		
		$this->assign('list',$list);
		$this->assign('catid',$catid);
		$this->assign('prid',$prid);
        $this->assign('qrnumber',$qrnumber);
        //$this->assign('batch',$batch);
		
		if ($parentid){
			$parentCat = $data->where(array('id'=>$parentid))->find();
		}
		$pname = M('Product_cat')->where(array('id'=>$catid))->find();
        
		$this->assign('pname',$pname);
		$prname=M('product')->where(array('id'=>$prid))->find();
		$this->assign('prname',$prname);
                $Dao=M('distributor');
                $dmap['shop_token'] = $this->get('token');
                $dislist = $Dao->where($dmap)->select();
                $this->assign('dislist',$dislist);                
		
		$this->assign('parentCat',$parentCat);
		$this->assign('parentid',$parentid);
		//类别信息
		$this->assign('product_cat',$this->selectProduct_cat(session('token')));
		$this->display();
	}

	public function unbindqr() {
                $data = M('qrcode');
                $prid = $this->_get('id');
                if(empty($prid)){
                	$this->error('请选择商品');
                }
                $catid = $this->_get('catid');
		$refa=$this->_get('refa');
                $this->assign('refa',$refa);
                $where = array('token' => session('token'),'product_id'=>$prid);
        if (IS_POST) {
            $key = $this->_post('searchkey');
            if(empty($key)){
                $this->error("关键词不能为空");
            }

            $map['token'] = $this->get('token');
            //$map['name|des'] = array('like',"%$key%"); 
                        $map['product_id'] = "0";
            $list = $data->where($map)->select();
            $count      = $data->where($map)->count();
            $Page       = new Page($count,10);
                $show       = $Page->show();
        } else {
		$rewhere="";
                if($refa==1){
                        $where['underQrcode']='';
                        $rewhere=' and underQrcode=""';
                }else if($refa==2){
                        $where['underQrcode']=array('neq','');
                        $rewhere=' and underQrcode!=""';
                }
		$res=M('wxuser')->where(array('token'=>session('token')))->find();
		if($res['lx']==1){
			$nametoken='distributor_token';
			$nameproduct_id='distributor_product_id';
		}else{
			$nameproduct_id='product_id';
                        $nametoken='token';
		}
                $count      = $data->where($where)->count();
                $Page       = new Page($count,10);
                $show       = $Page->show();
                $list = $data->join('tp_distributor on tp_qrcode.distributor_token=tp_distributor.token')->where("tp_qrcode.".$nameproduct_id."=$prid and tp_qrcode.".$nametoken."='".$this->get('token')."'".$rewhere)->field('tp_qrcode.*,tp_distributor.name as distributor_name')->order('tp_qrcode.id')->limit($Page->firstRow.','.$Page->listRows)->select();
               // $list = $data->where($where)->order('id')->limit($Page->firstRow.','.$Page->listRows)->select();
		//$this->assign('sql',$data->getLastSql());
        }
	
        $data01 = M('qrcode');
        $where01 = array($nametoken => session('token'),$nameproduct_id => $prid);
        $qrnumber      = $data01->where($where01)->count();
	$where01 = array('token' => session('token'),'product_id' => 0);
        $unqrnumber      = $data01->where($where01)->count();
        $where01=array('token'=>session('token'));
        $all = $data01->where($where01)->count();
        $where02 = array('token' => session('token'),'product_id' => $prid);
        $where02['distributor_token']=array('exp',' is NULL');
        $disnumber      = $data01->where($where02)->count();
        $this->assign('disnumber',$disnumber);
        $batch = 1;
		$this->assign('ffs',$qrnumber-$disnumber);
                $this->assign('all',$all);
                $this->assign('unqrnumber',$unqrnumber);
                $this->assign('page',$show);
                $this->assign('list',$list);
                $this->assign('catid',$catid);
                $this->assign('prid',$prid);
        $this->assign('qrnumber',$qrnumber);
        //$this->assign('batch',$batch);

                if ($parentid){
                        $parentCat = $data->where(array('id'=>$parentid))->find();
                }
		$pname = M('Product_cat')->where(array('id'=>$catid))->find();
                $this->assign('pname',$pname);
                $prname=M('product')->where(array('id'=>$prid))->find();
                $this->assign('prname',$prname);
                $Dao=M('distributor');
                $dmap['shop_token'] = $this->get('token');
                $dislist = $Dao->where($dmap)->select();
                $this->assign('dislist',$dislist);
		$this->assign('parentCat',$parentCat);
                $this->assign('parentid',$parentid);
                //类别信息
		$this->assign('product_cat',$this->selectProduct_cat(session('token')));

		//调出分销商
		$result=$this->selectname();
		$this->assign('dis_token',$result['token']);
		$this->assign('dis_name',$result['name']);
        $this->display();
        }

	public function unbatchqrcode(){
		$token=$this->_get('token');
		$prid=$this->_get('prid');
		$start=$this->_get('start');
		$batch=$this->_get('batch');

		$data['product_id']=0;
		$data['distributor_token']=array('exp','null');
                $data['distributor_product_id']=0;
		$data['remark1']='0';
                $data['remark2']="";
                $data['lastCheckTime']="";
                $data['isSall']=0;
                $qrcode=M('qrcode');
		$where=array('token'=>$token,'product_id'=>$prid,'lock'=>0);
		if($start!=""){
                        $where['id']=array('egt',$start);
                        $where01=array('token'=> $token,'id'=>$start);
                        $res=$qrcode->where($where01)->count();
                        if($res==0){
                                $this->error("非法操作，没有该起始id，或该二维码id已使用");
                        }//else{
                        //      $res=$data->where($where)->count();
                        //      $this->error($res);
                        //}
                }
                $result =  $qrcode->where($where)->order('id')->limit($batch)->save($data);

                if($result !== false){
                        $this->success('已解绑'.$result.'条');
                }
                $this->error('操作失败');
	}
	public function unbindqrcode(){
		$token=$this->_get('token');
		$prid=$this->_get('prid');
		$qrcode=$this->_get('qrcode');
		
                $data['product_id']=0;
                $where=array('token'=>$token,'id'=>$qrcode);

                $data['remark1']='0';
                $data['remark2']="";
                $data['lastCheckTime']="";
                $data['isSall']=0;
		$data['distributor_token']=array('exp','null');
                $data['distributor_product_id']=0;
                $qrcode=M('qrcode');
                $num=$qrcode->where($where)->data($data)->save();
		$this->success($num);
	}	
 
	public function bindqrcode(){
       // $id = $this->_get('id'); 	
		$prid = $this->_get('prid'); 
		$qrcode = $this->_get('qrcode'); 
            $data = D('qrcode');
            $where=array('token'=>session('token'));
			$check=$data->where($where)->find();
			if($check==false)$this->error('非法操作');
			$d['product_id'] = $prid;
					// 更新的条件
					$condition['qrcode'] = $qrcode;
					$result = $data->where($condition)->save($d);				
					if($result !== false){
						$this->success('新增成功');
					}else{
						$this->assign('id',$prid);
						$this->assign('token',$token);
						$this->assign('catid',$prid);	
						$this->display('bindqr');
					}
	}
	
	
	/**
	 * 创建分类
	 */
	public function catAdd(){
		if(IS_POST){
			$this->insert('Product_cat','/index');
		}else{
			$parentid=intval($_GET['parentid']);
			$parentid=$parentid==''?0:$parentid;
			$this->assign('parentid',$parentid);
			$this->display('catSet');
		}
	}
	
	/**
	 * 分类修改
	 */
	public function catSet(){
        $id = $this->_get('id'); 
		$checkdata = M('Product_cat')->where(array('id'=>$id))->find();
		if(empty($checkdata)){
            $this->error("没有相应记录.您现在可以添加.",U('Store/catAdd'));
        }
		if (IS_POST) {
            $data = D('Product_cat');
            $where=array('id'=>$this->_post('id'),'token'=>session('token'));
			$check=$data->where($where)->find();
			if($check==false)$this->error('非法操作');
			if($data->create()){
				if($data->where($where)->save($_POST)){
					if (!$this->isDining){
						$this->success('修改成功',U('Store/index',array('token'=>session('token'),'parentid'=>$this->_post('parentid'))));
					}else {
						$this->success('修改成功',U('Store/index',array('token'=>session('token'),'parentid'=>$this->_post('parentid'),'dining'=>1)));
					}
					
				}else{
					$this->error('操作失败');
				}
			}else{
				$this->error($data->getError());
			}
		}else{ 
			$this->assign('parentid',$checkdata['parentid']);
			$this->assign('set',$checkdata);
			$this->display();	
		
		}
	}
	
	/**
	 * 删除分类
	 */
	public function catDel() {
		if($this->_get('token')!=session('token')){$this->error('非法操作');}
        $id = $this->_get('id');
        if(IS_GET){                              
            $where=array('id'=>$id,'token'=>session('token'));
            $data=M('Product_cat');
            $check=$data->where($where)->find();
            if($check==false)   $this->error('非法操作');
            $product_model=M('Product');
            $productsOfCat=$product_model->where(array('catid'=>$id))->select;
            if (count($productsOfCat)){
            	$this->error('本分类下有商品，请删除商品后再删除分类',U('Store/index',array('token'=>session('token'),'dining'=>$this->isDining)));
            }
            $back=$data->where($wehre)->delete();
            if($back==true){
            	if (!$this->isDining){
                $this->success('操作成功',U('Store/index',array('token'=>session('token'),'parentid'=>$check['parentid'])));
            	}else {
            		$this->success('操作成功',U('Store/index',array('token'=>session('token'),'parentid'=>$check['parentid'],'dining'=>1)));
            	}
            }else{
                 $this->error('服务器繁忙,请稍后再试',U('Store/index',array('token'=>session('token'))));
            }
        }        
	}
	
	/**
	 * 分类属性列表
	 */
	public function norms() {
		$type = isset($_GET['type']) ? intval($_GET['type']) : 0;
		$catid = intval($_GET['catid']);
		if($checkdata = M('Product_cat')->where(array('id' => $catid, 'token' => session('token')))->find()){
			$this->assign('catData', $checkdata);
        } else {
        	$this->error("没有选择相应的分类.",U('Store/index'));
        }
        
		$data = M('Norms');
		$where = array('catid' => $catid, 'type' => $type);
		$count      = $data->where($where)->count();
		$Page       = new Page($count,20);
		$show       = $Page->show();
		$list = $data->where($where)->limit($Page->firstRow.','.$Page->listRows)->select();
		$this->assign('page', $show);		
		$this->assign('list', $list);
		$this->assign('catid', $catid);
		$this->assign('type', $type);
		$this->display();		
	}
	
	/**
	 * 分类规格的操作
	 */
	public function normsAdd() {
		$type = intval($_REQUEST['type']) ? intval($_REQUEST['type']) : 0;
		if($data = M('Product_cat')->where(array('id' => $this->_get('catid'), 'token' => session('token')))->find()){
			$this->assign('catData', $data);
        } else {
        	$this->error("没有选择相应的分类.", U('Store/index'));
        }
		if (IS_POST) { 
            $data = D('Norms');
            $id = intval($this->_post('id'));
            if ($id) {
	            $where = array('id' => $id, 'type' => $type, 'catid' => $this->_get('catid'));
				$check = $data->where($where)->find();
				if ($check == false) $this->error('非法操作');
            }
			if ($data->create()) {
				if ($id) {
					if ($data->where($where)->save($_POST)) {
						$this->success('修改成功', U('Store/norms',array('token' => session('token'), 'catid' => $this->_post('catid'), 'type' => $type)));
					} else {
						$this->error('操作失败');
					}
				} else {
					if ($data->add($_POST)) {
						$this->success('添加成功', U('Store/norms',array('token' => session('token'), 'catid' => $this->_post('catid'), 'type' => $type)));
					} else {
						$this->error('操作失败');
					}
				}
			} else {
				$this->error($data->getError());
			}
		} else { 
			$data = M('Norms')->where(array('id' => $this->_get('id'), 'type' => $type, 'catid' => $this->_get('catid')))->find();
			//print_r($data);die;
			$this->assign('catid', $this->_get('catid'));
			$this->assign('type', $type);
			$this->assign('token', session('token'));
			$this->assign('set', $data);
			$this->display();	
		}
	}
	
	/**
	 *属性的删除 
	 */
	public function normsDel() {
		if($this->_get('token') != session('token')){$this->error('非法操作');}
        $id = intval($this->_get('id'));
        $catid = intval($this->_get('catid'));
        $type = intval($this->_get('type'));
        if(IS_GET){                              
            $where = array('id' => $id, 'type' => $type, 'catid' => $catid);
            $data = M('Norms');
            $check = $data->where($where)->find();
            if($check == false) $this->error('非法操作');
            if ($back = $data->where($wehre)->delete()) {
            	$this->success('操作成功',U('Store/norms', array('type' => $type, 'catid' => $check['catid'])));
            } else {
				$this->error('服务器繁忙,请稍后再试',U('Store/norms', array('type' => $type, 'catid' => $check['catid'])));
            }
        }        
	}
	
	/**
	 * 分类属性列表
	 */
	public function attributes() {
		$catid = intval($_GET['catid']);
		if($checkdata = M('Product_cat')->where(array('id' => $catid, 'token' => session('token')))->find()){
			$this->assign('catData', $checkdata);
        } else {
        	$this->error("没有选择相应的分类.",U('Store/index'));
        }
		$data = M('Attribute');
		$where = array('catid' => $catid, 'token' => session('token'));
		$count      = $data->where($where)->count();
		$Page       = new Page($count,20);
		$show       = $Page->show();
		$list = $data->where($where)->limit($Page->firstRow.','.$Page->listRows)->select();
		$this->assign('page', $show);		
		$this->assign('list', $list);
		$this->assign('catid', $catid);
		$this->display();		
	}
	
	/**
	 * 分类属性的操作
	 */
	public function attributeAdd() {
		if($checkdata = M('Product_cat')->where(array('id' => $this->_get('catid'), 'token' => session('token')))->find()){
			$this->assign('catData', $checkdata);
        } else {
        	$this->error("没有选择相应的分类.", U('Store/index'));
        }
		if (IS_POST) { 
            $data = D('Attribute');
            $id = intval($this->_post('id'));
            $catid = intval($this->_post('catid'));
            if ($id) {
	            $where = array('id' => $id, 'token' => session('token'), 'catid' => $catid);
				$check = $data->where($where)->find();
				if ($check == false) $this->error('非法操作');
            }
			if ($data->create()) {
				if ($id) {
					if ($data->where($where)->save($_POST)) {
						$this->success('修改成功', U('Store/attributes',array('token' => session('token'), 'catid' => $this->_post('catid'))));
					} else {
						$this->error('操作失败');
					}
				} else {
					if ($data->add($_POST)) {
						$this->success('添加成功', U('Store/attributes',array('token' => session('token'), 'catid' => $this->_post('catid'))));
					} else {
						$this->error('操作失败');
					}
				}
			} else {
				$this->error($data->getError());
			}
		} else { 
			$data = M('Attribute')->where(array('id' => $this->_get('id'), 'token' => session('token'), 'catid' => $this->_get('catid')))->find();
			$this->assign('catid', $this->_get('catid'));
			$this->assign('token', session('token'));
			$this->assign('set', $data);
			$this->display();	
		}
	}
	
	/**
	 *属性的删除 
	 */
	public function attributeDel() {
		if($this->_get('token') != session('token')){$this->error('非法操作');}
        $id = intval($this->_get('id'));
        $catid = intval($this->_get('catid'));
        if(IS_GET){                              
            $where = array('id' => $id, 'token' => session('token'), 'catid' => $catid);
            $data = M('Attribute');
            $check = $data->where($where)->find();
            if($check == false) $this->error('非法操作');
            if ($back = $data->where($wehre)->delete()) {
            	$this->success('操作成功',U('Store/attributes', array('token' => session('token'), 'catid' => $catid)));
            } else {
				$this->error('服务器繁忙,请稍后再试',U('Store/attributes', array('token' => session('token'), 'catid' => $catid)));
            }
        }        
	}

	/**
     *  批量上传商品2015.06.26
	 */
	public function uploadproduct(){
		$product=M('product');
		if(empty($_FILES['file']['tmp_name'])){
			$this->error('请你上传刚下载填好数据的模板');
			exit();
		}
		$file=fopen($_FILES['file']['tmp_name'],'r');
		fgets($file);
		$data=array();
		while(! feof($file)){
			$stmp= fgets($file);
			$stmps=explode(',',mb_convert_encoding($stmp,'utf-8','gb2312'));
			if($stmp!=""){
				$d=array('name'=>$stmps[0],'keyword'=>$stmps[1],'price'=>$stmps[2],'vprice'=>$stmps[3]
					,'oprice'=>$stmps[4],'mailprice'=>$stmps[5],'num'=>$stmps[6],'intro'=>$stmps[7]);
				$d['token']=$_GET['token'];
				$d['sort']=$_GET['sort'];
				$d['storeid']=$_GET['storeid'];
				$d['catid']=$_GET['catid'];
				if($_GET['topid']){
					$d['topid']=$_GET['topid'];
				}else{
					$d['topid']=0;
				}
				$product->add($d);
			}
		}
		$this->success('添加完成');

	}
	
	/**
	 * 商品列表
	 */
	// public function product() {		
	     
	// 	$product_model = M('Product');
	// 	$product_cat_model = M('Product_cat');
	// 	$where = array('token' => session('token'));
	
 //        if(IS_POST){
 //            $key = $this->_post('searchkey');
 //            if(empty($key)){
 //                $this->error("空关键词不能为");
 //            }

 //            $map['token'] = $this->get('token'); 
 //            $map['name|intro|keyword'] = array('like',"%$key%"); 
 //            $list = $product_model->where($map)->order('sort')->select(); 
 //            $count      = $product_model->where($map)->count();       
 //            $Page       = new Page($count,15);
 //        	$show       = $Page->show();
 //        } else {
 //        	$count      = $product_model->where($where)->count();
 //        	$Page       = new Page($count,15);
 //        	$show       = $Page->show();
 //        	$list = $product_model->where($where)->order('sort')->limit($Page->firstRow.','.$Page->listRows)->select();
 //        }

	// 	$this->assign('page',$show);		
	// 	$this->assign('list',$list);
	// 	$this->assign('isProductPage',1);
	// 	$this->assign('catid', $catid);
 //        $this->assign('qrnumber', $count01);
	// 	$this->display();		
	// }
//标签商品列表
	public function product(){
        $sort="";
        $where="";
        $confset=M('confset');
		if(IS_GET){
			if($_GET['over']==1){
				$where="r.isover=1 and ";				
				$this->assign('over',1);
			}
            if($_GET['sort']){
                $sort="r.labelId ".$_GET['sort'].", ";
            }
            if($_GET['labeltype'] && $_GET['labeltype']!="-1"){
				$where.="r.labelType='".$_GET['labeltype']."' and ";			
			}
			if($_GET['barcode']){
            //按任意运单号查询标签记录	              
              $lbstr="(select labelId from tp_confset where barCode='".$_GET['barcode']."')";              
                $where.="r.labelId in ".$lbstr." and ";                
			}
			if($_GET['warn']>-1){
                $where.="r.isover=".$_GET['warn']." and ";	                
			}
		}
        
		if(IS_POST){
			
			if($_POST['labelid']){
				$where.="r.labelId='".$_POST['labelid']."' and ";				
			}
			if($_POST['labeltype'] && $_POST['labeltype']!="-1"){
				$where.="r.labelType='".$_POST['labeltype']."' and ";			
			}
			if($_POST['barcode']){
            //按任意运单号查询标签记录	
              
              $lbstr="(select labelId from tp_confset where barCode='".$_POST['barcode']."')";              
                $where.="r.labelId in ".$lbstr." and ";
                
			}
			if($_POST['warn']>-1){
                $where.="r.isover=".$_POST['warn']." and ";	                
			}
		}
	    $token =session('token');	    
	    //标签类型
	    $labeltype=M('product_type')->select();
	    $this->assign('labeltype',$labeltype);
	    
	    //foreach ($users as $key => $value) {
	    	//$where=array('username'=>$value['Fphone']);
	    	//此处企业员工的手机号作为上传人登陆的账号
	    	//$wherebar['username']=$value['Fphone'];
	    	//$list[]=$confset->where($wherebar)->order('id desc')->find();
	    //}
	    
        //$where.="r.token='".$token."'";
          	    	    
        $rds="select r.*,c.barCode from tp_recordset as r left join tp_confset as c on r.confId=c.confId where ".$where." r.id in (select max(id) from tp_recordset where token='".$token."' group by labelId) order by ".$sort."r.id desc";	    
	    $records=M()->query($rds);
	    $count=count($records);		    
	    $Page = new Page($count,10);	    
	    $recordss=M()->query($rds." limit ".$Page->firstRow.",".$Page->listRows);

	    //给分页加条件
	    // $wherearr=explode('and', $where);
	    // foreach ($wherearr as $k => $v) {
	    // 	$narr=explode('=', trim($v));	      	
	    // 	$Page->parameter[$narr[0]]=urlencode(substr($narr[1],1,strlen($narr[1])-2));	    	
	    // }
	    $show = $Page->show();
	    //分页	    
	    $this->assign('page',$show);
	    $this->assign('records',$recordss);
	    $this->display();
	}
	
    //处理报警
    public function deal(){
    	$id=$_GET['id'];
    	$res=M('recordset')->where(array('id'=>$id))->setField('isover',2);
        if($res){
        	$this->success('报警处理完成');
        }
    }
    //标签管理列表excel下载
    public function excellabel(){
    	$token=$_GET['token'];
    	
    	$arr2 = array('id','username','sex','age');
        $arr1 = array(array('id'=>1,'username'=>'YQJ','sex'=>'男','age'=>24),array('id'=>2,'username'=>'albb','sex'=>'female','age'=>34));
    	$tt='test';
    	$this->excelExport($arr1,$tt,$arr2);
    }
    //分页函数
    public function page_array($count,$page,$array){    
    //global $countpage; #定全局变量    
    $page=(empty($page))?'1':$page; #判断当前页面是否为空 如果为空就表示为第一页面     
       $start=($page-1)*$count; #计算每次分页的开始位置    
    // if($order==1){    
    //   $array=array_reverse($array);    
    // }       
    $totals=count($array);      
    $countpage=ceil($totals/$count); #计算总页面数    
    $pagedata=array();    
    $pagedata=array_slice($array,$start,$count);    
    return $pagedata;  #返回查询数据    
}
	//标签详情页
    public function detail(){
    	$labelid=$this->_get('labelid');
    	$where=array();
    	if(IS_POST){    		
    		if($_POST['username']){
    			$where['username'] = array('like','%'.$_POST['username'].'%');   			
    		}
    		if($_POST['uptime']){
    			$st=strtotime($_POST['uptime']);
    			$end=$st+86400;
    			$where['uptime'] = array('between',array($st,$end));
    		}
    		if($_POST['isover']>-1){
    			$where['isover'] = $_POST['isover'];			
    		}
    		//dump($where);
    	}
    	//一个标签多个配置
    	$label_confs=M('confset')->where(array('labelId'=>$labelid))->order('id desc')->select();
    	if($this->_get('id')){
    		$id=$this->_get('id');
        $label=M('confset')->where(array('id'=>$id,'labelId'=>$labelid))->find();
        $label_sel=$label['barCode'].'-'.$label['id'];
        $where['labelId']=$labelid;
        $where['confId']=$label['confId'];
        $records=M('recordset')->where($where)->order('id desc')->select();

    	}else{
    	
        //一个配置多条上传
        $where['labelId']=$labelid;
        $where['confId']=$label_confs[0]['confId'];	
        //dump($where);
        $records=M('recordset')->where($where)->order('id desc')->select();
        $label_sel=$label_confs[0]['barCode'].'-'.$label_confs[0]['id'];
        }
        if($records){
        //绘制图表信息，默认最新一次上传的数据
        $chart_st=$records[0]['startDate'];
        $chart_end=$records[0]['endDate'];
        $tb=strtoupper($labelid).'_'.date("Y",$label_confs[0]['deliveryTime']);
        $map['time']=array('between',array($chart_st,$chart_end));
        $chart=M()->table('tp_'.$tb)->where($map)->select();
        $echart=json_encode($chart);
        //基线数据
        $markline=M('confset')->field('humLowLimit,humUpLimit,temLowLimit,temUpLimit')->where(array('id'=>$chart[0]['cid']))->find();       
        $this->assign('markline',json_encode($markline));       
        $this->assign('barcode',$label_confs);
        $this->assign('records',$records);
        $this->assign('chart_st',$chart_st);
        $this->assign('chart_end',$chart_end);
        $this->assign('echart',$echart);
        }
        $this->assign('label_sel',$label_sel);
		$this->assign('labelid',$labelid);
    	$this->display();
    }
    //配置信息页面
    public function conf_detail(){
        $id=$_GET['id'];
        $list=M('confset')->where(array('id'=>$id))->find();        
        $this->assign('list',$list);
    	$this->display();
    }
    //记录信息页面
    public function record_detail(){
        $id=$_GET['id'];
        $record=M('recordset')->where(array('id'=>$id))->find();
        //绘制图表
        $chart_st=$record['startDate'];
        $chart_end=$record['endDate'];
        $tb=strtoupper($record['labelId']).'_'.date("Y",$record['batchtime']);
        $map['time']=array('between',array($chart_st,$chart_end));
        $chart=M()->table('tp_'.$tb)->where($map)->select();
        
        $echart=json_encode($chart);
        //基线数据
        $markline=M('confset')->field('humLowLimit,humUpLimit,temLowLimit,temUpLimit')->where(array('id'=>$chart[0]['cid']))->find(); 
        $this->assign('markline',json_encode($markline));
        $this->assign('echart',$echart);
        $this->assign('list',$record);
    	$this->display();
    }
    //记录信息生成pdf
    public function pdf_export($str){
    	vendor('tcpdf.tcpdf','','.php');
    	$pdf=new TCPDF('P','mm','A4',true,'UTF-8',false);
    	$pdf->SetCreator('Megain');
    	$pdf->SetAuthor('Megain_customer');
    	$pdf->SetTitle('Label record infomation');
    	$pdf->SetSubject('Label record items');
    	$pdf->SetKeywords('TCPDF,PDF,PHP');
    	//设置页眉页脚
    	$pdf->SetHeaderData('logo1.png',0,'www.megian.com','美佳音智能物联管理系统',array(0,64,255),array(0,64,128));
    	$pdf->setFooterData(array(0.64,0),array(0,64,128));
    	$pdf->setHeaderFont(array('stsongstdlight','','10'));
    	$pdf->setFooterFont(array('helvetica','','8'));
    	//设置默认等宽字体
    	$pdf->SetDefaultMonospacedFont('courier');
    	//设置间距
    	$pdf->SetMargins(15,27,15);
    	$pdf->SetHeaderMargin(5);
    	$pdf->SetFooterMargin(10);
    	//设置分页 
    	$pdf->SetAutoPageBreak(TRUE,25);
        $pdf->setImageScale(1.25);
        $pdf->setFontSubsetting(true);
        $pdf->SetFont('stsongstdlight','',14);
        $pdf->AddPage();
        //$str1="欢迎使用TCPDF";
        $pdf->writeHTML($str,true,false,false,false,'');
        $imgurl='http://tt.cloud315.org/'.session('baseimg');
        $pdf->Image($imgurl,'','',200,0,'','','',false,300,'',false,false,1,false,false,false);

        $pdf->Output('t.pdf','I');
    }
    //pdf内容
    public function pdf_file(){
    	if($_POST['baseimg']){
    		$picinfo=$_POST['baseimg'];   		
    		if(preg_match('/^(data:\s*image\/(\w+);base64,)/', $picinfo,$result)){
    			$stfile=date('Ymdhis').rand(100,999);
    			$path="uploads/temp/";
    		    $stFilename=$path.$stfile.".png";
    		    //清空文件夹
    		    $arr=scandir($path);
                foreach ($arr as $val) {
                	if($val !="." && $val !=".."){
                		unlink($path.$val);
                	}
                }
    		    //将图片放进文件夹
    		    if(file_put_contents($stFilename, base64_decode(str_replace($result[1], '', $picinfo)))){
    		    	session('baseimg',$stFilename);
                    $this->ajaxReturn($stFilename);
    		    }else{
    		    	$this->ajaxReturn('error');
    		    }
    		}else{
    			$this->ajaxReturn('error1');
    		}
    		 		
    	}
       $id=$_GET['id'];
       $list=M('recordset')->where(array('id'=>$id))->find();
       $conf=M('confset')->where(array('labelId'=>$list['labelId'],'confId'=>$list['confId']))->find();
       $workStatus=($list['workStatus']=='3')?'正常':'测试';
       if($list['isover']=='0'){$isover='无';}elseif($list['isover']=='1'){$isover='有';}else{$isover='已处理';}
       $str = "<p>标签的上传记录信息</p><table cellspacing='0'><tr><td>记录信息</td><td>固件信息</td></tr><tr><td>标签编号：".$list['labelId']."</td><td>APP版本：".$list['appVersion']."</td></tr><tr><td>标签类型：".$list['labelType']."</td><td>闪存容量：".$list['flashCapacity']."KB</td></tr><tr><td>上传定位：".$list['uploadAddr']."</td><td>帧 容 量：".$list['frameCapacity']."KB</td></tr><tr><td>湿度高于上限时长：".$list['cumHumMax']."分钟</td><td>硬件版本：".$list['hardwareVersion']."</td></tr><tr><td>湿度低于下限时长：".$list['cumHumMin']."分钟</td><td>固件版本：".$list['remoteFirmware']."</td></tr><tr><td>温度高于上限时长：".$list['cumTemMax']."分钟</td><td>STC版本：".$list['stcFirmware']."</td></tr><tr><td>温度低于下限时长：".$list['cumTemMin']."分钟</td><td>传输速度：".$list['transmitVelocity']."kpbs</td></tr><tr><td>采样起始时间：".date('Y-m-d H:m:s',$list['startDate'])."</td><td>工作状态：".$workStatus."</td></tr><tr><td>采样终止时间：".date('Y-m-d H:m:s',$list['endDate'])."</td><td>剩余电压：".$list['dumpEnergy']."V</td></tr><tr><td>最大湿度：".$list['humMax']."%</td><td></td></tr><tr><td>最小温度：".$list['tempMin']."℃</td><td></td></tr><tr><td>最小湿度：".$list['humMin']."%</td><td></td></tr><tr><td>采样时长：".$list['humTime']."小时</td><td></td></tr><tr><td>最大温度：".$list['tempMax']."℃</td><td></td></tr><tr><td>是否报警：".$isover."</td></tr><tr><td>上传时间：".date('Y-m-d H:m:s',$list['uptime'])."</td></tr><tr><td></td></tr><tr><td>配置信息</td></tr><tr><td>货物单号：".$conf['barCode']."</td></tr><tr><td>运单时间：".date('Y-m-d H:m:s',$conf['deliveryTime'])."</td></tr><tr><td>公司名称：".$conf['company']."</td></tr><tr><td>产品名称：".$conf['article']."</td></tr><tr><td>创建人：".$conf['configBy']."</td></tr><tr><td>发货地址：".$conf['shippingAddr']."</td></tr><tr><td>收货地址：".$conf['shipTo']."</td></tr><tr><td>延迟时间：".$conf['startDelay']."分钟</td></tr><tr><td>采样间隔时间：".$conf['frequency']."分钟</td></tr><tr><td>温度警戒上限：".$conf['temUpLimit']."℃</td></tr><tr><td>温度警戒下限：".$conf['temLowLimit']."℃</td></tr><tr><td>湿度警戒上限：".$conf['humUpLimit']."RH</td></tr><tr><td>湿度警戒下限：".$conf['humLowLimit']."RH</td></tr><tr><td>配置备注：".$conf['remark']."</td></tr></table>";
             
       $this->pdf_export($str);
}
    //上传记录画图
    public function chartline(){
    	//rid是recordset表id,cid是confset表的id 
    	$rid=$_POST['id'];
    	$cid=$_POST['cid'];        
    	
    	$record=M('recordset')->field('labelId,startDate,endDate,batchtime')->where(array('id'=>$rid))->find();
    	$tn=$record['labelId'].'_'.date('Y',$record['batchtime']);
        //echo $tn;
    	$where=array('cid'=>$cid);
    	$where['time']=array('between',array($record['startDate'],$record['endDate']));
    	//$this->ajaxReturn($where,'JSON');
    	$data=M()->table('tp_'.$tn)->where($where)->select();
    	
    	if($data){
    		$this->ajaxReturn($data,'JSON');
    	}else{
    		echo 'data error';
    	}
    	
    }
    //按时间查询数据
    public function timechart(){
    	//cid是confset表的id     	
    	$cid=$_POST['cid'];        
    	$st=$_POST['starttime'];
    	$end=$_POST['endtime'];
        $conf=M('confset')->field('labelId,confId,deliveryTime')->where(array('id'=>$cid))->find();
        
    	$record=M('recordset')->field('labelId,startDate,endDate')->where(array('labelId'=>$conf['labelId'],'confId'=>$conf['confId']))->select();
    	//$tn=$record['labelId'].'_'.date('Y',$record['uptime']);
        $first=$record[0]['startDate'];
        $last=$record[count($record)-1]['endDate'];
        if($st>$first-24*3600 && $st<$last+24*3600){
            $tb=$conf['labelId'].'_'.date('Y',$conf['deliveryTime']);
            
            $inmap=array('cid'=>$cid);
            $inmap['time']=array('between',array($st,$end));
            $indata=M()->table('tp_'.$tb)->where($inmap)->select();
            if($indata){
            //    echo '111';
            $this->ajaxReturn($indata,'JSON');
            }else{
                //echo 'data error';
                $this->ajaxReturn(['code'=>0,'info'=>'data error']);
            }
        }else{
            //echo 
            $str='本运单记录区间是'.date('Y-m-d H:i:s',$first).'至'.date('Y-m-d H:i:s',$last);
            $this->ajaxReturn(['code'=>0,'info'=>$str]);
        }

    }
    //导出csv方法    
    public function exportcsv(){
      $cid=$_GET['cid'];
      $linfo=M('confset')->where(array('id'=>$cid))->find();
      $rinfo=M('recordset')->where(array('confId'=>$linfo['confId']))->order('id desc')->find();
      $pitem=array("标签配置信息"=>'',"标签ID"=>$linfo['labelId'],"货物单号"=>$linfo['barCode'],"运单时间"=>date('Y-m-d H:i:s',$linfo['deliveryTime']),"公司名称"=>$linfo['company'],"产品名称"=>$linfo['article'],"创建人"=>$linfo['configBy'],"发货地址"=>$linfo['shippingAddr'],"收货地址"=>$linfo['shipTo'],"延迟时间"=>$linfo['startDelay']."分钟","采样间隔"=>$linfo['frequency']."分钟","温度警戒上限"=>$linfo['temUpLimit']."℃","温度警戒下限"=>$linfo['temLowLimit']."℃","湿度警戒上限"=>$linfo['humUpLimit']."RH","湿度警戒下限"=>$linfo['humLowLimit']."RH","备注"=>$linfo['remark'],""=>'',"固件信息"=>'',"固件版本"=>$rinfo['remoteFirmware'],"最大容量"=>$rinfo['flashCapacity']."KB","最大速率"=>$rinfo['transmitVelocity']."kpbs","硬件版本"=>$rinfo['hardwareVersion'],"电量状态"=>$rinfo['dumpEnergy']."V","单片机版本"=>$rinfo['stcFirmware']);     
      $dtitle=array('时间','温度(℃)','湿度(%)');
      //$where['time']=array('between',array($linfo['startDate'],$linfo['endDate']));
      $tb=$linfo['labelId'].'_'.date('Y',$linfo['deliveryTime']);
      $data=M()->table('tp_'.$tb)->where(array('cid'=>$cid))->select();
      $filename=date("YmdHis",time()).".csv";
      header('Content-Type: application/vnd.ms-excel');
      header('Content-Disposition: attachment;filename='.$filename);
      header('Cache-Control: max-age=0');
      $file=fopen('php://output', "a");
      //写入配置固件信息
      foreach ($pitem as $k => $v) {
        $ck=iconv('UTF-8', 'GB2312//IGNORE', $k);
      	$cv=iconv('UTF-8', 'GB2312//IGNORE', $v);
      	$carr=array($ck,$cv);
      	fputcsv($file, $carr);
      }
      unset($carr);
      //写入数据标题
      foreach ($dtitle as $v) {
      	$tv=iconv('UTF-8', 'GB2312//IGNORE', $v);
      	$ttarr[]=$tv;
      }
      fputcsv($file, $ttarr);
      //写入数据
      foreach ($data as $key => $value) {
      	$darr=array(date('Y-m-d H:i:s',$value['time']),$value['temps'],$value['hums']);
      	fputcsv($file, $darr);
      }
      unset($data);
      fclose($file);
    }
	/*查询供销商*/    
	public function  selectname(){

		        $shop_token=$this->_get('token');
                $token=$this->_get('dis_token');
                $db=M('distributor');
                $where['token']=$token;
                $where['shop_token']=$shop_token;
                $res=$db->where($where)->find();
                return $res;
      
	}

        public function ground() {
		$value=$_GET['value'];
		$id=$_GET['id'];
		$product = M('Product');
		$where=array('id'=>$id);
		$check=$product->where($where)->find();
		if($check['price']==0){
			$this->error('该商品没有设定价格，不能上架');
		}else{
			$data['isGrounding']=$value;
			$product->where($where)->data($data)->save();
			if($value==0){
				$this->success('上架成功');
			}else{
				$this->success('下架成功');
			}
		}
	}
	
	/**
	 * 添加商品
	 */
	public function addNew() {

		
		$id = intval($_GET['id']);
	
      
        if ($id && ($product = M('Product')->where(array('token' => session('token'), 'id' => $id))->find())) {
        	
           
        	$this->assign('set', $product);
        	
        }
       
	
		$this->display('set_new');
	}

	/*添加经销商商品*/
	public function addjproduct() {

		$wxuser = M('wxuser')->where(array('token'=>$_SESSION['token']))->find();
		$Fdis_id = $wxuser['Fdis_id'];
		$sql = "INSERT INTO tp_product (name, shortname, price, spec, num, logourl, sort, token)
SELECT name, shortname, price, spec, num, logourl, sort, '".$_SESSION['token']."'
FROM tp_wa_distributor_product WHERE uid = ".$Fdis_id;
		M()->query($sql);
		$this->success('添加成功');
        }
	
	/**
	 * 增加商品
	 */
	public function productSave() {
        
		$token = isset($_POST['token']) ? $_POST['token'] : '';
		
		$num = isset($_POST['num']) ? intval($_POST['num']) : 0;
		$pid = isset($_POST['pid']) ? intval($_POST['pid']) : 0;
		$name = isset($_POST['name']) ? $_POST['name'] : '';
		
		$pic = isset($_POST['pic']) ? $_POST['pic'] : '';
		$price = isset($_POST['price']) ? $_POST['price'] : '';
		$spec = isset($_POST['spec']) ? $_POST['spec'] : '';
		$sort = isset($_POST['sort']) ? intval($_POST['sort']) : 100;
        $shortname = isset($_POST['shortname']) ? $_POST['shortname'] : '';

		if ($token != session('token')) {
			exit(json_encode(array('error_code' => true, 'msg' => '不合法的数据')));
		}
		if (empty($name)) {
			exit(json_encode(array('error_code' => true, 'msg' => '商品不能为空')));
		}
		
		
		
		$data = array('token' => $token, 'num' => $num, 'sort' => $sort, 'name' => $name,'shortname' => $shortname, 'price' => $price, 'spec' => $spec,'logourl' => $pic,  'time' => time());

		$product = M('Product');
		if ($pid && $obj = $product->where(array('id' => $pid, 'token' => $token))->find()) {
			$product->where(array('id' => $pid, 'token' => $token))->save($data);
		} else {
			$pid = $product->add($data);
		}
		if (empty($pid)) {
			exit(json_encode(array('error_code' => false, 'msg' => '商品添加出错了')));
		}
		
		if (!empty($images)) {
			$product_image = M('Product_image');
			$images = json_decode($images, true);
			$iamgelist = $product_image->field('id')->where(array('pid' => $pid))->select();
			$oldImageId = array();
			foreach ($iamgelist as $val) {
				$oldImageId[$val['id']] = $val['id'];
			}
			foreach ($images as $row) {
				if (empty($row['image'])) continue;
				$data_d = array('pid' => $pid, 'image' => $row['image']);
				if ($row['id']) {
					unset($oldImageId[$row['id']]);
					$product_image->where(array('id' => $row['id'], 'pid' => $pid))->save($data_d);
				} else {
					$product_image->add($data_d);
				}
			}
			//删除上次剩余的库存
			foreach ($oldImageId as $id) {
				$product_image->where(array('id' => $id, 'pid' => $pid))->delete();
			}
		}
		exit(json_encode(array('error_code' => false, 'msg' => '商品操作成功','pid'=>$pid)));
	}

    /*更新排序*/

    // public function productSort(){
    //    //exit(json_encode(array('error_code' => false, 'msg' => '商品操作成功'))); 
    //    echo 'sss';    
    // }
	
	/**
	 * 删除商品
	 */
	public function del(){
		$product_model=M('Product');
		if($this->_get('token')!=session('token')){$this->error('非法操作');}
        $id = $this->_get('id');
        if(IS_GET){                              
            $where=array('id'=>$id,'token'=>session('token'));
            $check=$product_model->where($where)->find();
            if($check==false)   $this->error('非法操作');

            $back=$product_model->where($wehre)->delete();
            if($back==true){
            	$keyword_model=M('Keyword');
            	$keyword_model->where(array('token'=>session('token'),'pid'=>$id,'module'=>'Product'))->delete();
                $this->success('操作成功',U('Store/product',array('token'=>session('token'),'dining'=>$this->isDining)));
            }else{
                 $this->error('服务器繁忙,请稍后再试',U('Store/product',array('token'=>session('token'))));
            }
        }        
	}
	
	public function orders(){
		$product_cart_model=M('product_cart');
		if (IS_POST){
			if ($_POST['token']!=$this->_session('token')){
				exit();
			}
			for ($i=0;$i<40;$i++){
				if (isset($_POST['id_'.$i])){
					$thiCartInfo=$product_cart_model->where(array('id'=>intval($_POST['id_'.$i])))->find();
					if ($thiCartInfo['handled']){
					$product_cart_model->where(array('id'=>intval($_POST['id_'.$i])))->save(array('handled'=>0));
					}else {
						$product_cart_model->where(array('id'=>intval($_POST['id_'.$i])))->save(array('handled'=>1));
					}
				}
			}
			$this->success('操作成功',U('Store/orders',array('token'=>session('token'),'dining'=>$this->isDining)));
		} else {
			$where = array('token'=>$this->_session('token'), 'groupon' => 0, 'dining' => 0);
			if (IS_POST) {
				$key = $this->_post('searchkey');
				if(empty($key)){
					$this->error("关键词不能为空");
				}

				$where['truename|address'] = array('like',"%$key%");
				$orders = $product_cart_model->where($where)->select();
				$count      = $product_cart_model->where($where)->limit($Page->firstRow.','.$Page->listRows)->count();
				$Page       = new Page($count,20);
				$show       = $Page->show();
			}else {
				if (isset($_GET['handled'])){
					$where['handled']=intval($_GET['handled']);
				}
				$count      = $product_cart_model->where($where)->count();
				$Page       = new Page($count,20);
				$show       = $Page->show();
				$orders=$product_cart_model->where($where)->order('time DESC')->limit($Page->firstRow.','.$Page->listRows)->select();
			}


			$unHandledCount=$product_cart_model->where(array('token'=>$this->_session('token'),'handled'=>0))->count();
			$this->assign('unhandledCount',$unHandledCount);


			$this->assign('orders',$orders);

			$this->assign('page',$show);
			$this->display();
		}
	}
	
	public function orderInfo() {
		$this->product_model = M('Product');
		$this->product_cat_model = M('Product_cat');
		$product_cart_model = M('product_cart');
		$thisOrder = $product_cart_model->where(array('id'=>intval($_GET['id'])))->find();
		//检查权限
		if (strtolower($thisOrder['token'])!=strtolower($this->_session('token'))){
			exit();
		}
		if (IS_POST){
			if (intval($_POST['sent'])){
				$_POST['handled']=1;
			}
			$product_cart_model->where(array('id'=>$thisOrder['id']))->save(array('sent'=>intval($_POST['sent']),'paid'=>intval($_POST['paid']),'logistics'=>$_POST['logistics'],'logisticsid'=>$_POST['logisticsid'],'handled'=>1));
			//TODO 发货的短信提醒
			if ($_POST['sent']) {
				$company = D('Company')->where(array('token' => $thisOrder['token'], 'isbranch' => 0))->find();
				$userInfo = D('Userinfo')->where(array('token' => $thisOrder['token'], 'wecha_id' => $thisOrder['wecha_id']))->find();
				Sms::sendSms($this->token, "您在{$company['name']}商城购买的商品，商家已经给您发货了，请您注意查收", $userInfo['tel']);
			}
			
			//
			/************************************************/
			if (intval($_POST['paid'])&&intval($thisOrder['price'])){
				$member_card_create_db=M('Member_card_create');
				$wecha_id=$thisOrder['wecha_id'];
				$userCard=$member_card_create_db->where(array('token'=>$this->token,'wecha_id'=>$wecha_id))->find();
				$member_card_set_db=M('Member_card_set');
				$thisCard=$member_card_set_db->where(array('id'=>intval($userCard['cardid'])))->find();
				$set_exchange = M('Member_card_exchange')->where(array('cardid'=>intval($thisCard['id'])))->find();
				//
				$arr['token']=$this->token;
				$arr['wecha_id']=$wecha_id;
				$arr['expense']=$thisOrder['price'];
				$arr['time']=time();
				$arr['cat']=99;
				$arr['staffid']=0;
				$arr['score']=intval($set_exchange['reward'])*$order['price'];
				M('Member_card_use_record')->add($arr);
				$userinfo_db=M('Userinfo');
				$thisUser = $userinfo_db->where(array('token'=>$thisCard['token'],'wecha_id'=>$arr['wecha_id']))->find();
				$userArr=array();
				$userArr['total_score']=$thisUser['total_score']+$arr['score'];
				$userArr['expensetotal']=$thisUser['expensetotal']+$arr['expense'];
				$userinfo_db->where(array('token'=>$thisCard['token'],'wecha_id'=>$arr['wecha_id']))->save($userArr);
			}
			/************************************************/
			//
			
			$this->success('修改成功',U('Store/orderInfo',array('token'=>session('token'),'id'=>$thisOrder['id'])));
		}else {
			//订餐信息
			$product_diningtable_model = M('product_diningtable');
			if ($thisOrder['tableid']) {
				$thisTable=$product_diningtable_model->where(array('id'=>$thisOrder['tableid']))->find();
				$thisOrder['tableName']=$thisTable['name'];
			}
			//
			$this->assign('thisOrder',$thisOrder);
			$carts=unserialize($thisOrder['info']);

			//
			$totalFee=0;
			$totalCount=0;
			
			$data = $this->getCat($carts);
			if (isset($data[1])) {
				foreach ($data[1] as $pid => $row) {
					$totalCount += $row['total'];
					$totalFee += $row['totalPrice'];
					$listNum[$pid] = $row['total'];
				}
			}
			$list = $data[0];
//			print_r($list);die;
			$this->assign('products', $list);
			//
			$this->assign('totalFee',$totalFee);
			//
			$this->assign('totalCount',$totalCount);

			$db=M('express');
			$res=$db->select();
			$this->assign('express',$res);
			$this->display();
		}
	}
	
	/**
	 * 计算一次购物的总的价格与数量
	 * @param array $carts
	 */
	public function getCat($carts)
	{
		if (empty($carts)) {
			return array();
		}
		//邮费
		$mailPrice = 0;
		//商品的IDS
		$pids = array_keys($carts);
		
		//商品分类IDS
		$productList = $cartIds = array();
		if (empty($pids)) {
			return array(array(), array(), array());
		}
		
		$productdata = $this->product_model->where(array('id'=> array('in', $pids)))->select();
		foreach ($productdata as $p) {
			if (!in_array($p['catid'], $cartIds)) {
				$cartIds[] = $p['catid'];
			}
			$mailPrice = max($mailPrice, $p['mailprice']);
			$productList[$p['id']] = $p;
		}
	
		//商品规格参数值
		$catlist = $norms = array();
		if ($cartIds) {
			$normsdata = M('norms')->where(array('catid' => array('in', $cartIds)))->select();
			foreach ($normsdata as $r) {
				$norms[$r['id']] = $r['value'];
			}
			//商品分类
			$catdata = M('Product_cat')-> where(array('id' => array('in', $cartIds)))->select();
			foreach ($catdata as $cat) {
				$catlist[$cat['id']] = $cat;
			}
		}
		$dids = array();
		foreach ($carts as $pid => $rowset) {
			if (is_array($rowset)) {
				$dids = array_merge($dids, array_keys($rowset));
			}
		}
		//商品的详细
		$data = array();
		if ($dids) {
			$dids = array_unique($dids);
			$detail = M('Product_detail')->where(array('id'=> array('in', $dids)))->select();
			foreach ($detail as $row) {
				$row['colorName'] = isset($norms[$row['color']]) ? $norms[$row['color']] : '';
				$row['formatName'] = isset($norms[$row['format']]) ? $norms[$row['format']] : '';
				$row['count'] = isset($carts[$row['pid']][$row['id']]['count']) ? $carts[$row['pid']][$row['id']]['count'] : 0;
				$productList[$row['pid']]['detail'][] = $row;
				$data[$row['pid']]['total'] = isset($data[$row['pid']]['total']) ? intval($data[$row['pid']]['total'] + $row['count']) : $row['count'];
				$data[$row['pid']]['totalPrice'] = isset($data[$row['pid']]['totalPrice']) ? intval($data[$row['pid']]['totalPrice'] + $row['count'] * $row['price']) : $row['count'] * $row['price'];//array('total' => $totalCount, 'totalPrice' => $totalFee);
			}
		}
		//商品的详细列表
		$list = array();
		foreach ($productList as $pid => $row) {
			if (!isset($data[$pid]['total'])) {
				$data[$pid] = array();
				$row['count'] = $data[$pid]['total'] = isset($carts[$pid]['count']) ? $carts[$pid]['count'] : (isset($carts[$pid]) && is_int($carts[$pid]) ? $carts[$pid] : 0);
				$data[$pid]['totalPrice'] = $data[$pid]['total'] * $row['price'];
			}
			$row['formatTitle'] =  isset($catlist[$row['catid']]['norms']) ? $catlist[$row['catid']]['norms'] : '';
			$row['colorTitle'] =  isset($catlist[$row['catid']]['color']) ? $catlist[$row['catid']]['color'] : '';
			$list[] = $row;
		}
		return array($list, $data, $mailPrice);
		die;
		if (empty($carts)) {
			return array();
		}
		$pdata = $data = $list = $ids = $detail_list = $products = array();
		$mailPrice = 0;
		foreach ($carts as $pid => $rowset) {
			$totalCount = $totalFee = 0;
			$tmp = $this->product_model->where(array('id'=> $pid))->find();
			if (is_array($rowset)) {
				$norms = $cntArray = $dids = array();
				foreach ($rowset as $did => $count) {
					if (!in_array($did, $dids)){
						array_push($dids, $did);
						$cntArray[$did] = $count['count'];
					}
					$totalCount += $count['count'];
				}
				$normsdata = M('norms')->where(array('catid' => $tmp['catid']))->select();
				foreach ($normsdata as $r) {
					$norms[$r['id']] = $r['value'];
				}
				if ($dids) {
					$temp = M('Product_detail')->where(array('id'=> array('in', $dids), 'pid' => $pid))->select();
					foreach ($temp as $row) {
						if (isset($rowset[$row['id']])) {
							$row['colorName'] = isset($norms[$row['color']]) ? $norms[$row['color']] : '';
							$row['formatName'] = isset($norms[$row['format']]) ? $norms[$row['format']] : '';
							$row['count'] = $cntArray[$row['id']];
							$totalFee += $cntArray[$row['id']] * $row['price'];
							$detail_list[$pid][] = $row;
						}
					}
				}
			} else {
				$totalCount += $rowset;
				$totalFee += $rowset * $tmp['price'];
				$pdata[$pid] = $rowset;
			}
			$mailPrice = max($mailPrice, $tmp['mailprice']);
			$data[$pid] = array('total' => $totalCount, 'totalPrice' => $totalFee);
		}
		
		$ids = array_keys($carts);
		if (count($ids)) {
			$tmp = $this->product_model->where(array('id'=>array('in', $ids)))->select();
			foreach ($tmp as $row) {
				if (isset($detail_list[$row['id']])) {
					if ($catData = M('Product_cat')-> where(array('id' => $row['catid']))->find()) {
						$row['formatTitle'] =  $catData['norms'];
						$row['colorTitle'] =  $catData['color'];
					}
					$row['detail'] =  $detail_list[$row['id']];
				} else {
					$row['detail'] = '';
					$row['count'] = $pdata[$row['id']];
				}
				$list[] = $row;
			}
		}
		return array($list, $data, $mailPrice);
	
		$list = $ids = $detail_list = $products = array();
		$carts = empty($carts) ? $this->_getCart() : $carts;
		$pdata = $data = array();
		$mailPrice = 0;
		foreach ($carts as $pid => $rowset) {
			$totalCount = $totalFee = 0;
			$tmp = $this->product_model->where(array('id'=> $pid))->find();
			if (is_array($rowset)) {
				$norms = $cntArray = $dids = array();
				foreach ($rowset as $did => $count) {
					if (!in_array($did, $dids)){
						array_push($dids, $did);
						$cntArray[$did] = $count['count'];
					}
					$totalCount += $count['count'];
				}
				$normsdata = M('norms')->where(array('catid' => $tmp['catid']))->select();
				foreach ($normsdata as $r) {
					$norms[$r['id']] = $r['value'];
				}
				if ($dids) {
					$temp = M('Product_detail')->where(array('id'=> array('in', $dids), 'pid' => $pid))->select();
					foreach ($temp as $row) {
						if (isset($rowset[$row['id']])) {
							$row['colorName'] = isset($norms[$row['color']]) ? $norms[$row['color']] : '';
							$row['formatName'] = isset($norms[$row['format']]) ? $norms[$row['format']] : '';
							$row['count'] = $cntArray[$row['id']];
							$totalFee += $cntArray[$row['id']] * $row['price'];
							$detail_list[$pid][] = $row;
						}
					}
				}
			} else {
				$totalCount += $rowset;
				$totalFee += $rowset * $tmp['price'];
				$pdata[$pid] = $rowset;
			}
			$mailPrice = max($mailPrice, $tmp['mailprice']);
			$data[$pid] = array('total' => $totalCount, 'totalPrice' => $totalFee);
		}
		$ids = array_keys($carts);
		if (count($ids)) {
			$tmp = $this->product_model->where(array('id'=>array('in', $ids)))->select();
			foreach ($tmp as $row) {
				if (isset($detail_list[$row['id']])) {
					if ($catData = M('Product_cat')-> where(array('id' => $row['catid']))->find()) {
						$row['formatTitle'] = $catData['norms'];
						$row['colorTitle'] = $catData['color'];
					}
					$row['detail'] =  $detail_list[$row['id']];
				} else {
					$row['detail'] = '';
					$row['count'] = $pdata[$row['id']];
				}
				$list[] = $row;
			}
		}
		return array($list, $data, $mailPrice);
	}
	
	public function deleteOrder(){
		$product_model=M('product');
		$product_cart_model=M('product_cart');
		$product_cart_list_model=M('product_cart_list');
		$thisOrder=$product_cart_model->where(array('id'=>intval($_GET['id'])))->find();
		//检查权限
		$id=$thisOrder['id'];
		if ($thisOrder['token']!=$this->_session('token')){
			exit();
		}
		//
		//删除订单和订单列表
		$product_cart_model->where(array('id'=>$id))->delete();
		$product_cart_list_model->where(array('cartid'=>$id))->delete();
		
		//商品销量做相应的减少
		if (empty($thisOrder['paid'])) {
			$carts = unserialize($thisOrder['info']);
			//还原库存
			foreach ($carts as $pid => $rowset) {
				$total = 0;
				if (is_array($rowset)) {
					foreach ($rowset as $did => $row) {
						M('product_detail')->where(array('id' => $did, 'pid' => $pid))->setInc('num', $row['count']);
						$total += $row['count'];
					}
				} else {
					$total = $rowset;
				}
				$product_model->where(array('id' => $pid))->setInc('num', $total);
				$product_model->where(array('id' => $pid))->setDec('salecount', $total);
			}
//			foreach ($carts as $k => $c){
//				if (is_array($c)){
//					$productid=$k;
//					$price=$c['price'];
//					$count=$c['count'];
//					$product_model->where(array('id'=>$k))->setDec('salecount',$c['count']);
//				}
//			}
		}
		$this->success('操作成功',U('Store/orders', array('token' => session('token'))));
		//$this->success('操作成功',$_SERVER['HTTP_REFERER']);
	}
	
// 数据处理
	public function test(){
		$this->assign('token','fcmnob1442624539');
		$this->display();

	}
	public function testadd($token,$id){
		$users=M('wa_users')->where(array('Ftoken'=>$token,'id'=>$id))->find();
		$ids=$users['id'];
		if($ids){
			$str=$users['Faddress'];
			$arr=explode('#',$str);
			$str1=$arr[0];
			$str2=$arr[1];
			switch ($str1) {
			case '1':
				$value='10012';
				break;
			case '2':
				$value='10036';
				break;
			case '3':
				$value='10037';
				break;
			case '4':
				$value='10038';
				break;
			case '5':
				$value='10039';
				break;


			case '6':
				$value='10040';
				break;
			case '7':
				$value='10041';
				break;
			case '8':
				$value='10042';
				break;	
			case '9':
				$value='10043';
				break;
			case '10':
				$value='10044';
				break;


			case '11':
				$value='10045';
				break;
			case '12':
				$value='10046';
				break;
			case '13':
				$value='10047';
				break;
			case '14':
				$value='10048';
				break;
			case '15':
				$value='10049';
				break;



			case '16':
				$value='10050';
				break;
			case '17':
				$value='10051';
				break;
			case '18':
				$value='10052';
				break;	
			case '19':
				$value='10053';
				break;
			case '20':
				$value='10054';
				break;



			case '21A':
				$value='10057';
				break;
			case '21B':
				$value='10058';
				break;
			case '21C':
				$value='10059';
				break;

			case '22A':
				$value='10060';
				break;
			case '22B':
				$value='10061';
				break;
			case '22C':
				$value='10062';
				break;	



			case '23A':
				$value='10063';
				break;
			case '23B':
				$value='10064';
				break;
			case '23C':
				$value='10065';
				break;

			default:
				# code...
				break;
		}
		$data['Ffloorid']=$value;
		$data['Fremark']=$str2;
		$users->where(array('id'=>$id))->save($data);
		if($res){
			echo  1;
		}else{
			echo  0;
		}
	}
}
		


	
	/**
	 * 商城设置
	 */
	public function setting(){
		$setting = M('Product_setting');
		$obj = $setting->where(array('token' => session('token')))->find();
		if (IS_POST) {
			if ($obj) {
				$t = $setting->where(array('token' => session('token')))->save($_POST);
				if ($t) {
					$this->success('修改成功',U('Store/index',array('token' => session('token'))));
				} else {
					$this->error('操作失败');
				}
			} else {
				$pid = $setting->add($_POST);
				if ($pid) {
					$this->success('增加成功',U('Store/index',array('token' => session('token'))));
				} else {
					$this->error('操作失败');
				}
			}
		} else {
			$this->assign('setting', $obj);
			$this->display();	
		}
	}

	/*查询类别*/
	 public function selectProduct_cat($token){
		$product_cat = M('product_cat');
                $where = array('token' => $token);
                $cat_list = $product_cat->field('id,name')->where($where)->select();
               return $cat_list;
	}

   /**
     * 导出数据为excel表格
     *@param $data    一个二维数组,结构如同从数据库查出来的数组
     *@param $title   excel的第一行标题,一个数组,如果为空则没有标题
     *@param $filename 下载的文件名
     *@examlpe
    *$stu = M ('User');
    *$arr = $stu -> select();
    *exportexcel($arr,array('id','账户','密码','昵称'),'文件名!');
     */
public function exportexcel($data=array(),$title=array(),$filename='report'){   
	header("Pragma: public");
    header("Expires: 0");
    header("Cache-Control:must-revalidate, post-check=0, pre-check=0");
    header("Content-type:application/force-download");
    header("Content-type:application/vnd.ms-excel");
    header("Content-type:application/octet-stream");    
    //header("Content-type:application/vnd.openxxmlformats-officedocument.spreadsheetml.sheet");
    header("Accept-Ranges:bytes");    
    header("Content-Disposition:attachment;filename=".$filename.".xls");
    header("Content-Transfer-Encoding:binary");
    ob_clean();
    //导出xls 开始    
    if (!empty($title)){
        foreach ($title as $k => $v) {
            $title[$k]=iconv("UTF-8", "GB2312",$v);
        }
        $title= implode("\t", $title);
        echo "$title\n";
    }
    if (!empty($data)){
        foreach($data as $key=>$val){
            foreach ($val as $ck => $cv) {
                $data[$key][$ck]=iconv("UTF-8", "GB2312", $cv);
            }
            $data[$key]=implode("\t", $data[$key]);

        }
        echo implode("\n",$data);
    }
}
//用phpexcel导出表格
/**
 * @param  array   $list 		要导出的数据,二位数组
 * @param  string  $filename 	导出的Excel表的文件名,数组
 * @param  array   $indexKey 	$list数组中与Excel表格表头
 * @param  array   $startRow	第一条数据在Excel表格中起始行
 * @param  [bool]  $excel2007   是否生成Excel2007(.xlsx)以上兼容的数据表
 */
public function excelExport($list,$filename,$indexKey,$startRow=1,$excel2007=false){
    if(empty($filename)) $filename = 'report'.time();
	if(!is_array($indexKey)) return false;
	vendor('Excel.PHPExcel');
	$header_arr = array('A','B','C','D','E','F','G','H','I','J','K','L','M', 'N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
	//初始化PHPExcel()
	$objPHPExcel = new \PHPExcel();
	
	//设置保存版本格式
	if($excel2007){
		$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
		$filename = $filename.'.xlsx';
	}else{
		$objWriter = new PHPExcel_Writer_Excel5($objPHPExcel);
		$filename = $filename.'.xls';
	}	
	//写数据到表格里面去
	$objActSheet = $objPHPExcel->getActiveSheet();		
	
	//内容
	foreach ($list as $row) {
		foreach ($indexKey as $key => $value){
			//这里是设置单元格的内容
			if($startRow<2){$objActSheet->setCellValue($header_arr[$key].$startRow,$value);
			}else{
			$objActSheet->setCellValue($header_arr[$key].$startRow,$row[$value]);
		    }
		}
		$startRow++;
	}
	
	// 下载这个表格，在浏览器输出
	header("Pragma: public");
	header("Expires: 0");
	header("Cache-Control:must-revalidate, post-check=0, pre-check=0");
	header("Content-Type:application/force-download");
	header("Content-Type:application/vnd.ms-execl");
	header("Content-Type:application/octet-stream");
	header("Content-Type:application/download");;
	header('Content-Disposition:attachment;filename='.$filename.'');
	header("Content-Transfer-Encoding:binary");
	$objWriter->save('php://output');
}
}
?>
