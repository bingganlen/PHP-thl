<?php 
class WmemberAction extends UserAction{
    public function _initialize() {
        parent::_initialize();
    }

    public function index(){
        $db=M('Wa_users');
          $ord=M();
        $token=$_GET['token'];
        if(IS_POST){
            //搜索
       
          $where['Ftoken']=$token;
          if(!empty($_POST['Fusername'])){
           $where['Fusername']=$_POST['Fusername'];
          }
          
          if(!empty($_POST['Faddress'])){
            $where['Faddress']=array('like','%'.$_POST['Faddress'].'%');
          }
            $count= $db->where($where)->count();  
            $Page = new Page($count,10);     
            $res=$db->field('Fid,Fusername,Faddress,Fcreatetime,Frecom')->where($where)->limit($Page->firstRow.','.$Page->listRows)->order('Fcreatetime desc')->select();

             foreach($res as $k=>$v){
                //$ordindos=$ord->field('sum(Ftotal) as total')->where(array('Fusers'=>$v['Fusername'],'Ftotal'=>$token,'Ftype'=>0,'Fstatus'=>3))->find();
                //$sql="SELECT sum(Ftotal) as Ftotal from tp_wa_orders where Fusers='".$v['Fusername']."' and Fstatus=3 and Ftype=0 and Ftoken='".$token."'";
               // $sql="SELECT sum(Fmoney) as Ftotal from tp_wa_prolog where Fuser='".$v['Fusername']."' and Fstatus=0 and Ftoken='".$token."'";
              //$ordindos=$ord->query($sql);
              //$res[$k]['total']=!empty($ordindos[0]['Ftotal'])?$ordindos[0]['Ftotal']:0;
             $money1=M('Wa_prolog')->field('SUM(Fmoney) as Fmoney,SUM(Ftnum) as Ftnum')->where(array('Ftoken'=>$token,'Fstatus'=>1,'Fuser'=>$v['Fusername']))->select();    

             $money2=M('Wa_prolog')->field('SUM(Fmoney) as Fmoney,SUM(Ftnum) as Ftnum')->where(array('Ftoken'=>$token,'Fstatus'=>0,'Fuser'=>$v['Fusername']))->select();
              if(($money1[0]['Fmoney']-$money2[0]['Fmoney'])<=0){
                  $moneyw=0;
              }else{
                $moneyw=$money1[0]['Fmoney']-$money2[0]['Fmoney'];
              }

              $res[$k]['total']=!empty($moneyw)?$moneyw:0;
             
            }

        }else{
            $count= $db->where(array('Ftoken'=>$token))->count();   
            $Page = new Page($count,10);    
            $res=$db->field('Fid,Fusername,Faddress,Fcreatetime,Frecom')->where(array('Ftoken'=>$token))->limit($Page->firstRow.','.$Page->listRows)->order('Fcreatetime desc')->select();
         
            foreach($res as $k=>$v){
                //$ordindos=$ord->field('sum(Ftotal) as total')->where(array('Fusers'=>$v['Fusername'],'Ftotal'=>$token,'Ftype'=>0,'Fstatus'=>3))->find();
              //   $sql="SELECT sum(Fmoney) as Ftotal from tp_wa_prolog where Fuser='".$v['Fusername']."' and Fstatus=0 and Ftoken='".$token."'";

              // $ordindos=$ord->query($sql);
  
              // $res[$k]['total']=!empty($ordindos[0]['Ftotal'])?$ordindos[0]['Ftotal']:0;
                  $money1=M('Wa_prolog')->field('SUM(Fmoney) as Fmoney,SUM(Ftnum) as Ftnum')->where(array('Ftoken'=>$token,'Fstatus'=>1,'Fuser'=>$v['Fusername']))->select();    

             $money2=M('Wa_prolog')->field('SUM(Fmoney) as Fmoney,SUM(Ftnum) as Ftnum')->where(array('Ftoken'=>$token,'Fstatus'=>0,'Fuser'=>$v['Fusername']))->select();
              if(($money1[0]['Fmoney']-$money2[0]['Fmoney'])<=0){
                  $moneyw=0;
              }else{
                $moneyw=$money1[0]['Fmoney']-$money2[0]['Fmoney'];
              }

              $res[$k]['total']=!empty($moneyw)?$moneyw:0;
             
            }
            
           
        }
// var_dump($res);
        $show = $Page->show();
        //$res=$this->array_sort($res,'total');
        $this->assign('list',$res);
        $this->assign('page',$show);
        $this->display();
    }


public function userinfo(){

        $db=M('Wa_users');
        $Fid=$_GET['Fid'];
        $token=$_GET['token'];
        $info=$db->where(array('Fid'=>$Fid,'Ftoken'=>$token))->find();
    
       $Faddressinfos=explode('-', $info['Faddress']);
       $Faddressinfo=$Faddressinfos[1];

       $this->assign('Faddressinfo',$Faddressinfo);

        //欠费数量
       $ord=M();
   //$sql="SELECT sum(Ftotal) as count FROM tp_wa_orders WHERE Fstatus=3 and Ftype=0 and Fusers='".$info['Fusername']."'";
    //$money=$ord->query($sql);
   $money1=M('Wa_prolog')->field('SUM(Fmoney) as Fmoney,SUM(Ftnum) as Ftnum')->where(array('Ftoken'=>$token,'Fstatus'=>1,'Fuser'=>$info['Fusername']))->select();    

   $money2=M('Wa_prolog')->field('SUM(Fmoney) as Fmoney,SUM(Ftnum) as Ftnum')->where(array('Ftoken'=>$token,'Fstatus'=>0,'Fuser'=>$info['Fusername']))->select();
    if(($money1[0]['Fmoney']-$money2[0]['Fmoney'])<=0){
        $moneyw=0;
    }else{
      $moneyw=$money1[0]['Fmoney']-$money2[0]['Fmoney'];
    }

  //宿舍楼信息
   $dorm=M('Wa_dorm');
   $dorms=$dorm->where(array('Ftoken'=>$token))->select();
 
   $this->assign('dorms',$dorms);
   $this->assign('owcount',$moneyw);
        $this->assign('info',$info);

        $this->display();
    }

    public function userinfodo(){

        $db=M('Wa_users');
        $Fid=$_POST['id'];
        $Fusername=$_POST['Fusername'];
        $Faddressinfo=$_POST['Faddressinfo'];
        $Fownnum=$_POST['Fownnum'];
        $Fownfc=$_POST['Fownfc'];
        $Frecom=$_POST['Frecom'];
        $Fewm_id=$_POST['Fewm_id'];
        $floorid=$_POST['floorid'];

        $dorm=M('Wa_dorm');
        $Fnames=$dorm->field('Fname')->where(array('Fid'=>$floorid))->find();
        $Faddress=$Fnames['Fname'].'-'.$Faddressinfo;
        $data=array('Fid'=>$Fid,'Fusername'=>$Fusername,'Faddress'=>$Faddress,'Fownnum'=>$Fownnum,'Fownfc'=>$Fownfc,'Frecom'=>$Frecom,'Fewm_id'=>$Fewm_id,'Ffloorid'=> $floorid,'Fupdatetime'=>time());
        $res=$db->where(array('Fid'=>$Fid))->save($data);
       
         if($res){
            $this->success('更新成功');
         }else{
            $this->error('失败');
         }
      
    }

    //清空欠款
    public function clearmoney(){
        $db=M('Wa_orders');
        $user=M('Wa_users');
        $Fid=$_GET['Fid'];
        $token=$_GET['token'];
        $Fu=$user->field('Fusername')->where(array('Fid'=>$Fid,'Ftoken'=>$token))->find();
        $Fusers=$Fu['Fusername'];
        $res=$db->where(array('Fusers'=>$Fusers,'Ftoken'=>$token))->save(array('Ftype'=>1,'Fpaytype'=>1));
        if($res){
            $this->success('更新成功');
        }else{
            $this->error('更新成功'); 
        }
        //$this->display();
    }

  //最新注册会员的统计信息  
  public function countmember(){

     $db=M('Wa_dorm');
     $user=M('Wa_users');
    
     $floor=$db->where(array('Ftoken'=>$token))->select();
    
     if(!empty($_GET['token'])){
        $token=$_GET['token'];
     }else{
        $token= $_SESSION['token'];
     }
     $this->assign('floor',$floor);
      if(IS_POST){

         // $starttime=!empty($_POST['starttime'])? strtotime($_POST['starttime']) :0;
         // $endtime=!empty($_POST['endtime']) ?strtotime($_POST['endtime']):time();
          
         
           if($_POST['floor']!=-1){
        $Floorid=$_POST['floor'];

         if(($Floorid!=-1) && !empty($Floorid)){
             $where2=' AND users.Ffloorid='.$Floorid;
        }
        
     
    }
       $Fwnum=!empty($_POST['Fwnum'])?$_POST['Fwnum']:0;
      }else{

        // $starttime=!empty($_GET['starttime'])? strtotime($_GET['starttime']) :0;
        //  $endtime=!empty($_GET['endtime']) ?strtotime($_GET['endtime']):time();
        
         if($_GET['floor']!=-1){
         $Floorid=$_GET['floor'];

         if(($Floorid!=-1) && !empty($Floorid)){
             $where2=' AND users.Ffloorid='.$Floorid;
        }

        

       
    }

     $Fwnum=!empty($_GET['Fwnum'])?$_GET['Fwnum']:0;
      }
      
        // $endtime=($endtime+24*3600);

        // $where['Flasttime']=array('between',array($starttime,$endtime));
    
        if(($Floorid!=-1) && !empty($Floorid)){
            $where['Ffloorid']=$Floorid;
        }
     
         
         $where['Ftoken']=$token;
        if($Fwnum!=0){
           $where['Fwnum']=$Fwnum;
        }
	if($_POST['Ftel']){
                $where['Fusername']=$_POST['Ftel'];
        }


          // $sql2="SELECT count(users.Fusername) from tp_wa_users as users LEFT JOIN (select tp_wa_orders.Fid, tp_wa_orders.Ftotal, tp_wa_ordergoods.Fnum, tp_wa_orders.Ftoken, tp_wa_orders.Fusers, tp_wa_orders.Fordertime from tp_wa_orders left join tp_wa_ordergoods on tp_wa_ordergoods.Foid = tp_wa_orders.Fid ORDER BY tp_wa_orders.Fordertime DESC) as orders on users.Fusername=orders.Fusers WHERE users.Ftoken='".$token."' and orders.Ftoken='".$token."' AND users.Fcreatetime>'".$starttime."' AND users.Fcreatetime <'".$endtime."'".$where2." GROUP  BY users.Fid ";
           // $count= count($db->query($sql2));   

          $count=$user->where($where)->count();
        
        $Page = new Page($count,10);  
          // $sql="SELECT users.Fusername ,users.Faddress,count(orders.Fid) as ordercount, sum(orders.Fnum) as countts, sum(orders.Ftotal) as Ftotal, FROM_UNIXTIME(orders.Fordertime) as lasttime from tp_wa_users as users LEFT JOIN (select tp_wa_orders.Fid, tp_wa_orders.Ftotal, tp_wa_ordergoods.Fnum, tp_wa_orders.Ftoken, tp_wa_orders.Fusers, tp_wa_orders.Fordertime from tp_wa_orders left join tp_wa_ordergoods on tp_wa_ordergoods.Foid = tp_wa_orders.Fid ORDER BY tp_wa_orders.Fordertime DESC) as orders on users.Fusername=orders.Fusers WHERE users.Ftoken='".$token."' and orders.Ftoken='".$token."' AND users.Fcreatetime>'".$starttime."' AND users.Fcreatetime <'".$endtime."'".$where2." GROUP  BY users.Fid limit ".$Page->firstRow.", ".$Page->listRows;
        
         // $list=$db->query($sql);
      
         $list=$user->where($where)->limit($Page->firstRow.','.$Page->listRows)->order('Fcreatetime desc')->select();
    
       $show = $Page->show();
       $this->assign('page',$show); 
       $this->assign('starttime',$_POST['starttime']);
       $this->assign('endtime',$_POST['endtime']);
       $this->assign('floor',$floor);

    
        $this->assign('f',$Floorid);
       $this->assign('list',$list);

  
       $this->display();
  }

  //导出会员excel

public function excel(){
   //导出excel
    $where="";
    $wheredata=array();
    // if(!empty($_GET['date1'])){
    //     $date1=strtotime($_GET['date1']);
    // }else{
    //     $date1=0; 
    // }

    //  if(!empty($_GET['date2'])){
    //     $date2=strtotime($_GET['date2']);
    // }else{
    //     $date2=time(); 
    // }
    // $date2=($date2+3600*24);
    // $wheredata['Flasttime']=array('between',array($date1,$date2));
    if(($_GET['floor']!=-1) && (!empty($_GET['floor']))){
         $Floorid=$_GET['floor'];
        $where=' AND users.Ffloorid='.$Floorid;
         $wheredata['Ffloorid']=$_GET['floor'];
    }
   
    $token=$_GET['token'];
    $wheredata['Ftoken']=$token;
    //$wheredata['Fordernum']=array('gt',0);

    $wxname=M('Wxuser')->field('wxname')->where(array('token'=>$token))->find();
    $wxname=$wxname['wxname'];
    $db=M();
    if(!empty($_GET['excel'])){
    header("Content-type:application/vnd.ms-excel");

   header("Content-Disposition:attachment;filename=$wxname.xls");

    $string = "用户手机"."\t";

    $string .= "用户地址" . "\t";

   

    $string .= "下单桶数" . "\t";
    $string .= "下单金额" . "\t";
    $string .= "最后一次时间下单" . "\t";
    $string .= "注册时间\t";
    $string .= "\n";       

    
     $db2=M('Wa_users');

     $list=$db2->where($wheredata)->select();

        $count=count($list);
      

        for($j=0;$j<$count;$j++){
           $string .= $list[$j]['Fusername']."\t";
            $string .= trim($list[$j]['Faddress'])."\t";
            
            $string .= $list[$j]['Fwnum']."\t";
            $string .= $list[$j]['Fallmoney']."\t";
            $string .= date('Y-m-d H:i:s',$list[$j]['Flasttime'])."\t";
	    $string .= date('Y-m-d H:i:s',$list[$j]['Fcreatetime'])."\t";
             $string .= "\n";
         }
       

    echo iconv("UTF-8","GB2312//TRANSLIT",$string);
     
 }
}

//按某一种条件排序
public function sort_desc(){
      $token=$_GET['token'];

     // $starttime=!empty($_GET['date1'])? strtotime($_GET['date1']) :0;
     // $endtime=!empty($_GET['date2']) ?strtotime($_GET['date2']):time();

       $floor=M('Wa_dorm')->where(array('Ftoken'=>$token))->select();
   if(!empty($_GET['lasttime'])){
       $sort='Flasttime '.$_GET['sort'];
   }

 if(!empty($_GET['fordernum'])){
       $sort='Fordernum '.$_GET['sort'];
   }

   // $endtime=($endtime+24*3600);
   // $where['Flasttime']=array('between',array($starttime,$endtime));

   if((!empty($_GET['floor']))&& ($_GET['floor']!=-1)){
       $where['Ffloorid']=$_GET['floor'];
   }
   $token=$_GET['token'];
   $where['Ftoken']=$token;
   $db=M('Wa_users');
   $count=$db->where($where)->count();
    $Page = new Page($count,10);  
   $list=$db->where($where)->limit($Page->firstRow.','.$Page->listRows)->order($sort)->select();
  
    // $this->assign('starttime',$_GET['date1']);
    // $this->assign('endtime',$_GET['date2']);
    $show = $Page->show();
    $this->assign('page',$show); 
    $this->assign('list',$list);
    $this->assign('floor',$floor);
     $this->assign('f',$_GET['floor']);
    $this->display('countmember');   
   

}

public function array_sort($array,$keys,$type='desc'){
    if(!is_array($array)||empty($array)||!in_array(strtolower($type),array('asc','desc'))) return '';
    $keysvalue=array();
    foreach($array as $key=>$val){
        $val[$keys]=str_replace('-','',$val[$keys]);
        $val[$keys]=str_replace(' ','',$val[$keys]);
        $val[$keys]=str_replace(':','',$val[$keys]);
        $keysvalue[] =$val[$keys];
    }
    asort($keysvalue);//key值排序
    reset($keysvalue);//指针重新指向数组第一个
    foreach($keysvalue as $key=>$vals){
        $keysort[]=$key;
    }
    $keysvalue=array();
    $count=count($keysort);
    if(strtolower($type)!='asc'){
        for($i=$count-1;$i>=0;$i--){
            $keysvalue[]=$array[$keysort[$i]];
        }
    }else{
        for($i=0;$i<$count;$i++){
            $keysvalue[]=$array[$keysort[$i]];
        }
    }
    return $keysvalue;
}


public function orderinfo(){
     $userid=$_GET['userid'];
     $token=$_GET['token'];
     $Fusers=$_GET['suername'];
    $db=M('Wa_orders');
    $count=$db->where(array('Fusers'=>$Fusers,'Ftoken'=>$token,'Fstatus'=>3))->count();
    $Page = new Page($count,15);  
    $res= $db->where(array('Fusers'=>$Fusers,'Ftoken'=>$token,'Fstatus'=>3))->limit($Page->firstRow.','.$Page->listRows)->select();
    $this->assign('list',$res);
    $show = $Page->show();
    $this->assign('page',$show); 
    $this->display();
    
}

}


?>
