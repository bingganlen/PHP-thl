<?php
class WlistAction extends UserAction{
    public function _initialize() {
        parent::_initialize();
    }

   // 商品列表
    public function index(){

        // 开始时间当天0:0:1
        if(!empty($this->_get('st')))
        {
            $st=strtotime($this->_get('st'))+1;
        }else{
            $st=strtotime(date("Y-m-d",time()))-6*24*3600;
        }

        // 结束时间当天23:59：59
         if(!empty($this->_get('e')))
        {
            $e=strtotime($this->_get('e'))+86399;
        }else{
            // $e=strtotime(date('Y-m-d',time()));
            $e=time();
        }
        $token=session('token');
        $this->assign('start',$st);
        $this->assign('last',$e);
        //半月  ，最近一个月
        //$this->assign('zt',date("Y-m-d",strtotime("-1 day",time())));
        //$this->assign('zw',date("Y-m-d",strtotime("-15 day",time())));
        //$this->assign('zm',date("Y-m-d",strtotime("-30 day",time())));
        //本周，本月，本季
        $w=date('w')?date('w'):7;
        $season=ceil((date('n'))/3);
        $this->assign('bw',date("Y-m-d",mktime(0,0,0,date('m'),date('d')-$w+1,date('Y'))));
        $this->assign('bm',date("Y-m-d",mktime(0,0,0,date('m'),1,date('Y'))));
        $this->assign('bq',date("Y-m-d",mktime(0,0,0,$season*3-3+1,1,date('Y'))));
        $this->assign('now',date('Y-m-d',time()));
//标签总数：
        $total=A('User/Index')->seltotal($token,$st,$e);
        $this->assign('total',$total);
        $num1=A('User/Index')->selnum($token,$st,$e,0);
        $this->assign('upnum',$num1);
        $num2=A('User/Index')->selnum($token,$st,$e,1);
        $this->assign('ovnum',$num2);
//报警列表
        //$sql="SELECT r.labelId, r.labelType,r.uptime,w.Fname FROM tp_recordset as r LEFT JOIN tp_wa_workers as w on r.username=w.Fworkernum WHERE w.Ftoken='".$token."' AND r.uptime>='".$st."' AND r.uptime<='".$e."' AND r.isover>0 ORDER BY r.uptime";
        //$res=M()->query($sql);
        //dump($res);
        //$this->assign('res',$res);
        //标签类型和数量
        //$arr=$this->sellabel($token,$st,$e);
        //foreach ($arr as $key => $value) {
            //$arres[]=$value['labelType'];
        //}
        //$this->assign('reslb',array_count_values($arres));
        //dump(array_count_values($arres));
//商品统计     
    // $sql3="SELECT SUM(goods.Fnum)as Fnum ,goods.Fgoodsname FROM tp_wa_orders as orders left JOIN tp_wa_ordergoods as goods on orders.Fid=goods.Foid WHERE orders.Ftoken='".$token."'  AND orders.Fordertime>='".$st."' AND orders.Fordertime<='".$e."' AND orders.Fstatus='3' GROUP BY goods.Fgoodsid";
    // $res3=M()->query($sql3);
    // $this->assign('res3',$res3);
    $this->display();
    }
//ajax返回图标数据
    public function chartdata(){
        $start=strtotime($this->_post('start'));
        $end=strtotime($this->_post('end'));
        $theme=$this->_post('theme');
        $token=$this->_get('token');
        $days=array();
        $ydata=array();
        //x轴时间数组和y轴数据
        for($i=$start;$i<=$end;$i+=86400){
            $days[]=date("Y-m-d",$i);
            $iend=$i+86399;
            if($theme=='warning'){
            $ydata[]=A('User/Index')->selnum($token,$i,$iend,1);
            }elseif($theme=='upload'){
            $ydata[]=A('User/Index')->selnum($token,$i,$iend,0);
            }else{
            $ydata[]=A('User/Index')->seltotal($token,$i,$iend);
            }          
        } 
        $this->ajaxReturn(array('xarr'=>$days,'yarr'=>$ydata));       
    }
// 查所有标签数量
public function sellabel($token,$start,$end){
    $user=M('wa_workers')->field('Fworkernum,Fphone')->where(array('Ftoken'=>$token))->select();
    if($start!=='' && $end!==''){
        //以上传时间作为筛选时间来统计标签
        $where['uptime']=array('between',array($start,$end));
    }   
    $array=array();
    foreach ($user as $key => $value) {
        $where['username']=$value['Fworkernum'];
        $list=M('recordset')->where($where)->distinct(true)->field('labelId,labelType')->select();        
        // foreach ($list as $k => $v) {
        //     $array[]=$v['labelType'];
        // }
    }
    return $list;//返回标签类型的一维数组，不去重复
}

// 按照日期统计注册数





// 订单按照时间统计




//送水工
// $sql5="SELECT orders.Fphone,SUM(goods.Fnum) as Fnum FROM tp_wa_orders as orders left JOIN tp_wa_ordergoods as goods on orders.Fid=goods.Foid WHERE orders.Ftoken='".$token."' AND orders.Fphone !='' GROUP BY orders.Fworkerid "




// 水品统计
// $sql6="SELECT SUM(goods.Fnum),goods.Fgoodsname as Fnum FROM tp_wa_orders as orders left JOIN tp_wa_ordergoods as goods on orders.Fid=goods.Foid WHERE orders.Ftoken='".$token."' GROUP BY goods.Fgoodsid"












}
?>
