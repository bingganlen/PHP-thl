<?php 
class WorderAction extends UserAction{
    public function _initialize() {
        parent::_initialize();
    }

    public function index(){
        $db=M('Wa_users');
        $Page = new Page($count,10);
        $token=$_GET['token'];
        if(!empty($_POST['Fusername'])){
            $where=array('Fusername'=>$_POST['Fusername'],'token'=>$token);
            $count= $db->where($where)->count();       
            $res=$db->field('Fid,Fusername,Faddress,Fcreatetime')->where($where)->limit($Page->firstRow.','.$Page->listRows)->select();
        }else{
            $count= $db->where(array('token'=>$token))->count();       
            $res=$db->field('Fid,Fusername,Faddress,Fcreatetime')->where(array('token'=>$token))->limit($Page->firstRow.','.$Page->listRows)->select();
        }

        $this->assign('list',$res);
        $this->assign('page',$show);
        $this->display();
    }

    public function userinfo(){

        $db=M('Wa_users');
        $Fid=$_GET['Fid'];
        $token=$_GET['token'];
        $info=$db->where(array('Fid'=>$Fid,'token'=>$token))->find();
     
        $this->assign('info',$info);
        $this->display();
    }

}

?>