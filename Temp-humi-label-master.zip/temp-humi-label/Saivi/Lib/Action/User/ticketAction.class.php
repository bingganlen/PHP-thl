<?php
class ticketAction extends UserAction{

    public function _initialize() {
        parent::_initialize();

    }

    public function set(){
        $res = M('product')->where(array('token'=>$_GET["token"]))->select();
        $this->assign('product', $res);

        $res = M('wa_mode')->field("tp_wa_mode.*, tp_product.name gname")->join('left join tp_product on tp_product.id = tp_wa_mode.Fpid')->where(array('tp_wa_mode.Ftoken'=>$_GET["token"]))->select();
        $this->assign('mode', $res);

        $this->display();
    }

    public function addmode(){
        if(""==$_POST["modename"]||""==$_POST["modeprice"]||
            ""==$_POST["pid"]||""==$_POST["num"]){
            $this->error('请填入完整的信息');
        }
        $data = array();
        $data["Fname"] = $_POST["modename"];
        $data["Fprice"] = $_POST["modeprice"];
        $data["Fpid"] = $_POST["pid"];
        $data["Ftoken"] = $_GET["token"];
        $data["Fnum"] = $_POST["num"];
        $data["Fcreatetime"] = time();

        $db = M('wa_mode');
        $db->add($data);

        header('Location: '.U('set', $_GET));
    }


    public function delmode(){
        $where = array('Ftoken'=>$_GET["token"], 'Fid'=>$_GET["id"]);

        $db = M('wa_mode');
        $db->where($where)->delete();

        // echo $db->getlastsql();
        header('Location: '.U('set', array('token'=>$_GET["token"])));
    }

    public function info(){
        $this->display();
    }

    public function getticket(){
        $id = $_GET["id"];
        $token = $_GET["token"];

        $where = array('Fuser'=>$id, 'Ftoken'=>$token);
        $db = M('wa_ticket');
        $ticket = $db->field('tp_wa_ticket.*, tp_product.name gname')->where($where)->join('left join tp_product on tp_product.id = tp_wa_ticket.Fgoodsid')->select();

        $this->assign('list', $ticket);
        $this->display();
    }
}
?>