<?php
/**
 *商城首页幻灯片回复
**/
class StoreflashAction extends UserAction{
	public $tip;
	public function _initialize(){
		parent::_initialize();
		if (isset($_GET['tip'])){
			$this->tip=$this->_get('tip','intval');
		}else {
			$this->tip=1;
		}
		
	}
	public function index(){
		$db=D('Storeflash');

		//tip区分是幻灯片还是背景图
	

		$where['uid']=session('uid');
		$where['token']=session('token');
	
		$count=$db->where($where)->count();
		$page=new Page($count,25);
		$info=$db->where($where)->order('sort desc,id DESC')->limit($page->firstRow.','.$page->listRows)->select();
		$this->assign('page',$page->show());
		$this->assign('info',$info);

		$this->display();
	}
	public function add(){

		$this->display();
	}
	public function edit(){
		$where['id']=$this->_get('id','intval');
		$where['uid']=session('uid');
		$res=D('Storeflash')->where($where)->find();
		$this->assign('info',$res);


		$this->assign('id',$this->_get('id','intval'));
		$this->display();
	}
	public function del(){
	
		$where['id']=$this->_get('id','intval');
		$where['token']=$this->token;
		if(D(MODULE_NAME)->where($where)->delete()){
			$this->redirect(U(MODULE_NAME.'/index'));
			//$this->success('操作成功',U(MODULE_NAME.'/index',array('tip'=>$tip)));
		}else{
			$this->error('操作失败',U(MODULE_NAME.'/index'));
		}
	}
	public function insert(){
		$flash=D('Storeflash');
		$arr=array();
		$arr['token']=$this->token;
		$arr['img']=$this->_post('img');
		//$arr['url']=$this->_post('url');
		$arr['url']=$_POST['url'];
		$arr['info']=$this->_post('info');
		$arr['sort']=$this->_post('sort');
		$arr['attr']=$this->_post('attr');

		
		$flash->add($arr);
		$this->redirect(U(MODULE_NAME.'/index'));
		//$this->success('操作成功',U(MODULE_NAME.'/index',array('tip'=>$this->tip)));

		//$this->all_insert('Flash');
	}
	public function upsave(){


		$flash=D('Storeflash');
		$id=$this->_get('id','intval');

		$arr=array();
		$arr['img']=$this->_post('img');
		//$arr['url']=$this->_post('url');
	    $arr['url']=$_POST['url'];
		$arr['info']=$this->_post('info');
		$arr['sort']=$this->_post('sort');
		$arr['attr']=$this->_post('attr');
		
		$flash->where(array('id'=>$id))->save($arr);
		$this->redirect(U(MODULE_NAME.'/index'));
		//$this->success('操作成功',U(MODULE_NAME.'/index',array('tip'=>$this->tip)));
	}

}
?>