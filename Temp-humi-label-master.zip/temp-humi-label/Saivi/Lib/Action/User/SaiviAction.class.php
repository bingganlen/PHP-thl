<?php
class saiviAction extends UserAction{
	public function index(){
	
		$this->display();
    }
}
?>