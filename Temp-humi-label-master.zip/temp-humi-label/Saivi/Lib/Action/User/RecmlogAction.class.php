<?php 
class RecmlogAction extends UserAction{

    public function _initialize() {
        parent::_initialize();
    }

    public function index(){
       $token=$_GET['token'];
       $db=M('Wa_recom');
       

 
       if($_POST){
        $Fphone=$_POST['Fphone'];
        $where=array('Ftoken'=>$token,'Fphone'=>$Fphone);
       }else{
        $where=array('Ftoken'=>$token);
       }
       $count= $db->where($where)->count();
       
       $Page = new Page($count,10);
       $res=$db->where($where)->limit($Page->firstRow.','.$Page->listRows)->order('Fcreate_time desc')->select();
       $show= $Page->show();
       $this->assign('page',$show);
       $this->assign('list',$res);
       $this->display();
    }

    public function recminfo(){
        $db2=M('Wa_recomlog');
        $Fid=$_GET['Fid'];
        $count= $db2->where(array('Fworker_num'=>$Fid))->count();
       
        $Page = new Page($count,10);
        $res=$db2->where(array('Fworker_num'=>$Fid))->limit($Page->firstRow.','.$Page->listRows)->order('Fcreatetime desc')->select();
        
        $show= $Page->show();
        $this->assign('page',$show);
        $this->assign('list',$res);
    
        $this->display();
    }

    //更改状态
    public function statuschange(){
        $Fid=$_GET['Fid'];
        $db=M('Wa_recomlog');
        $res=$db->where(array('Fid'=>$Fid))->save(array('Fstatus'=>1));
        if($res){
            $this->success('更新成功');
        }else{
            $this->error('更新失败');
        }
}

//批量结账
   public function achange(){
      $token=$_GET['token'];
      $Fid=$_GET['Fid'];
       $db=M('Wa_recomlog');
      $res=$db->where(array('Fworker_num'=>$Fid))->save(array('Fstatus'=>1));
      // echo $db->getlastSql();
      if($res){
          $this->success('更新成功'); 
      }else{
          $this->error('更新失败');
      }
   }
}


?>