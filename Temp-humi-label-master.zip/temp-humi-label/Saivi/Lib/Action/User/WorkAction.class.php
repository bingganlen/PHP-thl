<?php
class WorkAction extends UserAction{
    public $token;

    public function _initialize() {
        parent::_initialize();
        // $this->canUseFunction('shop');
        // $this->assign('userinfo',session('userinfo'));
        // $this->assign('isDining', 0);
    }
    
    /**
     * 分类列表
     */
    public function index() {
        $data = M('Wa_workers');
        $where = array('Ftoken' => session('token'));

        $count      = $data->where($where)->count();
        $Page       = new Page($count,10);
        $show       = $Page->show();
        $list = $data->where($where)->order('Fid')->limit($Page->firstRow.','.$Page->listRows)->select();
 
        $this->assign('page',$show);        
        $this->assign('list',$list);
        $this->display();       
    }

    //查看用户推荐数
    public function catuser(){
        // echo "123123123";
        $id = $_GET["fid"];
        $db = M('wa_users');
        $c = $db->where(array('Frecom'=>$id))->count();
        $this->assign('alltj', $c);
        $c = M()->query('select count(*) c from tp_wa_users where Frecom = '.$id.' and month(FROM_UNIXTIME(Fcreatetime)) = month(now())');
        $this->assign('montjl', $c[0]['c']);
        $c = M()->query('select count(*) c from tp_wa_users where Frecom = '.$id.' and month(FROM_UNIXTIME(Fcreatetime)) = month(now())-1');
        $this->assign('nmontjl', $c[0]['c']);

        $db = M('wa_workers');
        $res = $db->where(array('Fworkernum'=>$id))->find();
        $Fid = $res["Fid"];
        $db = M('wa_workerlog');
        $res = $db->where(array('Fid'=>$Fid))->sum('Freward');
        $this->assign('alljl', $res);
        $db = M();
        $res = $db->query('select sum(Freward) c from tp_wa_workerlog where Fstyle = 0 and Fid = "'.$Fid.'" and month(FROM_UNIXTIME(Fcreatetime)) = month(now())');
        $this->assign('monthjl', $res[0]['c']);
        $res = $db->query('select sum(Freward) c from tp_wa_workerlog where Fstyle = 0 and Fid = "'.$Fid.'" and month(FROM_UNIXTIME(Fcreatetime)) = month(now())-1');
        $this->assign('nmonthjl', $res[0]['c']);
        // echo $db->getlastsql();
        $this->display();
    }

    /**
     * 添加
     */
    public function add(){
        $this->assign('token',session('token'));
        $this->display('add');
    }
    
    /**
     * 添加处理
     */
    public function adddo(){
        if(IS_POST){
           $data['Fname']= $_POST['Fname'];

             $result=M('wxuser')->where(array('token'=>session('token'))) ->find(); 
             $num =$result['id'];
             $bit = 4;//产生4位数的数字编号
             $num_len = strlen($num);
             $zero = '';
             for($i=$num_len; $i<$bit; $i++){
              $zero .= "0";
             }
             $real_num = $zero.$num.rand(10,100);


           $data['Fworkernum']= $real_num;
           $data['Fphone']= $_POST['Fphone'];
           $data['Ftoken']= session('token');
           $data['Fpwd']=md5($_POST['Fpwd']);
           // $data['Fshenfen']=$_POST['shenfen'];
           $data['Flasttime']=time();
           $data['Fcreatetime']=time();
           $id=M('Wa_workers')->data($data)->add();
            if($id){
                // $this->success("添加成功");
                 $this->redirect('Work/index',array('token'=>session('token')));

            }else{
                $this->redirect('Work/index',array('token'=>session('token')));
            }
        }
    }


    /**
     * 信息修改
     */
    public function edit(){
        $token=session('token');
        $Fid = $this->_get('Fid'); 
        $res = M('Wa_workers')->where(array('Fid'=>$Fid,'token'=>$token))->find();
       

        if (IS_POST) {
           $data['Fname']= $_POST['Fname'];
           // $data['Fworkernum']= $_POST['Fworkernum'];
           $data['Fphone']= $_POST['Fphone'];
           $data['Fpwd']= md5($_POST['Fpwd']);
           $data['Ftoken']= session('token');
           // $data['Fshenfen']=$_POST['shenfen'];
           $data['Flasttime']=time();
           $Fid=$_POST['Fid'];
           $res=M('Wa_workers')->where(array('Fid'=>$Fid))->save($data);
            if($res){
                $this->success('修改成功',U('Work/index',array('token'=>session('token'))));
            }else{
                 $this->error('修改失败',U('Work/index',array('token'=>session('token'))));
            }     
        }else{
            if(empty($res)){
                $this->error("没有相应记录.您现在可以添加.",U('Work/add',array('token'=>session('token'))));
            }else{
                $this->assign('Fid',$Fid);
                $this->assign('data',$res);
                $this->display('edit');
            }
        }
    }    
    
    /**
     * 删除分类
     */
    public function del() {
        $Fid = $this->_get('Fid');
        if(IS_GET){                              
            $where=array('Fid'=>$Fid,'Ftoken'=>session('token'));
            $data=M('Wa_workers');
            $check=$data->where($where)->find();
            if($check==false)   {
                // echo "111";
                $this->error('非法操作');
            }else{
                 $back=$data->where($wehre)->delete();
                    if($back==true){
                        $this->success('操作成功',U('Work/index',array('token'=>session('token'))));
                    }else{
                        $this->error('服务器繁忙,请稍后再试',U('Work/index',array('token'=>session('token'))));
                        // echo $data->getlastsql();
                    }
                }
        }        
    }
    

    /**
     * 查看日志
     */

    public function log(){
        $Fid = $this->_get('Fid');
        $where=array('Fw_id'=>$Fid);
        $data=M('Wa_workerlog');

        if(IS_POST){
            $where["Fcreatetime"] = array(array('egt', strtotime($_POST["start"])), array('elt', strtotime($_POST["end"]." 23:59:59")));
        }

        $count      = $data->where($where)->count();
        $Page       = new Page($count,10);
        $show       = $Page->show();
        $this->assign('page',$show);  
        $check=$data->where($where)->limit($Page->firstRow.','.$Page->listRows)->select();
        if(!empty($check))   {
            $this->assign('data',$check);
        }
        $this->display();
    }


     /**
     * 查看接单记录
     */

    // public function wlist(){
      
       
    //     $data=M('Wa_orders');

    //     if(IS_POST){
    //         $Fid = $this->_post('Fid');
    //          $where=array('Fworkerid'=>$Fid);
    //         $where["Fordertime"] = array(array('egt', strtotime($_POST["start"])), array('elt', strtotime($_POST["end"]." 23:59:59")));
    //     }else{
    //         $Fid = $this->_get('Fid');
    //         $where=array('Fworkerid'=>$Fid);
    //         $where["Fordertime"] = array(array('egt', strtotime($_GET["start"])), array('elt', strtotime($_GET["end"]." 23:59:59")));
    //     }
        
    //     $count      = $data->where($where)->count();
    //     $Page       = new Page($count,10);
    //     $show       = $Page->show();
    //     $this->assign('page',$show);  
    //     $check=$data->where($where)->limit($Page->firstRow.','.$Page->listRows)->select();
    //      //echo $data->getlastsql();
    //     if(!empty($check))   {
    //         $this->assign('data',$check);
    //     }
    //     $this->display();
    // }
    //查看上传日志
    public function wlist(){  
        $workerid=$_GET['Fid'];    
        $data=M('recordset');
        $user=M('wa_workers')->where(array('Fid'=>$workerid))->find();
        $where=array('username'=>$user['Fphone'],'token'=>$user['Ftoken']);
        if(IS_POST){

        $labelid = $this->_post('labelid');
            if($labelid){
                $where['labelId'] = $this->_post('labelid');
            }        
        $where["startDate"] = array('egt', strtotime($_POST["start"]));
        $where["endDate"] = array('elt', strtotime($_POST["end"]." 23:59:59"));
        //array(array('egt', strtotime($_POST["start"])), array('elt', strtotime($_POST["end"]." 23:59:59")));
        //dump($where);exit;
        }
        //     $Fid = $this->_get('Fid');
        //     $where=array('Fworkerid'=>$Fid);
        //     $where["Fordertime"] = array(array('egt', strtotime($_GET["start"])), array('elt', strtotime($_GET["end"]." 23:59:59")));
        // }

        $count = $data->where($where)->count();
        $Page  = new Page($count,10);
        $show  = $Page->show();
        $record=$data->where($where)->limit($Page->firstRow.','.$Page->listRows)->select();
        foreach ($record as $key => &$value) {
            $cid=M('confset')->field('id')->where(array('confId'=>$value['confId']))->find();
            $value['cid']=$cid['id'];            
        }
        $this->assign('page',$show);        
        //echo $data->getlastsql();
        // if(!empty($check))   {
        //     $this->assign('data',$check);
        // }
        $this->assign('user_record',$record);
        $this->display();
    }

}
?>
