<?php 

class Water_manageAction extends WapAction{

  public function index(){

    if(session('manege_user')==''||session('manege_userid')==''||$_GET["token"]!=$_SESSION["token"]){
                  
          $this->redirect(U('Water_manage/userlogin'));
    }

     //$token=$_GET['token'];session('token')=
      $token=session('token');
   
      if(empty($token)){
        $this->error('请选择商户');
      }

      $status=empty($_GET['status']) ? '1':$_GET('status');
      $t = time();
      $start = mktime(0,0,0,date("m",$t),date("d",$t),date("Y",$t));
      $end = mktime(23,59,59,date("m",$t),date("d",$t),date("Y",$t));
      
      
      $db=M('Wa_orders');
      $od=M('Wa_ordergoods');
      $worker=M('Wa_workers');
      $workers=$worker->field('Fid,Fname')->where(array('Ftoken'=>$token))->select();
      //and Fordertime<='".$end."' and Fordertime>='".$start."' and
      $orderscount=$db->where("Ftoken='".$token."' and Fstatus!=0")->count();
      $orderscount1=$db->where("Ftoken='".$token."' and Fstatus=1")->count();
      $orderscount2=$db->where("Ftoken='".$token."' and Fstatus=2")->count();
      $orderscount3=$db->where("Ftoken='".$token."' and Fstatus=3")->count();
      

      //未派单
      $orders1=$db->where("Ftoken='".$token."' and Fstatus=1")->order('Fordertime asc')->select();
       foreach($orders1 as $k=>$v){
          // echo $v['Fid'];
         $goods=$od->field('Fgoodsname,Fnum,shortname')->where(array('Foid'=>$v['Fid']))->find();
         $orders1[$k]['Fgoodsname']=$goods['Fgoodsname'];
         $orders1[$k]['Fnum']=$goods['Fnum'];
        
       }
     
      //已派单
       $wxuser=M('Wxuser');
     $orders2=$db->where("Ftoken='".$token."' and Fstatus=2 ")->order('Fordertime asc')->select();

       foreach($orders2 as $k=>$v){
          // echo $v['Fid'];
         $goods=$od->field('Fgoodsname,Fnum,shortname')->where(array('Foid'=>$v['Fid']))->find();
      
       $worksss=$worker->field('Fphone,Fname')->where(array('Ftoken'=>$token,'Fid'=>$v['Fworkerid']))->find();
  
         $orders2[$k]['Fname']=$worksss['Fname'];
          $orders2[$k]['Fgoodsname']=$goods['Fgoodsname'];
         $orders2[$k]['Fnum']=$goods['Fnum'];
       }

    //水站的信息
       
       $wxuserinfo=$wxuser->field('phone,wxname')->where(array('token'=>$token))->find();
       $this->assign('wxuserinfo',$wxuserinfo);
       $this->assign('orders2',$orders2);
       $this->assign('orders1',$orders1);
       $this->assign('token',$token);
       $this->assign('orderscount',$orderscount);
       $this->assign('orderscount2',$orderscount2);
        $this->assign('orderscount1',$orderscount1);
        $this->assign('orderscount3',$orderscount3);
        $this->assign('workers',$workers);
      //echo $db->getlastSql();
  
      $this->display();
  }

  public function send_do(){

    $db=M('Wa_orders');
    $worker=$_POST['worker'];
    $db2=M('Wa_workers');
    $phone=$db2->where(array('Fid'=>$worker))->find();
    $ph=$phone['Fphone'];
    
    $ids=$_POST['data'];
    $array=explode(',', $ids);
    array_pop($array);
    foreach ($array as $value){
        $db->where(array('Fid'=>$value))->save(array('Fstatus'=>2,'Fworkerid'=>$worker,'Fphone'=>$ph));
       
    }
    echo '1';
  }

  public function userlogin(){
      
      $this->display();

    }

  public function userlogindo(){
    $db= M('Users');
    $db2= M('Wxuser');
    $username=$_POST['username'];
    $password=md5($_POST['password']);
   $res= $db->where(array('username'=>$username,'password'=>$password))->find();

   if($res){
   
   $token=$db2->field('token')->where(array('uid'=>$res['id']))->find();
    
    session('manege_userid',$res['id']);
    session('manege_user',$res['username']);
    session('token', $token['token']);
     //$this->success('成功',U('Water_manage/index',array('token'=>$token['token'])));
    $this->redirect(U('Water_manage/index',array('token'=>$token['token'])));
   }else{


      $this->error('帐号密码错误',U('Water_manage/userlogin'));
   }
  }


  //异步更新数据 新下单

  public function orderlist(){
        $status=$_POST['status'];
        $token=$_POST['token'];
        $sql="SELECT * FROM tp_wa_orders WHERE Fstatus='".$status."' AND Ftoken='".$token."'";
        $data=M();
        $res=$data->query($sql);
         $count=count($res);
        if($count>0){
            for ($i=0; $i <$count ; $i++) { 
                $str.='<div class="list_k">
                        <div class="phone list_font">客户:'.$res[$i]['Fusers'].'</div>
                        <div class="water list_font">订单号:'.$res[$i]['Forderid'].'</div>
                        <div class="price list_font">金额:'.$res[$i]['Ftotal'].'</div>
                        <div class="time list_font">时间:'.立即送达.'</div>
                        <div class="place list_font">地址:'.$res[$i]['Faddress'].'</div>
                        <div class="more_button"><a href="index.php?&g=Wap&m=Wk&a=wgoods&oid='.$res[$i]['Fid'].'">订单详情</a></div>
                        <div class="more_buttonx"><a href="tel:'.$res[$i]['Fusers'].'">呼叫订户</a></div>
                    </div>';
            }
             echo  $str;
        }

       
    }

    public function statuscg(){

      $token=$_GET['token'];
      $Fid=$_GET['Fid'];
      $res=M('Wa_orders')->where(array('Fid'=>$Fid))->save(array('Fstatus'=>0));
  
        $this->redirect('Water_manage/index',array('token'=>$token['token']));
    }


}

?>