<?php
class ticketAction extends WapAction{

    public function _initialize() {
        parent::_initialize();

    }

    public function buy(){
//var_dump($_SESSION);exit();
        $Ftoken=session('FFtoken');
        $product = M('product')->where(array('token'=>$Ftoken, 'id'=>$_GET["id"]))->find();
        $this->assign('product',$product);

        $res = M('wa_mode')->where(array('Ftoken'=>$Ftoken, 'Fpid'=>$_GET["id"]))->select();
        $this->assign('list',$res);
        // var_dump($Ftoken);

        $this->display();
    }

    public function forder(){
        // var_dump($_SESSION);exit();
        $id = $_GET["id"];
        if($id){
            $db = M('wa_orders');
            $where = array('Fid'=>$id, 'Fphone'=>$_SESSION["Fphone"]);
            $data = array('Fstatus'=>'3', 'Ftype'=>'1', 'Fpaytype'=>'1');
            
	$ticket = M('wa_ticketlog')->where(array('Foid'=>$id))->find();
            $order = M('wa_orders')->where(array('Fid'=>$id,'Fstatus'=>array('eq',2)))->find();
//	var_dump($order);exit();
	$db->where($where)->data($data)->save();

            //送水工确认的时候调用
            $pticket = M('wa_ticket')->where(array("Fgoodsid"=>$ticket["Fgoodsid"], "Ftoken"=>$ticket["Ftoken"], "Fuser"=>$order["Fusers"]))->find();
            if($pticket && $order){
                M()->query("update tp_wa_ticket set Fnum = Fnum + ".$ticket["Fnum"]." where Fgoodsid='".$ticket["Fgoodsid"]."' and Ftoken='".$ticket["Ftoken"]."' and Fuser='".$order["Fusers"]."'");
            }else{
                $tt = M('wa_ticket');
                $data = array(
                    'Fnum'=>$ticket["Fnum"],
                    'Fgoodsid'=>$ticket["Fgoodsid"],
                    'Ftoken'=>$ticket["Ftoken"],
                    'Fuser'=>$order["Fusers"],
                );
                $tt->add($data);
            }
        }
        header('Location:'.U('Wk/order', $_GET));
    }

    public function order(){
        $type = $_POST["sel"];
        $ticket = $_POST["ticket"];
        $pid = $_POST["pid"];
        $token = $_SESSION["FFtoken"];
        $Fuser = $_SESSION["FFphone"];
        $orderSn = $yCode[intval(date('Y')) - 2011] . strtoupper(dechex(date('m'))) . date('d') .substr(microtime(), 2, 5);

        $mode = M('wa_mode')->where(array('Ftoken'=>$token, 'Fid'=>$ticket))->find();

        if($type == "xianjin"){
            $user = M('wa_users')->where(array("Fusername"=>$Fuser, "Ftoken"=>$token))->find();
            $product = M('product')->where(array("id"=>$pid, "token"=>$token))->find();
            $od=M('Wa_orders');
            $data=array(
                'Ftoken'=>$token,
                'Fpaytype'=>"1",
                'Fusers'=>$user['Fusername'],
                'Faddress'=>$user['Faddress'],
                'Forderid'=>$orderSn,
                'Fstatus'=>1,
                'Ftotal'=>$mode["Fprice"],
                'Fhours'=>$Fhours,
                'Frid'=>"0",
                'Fbid'=>"1",
                'Ftype'=>"0",
                'Fticket'=>"1",
                'Fordertime'=>time(),
                'Fcreatetime'=>date("Y-m-d"),
            );
            $oid = $od->add($data);
            $gd = M('Wa_ordergoods');
            $data = array(
                'Forderid'=>$orderSn,
                'Fgoodsid'=>$product["id"],
                'Fgoodsname'=>$product["name"],
                'Fprice'=>$mode["Fprice"],
                'Ftotal'=>$mode["Fprice"],
                'Fnum'=>$mode["Fnum"],
                'Foid'=>$oid,
                'Fcreate_time'=>time(),
            );
            $gd->add($data);
            $tl = M('wa_ticketlog');
            $data = array(
                'Fnum'=>$mode["Fnum"],
                'Fname'=>$mode["Fname"],
                'Fgoodsid'=>$product["id"],
                'Fprice'=>$mode["Fprice"],
                'Ftoken'=>$token,
                'Foid'=>$oid,
                'Fcreate_time'=>time(),
            );
            $tl->add($data);

            header('Location:'.U('Store/orders'));
        }else if($type == "weixin"){

        }
    }

}
?>
