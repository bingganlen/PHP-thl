<?php 

class StoreAction extends WapAction{
  
// public $FFtoken;
public $FFqid='abcde';
public $FFuser;
public $FFtoken;
public $FFphone;
// 获取token
public function gettoken(){
   if(!empty($_GET['FFtoken'])){
    $FFtoken=$_GET['FFtoken'];
    session('FFtoken',$FFtoken);
   
  }else if(!empty(session('FFtoken'))){
     $FFtoken=session('FFtoken');
  }else if(session('FFtoken') && $_GET['FFtoken']){
    $FFtoken=$_GET['FFtoken'];
  }else{
    $FFtoken='';
  }
  return $FFtoken;
}
//积分
public function integration(){
  $size = 10;
  $page = $_GET['p']-1;
  if($page < 0){
    $page = 0;
  }
  $_GET['p'] = $page + 1;
  $sql = "SELECT a.Ftotal,a.Fcreatetime,a.Fproductid,b.name FROM tp_wa_integration a
LEFT JOIN tp_product b ON a.Fproductid = b.id
WHERE a.Ftoken = '%s' AND a.Fphone = '%s'
ORDER BY Fcreatetime DESC LIMIT %s, ".$size;

  $sql = sprintf($sql, $_SESSION['FFtoken'], $_SESSION['FFphone'], $page*$size);
  $data = M()->query($sql);

  $totalsql = "SELECT SUM(a.Ftotal) AS n FROM tp_wa_integration a WHERE a.Ftoken = '%s' AND a.Fphone = '%s'";

  $totalsql = sprintf($totalsql, $_SESSION['FFtoken'], $_SESSION['FFphone']);
  $total = M()->query($totalsql);

  $this->assign('data', $data);
  $this->assign('total', $total[0]['n']);
  $this->display();
}
//水站引导页
public function station(){
  $appId=$this->options['appid'];
  $appSecret=$this->options['appsecret'];
  $jssdk = new Location($appId,$appSecret);
  $signPackage=$jssdk->getSignPackage();
  //dump($signPackage);exit;
  $this->assign('signPackage',$signPackage);
  /*$lists=M('wxuser')->field('id,wxname,token,province,city,country,waddress')->order('member_code desc')->limit(5)->select();  
  $this->assign('lists',$lists);*/
  $this->display();
}
//根据定位推荐水站方法
public function wastation(){
  //$lat=$_POST['latitude'];
  //$lon=$_POST['longitude'];  
  $lat=$_GET['latitude'];
  $lon=$_GET['longitude'];
  $raidus='5000';
  $location=new Location();
  $scale=$location->getAround($lat, $lon, $raidus);
  //dump($scale);
  //数据库查范围内的数据
  $where=array();
  $where['latitude']=array('between',array($scale['minLat'],$scale['maxLat']));
  $where['longitude']=array('between',array($scale['minLng'],$scale['maxLng']));
  $where['member_code']>=0;
  $data=M('wxuser')->where($where)->field('id,wxname,token,province,city,country,waddress')->order('member_code desc')->limit(5)->select();
  //dump($data);
  $this->ajaxReturn($data,'JSON');
  //echo json_encode($data);
}
//水桶押金页面
public function bottle(){//复制积分页面，待修改
  $size = 10;
  $page = $_GET['p']-1;
  if($page < 0){
    $page = 0;
  }
  $_GET['p'] = $page + 1;
  $sqll = "SELECT 
  d.Fnum,
  d.Fcreate_time,  
  p.name,
  d.Fnum*p.foregift as price
FROM tp_wa_user_deposit d
LEFT JOIN tp_product p
ON d.Fgoodsid = p.id
WHERE d.Ftoken = '%s' AND d.Fusers = '%s'
ORDER BY Fcreate_time DESC
LIMIT %s, ".$size;

  $sql = sprintf($sqll, $_SESSION['FFtoken'], $_SESSION['FFphone'], $page*$size);
  $data = M()->query($sql);

  $totalsql = "SELECT SUM(d.Fnum*p.foregift) AS n
FROM tp_wa_user_deposit d
LEFT JOIN tp_product p
ON d.Fgoodsid = p.id
WHERE d.Ftoken = '%s' AND d.Fusers = '%s'";

  $totalsql = sprintf($totalsql, $_SESSION['FFtoken'], $_SESSION['FFphone']);
  $total = M()->query($totalsql);

  $this->assign('data', $data);
  $this->assign('total', $total[0]['n']);
  $this->display();
}
//水站通知页面
public function notice(){
  $token = $this->gettoken();
  $notice = M('wa_notice')->where(array('Ftoken'=>$token))->order('start_time desc')->select();
  //dump($notice);exit;
  $this->assign('notice',$notice);
  $this->display();
}
//水票页面
public function ticket(){
  /*if(!empty($_GET['FFphone'])){
    $Fuser=$_GET['FFphone'];
    session('FFphone',$Fuser);
  }else{
    $Fuser=session('FFphone');
  }
  if(!empty($_GET['FFtoken'])){
    $token=$_GET['FFtoken'];
    session('FFtoken',$_GET['FFtoken']);
  }else{
    $token=session('FFtoken');
  }*/
  $Fuser=$this->getphone();
  $token=$this->gettoken();

  $ticketsql="SELECT p.name, sum(t.Fnum) as num FROM tp_wa_ticketlog t LEFT JOIN tp_product p ON t.Fgoodsid=p.id WHERE t.Fphone='".$Fuser."' and t.Ftoken='". $token."'and t.Fpay=1 GROUP BY p.name";
   $tickets=M()->query($ticketsql);

  $this->assign('tickets_log',$tickets);
  $this->display();
}
//水票明细页面
public function ticket_detail(){
  $Fphone=$this->getphone();
  $Ftoken=$this->gettoken();
  $st_time=strtotime($_POST['st_time']);
  $end_time=strtotime($_POST['end_time']);
  if(!$st_time){
    $st_time='1451577600';
  }
  if(!$end_time){
    $end_time=time();
  }
  $st_date=date("Y-m-d",$st_time);
  $end_date=date("Y-m-d",$end_time);
  $wherein=array();
  $wherein['Fphone']=$Fphone;
  $wherein['Ftoken']=$Ftoken;
  $wherein['Fcreate_time']=array('between',array($st_time,$end_time));
  $wherein['Fnum']=array('gt',0);
  $wherein['Fpay']='1';
  $ticket_log=M('wa_ticketlog');
  //购入总水票
  $total_in=$ticket_log->where($wherein)->field('SUM(Fnum) as num')->find();
  //消费中水票 
  $whereout=array();
  $whereout['Fphone']=$Fphone;
  $whereout['Ftoken']=$Ftoken;
  $whereout['Fcreate_time']=array('between',array($st_time,$end_time));
  $whereout['Fnum']=array('lt',0);
  //dump($ticket_log->getLastSql());exit;
  $total_out=$ticket_log->where($whereout)->field('abs(SUM(Fnum)) as num')->find();
  //记录
  $where=array();
  $where['Fphone']=$Fphone;
  $where['Ftoken']=$Ftoken;
  $where['Fpay']=1;
  $where['Fcreate_time']=array('between',array($st_time,$end_time));
  $list=$ticket_log->where($where)->order('Fcreate_time desc')->select();
  
  //dump($list);exit;
  $this->assign('st_date',$st_date);
  $this->assign('end_date',$end_date);
  $this->assign('total_in',$total_in);
  $this->assign('total_out',$total_out);
  $this->assign('list',$list);
  $this->display();
}
// 获取手机号
public function getphone(){
  // $FFphone='';
  if(!empty($_GET['FFphone'])){
   $FFphone=$_GET['FFphone'];
    session('FFphone',$FFphone);
  }else if(!empty(session('FFphone'))){
   
     $FFphone=session('FFphone'); 
   
  }else if(session('FFphone') && $_GET['FFphone']){
    $FFphone=$_GET['FFphone'];
  }else{
    $FFphone='';
  }
  return $FFphone;
}

public function _initialize() {
parent::_initialize();
$FFphone=$this->getphone();
  if(!empty($FFphone)){
    $this->assign('FFphone',$FFphone);
  }

$FFtoken=$this->gettoken();
  if(!empty($FFtoken)){
    $this->assign('FFtoken',$FFtoken);
  }

// 如果一瓶一码，   如果是公共二维码
  // if($FFtoken =='' ){
  //  //header('Location:/index.php?g=Wap&m=login&a=index');
 //    $this->error('请重新扫码下单并收藏，敬请见谅');
  // }

    // $FFtoken=session('FFtoken');
    $this->userinfo=$this->wxusers();
    $this->assign('userinfo',$this->userinfo);
}

private $options = array(
          //物勒工名公众号
          //'token'=>'water', //填写你设定的key
          //'encodingaeskey'=>'JBFRkpniSjRNg9ztFmX6YtzAOuDROnwEGMzm6PRXoYH', //填写加密用的EncodingAESKey
          //'appid'=>'wxb7dc9db1bd06e502', //填写高级调用功能的app id, 请在微信开发模式后台查询
          //'appsecret'=>'f285fc7ab350e3e75f9f85393793686a' //填写高级调用功能的密钥
          //码上生活公众号
          //'token'=>'water', //填写你设定的key
          //'encodingaeskey'=>'JgUWac4jdrZD9C0HWHq20bA2MsvH2SrRmWk5liOUXS2', //填写加密用的EncodingAESKey
          //'appid'=>'wx99eaee315bb76d7a', //填写高级调用功能的app id, 请在微信开发模式后台查询
          //'appsecret'=>'c31662e737e1cfa00a383096843f1b9e' //填写高级调用功能的密钥
          //测试号
          'token'=>'water', //填写你设定的key
          'appid'=>'wxc0990ff117559850', 
          'appsecret'=>'4da6c0f3cc8da343af5706248759ae49'
        );

public function check(){
    $auth = new TPWechat($this->options);
    return $auth->valid();
}
//老板端调用微信授权，发送模板消息时使用
public function wxboss(){
  $token=$_GET['token'];//获得老板token
  if(parent::is_wx()){
      $auth2 = new Wxauth($this->options);
      $openid=$auth2->open_id;
      //$res=$this->http_curl($auth2);
      $res=M('Wxuser')->where(array('token'=>$token))->setField('openid',$openid);
      
      if($res){
        header("Location: http://www.eyuanonline.com/waterHtml/index.html");        
      }else{
        $this->error('openid写入失败');
      }
  }else{
    echo '请用微信进入页面';
  }
}

public function _before_index(){
    if(parent::is_wx()){
        $auth = new Wxauth($this->options);
        //dump($auth);
    }else{

    }
}

/*public function test_tui(){
    $gt = new GeTui();
    $x  = $gt->pushToAndroidApp('测试', '测试1', 'ceshi123456');
    dump($x);
}*/

 public function index(){
     // 通过带q的二维码，
    if($_GET['FFqid']){
        $FFqid=$_GET['FFqid'];  
    }else{
        $FFqid=session('FFqid');
    }
    if($_GET['FFphone']){
      $users=$_GET['FFphone'];
    }
    
     // 如果是一瓶一码  (浏览器打开多个可能公共二维码也走这里)
    if($FFqid && !$users){
        $users=M('wa_users')->where(array('Fewm_id'=>$FFqid))->find();
        $this->assign('integration',$users['Fintegration']);
        $this->assign('address',$users['Faddress']);
        $this->assign('phone',$users['Fusername']);
        // 如果用户没注册
        if(empty($users)){
          $this->assign('token',$this->gettoken());
          $this->assign('q',$FFqid);
          $FFtoken=$this->gettoken();
          // update by shitao 20161019 start
          $this->redirect(U('Reg/station',array('FFtoken'=>$FFtoken,'FFqid'=>$FFqid)));
          //$this->redirect(U('Reg/lottery_index',array('FFtoken'=>$FFtoken,'FFqid'=>$FFqid)));
          // update by shitao 20161019 end
          exit();
        }else{
           session('FFphone',$users['Fusername']);
           // add by shitao 20170823
           $b = [];
           $a = [];
           $b['address'] = $users['Faddress'];
           $b['name'] = $users['Fusername'];
           $b['phone'] = $users['Fusername'];
           $a[] = $b;
           $c = json_encode($a);
           $this->assign('user_id', $users['Fid']);
           $this->assign('addressInfo', $c);
        }

    }
     $FFphone=$this->getphone();
     $FFtoken=$this->gettoken();

     $whereorder=array();
     $whereorder['Fusers']=$FFphone;
     $whereorder['Ftoken']=$FFtoken;
     $whereorder['Fticket']=0;
     $whereorder['Fstatus']=array('neq',0);
     $db=M('Wa_orders');
     $ord=M('Wa_orders')->field('Forderid,Fpaytype,Fordertime,Fid')->where($whereorder)->limit(0,1)->order('Fordertime desc')->find();
    
     $go=M('Wa_ordergoods');
     $goods=$go->where(array('Forderid'=>$ord['Forderid']))->limit(0,1)->order('Fcreate_time desc')->find();

    
      //统计用户订单次数以及设置 优惠
   $Wxuserms2=M('Wxuser');
   // $u=$Wxuserms2->field('types,num,Ftype')->where(array('token'=>$FFtoken))->find();
   // add by shitao 20170823
   $u = $Wxuserms2->field('id,types,num,Ftype,Fdis_id,Fstaff_no')->where(array('token'=>$FFtoken))->find();
   $dishId = $u['Fdis_id'];//经销商id
   // $dis = M('Wa_distributor')->field('Fstaff_no')->where(array('Fid'=>$dishId))->find();
   $staffNo = $u['Fstaff_no'];
   $this->assign('staffNo',$staffNo);
   $this->assign('shop_id',$u['id']); 

   $setnum=$u['num']-1;
   if($u['types']==1){//优惠开启
      $ordcount=$db->where(array('Fusers'=>$FFphone,'Ftoken'=>$FFtoken,'Fstatus'=>3,'Fbid'=>0,'Fticket'=>0))->count();

      if($ordcount>=$setnum){
        //享受优惠
         $rew="rew";
        
         $goods['Ftotals']=($goods['Fnum']-1)*$goods['Fprice'];

      }else{
        //不优惠
         $rew="norew";
        
          $goods['Ftotals']=$goods['Fnum']*$goods['Fprice'];
      }
    }else{
      //优惠关闭
       $rew="norew";
         
      $goods['Ftotals']=$goods['Fnum']*$goods['Fprice'];
   }
   //$goods['Ftotal']=$goods['Fnum']*$goods['Fprice'];

    $this->assign('rew',$rew);
    //优惠结束
      

    //查询商品
   $goospro=M('Product')->where(array('id'=>$goods['Fgoodsid']))->find();
   $this->assign('goosproname',$goospro['name']);
   $this->assign('logourl',$goospro['logourl']);
   $this->assign('price',$goospro['price']);
   $this->assign('spec',$goospro['spec']);
   $this->assign('gid',$goospro['id']);
   $this->assign('goods',$goods);
   $this->assign('order',$ord);
   
   //幻灯片
   $flash=M('Storeflash');
   $station=M('wxuser')->where(array('token'=>$FFtoken))->field('notice,Ftitle,province,city')->find();
   //$res=$flash->field('url,img,info')->where(array('attr'=>1,'token'=>'admin'))->order('id desc')->limit(5)->select();
   $flashwhere=array('attr'=>1,'province'=>$station['province'],'city'=>$station['city']);
   $res2=$flash->field('url,img,info')->where($flashwhere)->order('id desc')->limit(3)->select();
   // update by shitao 20160830 start
   // $res0 = M('wa_distributor_banner')->where(array('uid'=>$this->userinfo['Fdis_id']))->order('sort')->limit(5)->select();
   //$res0 = M('wa_distributor_banner')->where(array('uid'=>$this->userinfo['Fdis_id']))->order('sort')->limit(3)->select();
   // update by shitao 20160830 end 
   //$this->assign('res0',$res0);
   //$this->assign('res',$res);
   $this->assign('res2',$res2);

   //公告   
   $this->assign('notice',$station);
   /*$notice=M('Wa_notice');
   $noticeinfo=$notice->field('Fbody')->where(array('Ftoken'=>$FFtoken,'Fshow'=>1))->find();
   $this->assign('noticeinfo',$noticeinfo);*/
  
   //活动抽奖判断 
   $praise=M('Wa_praisedset');
   $praisestatus=$praise->field('Fstatus,Fname,Ftimes,Fendtime')->find();
   $activeon=$this->activeon($_GET['FFtoken']);
 
   if($activeon=='1'){

     $this->assign('praisestatuson',$praisestatus['Fstatus']);
   }else{

     $this->assign('praisestatuson','2');
   }
   
  
   //判断当前订单的次数
   $daybegin=strtotime(date("Ymd"));  
   $dayend=$daybegin+86400;
   $choujwhere['Fusers']=session('Fcustom_user');
   $choujwhere['Fordertime']=array('between',array($daybegin,$dayend));

   //$choujiangcount=M('Wa_orders')->where($choujwhere)->find();

   $this->assign('praisename',$praisestatus['Fname']);
    if(empty(session('Fcustom_user'))){
       $praiselogin='true';
    }else{
      
       $active=$_SESSION['active'];
       $praiselogin='false';
       $praiselog=M('Wa_praised');
       

      $begintime=strtotime(date('Y-m-d'));
      $where['Fusername']=session('Fcustom_user');
      $where['Ftoken']=$FFtoken;
      $where['Fcreatetime']=array('between',array($begintime,time()));
      $praisecount=$praiselog->where($where)->count();
  
       $lasttimes=intval($praisestatus['Ftimes']-$praisecount);
    
        if(($_COOKIE['prizetime']) && ($praisecount<3)){
           //如果有下单则增加两次
           $lasttimes=$lasttimes+2;
        }
       if($lasttimes<0){
        $lasttimes=0;
       }
       $this->assign('lasttimes',$lasttimes);
    }
    $this->assign('praiselogin',$praiselogin);
    //抽奖结束
    //社会水站还是学校水站 本地生活模块
    $this->assign('ftype',$u['Ftype']);

    //add by shitao 20160929 
    $totalsql = "SELECT SUM(a.Ftotal) AS n
FROM tp_wa_integration a
WHERE a.Ftoken = '%s' AND a.Fphone = '%s'";

  $totalsql = sprintf($totalsql, $_SESSION['FFtoken'], $_SESSION['FFphone']);
  $total = M()->query($totalsql);

  $this->assign('total', $total[0]['n']);

    $this->display();

 }

/**
 * 下单完成
 * added by shitao 20160826
 * @return [type] [description]
 */
public function orderover() {
    /*$res0 = M('wa_distributor_banner')->where(array('uid'=>$this->userinfo['Fdis_id']))->order('sort')->limit(3)->select();
    $this->assign('ads',$res0);*/
//下单成功后个推推送信息和模板消息发送下单推送
    $token=$_GET['FFtoken'];
    if($_GET['oid']){
      $oid=$_GET['oid'];
      $this->templatecs($token,$oid);
    }
    $this->display();
}

/**
 * 再来一单
 * @return [type] [description]
 */
 public function rebuy(){

    // 通过带q的二维码，
    if($_GET['FFqid']){
        $FFqid=$_GET['FFqid'];  
    }else{
        $FFqid=session('FFqid');
    }

    $FFphone=$this->getphone();
    $FFtoken=$this->gettoken();
    $user=M('wa_users')->where(array('Fusername'=>$FFphone,'Ftoken'=>$FFtoken))->find();

    if($user){
        $address=$fllorr['Fname'].'-'.$fllorr['Fremark'];
        $this->assign('user',$user);
        $this->assign('address', $user['Faddress']);
        $this->assign('phone',$user['Fusername']);
        $this->assign('Fusername',$user['Fusername']);
    }

    $this->assign('FFtoken',$FFtoken);
    //首页信息
    $db=M('Wa_orders');
//  判断是否购买过count
    $sql5="select count(Fid) as count from tp_wa_orders where Ftoken='".$FFtoken."' and Fusers='".$FFphone."' and Fstatus!=0";

    $conts=M()->query($sql5);
    $cont=$conts[0]['count'];
    $users5=M('wa_users')->where(array('Fewm_id'=>$FFqid,'Ftoken'=>$FFtoken))->find();
   
    if($users5){
        $Fusers5=$users5['Fusername'];
    }else{
        $Fusers5=$FFphone;
    }

     
  //     if($Fusers5 =='' ){
  //   //header('Location:/index.php?g=Wap&m=login&a=index');
  //   $this->error('请重新扫码下单并收藏，敬请见谅');
  // }
     $whereorder=array();
     $whereorder['Fusers']=$Fusers5;
     $whereorder['Ftoken']=$FFtoken;
     $whereorder['Fstatus']=array('neq',0);

      $ord=M('Wa_orders')->field('Forderid,Fpaytype,Fordertime')->where($whereorder)->limit(0,1)->order('Fordertime desc')->find();

  $this->assign('ordertimes',$ord['Fordertime']);
         //判断当前订单的次数
   $daybegin=strtotime(date("Ymd"));  
   $dayend=$daybegin+86400;
   $whereorder['Fordertime']=array('between',array($daybegin,$dayend));

      //$ord=M('Wa_orders')->field('Forderid,Fpaytype,Fordertime')->where($whereorder)->limit(0,1)->order('Fordertime desc')->find();
  $orderalltimes=M('Wa_orders')->where($whereorder)->count();
  //系统设置下单次数
  $settimes=M('Wxuser')->field('Fordertimes')->where(array('token'=>$FFtoken))->find();
  $this->assign('settimes',$settimes['Fordertimes']);
  $this->assign('orderalltimes',$orderalltimes);
  $this->assign('notime',time());
   // if($cont==0){

   //   $this->redirect(U('Store/goodslist',array('FFtoken'=>$FFtoken,'FFphone'=>$FFphone)));
   // }

   $go=M('Wa_ordergoods');
   $goods=$go->where(array('Forderid'=>$ord['Forderid']))->limit(0,1)->order('Fcreate_time desc')->find();

    //判断用户地址宿舍楼是否为空
     $floor=M('Wa_users')->field('Ffloorid')->where(array('Fusername'=>$FFphone,'Ftoken'=>$FFtoken))->find();
   
     if(!empty($floor['Ffloorid'])){
      
        $this->assign('floor','floor');
     }
     //查询商品
   $goospro=M('Product')->where(array('id'=>$goods['Fgoodsid']))->find();

   //统计用户订单次数以及设置 优惠
   $Wxuserms2=M('Wxuser');
   $u=$Wxuserms2->field('types,num')->where(array('token'=>$FFtoken))->find();

   $setnum=$u['num']-1;
   if($u['types']==1){
      $ordcount=$db->where(array('Fusers'=>$FFphone,'Ftoken'=>$FFtoken,'Fstatus'=>3,'Fbid'=>0,'Fticket'=>0))->count();

      if($ordcount>=$setnum){
         $rew="rew";
        
         $goods['Ftotals']=($goods['Fnum']-1)*$goospro['price'];

      }else{

         $rew="norew";
        
          $goods['Ftotals']=$goods['Fnum']*$goospro['price'];
      }
      }else{
       $rew="norew";
         
      $goods['Ftotals']=$goods['Fnum']*$goospro['price'];
   }
   $goods['Ftotal']=$goods['Fnum']*$goospro['price'];

    $this->assign('rew',$rew);
   //优惠结束
   

   //当前时间
   $nowtme=date('H');
   
   $nowtme2=$nowtme+1;
   $daybegin=strtotime(date("Ymd"));  
   $dayend=$daybegin+86400;
    $this->assign('daybegin',$daybegin);
     $this->assign('dayend',$dayend);
   $this->assign('nowtme',$nowtme);
   $this->assign('nowtme2',$nowtme2);
   
   $this->assign('goosproname',$goospro['name']);
   $this->assign('logourl',$goospro['logourl']);
    $this->assign('price',$goospro['price']);
     $this->assign('spec',$goospro['spec']);
   $this->assign('goods',$goods);
   $this->assign('order',$ord);
  

  //时间段拼接
  

  if(8<=$nowtme && $nowtme<16){

     for($i=$nowtme;$i<16;$i++){

        $options.='<option value="'.$i.'">'.$i.':00</option>';
      
     }

     for($k=$nowtme;$k<16;$k++){

        $options2.='<option value="'.($k+1).'">'.($k+1).':00</option>';
      
     }

  }else if(0<=$nowtme && $nowtme<8){

     for($i=8;$i<16;$i++){

        $options.='<option value="'.$i.'">'.$i.':00</option>';
      
     }

     for($k=8;$k<16;$k++){

        $options2.='<option value="'.($k+1).'">'.($k+1).':00</option>';
      
     }

  }else{
  
     $options='<option>请预约明日</option>';
     $bid='12';
     
  }


    $this->assign('bid',$bid);

       $this->assign('options2',$options2);
       $this->assign('options3',$options3);
  
      $this->assign('options',$options);
        //根据后台设置时间
  $gettimes=M('Wxuser')->field('Fstart_time,Fend_time')->where(array('token'=>$FFtoken))->find();
  $start=$gettimes['Fstart_time'];
  $end=$gettimes['Fend_time'];
  $this->assign('get_time',$this->get_time($start,$end));


  //活动抽奖判断 
   $praise=M('Wa_praisedset');
   $praisestatus=$praise->field('Fstatus,Fname,Ftimes,Fendtime')->find();
   if($praisestatus['Fstatus']=='1'){
     $daybegin=strtotime(date("Ymd"));  
   $dayend=$daybegin+86400;
   $choujwhere['Fusername']=session('Fcustom_user');
   $choujwhere['Ftoken']=$FFtoken;
   $choujwhere['Fcreatetime']=array('between',array($daybegin,$dayend));
    $countcj=M('Wa_praised')->where($choujwhere)->count();

 $activeon=$this->activeon($_GET['FFtoken']);

   if($activeon=='1'){
    
        if($countcj<3){
        if($_COOKIE['prizetime']){
            $pon='2';
        }else{
           $pon='1';
        }
       
      }else{
          $pon='2'; 
      }

   }else{
     // $this->assign('praisestatuson','2');
      $pon='2'; 
   }
 $this->assign('praisestatuson',$pon);
}

  $this->display();
 }


public function get_time($start=8,$end=21,$token='uyezkd1457501171'){
  // 当前时间
  $nowtme=date('H.i');
  $nowtme2=$nowtme+1;
// 如果是8-21

 if($start<=$nowtme && $nowtme<$end){
        for($i=(int)$nowtme+1;$i<$end+3&&$i<24;$i+=0.5){
            //if($i>24){$i=24;}
             if(($i-0.5)==floor($i)){
             $options.='<option value="'.$i.'">'.($i-0.5).':30</option>';
             }else{
              $options.='<option value="'.$i.'">'.$i.':00</option>';
             }
         }
         for($k=(int)$nowtme+3;$k<=$end+2&&$k<=24;$k+=0.5){
            //if($k>24){$k=24;}
              $a = ($k -floor($k))*60;
              if($a==0){
                $a = '00';
              }
              if(floor($k)!=floor($nowtme)) {
                  // add by shitao 20161110 start  阿坝师专订水时间+1
                  if($token=='uyezkd1457501171'){
                      $k = $k + 1;
                      if($k > $end){
                        $k = $end;
                      }
                  }
                  // add by shitao 20161110 end
                  $options2.='<option value="'.($k).'">'.(floor($k)).':'.$a.'</option>';
              }
         }
   $str='<select class="sele_type font5b"  name="Fhours1" id="Fhours1">
        '.$options.'
        </select>&nbsp;至&nbsp;
        <select class="sele_type font5b"  name="Fhours2" id="Fhours2">
        '.$options2.'
        </select>';

  }else if($end<$nowtme && $nowtme<=24){
    //如果是21-24 
    $str='<input type="hidden" name="Fhours1" id="Fhours1" value="1">
    <input type="hidden" name="Fhours2" id="Fhours2" value="2">
    <span>订水时间已过，请明日再来</span>
    ';
  exit;
  }else{
// 如果是0-9
// 如果是第二天
    for($i=floor($start);$i<$end;$i+=0.5){
       
             if(($i-0.5)==floor($i)){

              $options.='<option value="'.$i.'">'.($i-0.5).':30</option>';
             }else{
              $options.='<option value="'.$i.'">'.$i.':00</option>';
             }
        
      
         }
     
        for($k=$start;$k<$end;$k+=0.5){
              $a = ($k-floor($k))*60;
              if($a==0){
                $a = '00';
              }
              if(floor($k)!=floor($nowtme)) {
                  // add by shitao 20161110 start  阿坝师专订水时间+1
                  if($token=='uyezkd1457501171'){
                      $k = $k + 1;
                      if($k > $end){
                        $k = $end;
                      }
                  }
                  // add by shitao 20161110 end
                $options2.='<option value="'.($k).'">'.(floor($k)).':'.$a.'</option>';
              }

         }


     $str='<select class="sele_type font5b"  name="Fhours1" id="Fhours1">
        '.$options.'
        </select>&nbsp;至&nbsp;
        <select class="sele_type font5b"  name="Fhours2" id="Fhours2">
        '.$options2.'
        </select>';

  }

 return $str;

}

 public function goodslist(){
    $FFtoken=$this->gettoken();
    //站点轮播图和公告      
        
    $notice=M('wxuser')->where(array('token'=>$FFtoken))->field('notice,Ftitle,province,city,wx_pay')->find();
    $flashwhere=array('attr'=>1,'province'=>$notice['province'],'city'=>$notice['city']);
    $res2=M('Storeflash')->field('url,img,info')->where($flashwhere)->order('id desc')->limit(3)->select();
    $this->assign('res2',$res2);
    $this->assign('notice',$notice);
    //商品列表
    if($FFtoken){
      $product=M('Product');
      $ticket=M('wa_ticket');
       //桶装水
      $product_bar=$product->where(array('token'=>$FFtoken,"shelfstate"=>0,"category"=>0))->field('name,id,logourl,price,spec,gb_label,ga_label')->order('sort desc')->select();
       //瓶装水
      $product_bot=$product->where(array('token'=>$FFtoken,"shelfstate"=>0,"category"=>1))->field('name,id,logourl,price,spec,gb_label,ga_label')->order('sort desc')->select();
        //其他
      $product_oth=$product->where(array('token'=>$FFtoken,"shelfstate"=>0,"category"=>2))->field('name,id,logourl,price,spec,gb_label,ga_label')->order('sort desc')->select();
        //水票
      $product_tic=$ticket->alias('t')->join('left join tp_product AS p ON t.Fgoodsid=p.id')->where(array('t.Ftoken'=>$FFtoken,"t.Fcategory"=>0,'p.shelfstate'=>0))->field('t.Fname as tname,p.name as pname,t.Fid as id,t.Fprice as price,t.remarks,p.logourl as logourl,p.spec,t.Fnum as num')->order('t.Fid desc')->select();
      
      $this->assign('product_bar',$product_bar);
      $this->assign('product_bot',$product_bot);
      $this->assign('product_oth',$product_oth);
      $this->assign('product_tic',$product_tic);
      $this->display();
    }else{
      $this->error('请重新扫描登录');
    }
   
 }

 public function orderinfo(){
  //dump("欢迎id");exit;
  $FFphone=$this->getphone();
  $FFtoken=$this->gettoken();
  
  $station=M('wxuser');
  $ordb=M('Wa_orders');
  $products=M('Product');
  //店铺营业时间和公告信息
  $stinfo=$station->where(array('token'=>$FFtoken))->field('Fstart_time,Fend_time,notice,wx_pay')->find();
  
  $st_time=str_replace('.',':',$stinfo['Fstart_time']);
  $e_time=str_replace('.',':',$stinfo['Fend_time']);
   $st_time1=$stinfo['Fstart_time'];
  $e_time1=$stinfo['Fend_time'];
  $stinfo['Fstart_time']=$st_time;
  $stinfo['Fend_time']=$e_time;
  $this->assign('stinfo',$stinfo);
   //下单提交过来的信息
  $product=$_GET['product'];
  $productnum=(int)$_GET['productnum'];
  //session('product',$product);
  //session('productnum',$productnum);
  $q=$_GET['q'];
  
  if(preg_match("/ticket/",$product)){
    //购水票订单
    $pid=intval($product);//组合id
    $goods=M('wa_ticket')->alias('t')->join('left join tp_product AS p ON t.Fgoodsid=p.id')->where(array('t.Fid'=>$pid))->field('t.Fname as tname,p.name as name,t.Fid as id,t.Fprice as price,p.logourl as logourl,t.Fnum as num')->find();
      $goodsorder['Fgoodsid']=$pid;      
      $goodsorder['spec']=$goods['num'].'张水票';
      $goodsorder['Fticket']='1';
  }else{
    //购非水票订单
    $goods=$products->field('name,price,spec,ga_label,logourl,foregift,category')->where(array('id'=>$product))->find();
    $goodsorder['Fgoodsid']=$product;
    $goodsorder['spec']=$goods['spec'];
    $goodsorder['Fticket']='0';
    //商品是否有桶押金
    if($goods['category']==0){
      $goodsorder['foregift']=$goods['foregift'];
    }
  }
  
  $goodsorder['Fnum']=$productnum;
  $goodsorder['Fgoodsname']=$goods['name'];  
  $goodsorder['Frice']=$goods['price']; 
  $goodsorder['ga_label']=$goods['ga_label'];  
  $token=$FFtoken;
  $username=$FFphone;
  $goodsorder['Ftotal']=$productnum*$goods['price'];
  //$logo=$products->field('logourl')->where(array('id'=>$product))->find();
  $goodsorder['logourl']=$goods['logourl'];

  //$this->assign('goodsorder',$goodsorder);
  // 用户楼层，用户信息和上楼费
     $user=M('Wa_users')->where(array('Fusername'=>$FFphone,'Ftoken'=>$FFtoken))->find();
    //判断用户地址宿舍楼是否为空
     if(!empty($user['Ffloorid'])){    
        $this->assign('floor',$user['Ffloorid']);
     }
     //上楼费
     if($user['set_overhead_cost']>0 && $user['overhead_cost']>0){
      $this->assign('overhead_cost',$user['overhead_cost']);
      $this->assign('reason_overhead',$user['reason_overhead_cost']);
     }

     $this->assign('user',$user);
    //最近的有效订单的下单时间
     $whereorder=array();
     $whereorder['Fusers']=$FFphone;
     $whereorder['Ftoken']=$FFtoken;
     $whereorder['Fstatus']=array('neq',0);

     $ord=$ordb->field('Forderid,Fpaytype,Fordertime')->where($whereorder)->limit(0,1)->order('Fordertime desc')->find();

  $this->assign('ordertime',$ord['Fordertime']);
  $this->assign('notime',time());
   //统计用户订单次数以及设置 优惠
   //$Wxuserms2=M('Wxuser');
   //types是否优惠，num桶数
   $u=$station->field('types,num')->where(array('token'=>$FFtoken))->find();

   $setnum=$u['num']-1;
   if($u['types']==1){
    //优惠开启
      $ordcount=$ordb->where(array('Fusers'=>$username,'Ftoken'=>$FFtoken,'Fstatus'=>3,'Fbid'=>0,'Fticket'=>0))->count();
      if($ordcount>=$setnum){
         $rew="rew";//享受优惠
         $goodsorder['Ftotal']=($productnum-1)*$goods['price'];

      }else{
         $rew="norew";
        
      }     
      
   }else{
     $rew="norew";
     
   }
    $goodsorder['Ftotal']=$productnum*$goods['price'];
  //桶装水设优惠金额和实付金额
     if($goods['category']==0 && $user['Fdiscount']>0){
      $goodsorder['discount']=$user['Fdiscount']*$productnum;
      $goodsorder['discount_reason']=$user['Fdiscount_reason'];
      $goodsorder['paytotal']=$goodsorder['Ftotal']-$goodsorder['discount'];
     }

    //当前时间
   $nowtme=date('H');
   $nowtmes=date('H.i');

   $nowtme2=$nowtme+1;
  //时间段拼接，8-21点可选配送时间，21点后预约明天的时间
  /*if(8<=$nowtme && $nowtme<21){
     for($i=$nowtme;$i<21;$i++){
        $options.='<option value="'.$i.'">'.$i.':00</option>';      
     }
     for($k=$nowtme;$k<21;$k++){
        $options2.='<option value="'.($k+1).'">'.($k+1).':00</option>';      
     }
  }else if(0<=$nowtme && $nowtme<8){
     for($i=8;$i<21;$i++){
        $options.='<option value="'.$i.'">'.$i.':00</option>';      
     }
     for($k=8;$k<21;$k++){
        $options2.='<option value="'.($k+1).'">'.($k+1).':00</option>';       
     }
  }else{
     $options='<option>预约明日</option>';     
     $bid='12';
  }
       $this->assign('bid',$bid);*/
       //$this->assign('options2',$options2);
      
     // $this->assign('options',$options);    

//系统设置每天下单次数
  $daybegin=strtotime(date("Y-m-d"));
  $dayend=$daybegin+86400;   
  $settimes=$station->field('Fordertimes')->where(array('token'=>$FFtoken))->find();

     $settimesarray['Fusers']=$FFphone;
     $settimesarray['Ftoken']=$FFtoken;
     $settimesarray['Fstatus']=array('neq',0);
     $settimesarray['Fordertime']=array('between',array($daybegin,$dayend));
     $orderalltimes=$ordb->where($settimesarray)->count();

    $this->assign('orderalltimes',$orderalltimes);
    $this->assign('settimes',$settimes['Fordertimes']);
  
    $this->assign('daybegin',$daybegin);
    $this->assign('dayend',$dayend);
    $this->assign('nowtme',$nowtme);
    $this->assign('nowtme2',$nowtme2);


    $this->assign('rew',$rew);
   //优惠结束
   $this->assign('q',$q);
   $this->assign('goodsorder',$goodsorder);
// 用户信息
  //$user=M('wa_users')->where(array('Fusername'=>$FFphone,'Ftoken'=>$FFtoken))->find();

  //$this->assign('user',$user);
  //根据后台设置时间
  /*$gettimes=$station->field('Fstart_time,Fend_time')->where(array('token'=>$FFtoken))->find();
  $start=$gettimes['Fstart_time'];
  $end=$gettimes['Fend_time'];*/
  
  //$get_time1=$this->get_time($st_time,$e_time,$token);
  //public function get_time($start=8,$end=21,$token='uyezkd1457501171')
  
  //dump($stinfo['Fstart_time']);
  //dump($stinfo['Fend_time']);
  if($nowtmes>$e_time1){

  $get_time1="<span class='sele_type font5b'>水站营业时间已过</span>";
  }else {
    $get_time1=$this->get_time($st_time1,$e_time1,$token);
  }
  
  $this->assign('get_time',$get_time1);

  //活动抽奖判断 
   $praise=M('Wa_praisedset');
   $praisestatus=$praise->field('Fstatus,Fname,Ftimes,Fendtime')->find();
   if($praisestatus['Fstatus']=='1'){
     $daybegin=strtotime(date("Ymd"));  
   $dayend=$daybegin+86400;
   $choujwhere['Fusername']=session('Fcustom_user');
   $choujwhere['Ftoken']=$FFtoken;
   $choujwhere['Fcreatetime']=array('between',array($daybegin,$dayend));
    $countcj=M('Wa_praised')->where($choujwhere)->count();
  $activeon=$this->activeon($_GET['FFtoken']);

   if($activeon=='1'){
     // $this->assign('praisestatuson',$praisestatus['Fstatus']);
      if($countcj<3){
        if($_COOKIE['prizetime']){
            $pon='2';
        }else{
           $pon='1';
        }
       
      }else{
          $pon='2'; 
      }

   }else{
     // $this->assign('praisestatuson','2');
      $pon='2'; 
   }


 $this->assign('praisestatuson',$pon);
} 
   $this->display();
 }
//提交订单
 public function orderdon(){
 
   $token=$this->gettoken();
   $FFphone=$this->getphone();
   //$today=!empty($_POST['today']) ?$_POST['today']:'今天';
   //dump($_POST);exit;
   $Fpaytype=$_POST['Fpaytype'];   
   $wxuser=M('wxuser');
   $wa_users=M('wa_users');
  $usinfo=$wa_users->where(array('Ftoken'=>$token,'Fusername'=>$FFphone))->find();
 //  $Ffloorid=$usinfo['Ffloorid'];
 // if(empty($Ffloorid)){
 //   //$this->error('请选择宿舍楼');
 //    echo '请选择宿舍楼';
 // }
  // if(!empty($_POST['Faddress'])){
  //   $Faddress=$_POST['Faddress'];
  // }else{
    $Faddress=$usinfo['Faddress'];
  // }
  $Faddress=trim($Faddress);

  if(empty($Faddress) || $Faddress==''){
    // update by shitao 20161030 start
    // echo '地址有误';
    // exit();
    $post_address = $_POST['Faddress'];
    // 保存用户地址
    $wa_users->where(array('Fusername'=>$FFphone,'Ftoken'=>$token))->save(array('Faddress'=>$post_address));
    // update by shitao 20161030 end
  }

   $Fusername=$FFphone;

   if(empty($Fusername) || $Fusername==''){
    //$this->error('用户名不能为空');
    echo '用户名不能为空';
   }
   $Fgoodsname=$_POST['Fgoodsname'];
   $Fgoodsid=$_POST['Fgoodsid'];
   $Fnum=(int)$_POST['Fnum'];
   $spec=$_POST['spec'];
   $Fhours1=(int)$_POST['Fhours1'];
   $Fhours2=(int)$_POST['Fhours2'];
   $Fticket=$_POST['Fticket'];//水票订单标志
   // $Fhours3=(int)$_POST['Fhours3'];
   // $Fhours4=(int)$_POST['Fhours4'];
  //用户优惠
   if($_POST['discount']&&$_POST['discount']>0){
    $discount=$_POST['discount'];    
   }else{
    $discount=0;
   }
   //用户实付金额
   if($_POST['paytotal']&&$_POST['paytotal']>0){
    $paytotal=$_POST['paytotal'];    
   }else{
    $paytotal=0;
   }
   //上楼费
   if($_POST['overhead_cost']&&$_POST['overhead_cost']>0){
    $overhead_cost=$_POST['overhead_cost'];    
   }else{
    $overhead_cost=0;
   }

   $d=date('H',time());
     if($Fhours1>$Fhours2){    
      echo '请选择正确的时间';      
     exit;
   }
  if($Fhours2<$d){
     echo '订水时间已过，请明日再来';      
     exit;
  }

     $daybegin=strtotime(date("Ymd"));  
     $dayend=$daybegin+86400;
     $lstarray['Fordertime']=array('between',array($daybegin,$dayend));
     $lstarray['Fusers']=$Fusername;
     $lstarray['Ftoken']=$token;
     $lstarray['Fstatus']=array('neq',0);
     $latim=M('Wa_orders')->where($lstarray)->count();

     //系统设置订水次数
     $settimes=$wxuser->field('Fordertimes')->where(array('token'=>$token))->find();

     if($settimes['Fordertimes']<=$latim){
        echo '您一天内已订水'.$latim.'次';
        exit();
     }

    
       $timestaps=time();
        
        if(($_POST['Fhours1']-$Fhours1)==0.5){
          $Forder_time1=mktime($Fhours1,30,0,date('m'),date('d'),date('Y'));
        }else{
          $Forder_time1=mktime($Fhours1,0,0,date('m'),date('d'),date('Y'));
        }

        if(($_POST['Fhours2']-$Fhours2)==0.5){
          $Forder_time2=mktime($Fhours2,30,0,date('m'),date('d'),date('Y'));
        }else{
          $Forder_time2=mktime($Fhours2,0,0,date('m'),date('d'),date('Y'));
        }
    
    $date=date('m-d',$timestaps);
   $Fhours=date('H:i',$Forder_time1).'-'.date('H:i',$Forder_time2);
  $Fhours=$date.' / '.$Fhours;
  if($Fticket=='0'){
  //购非水票订单
   $pro=M('Product')->field('price,ga_label as shortname')->where(array('id'=>$Fgoodsid))->find();
  }else{
  //购水票订单
    $pro=M('wa_ticket')->field('Fprice as price,Fname as shortname,Fgoodsid,Fid')->where(array('Fid'=>$Fgoodsid))->find();
  }
   
  if(!$pro){
    //$this->error('请选择商品');
    echo '请选择商品';
    exit;
   }
   $Frice=$pro['price'];
   $shortname=$pro['shortname'];
   if(ereg("^[0-9]*[1-9][0-9]*$",$Fnum)!=1)//当不为整数时
{

    //$this->error('提交正确的数量');
  echo '数量不正确';
    exit;
}
 $od=M('Wa_orders');

//统计用户订单次数以及设置 优惠
   //$Wxuserms2=M('Wxuser');
   $u=$wxuser->field('types,num,id,uid')->where(array('token'=>$token))->find();

   $setnum=$u['num']-1;
   if($u['types']==1){
      $ordcount=$od->where(array('Fusers'=>$Fusername,'Ftoken'=>$token,'Fstatus'=>3,'Fbid'=>0,'Fticket'=>0))->count();
      if($ordcount>=$setnum){
         $rew="rew";
         $Ftotal=$Frice*($Fnum-1);
         $Frid=1;
      }else{
         $rew="norew";
        $Ftotal=$Frice*$Fnum;
        $Frid=0;
      }
    
      // $this->assign('rew',$rew);
      
   }else{
     $Ftotal=$Frice*$Fnum;
     $Frid=0;
   }
   //优惠结束
  
   $yCode = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J');
   $orderSn = $yCode[intval(date('Y')) - 2011] . strtoupper(dechex(date('m'))) . date('d') .substr(microtime(), 2, 5);
  
  $data=array(
    'Ftoken'=>$token,
    'Fpaytype'=>$Fpaytype,
    'Fusers'=>$Fusername,
    'Faddress'=>$Faddress,
    'Forderid'=>$orderSn,
    'Fstatus'=>1,
    'Ftotal'=>$Ftotal,
    'Fhours'=>$Fhours,
    'Fordertime'=>time(),
    'Fcreatetime'=>date("Y-m-d"),    
    'Frid'=>$Frid,
    'Forder_time1'=>$Forder_time1,
    'Forder_time2'=>$Forder_time2,
    'Fdiscount'=>$discount,
    'Fpaytotal'=>$paytotal,
    'overhead_cost'=>$overhead_cost
    );
    //'Ffloorid'=>$Ffloorid,
    //派单时间不用'Flast_time'=>time(),
  //水票支付判断水票数量
  if($Fpaytype==0){
  $tl=M('wa_ticketlog')->where(array('Fuserid'=>$usinfo['Fid'],'Ftoken'=>$token,'Fgoodsid'=>$Fgoodsid,'Fpay'=>1))->field('sum(Fnum) as num')->find();    
    if(intval($tl['num'])<$Fnum){
      echo '水票不足，请选择其他支付方式';
      exit;
    }
    $data['Fbid']='1';
    $data['Ftype']='1';
  }
       
  if($Fticket=='1'){
  //购水票订单
    $data['Fticket']='1';
  }else{
  //购非水票订单
    $data['Fticket']='0';
  }
  //留言
  if($_POST['liuyan']!==''){
    $data['Fliuyan']=$_POST['liuyan'];
  }
  //更换的手机号
  if($_POST['Fphone']!=='undefined'){
    $data['Fphone']=$_POST['Fphone'];
  }else{
    $data['Fphone']=$Fusername;
  }
  //是否扫码订单
  if(!$_POST['FFqid']){
    $data['isFqid']=1;
  }else{
    $data['isFqid']=0;
  }
  $res=$od->add($data);
  if(!$res){
    return '下单失败';
  }  
  //购实物,水票支付订单
  if($Fpaytype==0){
    //可用水票数量     
    $tcklog_pay=array(
      'Fnum'=>'-'.$Fnum,
      'Fname'=>$Fgoodsname,
      'Fcreate_time'=>time(),
      'Fgoodsid'=>$Fgoodsid,      
      'Fphone'=>$Fusername,
      'Fuserid'=>$usinfo['Fid'],
      'Ftoken'=>$token,
      'Foid'=>$res,
      'Fprice'=>$Frice,
      'Fbalance'=>$tl['num']-$Fnum,
      'Fpay'=>1
      );
    $ticlog=M('wa_ticketlog')->add($tcklog_pay);
    //更新用户水票数量
    $wa_users->where(array('Fusername'=>$Fusername,'Ftoken'=>$token))->setDec('Fwanum',$Fnum);

  }
  //接口

   //$url='http://www.eyuanonline.com:3000/water/'.$token.'/0';
  
     //$url='api.fangweihao.com:3000/water/'.$token.'/0';
    // $url=C('my_api').$token.'/0';
    //$rest=url_get($url,$data);
    //$mes=json_decode($rest);
    // if($mes->status!=200){
       //$this->error('接口调用失败');
      // echo $url;
      // exit;
    // }
  //文档接口 http://www.eyuanonline.com:8887/api/push/alias/?k=密钥&timestamp=时间戳&signature=密钥签名&alias=参数
   // $k=$u['id'];
   //$url2= 'http://www.eyuanonline.com:8887/api/push/alias/?alias='.$token;
  // $rest2=url_get($url);
  //$rest2=url_post($url2);
  // var_dump($url2);

  $datagoods=array(
   'Forderid'=>$orderSn,
   'Fgoodsid'=>$Fgoodsid,//商品id或水票套餐id
   'Fgoodsname'=>$Fgoodsname,
   'Fspec'=>$spec,
   'Fprice'=>$Frice,
   'Ftotal'=>$Ftotal,
   'Fnum'=>$Fnum,
   'Fcreate_time'=>time(),
   'Foid'=>$res,
   'shortname'=>$shortname
    );
   $og=M('Wa_ordergoods');
   $og->add($datagoods);
   //购水票订单ticketlog表记录
   if($Fticket=='1'){
    
    $ticketlog=array(
      'Fnum'=>$Fnum*intval($spec),
      'Fname'=>$pro['shortname'],//套餐名
      'Fcreate_time'=>time(),
      'Fgoodsid'=>$pro['Fgoodsid'],
      'Fticketid'=>$pro['Fid'],
      'Fphone'=>$Fusername,
      'Fuserid'=>$usinfo['Fid'],
      'Ftoken'=>$token,
      'Foid'=>$res,
      'Fprice'=>$Frice,
      'Fprice_ap'=>$Frice,
      //支付后更新可用值'Fbalance'=>intval($tl['num'])+$Fnum*intval($spec)
      );
    $ticlog=M('wa_ticketlog')->add($ticketlog);

    //更新用户水票数量
    /*if($ticlog){
      $wa_users->where(array('Fusername'=>$Fusername,'Ftoken'=>$token))->setInc('Fwanum',$ticketlog['Fnum']);
    }else{
      return '购买水票失败';
    }*/
   
   }
   //更新用戶表最後一次下單時間
   
   $wa_users->where(array('Fusername'=>$Fusername,'Ftoken'=>$token))->save(array('Flasttime'=>time()));

   $this->write_recomlog($token,$Fusername,$orderSn);

  
//下单成功后个推推送信息和模板消息发送
    if($Fpaytype<2){//线下支付
      //if($Fticket!=='1'){
         //传入cliendid;
        $cid=$wxuser->where(array('token'=>$token))->field('clientid')->find();
        $gt=new GeTui();
        $gt->setcid($cid);
        $gt->pushMessageToSingle(); 
        //}
        //推送内容在GeTui.class.php中设置
      //现金支付和水票支付订单给老板的H5端发送模板消息
      $this->templatecs($token,$res);    
    }
  if($res){
    //更新Fbid 状态
      if($rew=='rew'){    
      $od->where(array('Fusername'=>$Fusername,'Ftoken'=>$token))->save(array('Fbid'=>1));
      // echo $od->getlastSql();
      }     
      //$this->redirect(U('Store/orders',array('FFtoken'=>$token,'FFphone'=>$Fusername,'FFqid'=> session('FFqid'))));
      //抽奖活动的设置
      $dbset=M('Wa_praisedset');
      $sta=$dbset->field('Fstatus')->find();
      if($sta['Fstatus']=='1'){
         session('prizetime',2);

         //判断水站
         $activeon=$this->activeon($token);
         if($activeon=='1'){
            $daybegin=strtotime(date("Ymd"));  
       
            $dayend=$daybegin+86400;
            setcookie('prizetime','2',$dayend);
         }  

      }
      session('oid',$res);
      echo 'success';

  }
 
 }
 //测试模板消息
 public function templatecs($Ftoken,$orderid){
  //$Ftoken=$_GET['FFtoken'];//
  //$orderid=$_GET['orderid'];
  $openid=M('wxuser')->where(array('token'=>$Ftoken))->field('openid')->find();
  $order=M('wa_orders')->where(array('Fid'=>$orderid))->field('Forderid,Fphone,Faddress,Fpaytotal')->find();
  $goodsinfo=M('wa_ordergoods')->where(array('Foid'=>$orderid))->field('Fgoodsname,Fnum,Ftotal')->find();
  if($order['Fpaytotal']>0){$goodsinfo['Ftotal']=$order['Fpaytotal'];}
  $order_info=$goodsinfo['Fgoodsname'].'×'.$goodsinfo['Fnum'].'(￥'.$goodsinfo['Ftotal'].')';
  $wechat= new TPWechat($this->options);
  $access_token=$wechat->checkAuth(); 
  //订单信息
  
  //$tpl_id='Q89pU4cZ_pPs6AzhCrR6-tlUbBZoF4fvLVRFh5Lqk2w';
  //$tpl_id='dyNVD6upbq8DjZV8TZpnYIk8KUIV12xYFyxR45USQWY';
  $tpl_id='IYlnqSgYUnYZn3fa7WPR-QCRqddA0R-koBEt5BBJVYo';
  //$time=date('Y-m-d H:i:s',time());
   
  $message=[
     'touser'=>$openid['openid'],
     'template_id'=>$tpl_id,
     'data'=>[
         'first'=>['value'=>'您有新的码上订水订单！'],
         'keyword1'=>['value'=>$order['Forderid']],
         'keyword2'=>['value'=>$order_info],
         'keyword3'=>['value'=>$order['Fphone']], 
         'keyword4'=>['value'=>$order['Fphone']],         
         'keyword5'=>['value'=>$order['Faddress']],
         'remark'=>['value'=>'请及时配送！']
     ]
  ];
  $res=$wechat->sendTemplateMessage($message);  
  return $res;
 }

 public function templatecs2($Ftoken,$orderid){
  //$Ftoken=$_GET['FFtoken'];
  $openid=M('wxuser')->where(array('token'=>$Ftoken))->field('openid')->find();
  $wechat= new TPWechat($this->options);
  $access_token=$wechat->checkAuth(); 
  /*dump($openid);
  dump($orderid);
  dump($access_token);exit;*/
  //订单信息
  $order=M('wa_orders')->where(array('Fid'=>$orderid))->field('Forderid,Fphone,Faddress')->find();
  //$tpl_id='Q89pU4cZ_pPs6AzhCrR6-tlUbBZoF4fvLVRFh5Lqk2w';
  $tpl_id='dyNVD6upbq8DjZV8TZpnYIk8KUIV12xYFyxR45USQWY';
  $time=date('Y-m-d H:i:s',time());
  
  $message=[
     'touser'=>$openid['openid'],
     'template_id'=>$tpl_id,
     'data'=>[
         'first'=>['value'=>'您有新的码上订水订单！'],
         'keyword1'=>['value'=>$order['Forderid']],
         'keyword2'=>['value'=>$time],
         'keyword3'=>['value'=>$order['Fphone']],         
         'keyword4'=>['value'=>$order['Faddress']],
         'remarks'=>['value'=>'请及时配送！']
     ]
  ];
  $res=$wechat->sendTemplateMessage($message);
  return $res;
 }
//微信预支付页面
 public function orderdown1(){
  $token=$this->gettoken();
  $FFphone=$this->getphone();
  if($oid = $_GET['oid']){
    $oid = $_GET['oid'];
  }else{
    $oid = session('oid');
  }
   
  //dump($oid);exit;
$orderinfo=M('wa_orders')->where(array('Fid'=>$oid))->find();

if($orderinfo['Fpaytotal']>0){
  $totalfee=$orderinfo['Fpaytotal']*100;
}else{
  $totalfee=$orderinfo['Ftotal']*100;
}
//页面数据
$this->assign('orderinfo',$orderinfo);
$this->display();
 }
public function orderdown(){
  ini_set('date.timezone','Asia/Shanghai');
//error_reporting(E_ERROR);
  Vendor('Wxpay.lib.WxPay','','.Api.php');
  Vendor('Wxpay.example.WxPay','','.JsApiPay.php');
  //Vendor('Wxpay.example','','log.php');
  require_once(dirname(__FILE__).'/'.'../../ORG/log.php');
//require_once(dirname(__FILE__).'/'.'../../ORG/WxPay.JsApiPay.php');
//require_once "../ORG/WxPay.Api.php";
//require_once "../../WxPay.JsApiPay.php";
//require_once '../../log.php';
//通过orderid查询对应的订单信息
  $token=$this->gettoken();
  $FFphone=$this->getphone();
  if($oid = $_GET['oid']){
    $oid = $_GET['oid'];
  }else{
    $oid = session('oid');
  }
   
  //dump($oid);exit;
$orderinfo=M('wa_orders')->where(array('Fid'=>$oid))->find();
if($orderinfo['Fpaytotal']>0){
  $totalfee=$orderinfo['Fpaytotal']*100;
}else{
  $totalfee=$orderinfo['Ftotal']*100;
}

//页面数据
$this->assign('orderinfo',$orderinfo);
//初始化日志
$logHandler= new CLogFileHandler("../logs/".date('Y-m-d').'.log');
$log = Log1::Init($logHandler, 15);

//打印输出数组信息
/*function printf_info($data)
{
    foreach($data as $key=>$value){
        echo "<font color='#00ff55;'>$key</font> : $value <br/>";
    }
}*/

//①、获取用户openid
$tools = new JsApiPay();
$openId = $tools->GetOpenid();
//dump($openId);exit;
//②、统一下单
$input = new WxPayUnifiedOrder();
$input->SetBody("本次订单金额");//设置商品或支付单简要描述
$input->SetAttach("订单编号：".$orderinfo['Forderid']);//设置附加数据，在查询API和支付通知中原样返回，该字段主要用于商户携带订单的自定义数据
  $orderId=WxPayConfig::MCHID.date("YmdHis");
$input->SetOut_trade_no($orderId);//设置商户系统内部的订单号

$input->SetTotal_fee($totalfee);//设置订单总金额
$input->SetTime_start(date("YmdHis"));//设置订单生成时间
$input->SetTime_expire(date("YmdHis", time() + 600));//设置订单失效时间
$input->SetGoods_tag("水品信息");//设置商品标记，代金券或立减优惠功能的参数
$input->SetNotify_url("http://paysdk.weixin.qq.com/example/notify.php");//设置接收微信支付异步通知回调地址
$input->SetTrade_type("JSAPI");
$input->SetOpenid($openId);
$order = WxPayApi::unifiedOrder($input);
//echo '<font color="#f00"><b>统一下单支付单信息</b></font><br/>';
//printf_info($order);
//dump($order);exit;
$jsApiParameters = $tools->GetJsApiParameters($order);//获取jsapi支付的参数
$this->assign('jsApiParameters',$jsApiParameters);
$this->assign('orderId',$orderId);
//dump($jsApiParameters);
//获取共享收货地址js函数参数
$editAddress = $tools->GetEditAddressParameters();
$this->assign('editAddress',$editAddress);
//return 'success';
//dump($editAddress);
$this->display();
//③、在支持成功回调通知中处理成功之后的事宜，见 notify.php
/**
 * 注意：
 * 1、当你的回调地址不可访问的时候，回调通知会失败，可以通过查询订单来确认支付是否成功
 * 2、jsapi支付时需要填入用户openid，WxPay.JsApiPay.php中有获取openid流程 （文档可以参考微信公众平台“网页授权接口”，
 * 参考http://mp.weixin.qq.com/wiki/17/c0f37d5704f0b64713d5d2c37b468d75.html）
 */
}
//微信支付回调
/*public function wx_notify(){
  Vendor('Wxpay.example','','notify.php');
  $notify=new PayNotifyCallBack();  
//接收微信返回的数据数据,返回的xml格式
   $xmlData = file_get_contents('php://input');
   //将xml格式转换为数组
   $data = $notfiy->FromXml($xmlData);
   //用日志记录检查数据是否接受成功，验证成功一次之后，可删除。
   $file = fopen('./log.txt', 'a+');
   fwrite($file,var_export($data,true));
   //为了防止假数据，验证签名是否和返回的一样。
   //记录一下，返回回来的签名，生成签名的时候，必须剔除sign字段。
   $sign = $data['sign'];
   unset($data['sign']);
  if($sign == $this->getSign($data)){
    
    //签名验证成功后，判断返回微信返回的
    if ($data['result_code'] == 'SUCCESS') {
      
        //根据返回的订单号做业务逻辑
        $arr = array(
               'Ftype' => 1,
            );
        $re = M('wa_orders')->where(array('Forderid'=>$data['out_trade_no']))->save($arr);
        //处理完成之后，告诉微信成功结果！
        if($re){
          echo '<xml>
      <return_code><![CDATA[SUCCESS]]></return_code>
      <return_msg><![CDATA[OK]]></return_msg>
      </xml>';
      $this->orderover();
        }
    }else{//支付失败，输出错误信息
        $file = fopen('./log.txt', 'a+');
        fwrite($file,"错误信息：".$data['return_msg'].date("Y-m-d H:i:s"),time()."\r\n");    
    }
  }else{
    $file = fopen('./log.txt', 'a+');
    fwrite($file,"错误信息：签名验证失败".date("Y-m-d H:i:s"),time()."\r\n");    
  }
}*/
public function wxord_check(){
   $oid=$_GET['oid'];
   $ispay=M('wa_orders')->where(array('Fid'=>$oid))->field('Ftype')->find();
  if($ispay['Ftype']==1){
    return false;
  }
  Vendor('Wxpay.lib.WxPay','','.Api.php');
  $tradeId = $_GET["out_trade_no"];
  if(isset($tradeId) && $tradeId != "")
{
    $input = new WxPayOrderQuery();
    $input->SetOut_trade_no($tradeId); // 设置好要查询的订单
    $order = WxPayApi::orderQuery($input); // 进行查询
    //var_dump($order);exit; // 打印出订单信息
    
      $token=$_GET['FFtoken'];
      $phone=$_GET['FFphone'];
      //dump($order);exit;    
    if($order['trade_state']=='SUCCESS'){//NOTPAY
      //更新订单表支付状态
      $wa_orders=M('wa_orders');
      $wa_ticketlog=M('wa_ticketlog');
      $arr_oid=array('Fid'=>$oid);
      $arroid=array('Foid'=>$oid);
      //个推
      if($Fticket!=='1'){
         //传入cliendid;
        $cid=M('wxuser')->where(array('token'=>$token))->field('clientid')->find();
        $gt=new GeTui();
        $gt->setcid($cid);
        $gt->pushMessageToSingle(); 
        }
      //$this->templatecs($token,$oid);发送模板消息
          
      $res=$wa_orders->where($arr_oid)->save(array('Ftype'=>1,'transaction_id'=>$order['transaction_id']));
      //购水票订单更新水票Fpay,金额Fticket_balance      
      $ord=$wa_orders->where($arr_oid)->field('Fticket,Ftotal')->find();
      //dump($ord['Fticket']);
      if($ord['Fticket']==1){
        //更新订单为已完成
        $wa_orders->where($arr_oid)->save(array('Fstatus'=>3));
        //Fbalance 水票余量值暂不更新，只更新用户的水票余量
        //$goodsid=M('Wa_ordergoods')->where($arroid)->field('Fgoodsid')->find();
        //$Fbalance=$wa_ticketlog->where(array('Ftoken'=>$token,'Fphone'=>$phone,'Fpay'=>1,'Fgoodsid'=>$goodsid['Fgoodsid']))->field('sum(Fnum) as num')->find();
        $ticord=$wa_ticketlog->where($arroid)->field('Fnum')->find();

        $ticket_balance=$wa_orders->where(array('Ftoken'=>$token,'Fticket'=>1,'Ftype'=>1))->field('sum(Ftotal) as total')->find();

        $arr=array(
          'Fpay'=>1,          
          'Fticket_balance'=>$ticket_balance['total']
          );        
        $wa_ticketlog->where($arroid)->save($arr);
        //更新用户水票余量
        M('wa_users')->where(array('Fusername'=>$phone,'Ftoken'=>$token))->setInc('Fwanum',$ticord['Fnum']);
        //更新水站老板表tp_wxuser的ticket_account
        M('wxuser')->where(array('token'=>$token))->setInc('ticket_account',$ord['Ftotal']);//save(array('ticket_account'=>$ticket_balance['total']));
        //dump($arr);exit;
      }else{
        //更新wa_orders表的Fbalance
        $Fbalance_o=$wa_orders->where(array('Ftoken'=>$token,'Fticket'=>0,'Fpaytype'=>2,'Ftype'=>1))->field('sum(Ftotal) as total','sum(Fdiscount) as discount')->find();
        $Fbalance_t=$Fbalance_o['total']-$Fbalance_o['discount'];
        $wa_orders->where($arr_oid)->save(array('Fbalance'=>$Fbalance_t));
        //更新水站老板表tp_wxuser的cash_account
        //M('wxuser')->where(array('token'=>$token))->save(array('cash_account'=>$Fbalance_o['total']));
      }
      if($res>0){        
        $this->redirect(U('Store/orderover',array('FFtoken'=>$token,'oid'=>$oid,'FFphone'=>$FFphone)));
      }else{
        $this->error('支付成功，但订单状态更新失败');
        $this->redirect(U('Store/orders',array('FFtoken'=>$token,'FFphone'=>$FFphone)));
      }
    }else{
      $this->error('未支付成功');
    }
}
}

 public function ticketcheck(){  
  $goodsid=$_POST['gid'];
  $token=$_POST['token'];
  $phone=$_POST['user'];
  $Fqid=$_POST['Fqid'];
  
  $uid=M('wa_users')->where(array('Fusername'=>$phone,'Ftoken'=>$token))->field('Fid')->find();  
  
  $tl=M('wa_ticketlog')->where(array('Fuserid'=>$uid['Fid'],'Ftoken'=>$token,'Fgoodsid'=>$goodsid,'Fpay'=>1))->field('sum(Fnum) as num')->find();
  
  $this->ajaxReturn($tl['num']);
   
 }
//下单更换手机号
  public function phone_chose(){
    
    $Fuser=$this->getphone();
    $token=$this->gettoken();
    $product=$_GET['product'];
    $productnum=$_GET['productnum'];
    //如果客户未登录或注册，先注册或登录
    //dump($Fuser);
    
    if(!$Fuser||!$token){      
      $this->redirect(U('Reg/slogin',array('FFtoken'=>$token,'FFqid'=>$FFqid,'product'=>$product,'productnum'=>$productnum)));
      exit;
    }
    //同一个手机注册不同站点，手机号在缓存问题
    $isFuser=M('wa_users')->where(array('Fusername'=>$Fuser,'Ftoken'=>$token))->find();
    if(!$isFuser){
       $this->error('手机号未注册本水站，正在为您跳转注册页面...',U('Reg/station',array('FFtoken'=>$token,'FFphone'=>$Fusers,'product'=>$product,'productnum'=>$productnum)));
    }
    $phoneNo=$this->_get('phoneNo');
    //$phoneNo=$_GET['FFphone'];
    //dump($phoneNo);exit;
    $data['Fphone']=$phoneNo;
    $data['Ftoken']=$token;
    $data['Fuser']=$Fuser;
    $data['Fcreate_time']=time();
    $phoneli=D('wa_home_list')->where(array('Ftoken'=>$token,'Fuser'=>$Fuser))->select();
    if($phoneNo){
      //判断不重复            
        foreach($phoneli as $v){
          if($v['Fphone']==$phoneNo){
            $this->ajaxReturn('号码已经存在');
          }          
        };
        
      $add=D('wa_home_list')->add($data);
      if($add){
        $this->ajaxReturn('true');
      }else{
        $this->ajaxReturn('号码添加失败');
      }
    }
    //删除号码
    $phoneid=$this->_get('phoneid');
    if($phoneid){
      $phone_del=D('wa_home_list')->delete($phoneid);
      $this->ajaxReturn('true');
    }
    $this->assign('phones',$phoneli); 
    //地址
    $address=M('wa_users')->where(array('Ftoken'=>$token,'Fusername'=>$Fuser))->field('Fcity1,Fcity2,Fcity3,Faddress')->find();
    $whereor['Fid']=array('in',$address);
    //dump($whereor);exit;
    if($whereor['Fid'][1]){
      $city_name=M('tn_city')->where($whereor)->field('Fid,Fname')->select();
      $addrinfo=$city_name[0]['Fname'].$city_name[1]['Fname'].$city_name[2]['Fname'].$address['Faddress'];
      $this->assign('address',$addrinfo);
    }else{
      $this->assign('address',$address['Faddress']);
    }    
    //更换手机号js处理
    $city1 = D('tn_city')->where("Flevel = 0")->order('Fid ASC')->select();
        $this->assign('city1', $city1);
  //地址分配
    
    $this->assign('city_name',$city_name);
    //$this->assign('address',$address);
    $this->display();
  }
  //phone_chose页面的地址ajax方法
  public function phone_chose_addr(){
    //echo $_POST;exit;
    $token=$_POST['token'];
    $user=$_POST['user'];
    $data['Fcity1']=$_POST['city1'];
    $data['Fcity2']=$_POST['city2'];
    $data['Fcity3']=$_POST['city3'];
    $data['Faddress']=$_POST['Faddress'];
    if($_POST['Faddress']){
      $res=M('wa_users')->where(array('Fusername'=>$user,'Ftoken'=>$token))->save($data);
      if($res){
        echo 'success';
      }else{
        echo 'error';
      }      
    }else{
      echo 'error';
    }
  }
  //用户注册
  public function start(){
    $token=$this->gettoken();
    $this->assign('token',$token);
    $this->display();
  }
//个人中心个人信息修改
  public function my_edit(){
    $Fuser=$this->getphone();
    $token=$this->gettoken();

    if(!$Fuser||!$token){
      $this->redirect(U('Reg/slogin',array('FFtoken'=>$token,'FFphone'=>$Fusers)));
      exit;
    }
    $phoneNo=$this->_get('phoneNo');
    $data['Fphone']=$phoneNo;
    $data['Ftoken']=$token;
    $data['Fuser']=$Fuser;
    $data['Fcreate_time']=time();
    $phoneli=D('wa_home_list')->where(array('Ftoken'=>$token,'Fuser'=>$Fuser))->select();
    if($phoneNo){
      //判断不重复 
           
        foreach($phoneli as $v){
          if($v['Fphone']==$phoneNo){
            $this->ajaxReturn('号码已经存在');
          }          
          
        };
        
      $add=D('wa_home_list')->add($data);
      if($add){
        $this->ajaxReturn('true');
      }else{
        $this->ajaxReturn('号码添加失败');
      }
    }
 
    //删除号码
    $phoneid=$this->_get('phoneid');
    if($phoneid){
      $phone_del=D('wa_home_list')->delete($phoneid);
      $this->ajaxReturn('true');
    }

    $this->assign('phones',$phoneli);    

    $city1 = D('tn_city')->where("Flevel = 0")->order('Fid ASC')->select();
        $this->assign('city1', $city1);
  //地址分配
    $address=D('wa_users')->where(array('Ftoken'=>$token,'Fusername'=>$Fuser))->field('Fcity1,Fcity2,Fcity3,Faddress')->find();
    if(!$address){
      $this->error('您登录的号码未注册本水站,正在跳转注册页面...',U('Reg/station',array('FFtoken'=>$token,'FFphone'=>$Fusers)));
    }else{
      $where['Fid']=array('in',$address);
          
      $city_name=D('tn_city')->where($where)->field('Fid,Fname')->select();
      //dump($city_name);exit;
      $this->assign('city_name',$city_name);
    
      $this->assign('address',$address);
    }
    //接收地址和密码修改
    if(IS_POST){
      if($_POST['new_pass']!==$_POST['con_pass']){
          $this->error('重填密码和修改的登录密码不一致');
      }else{
        $equ=$_POST['city1']==$address['Fcity1']&&$_POST['city2']==$address['Fcity2']&&$_POST['city3']==$address['Fcity3']&&$_POST['Faddress']==$address['Faddress'];
        //dump($equ);
        if($_POST['new_pass']==''&& $equ){
            $this->redirect('Store/user', array('FFtoken'=>$token,'FFphone'=>$Fuser), 0, '');
        }else{
          $ndata['Fcity1']=$_POST['city1'];
          $ndata['Fcity2']=$_POST['city2'];
          $ndata['Fcity3']=$_POST['city3'];
          $ndata['Faddress']=$_POST['Faddress'];
          $ndata['Fpassword']=md5($_POST['new_pass']);
          $new_rec=D('wa_users')->where(array('Ftoken'=>$token,'Fusername'=>$Fuser))->save($ndata);
          $this->redirect('Store/user', array('FFtoken'=>$token,'FFphone'=>$Fuser), 0, '');
        }
      }
    }
    $this->display();
  }
//获取省市地址
/**
     * 获取第二层城市
     * @return [type] [description]
     */
    public function get_city2()
    {
        $city1 = $this->_get('city1');
        $city2 = D('tn_city')->where("Flevel = 1 and Fpid =".$city1)->order('Fid ASC')->select();
        // $this->assign('city2', $city2);
        // $this->success("");
        $this->ajaxReturn($city2);

    }
    /**
     * 获取第3层城市
     * @return [type] [description]
     */
    public function get_city3()
    {
        $city2 = $this->_get('city2');
        $city3 = D('tn_city')->where("Flevel = 2 and Fpid =".$city2)->order('Fid ASC')->select();
        $this->ajaxReturn($city3);
    }
//实物订单和水票订单合并函数
  public function comorder($orders){
    //改水票订单
    $order=M('wa_orders');
    foreach ($orders as $k => $v) {
      if($v['Fticket']==1){
        $orid=$v['Fid'];//订单id
        $tikord=$order->join('tp_wa_ticketlog as tl on tp_wa_orders.Fid=tl.Foid','left')->join('tp_product as p on tl.Fgoodsid=p.id','left')->where(array('tp_wa_orders.Fid'=>$orid))->field('tl.Fnum,tl.Fgoodsid as Fgoodsid,p.logourl')->find();
        $v['Fnum']=$tikord['Fnum'];
        $v['Fgoodsid']=$tikord['Fgoodsid'];
        $v['logourl']=$tikord['logourl'];
        //dump($v);
      }
      $rorders[]=$v;
      
    }
    //dump($rorders);exit;
    return $rorders;
  }
 public function orders(){
    //幻灯片
  $FFphone=$_GET['FFphone'];
  $FFtoken=$_GET['FFtoken'];
  $flash=M('Storeflash');   
  $station=M('wxuser')->where(array('token'=>$FFtoken))->field('province,city')->find();
  $flashwhere=array('attr'=>1,'province'=>$station['province'],'city'=>$station['city']);
  $res2=$flash->field('url,img,info')->where($flashwhere)->order('id desc')->limit(3)->select();   
  $this->assign('res2',$res2);    
    
    if($FFphone && $FFtoken){
    $order=M('wa_orders');
    //全部订单
    $allorders=$order->join('tp_wa_ordergoods as og on tp_wa_orders.Fid=og.Foid','left')->join('tp_product as p on og.Fgoodsid=p.id','left')->where("tp_wa_orders.Ftoken='".session('FFtoken')."' and tp_wa_orders.Fusers='".session('FFphone')."'")->field('tp_wa_orders.*,og.Fgoodsname as Fgoodsname,og.Fnum as Fnum,og.Fgoodsid as Fgoodsid,p.logourl')->order('tp_wa_orders.Fordertime desc')->limit(0,8)->select();
    $cmallorders=$this->comorder($allorders);      
    
    //已完成订单
    $orders3=$order->alias('o')->join('tp_wa_ordergoods as og on o.Fid=og.Foid','left')->join('tp_product as p on og.Fgoodsid=p.id','left')->where("o.Ftoken='".session('FFtoken')."' and o.Fstatus=3 and o.Fusers='".session('FFphone')."'")->field('o.*,og.Fgoodsname as Fgoodsname,og.Fnum as Fnum,og.Fgoodsid as Fgoodsid,p.logourl')->order('o.Fordertime desc')->limit(0,8)->select();
    $cmorders3=$this->comorder($orders3);
    //未派送订单
    $orders1=$order->alias('o')->join('tp_wa_ordergoods as og on o.Fid=og.Foid','left')->join('tp_product as p on og.Fgoodsid=p.id','left')->where("o.Ftoken='".session('FFtoken')."' and o.Fstatus =1 and o.Fusers='".session('FFphone')."'")->field('o.*,og.Fgoodsname as Fgoodsname,og.Fnum as Fnum,og.Fgoodsid as Fgoodsid,p.logourl')->order('o.Fordertime desc')->select();
    $cmorders1=$this->comorder($orders1);
    //已派件
   $orders2=$order->alias('o')->join('tp_wa_ordergoods as og on o.Fid=og.Foid','left')->join('tp_product as p on og.Fgoodsid=p.id','left')->where("o.Ftoken='".session('FFtoken')."' and o.Fstatus =2 and o.Fusers='".session('FFphone')."'")->field('o.*,og.Fgoodsname as Fgoodsname,og.Fnum as Fnum,og.Fgoodsid as Fgoodsid,p.logourl')->order('o.Fordertime desc')->select();
   $cmorders2=$this->comorder($orders2);
    // foreach($orders2 as $k2=>$v2){
      
    //   $orlogo2=M('Product')->field('logourl')->where(array('id'=>$v2['Fgoodsid']))->find();
    //    $orders2[$k2]['logourl']=$orlogo2['logourl'];
    // }

    // foreach($orders1 as $k1=>$v1){
      
    //    $orlogo1=M('Product')->field('logourl')->where(array('id'=>$v1['Fgoodsid']))->find();
  
    //    $orders1[$k1]['logourl']=$orlogo1['logourl'];
    // }
   
    $cont3=$order->field('count(Fid) as count3')->where(array('Ftoken'=>$FFtoken,'Fusers'=>$FFphone,'Fstatus'=>3))->find();
    $cont2=$order->field('count(Fid) as count2')->where("Ftoken='".$FFtoken."' AND Fusers='".$FFphone."' AND Fstatus =2")->find();
    $cont1=$order->field('count(Fid) as count1')->where("Ftoken='".$FFtoken."' AND Fusers='".$FFphone."' AND Fstatus =1")->find();
    $allcont=$order->field('count(Fid) as allcount')->where("Ftoken='".$FFtoken."' AND Fusers='".$FFphone."' AND Fstatus < 4")->find();
  }
    $this->assign('cont2',$cont2['count2']); 
    $this->assign('cont1',$cont1['count1']); 
    $this->assign('cont3',$cont3['count3']); 
    $this->assign('allcont',$allcont['allcount']);
    $this->assign('orders2',$cmorders2);
    $this->assign('orders1',$cmorders1);
    $this->assign('orders3',$cmorders3);
    $this->assign('allorders',$cmallorders);
    //$this->assign('bid','orders');
    //$this->assign('Fusers',$Fusers);
  
    $this->display();

 }
public function ordersload(){
 $offset=$_GET['offset'];
 $pagesize=$_GET['pagesize'];
 $order=M('wa_orders'); 

    $ordersall=$order->join('tp_wa_ordergoods on tp_wa_orders.Fid=tp_wa_ordergoods.Foid','left')->join('tp_product on tp_wa_ordergoods.Fgoodsid=tp_product.id','left')->where("tp_wa_orders.Ftoken='".session('FFtoken')."' and tp_wa_orders.Fusers='".session('FFphone')."'")->field('tp_wa_orders.*,tp_wa_ordergoods.Fgoodsname as Fgoodsname,tp_wa_ordergoods.Fnum as Fnum,tp_wa_ordergoods.Fgoodsid as Fgoodsid,tp_product.logourl')->order('tp_wa_orders.Fordertime desc')->limit($offset,$pagesize)->select();
    $cmordersall=$this->comorder($ordersall);
    //dump($orders1);exit;
    $this->assign('ordersall',$cmordersall);
    $this->display();

}

public function ordersload2(){
 $offset=$_GET['offset'];
 $pagesize=$_GET['pagesize'];
 $order=M('wa_orders'); 

    $ordersld2=$order->join('tp_wa_ordergoods on tp_wa_orders.Fid=tp_wa_ordergoods.Foid','left')->join('tp_product on tp_wa_ordergoods.Fgoodsid=tp_product.id','left')->where("tp_wa_orders.Ftoken='".session('FFtoken')."' and tp_wa_orders.Fstatus=3 and tp_wa_orders.Fusers='".session('FFphone')."'")->field('tp_wa_orders.*,tp_wa_ordergoods.Fgoodsname as Fgoodsname,tp_wa_ordergoods.Fnum as Fnum,tp_wa_ordergoods.Fgoodsid as Fgoodsid,tp_product.logourl')->order('tp_wa_orders.Fordertime desc')->limit($offset,$pagesize)->select();
   $cmordersld2=$this->comorder($ordersld2);
    $this->assign('orders2',$cmordersld2);

    $this->display();

}
 //订单异步刷新

public function orderwwc(){
    $order=M('Wa_orders');
    $orders=$order->join('tp_wa_ordergoods on tp_wa_orders.Fid=tp_wa_ordergoods.Foid')->where("tp_wa_orders.Ftoken='".session('FFtoken')."' and tp_wa_orders.Fstatus !=3 and tp_wa_orders.Fstatus!=0 and tp_wa_orders.Fusers='".session('FFphone')."'")->field('tp_wa_orders.*,tp_wa_ordergoods.Fgoodsname as Fgoodsname,tp_wa_ordergoods.Fnum as Fnum ')->order('tp_wa_orders.Fordertime desc')->select();
      
   //   foreach($orders as $k=$v){
   //       $str="";
   //       $str.=
   //      <div class="dd_list <if condition='$item[Fticket] eq "1"' >bg_list</if>">
   //      <div class="dd_list_left" style="width:46%;">
   //          <div class="dd_sz_name" style="font-size:2.5rem" >{Saivi:$item.Fgoodsname}</div>
   //          <div class="dd_price"  style="font-size:2.5rem"><if condition='$item[Fticket] eq "1"' >{Saivi:$item["Fnum"]}张/</if>金额:{Saivi:$item.Ftotal}
   //          <span style="color:#000;"><if condition='$item[Fticket] eq "1"' >【水票】</if></span>
   //          </div>
   //      </div>
   //      <div class="dd_list_middle" style="width:20%;">
   //          <div class="dd_sz_name"  style="font-size:2.5rem">{Saivi:$item.Fordertime|date="m/d",###}</div>
   //          <div class="dd_sz_name" style=" line-height:0px; text-indent:20px; color:#000;font-size:2.5rem">{Saivi:$item.Fordertime|date="H:i",###}</div>
   //      </div>
   //      <a href="{Saivi::U('Store/orders_detail',array('Fid'=>$item['Fid']))}">
   //      <div class="dd_list_right" style="">
   //      <if condition="$item.Fstatus eq '1' ">
   //          <div class="dd_zt1">未派送</div>
   //      <else/>
   //           <div class="dd_zt">配送中</div>
   //      </if>
   //      </div>
   //      </a>
   //  </div>
   //  <div class="line4"></div>

   // }

}
public function orderywc(){
    $order=M('Wa_orders');
    $orders=$order->join('tp_wa_ordergoods on tp_wa_orders.Fid=tp_wa_ordergoods.Foid')->where("tp_wa_orders.Ftoken='".session('FFtoken')."' and tp_wa_orders.Fstatus=3 and tp_wa_orders.Fusers='".session('FFphone')."'")->field('tp_wa_orders.*,tp_wa_ordergoods.Fgoodsname as Fgoodsname,tp_wa_ordergoods.Fnum as Fnum ')->order('tp_wa_orders.Fordertime desc')->select();
}

 //结束

 public function orders_detail(){
    $Fid=$_GET['Fid'];
    $db=M('Wa_orders');
    $Fuser=$this->getphone();
    $token=$this->gettoken(); 
    //$token=session('FFtoken');
    //$Fusers=session('FFphone');    
    $order=$db->where(array('Fid'=>$Fid))->find();    
    //水票和非水票订单
    $ordergods=M('Wa_ordergoods')->where(array('Forderid'=>$order['Forderid']))->find();
    //水票订单
    if($order['Fticket']=='1'){
      $tt=M('wa_ticketlog')->where(array('Foid'=>$order['Fid']))->field('Fgoodsid')->find();
      $goodlogo=M('Product')->field('logourl')->where(array('id'=>$tt['Fgoodsid']))->find();
    }else{
      $goodlogo=M('Product')->field('logourl')->where(array('id'=>$ordergods['Fgoodsid']))->find();
      
    }
    $ordergods['logourl']=$goodlogo['logourl'];
    $ordergods['total']=intval($ordergods['Ftotal']);
    //优惠原因
    $discount_reason=M('wa_users')->where(array('Fusername'=>$order['Fusers'],'Ftoken'=>$token))->field('Fdiscount_reason')->find();

    $worker=M('Wa_workers')->where(array('Fid'=>$order['Fworkerid'],'Ftoken'=>$token))->find();
    
    $this->assign('order',$order);
    $this->assign('worker',$worker);
    $this->assign('discount_reason',$discount_reason);
    $this->assign('ordergoods',$ordergods);
    
    $this->display();

 }

 //设置订单催单状态
 public function cd(){
   $Fid=$_POST['Fid'];
   
   $token=$_POST['token'];
  
   if(empty(session('cdtime'))){
      $cdtime=time();
      session('cdtime',$cdtime);
   }else{
     if((session('cdtime')+60)>time()){
       
       echo '2';
       exit();
     }
     session('cdtime',time());
   }

   $sta=M('Wa_orders')->field('Fstatus')->where(array('Fid'=>$Fid))->find();
   if($sta['Fstatus']!='1'){
      echo '3';
      exit();
   }
   // add by shitao 20160701 start
   // 催单推送接口
    $url2= 'http://www.eyuanonline.com:8887/api/push/reminder/?alias='.$token;
    $rest2=url_post($url2);
   // add by shitao 20160701 end
   
   //$url='http://www.eyuanonline.com:3000/water/'.$token.'/0?warn=-1';
   //$url=C('my_url').':3000/water/'.$token.'/0?warn=-1';
   $url=C('my_api').$token.'/0?warn=-1';
   //$url='api.fangweihao.com:3000/water/'.$token.'/0?warn=-1';
   $rest=url_get($url);
    $res=M('Wa_orders')->where(array('Fid'=>$Fid))->save(array('Fcd'=>1,'Fcd_time'=>time()));
    // $mes=json_decode($rest);
    //  if($mes->status!=200){
    //    $this->error('接口调用失败');
    //  }
   echo $res;
 }

 public function cancel(){

    $Fid=$_GET['Fid'];
    $Fusers=$this->getphone();
    $token=$this->gettoken(); 
    $orders=M('Wa_orders');
    $ticketlog=M('wa_ticketlog');
    $sta=$orders->field('Fstatus,Ftype,Fpaytype,transaction_id')->where(array('Fid'=>$Fid))->find();
    
    //未派单可取消订单
     if($sta['Fstatus']=='1'&& $sta['Ftype']=='0'){   
         
        //未派单未支付，成功取消订单
        $res0=$orders->where(array('Fid'=>$Fid))->save(array('Fstatus'=>0));
        if($res0){
          echo '1';
        }else{
          echo '0';
        }
     }elseif($sta['Fstatus']=='1'&& $sta['Ftype']=='1'){
     
      //未派单水票已支付，成功取消订单
        if($sta['Fpaytype']=='0'){
          
          //订单状态取消，未支付
          $res=$orders->where(array('Fid'=>$Fid))->save(array('Fstatus'=>0,'Ftype'=>0));
          //水票记录表水票数量恢复
          $num=$ticketlog->where(array('Foid'=>$Fid))->field('Fnum,Fbalance')->find();
          $res1=$ticketlog->where(array('Foid'=>$Fid))->save(array('Fnum'=>0,'Fbalance'=>$num['Fbalance']-$num['Fnum'],'Fpay'=>0));
          //用户水票数量更新
          $wanum=M('wa_users')->where(array('Ftoken'=>$token,'Fusername'=>$Fusers))->field('Fwanum')->find();
          $res2=M('wa_users')->where(array('Ftoken'=>$token,'Fusername'=>$Fusers))->save(array('Fwanum'=>$wanum['Fwanum']-$num['Fnum']));
          if($res&&$res1&&$res2){
            echo '1';
          }else{
            echo '0';
          }
          
        }elseif($sta['Fpaytype']=='2'){
          
          //微信支付，取消订单
          $result = $this->wxRefund($Fid);
          //dump($result);
          if(($result['return_code']=='SUCCESS') && ($result['result_code']=='SUCCESS')){
          //处理订单状态
            $thisorder=$orders->where(array('Fid'=>$Fid))->field('Ftotal,Fbalance')->find();
          $res=$orders->where(array('Fid'=>$Fid))->save(array('Fstatus'=>0,'Ftype'=>0,'Fbalance'=>0));
          //更新老板表wxuser的cash_account
          //$cash_val=$thisorder['Fbalance']-$thisorder['Ftotal'];
          //M('wxuser')->where(array('token'=>$token))->save(array('cash_account'=>$cash_val));   
          echo '1';
          }else {  
          //if(($result['return_code']=='FAIL') || ($result['result_code']=='FAIL'))
          //$reason = (empty($result['err_code_des'])?$result['return_msg']:$result['err_code_des']); 
          echo '0';
           //echo $result;
          }
        }else{
          
          echo '0';
        }
       
     }else{
      //已派单，不退
      
        echo '0';
     }
    
     
     //$this->redirect(U('Store/orders',array('FFtoken'=>$token,'FFphone'=>$Fusers)));
 }

 /** 
 * 微信退款 订单取消方法
 */ 
 public function wxRefund($order_id){
    //dump($_SERVER['DOCUMENT_ROOT']);exit;
    //我的SDK放在项目根目录下的Api目录下  
    //require_once APP_ROOT."/Api/wxpay/lib/WxPay.Api.php"; 
    Vendor('Wxpay.lib.WxPay','','.Api.php'); 
    //查询订单,根据订单里边的数据进行退款  
    $order = M('wa_orders')->where(array('Fid'=>$order_id,'Fpaytype'=>2,'Ftype'=>1))->find();
    if($order['Fpaytotal']>0){
      $order['Ftotal']=$order['Fpaytotal'];
    }

    $merchid = WxPayConfig::MCHID;      
    if(!$order) return false;      
    $input = new WxPayRefund();  
    //$input->SetOut_trade_no($order['Forderid']); //自己的订单号  
    $input->SetTransaction_id($order['transaction_id']); //微信官方生成的订单流水号，在支付成功中有返回      
    $input->SetOut_refund_no(WxPayConfig::MCHID.date("YmdHis"));  //退款单号      
    $input->SetTotal_fee($order['Ftotal']*100); //订单标价金额，单位为分  
    $input->SetRefund_fee($order['Ftotal']*100);  //退款总金额，订单总金额，单位为分，只能为整数  
    $input->SetOp_user_id($merchid);  
      
    $result = WxPayApi::refund($input); //退款操作  
      
    // 这句file_put_contents是用来查看服务器返回的退款结果 测试完可以删除了  
    //file_put_contents(APP_ROOT.'/Api/wxpay/logs/log3.txt',arrayToXml($result),FILE_APPEND);  
    return $result; 
  }

 //个人中心

public function user(){
  //$userid=$_GET['Fuser']; 页面基础数据
   
  if(!empty($_GET['FFphone'])){
    $Fuser=$_GET['FFphone'];
    session('FFphone',$Fuser);
  }else{
    $Fuser=session('FFphone');
  }
  if(!empty($_GET['FFtoken'])){
    $token=$_GET['FFtoken'];
    session('FFtoken',$_GET['FFtoken']);
  }else{
    $token=session('FFtoken');
  }
  /*轮播图
   $flash=M('Storeflash');
   $res=$flash->field('url,img')->where(array('attr'=>1,'token'=>'admin'))->order('id desc')->limit(5)->select();
   //$res=$flash->field('url,img')->where(array('attr'=>1))->order('id desc')->limit(5)->select();
   
    $res2=$flash->field('url,img')->where(array('attr'=>1,'token'=>$token))->order('id desc')->limit(5)->select();
   $this->assign('Fuser',$_GET['Fuser']);
   $this->assign('res',$res);
   $this->assign('res2',$res2);*/
  //活动抽奖判断 
   /*$praise=M('Wa_praisedset');
   $praisestatus=$praise->field('Fstatus,Fname,Ftimes,Fendtime')->find();
   $activeon=$this->activeon($_GET['FFtoken']);
    
     if($activeon=='1'){
      $pds=$praisestatus['Fstatus'];

   }else{
      $pds='2';
   }

   $this->assign('praisestatuson',$pds);*/
   //剩余水票数量，总积分，水桶押金  
  $user=M('wa_users')->where(array('Fusername'=>$Fuser,'Ftoken'=>$token))->field('Fusername,Fmoney,Fwanum,Fintegration')->find();
  //水站通知
  $where['end_time']=array('gt',time());
  $where['Ftoken']=$token;
  $notice = M('wa_notice')->where($where)->order('start_time desc')->limit(1)->find();

  //dump($notice);exit;
  //水站电话
  $stphone=M('wxuser')->where(array('token'=>$token))->field('phone')->find();
  //dump($stphone);exit;
  $this->assign('station_phone',$stphone);
  $this->assign('notice',$notice);
  $this->assign('user',$user);
  $this->display();
}

public function userset(){
    $Fuser=session('FFphone');

    $token=session('FFtoken');

     if(empty(session('Fcustom_user'))){
       $this->redirect('Reg/st_login',array('FFqid'=>$_GET['FFqid'],'token'=>$_GET['FFtoken']));
       exit();
    }
    $address=M('wa_users')->field('Faddress,Ffloorid,Fremark')->where(array('Fusername'=>$Fuser,'Ftoken'=>$token))->find();
   
    //宿舍楼名称
    $floor=M('Wa_dorm')->where(array('Ftoken'=>$token))->select();
    //判断社会水站或者学校水站

    $Ftype=M('Wxuser')->field('Ftype')->where(array('token'=>$_GET['FFtoken']))->find();  
    $this->assign('Ftype',$Ftype['Ftype']);
    
    $this->assign('floor',$floor);
    $this->assign('Fuser',$Fuser);
    $this->assign('FFqid',$_GET['FFqid']);
    $this->assign('address',$address);

    $this->display();
}

public function usersetdo(){
 
    $Fuser=$_GET['FFphone'];
    $address=trim($_POST['address']);
    if($address=='' || empty($address)){
      $this->error('地址不能为空');
    }
    $floorid=$_POST['floorid'];
    if($floorid=='' || empty($floorid)){
      $this->error('请选择宿舍楼');
    }
    $token=$_GET['token'];
    $Fnames=M('Wa_dorm')->field('Fname')->where(array('Ftoken'=>$token,'Fid'=>$floorid))->find();
    $address2=$Fnames['Fname'].'-'.$address;
   M('wa_users')->where(array('Fusername'=>$Fuser,'Ftoken'=>$token))->save(array('Faddress'=>$address2,'Ffloorid'=>$floorid,'Fremark'=>$address));

   $this->redirect(U('Store/user',array('FFtoken'=>$token,'FFphone'=>$Fuser)));
}



public function userinfo(){
 
   if(!empty($_GET['FFphone'])){
     $Fuser=$_GET['FFphone'];
     session('FFphone',$Fuser);
   }else{
       $Fuser=session('FFphone');
   }
  $FFtoken=$_GET['FFtoken'];
   $userinfos=M('wa_users')->where(array('Fusername'=>$Fuser))->find();
   $ord=M();
   $sql="SELECT sum(Ftotal) as count FROM tp_wa_orders WHERE Ftype=0 and Fstatus=3 and Fusers='".$Fuser."' and Ftoken='". $FFtoken."'";
   $res=$ord->query($sql);

   $sql2="SELECT sum(tp_wa_ordergoods.Fnum) as count2 FROM tp_wa_ordergoods  LEFT JOIN tp_wa_orders ON tp_wa_ordergoods.Foid=tp_wa_orders.Fid WHERE tp_wa_orders.Fstatus=3 and tp_wa_orders.Fusers='".$Fuser."' and tp_wa_orders.Ftoken='".$FFtoken."'";
   
   $res2=$ord->query($sql2);
   if(!empty($_GET['FFtoken'])){
     $token=$_GET['FFtoken'];
     session('FFtoken',$_GET['FFtoken']);
   }else{
     $token=session('FFtoken');
   }
   
   $where = array('Fuser'=>$Fuser, 'Ftoken'=>$token);
   $db = M('wa_ticket');
   $ticket = $db->field('tp_wa_ticket.*, tp_product.name gname')->where($where)->join('left join tp_product on tp_product.id = tp_wa_ticket.Fgoodsid')->select();

   $this->assign('ticket',$ticket);
   //欠款
   $money1=M('Wa_prolog')->field('SUM(Fmoney) as Fmoney,SUM(Ftnum) as Ftnum')->where(array('Ftoken'=>$token,'Fstatus'=>1,'Fuser'=>$Fuser))->select();

  //还款数
   $money2=M('Wa_prolog')->field('SUM(Fmoney) as Fmoney,SUM(Ftnum) as Ftnum')->where(array('Ftoken'=>$token,'Fstatus'=>0,'Fuser'=>$Fuser))->select();
  

  // 欠桶
   $cnum1=M('Wa_prolog')->field('SUM(Ftnum) as Ftnum')->where(array('Ftoken'=>$token,'Ftype'=>1,'Fuser'=>$Fuser))->select();
    
   //还桶
   $cnum2=M('Wa_prolog')->field('SUM(Ftnum) as Ftnum')->where(array('Ftoken'=>$token,'Ftype'=>0,'Fuser'=>$Fuser))->select();

    if(($money1[0]['Fmoney']-$money2[0]['Fmoney'])<=0){
        $moneyw=0;
    }else{
      $moneyw=$money1[0]['Fmoney']-$money2[0]['Fmoney'];
    }
    $this->assign('owtcount',($cnum1[0]['Ftnum']-$cnum2[0]['Ftnum']));
    $this->assign('owcount',$moneyw);
    $this->assign('count2',$res2[0]['count2']);
    

   $this->assign('userinfos',$userinfos);
   $this->display();
}


//水站介绍
public function intro(){
  $token=session('FFtoken');

  $intro=M('Wxuser')->field('body')->where(array('token'=>$token))->find();
  //echo M('Wxuser')->getlastSql();
   $body=htmlspecialchars_decode($intro['body']);
   //echo $body;
  $this->assign('intro',$body);
  $this->display();
}

//水站信息
public function wxusers(){
    //商家用户
     $Wxuserm=M('Wxuser');
     $Wxuserms=$Wxuserm->field('wxname,smsuser,waddress,phone,Fdis_id')->where(array('token'=>session('FFtoken')))->find();
     $userinfo=array(
       'Flinkman'=>$Wxuserms['smsuser'],
       'Fphone'=>$Wxuserms['phone'],
       'Fwatername'=>$Wxuserms['wxname'],
       'Faddress'=>$Wxuserms['waddress'],
  'Fdis_id'=>$Wxuserms['Fdis_id']
      );
   return $userinfo;
}

//消费者基本信息
// public function wusersall(){

//        $wuser=M('wa_users');
//        $user=$wuser->where(array('Fewm_id'=>session('FFqid')))->find();
//    echo $user;
//        return $user;
// }

// 客户下单成功，查询用户是否为第一次下单，如果为第一次下单，修改状态，下单后将订单信息存入到推荐奖励日志中
// $phone   客户手机号

public function write_recomlog($token,$phone,$order_id){
// 查询学生推广的第一次下单的用户
    $sql="SELECT * FROM tp_wa_users WHERE Fusername ='".$phone."' AND Fstatus ='1' and Ftoken='".$token."'";
    $res=M()->query($sql);
    if($res){
      // 更新推广用户为非第一次下单
      $sql1="UPDATE tp_wa_users SET Fstatus ='2' WHERE Fusername ='".$phone."' AND Ftoken='".$token."'";
      $res1=M()->query($sql1);
       // 工号
       $worker_num=$res[0]['Frecom'];
       // 查询推广学生信息
       $sql2="SELECT * FROM tp_wa_recom WHERE Fid ='".$worker_num."'  and Ftoken='".$token."'";
       $res2=M()->query($sql2);
      // 在系统后台查询出奖励金额；$money
        $res3=M('wxuser')->field('rem_type,rem_money')->where(array('token'=>$token))->find();
        $money=$res3['rem_money'];

      // 如果存在该学生
       if($res2){
        // 后台设置奖励为打开状态
          if($res3['rem_type']==1){
             $data['Fphone']=$phone;
             $data['Fworker_no']=$worker_num;
             $data['Fmoney']=$money;
             $data['Fuser']=$res2[0]['Fphone'];
             $data['Forder_id']=$order_id;
             $data['Fcreatetime']=time();
             M('wa_recomlog')->add($data);
          }
       }
    }
}



//活动判断水站
public function activeon($token){
  if($token=='gkgosv1442290930'){
      return '1';
  }else{
      return '2';
  }
}



}

?>
