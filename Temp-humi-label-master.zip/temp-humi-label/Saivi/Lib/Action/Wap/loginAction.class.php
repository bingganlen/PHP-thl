<?php 
class loginAction extends WapAction{

    public function _initialize() {

    }

    public function index(){
        if(IS_POST){
            $name = $_POST["username"];
            $passwd = $_POST["password"];

            $db = M('wa_users');
            $res = $db->where(array('Fusername'=>$name, 'Fpassword'=>md5($passwd)))->find();
            if($res){
                $_SESSION["stmp_name"] = $name;
                $_SESSION["stmp_pwd"] = $passwd;
                echo "/index.php?g=Wap&m=login&a=ulist";
                return;
            }
            echo "0";
            return;
        }
        $this->display();
    }

    public function ulist(){
        $name = $_SESSION["stmp_name"];
        $passwd = $_SESSION["stmp_pwd"];

        $db = M('wa_users');
        $res = $db->where(array('tp_wa_users.Fusername'=>$name, 'tp_wa_users.Fpassword'=>md5($passwd)))->field("tp_wa_users.Fewm_id, tp_wxuser.wxname, tp_qrcode.qrcode")->join("left join tp_wxuser on tp_wxuser.token = tp_wa_users.Ftoken left join tp_qrcode on tp_qrcode.id = tp_wa_users.Fewm_id")->select();

        $this->assign('list',$res);
        $this->display();
    }
}
?>