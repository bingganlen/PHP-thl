<?php
class WkAction extends WapAction{
    public function _initialize(){
        parent::_initialize();

        // if($_SESSION['Fphone']){
        //     $res=$this->info();
        //     $this->assign('total',$res);
        // }
    }

    /**
     * 登录
     */
    public function login() {
        import("@.ORG.Image");
        $this->display();       
    }

     /**
     * 登录验证
     */
    public function checklogin(){
        $phone=$_POST['phone'];
        $pwd=$_POST['pwd'];
        $sql="SELECT count(Fid) as num FROM tp_wa_workers WHERE Fphone='".$phone."' ";
        $data=M();
        $res=$data->query($sql);
        $count=$res[0]['num'];
        if($count=='1'){
            $sql1="SELECT count(Fid) as num FROM tp_wa_workers WHERE Fphone='".$phone."' and Fpwd='".md5($pwd)."' ";
            $res1=$data->query($sql1);
            $num=$res1[0]['num'];
            if($num=='1'){
                $_SESSION['Fphone']=$phone;
                // $this->display('Wk/order');
                $this->order();
            }else{
                $this->display('login');
            }
        }else{
            $this->display('login'); 
               }
    }

    /**
     * 订单
     */
    public function order(){
        if(session('Fphone')){
            $tel=session('Fphone');
            // $tel='13143234534';
            $this->assign('tel',$tel);
            // 公共头信息
            $result=$this->info();
            $this->assign('total',$result);
            $this->display('order');
        }else{
            $this->display('login');
        }
    }



    //已完成详情 
    public function goods(){
        if(session('Fphone')){
            $order_id=$_GET['oid'];
            $res=$this->detail($order_id);
            $this->assign('oid',$order_id);
            $this->assign('res',$res);
            $Fusers=$this->user_phone($order_id);
            $this->assign('Fusers',$Fusers);
            // 公共头信息
            $result=$this->info();
            $this->assign('total',$result);

            $this->display();
        }else{
            $this->display('login');
        }
    }


    // 未完成详细
    public function wgoods(){
        if(session('Fphone')){
            $order_id=$_GET['oid'];
            $res=$this->detail($order_id);
            $this->assign('oid',$order_id);

            $this->assign('res',$res);

            // 公共头信息
            $result=$this->info();
            $this->assign('total',$result);

            $this->display();
        }else{
            $this->display('login');
        }
    }
     

     // 现场操作
    public function action(){
        if(session('Fphone')){
            $oid=$_GET['oid'];
            $user=$_GET['user'];
            // 公共头信息
            $result=$this->info();
            $this->assign('total',$result);

            $this->assign('oid',$oid);
            $this->assign('user',$user);
            $this->assign('worker',session('Fphone'));
            $this->display();
        }else{
            $this->display('login');
        }
    }



    //个人信息
    public function my(){
        if(session('Fphone')){
            $tel=session('Fphone');
            // '13143234534';
            $res=$this->station($tel);
            $this->assign('res',$res);
            $res=M('wa_workers')->where(array('Fphone'=>$tel))->find();

            $sql="select count(Fid) as num from tp_wa_users where Frecom='".$res['Fworkernum']."'";
            $result=M()->query($sql);
            $num=$result[0]['num'];
            $this->assign('num',$num);
            // 公共头信息
            $result=$this->info();
            $this->assign('total',$result);
            $this->display();
        }else{
            $this->display('login');
        }
    }


    public function buy(){
        if(session('Fphone')){
            // 公共头信息
            $result=$this->info();
            $this->assign('total',$result);

            // 如果支付 将订单变为支付过，
            $oid= $_POST['oid'];

            // 存入到操作日志表
            $data['Fuser']=$_POST['user'];
            $data['Fworker']=$_POST['worker'];
            $data['Fsta']=intval($_POST['type']);
            $data['Fwnum']=intval($_POST['num']);
            $data['Ftotal']=$_POST['money'];

            $res=M('wa_prolog')->data($data)->add();

           
            $this->redirect('order');
        }else{
            $this->display('login');
        }
    }

/*
*公共调用方法
*/ 





    //根据状态查询订单信息 未完成订单
    public function check($status,$tel){
        // $sql="SELECT * FROM tp_wa_orders WHERE Fstatus='".$status."' AND Fphone='".$tel."'";
        $sql1="SELECT * FROM tp_wa_workers WHERE Fphone='".$tel."'";
        $result=M()->query($sql1);
        $token=$result[0]['Ftoken'];
        $sql="SELECT orders.Fid as Fid,orders.Ftotal as Ftotal,orders.Faddress as Faddress,orders.Fusers as Fusers, orders.Fhours as Fhours,goods.Fnum as Fnum,goods.Fspec as Fspec,goods.Fgoodsname as Fgoodsname, orders.Fticket  FROM tp_wa_orders as orders left JOIN tp_wa_ordergoods as goods ON orders.Fid = goods.Foid WHERE orders.Fstatus='".$status."' AND orders.Fphone='".$tel."'";
        $data=M();
        $res=$data->query($sql);
        $count=count($res);
        if($count>0){
            for ($i=0; $i <$count ; $i++) { 
                $str.='<div class="list_k '.($res[$i]["Fticket"] == '1'?'bg_list':'').'">
                        <div class="phone list_font">';
                // $str.=$res[$i]["Fticket"] == '1'?'水票:':'水品:';
                //('.($res[$i]["Fticket"] == '1'?'水票':$res[$i]['Fspec']).')
                $str.=($res[$i]["Fticket"] == '1'?$res[$i]['Fgoodsname'].'<span class="r_color">【水票】</span>':$res[$i]['Fgoodsname']).'</div>


                        <div class="water list_font">数量:'.$res[$i]['Fnum'].
                        '&nbsp;&nbsp;</div>
                        <div class="price list_font">金额:'.$res[$i]['Ftotal'].'</div>
                        <div class="time list_font">时间:'.$res[$i]['Fhours'].'</div>
                        <div class="place list_font">地址:'.$res[$i]['Faddress'].'</div>

                        <div class="'.($res[$i]["Fticket"] == '1'?'more_button_sp':'more_button sd').'" onclick="tanchu('.$res[$i]['Fid'].', '.$res[$i]["Fticket"].');">'.($res[$i]["Fticket"] == '1'?'确认完成':'现场操作').'</div>

                        <a href="tel:'.$res[$i]['Fusers'].'"><div class="'.($res[$i]["Fticket"] == '1'?'more_buttonx_sp':'more_buttonx').'">呼叫订户</div></a>
                        <div class="line3"></div>
                    </div>';
            }
        }else{
            $str='<div class="nocontent">暂无内容</div>';
        }
        $str.="<input type='hidden' value='".$count."' id='ordercount'>";
        $str.="<input type='hidden' value='".$tel."' id='tel'>";
        $str.="<input type='hidden' value='".$token."' id='token'>";
        echo  $str;
    }

    // public function check($status,$tel){
    //     // $sql="SELECT * FROM tp_wa_orders WHERE Fstatus='".$status."' AND Fphone='".$tel."'";
    //     $sql1="SELECT * FROM tp_wa_workers WHERE Fphone='".$tel."'";
    //     $result=M()->query($sql1);
    //     $token=$result[0]['Ftoken'];
    //     $sql="SELECT orders.Fid as Fid,orders.Ftotal as Ftotal,orders.Faddress as Faddress,orders.Fusers as Fusers, orders.Fhours as Fhours,goods.Fnum as Fnum,goods.Fspec as Fspec,goods.Fgoodsname as Fgoodsname  FROM tp_wa_orders as orders left JOIN tp_wa_ordergoods as goods ON orders.Fid = goods.Foid WHERE orders.Fstatus='".$status."' AND orders.Fphone='".$tel."'";
    //     $data=M();
    //     $res=$data->query($sql);
    //     $count=count($res);
    //     if($count>0){
    //         for ($i=0; $i <$count ; $i++) { 
    //             $str.='<div class="list_k">
    //                     <div class="phone list_font">水品:'.$res[$i]['Fgoodsname'].'</div>
    //                     <div class="water list_font">数量:'.$res[$i]['Fnum'].'&nbsp;&nbsp;('.$res[$i]['Fspec'].')</div>
    //                     <div class="price list_font">金额:'.$res[$i]['Ftotal'].'</div>
    //                     <div class="time list_font">时间:'.$res[$i]['Fhours'].'</div>
    //                     <div class="place list_font">地址:'.$res[$i]['Faddress'].'</div>

    //                     <div class="more_button"><a href="index.php?&g=Wap&m=Wk&a=wgoods&oid='.$res[$i]['Fid'].'">订单详情</a></div>

    //                     <div class="more_buttonx"><a href="tel:'.$res[$i]['Fusers'].'">呼叫订户</a></div>
    //                     <div class="line3"></div>
    //                 </div>';
    //         }
    //     }else{
    //         $str='<div class="nocontent">暂无内容</div>';
    //     }
    //     $str.="<input type='hidden' value='".$count."' id='ordercount'>";
    //     $str.="<input type='hidden' value='".$tel."' id='tel'>";
    //     $str.="<input type='hidden' value='".$token."' id='token'>";
    //     echo  $str;
    // }






    // 更具状态查询订单信息 已完成订单
    public function complete(){
        $status=$_POST['status'];
        $tel=$_POST['tel'];
        // $sql="SELECT * FROM tp_wa_orders WHERE Fstatus='".$status."' AND Fphone='".$tel."'limit 0,30";
        $sql="SELECT orders.Fid as Fid,orders.Ftotal as Ftotal,orders.Faddress as Faddress,orders.Fusers as Fusers, orders.Fhours as Fhours,goods.Fnum as Fnum,goods.Fspec as Fspec,goods.Fgoodsname as Fgoodsname, orders.Fticket  FROM tp_wa_orders as orders left JOIN tp_wa_ordergoods as goods ON orders.Fid = goods.Foid WHERE orders.Fstatus='".$status."' AND orders.Fphone='".$tel."' limit 0,30";
        $data=M();
        $res=$data->query($sql);
        $count=count($res);
        if($count>0){
            for ($i=0; $i <$count ; $i++) { 


                $str.='<div class="list_k '.($res[$i]["Fticket"] == '1'?'bg_list':'').'">
                        <div class="phone list_font">';
                $str.=$res[$i]["Fticket"] == '1'?'水票:':'水品:';
                $str.=($res[$i]["Fticket"] == '1'?$res[$i]['Fgoodsname'].'<span class="r_color">【水票】</span>':$res[$i]['Fgoodsname']).'</div>

                        <div class="water list_font">数量:'.$res[$i]['Fnum'].
                        '&nbsp;&nbsp;('.($res[$i]["Fticket"] == '1'?'':$res[$i]['Fspec']).')</div>
                        <div class="price list_font">金额:'.$res[$i]['Ftotal'].'</div>
                        <div class="time list_font">时间:'.$res[$i]['Fhours'].'</div>
                        <div class="place list_font">地址:'.$res[$i]['Faddress'].'</div>
                        <a href="index.php?&g=Wap&m=Wk&a=goods&oid='.$res[$i]['Fid'].'"><div class="'.($res[$i]["Fticket"] == '1'?'more_button_sp':'more_button sd').'">订单详情</div></a>
                        <a href="index.php?&g=Wap&m=Wk&a=action&oid='.$res[$i]['Fid'].'&user='.$res[$i]['Fusers'].'"><div class="'.($res[$i]["Fticket"] == '1'?'more_buttonx_sp':'more_buttonx').'">现场操作</div></a>
                        <div class="line3"></div>
                    </div>';
            }
            // return $res;
        }else{
            $str='<div class="nocontent">暂无内容</div>';
        }
        echo  $str;
    }

    // 取消的订单
     //根据状态查询订单信息 未完成订单
    public function quxiao($status,$tel){
        // $sql="SELECT * FROM tp_wa_orders WHERE Fstatus='".$status."' AND Fphone='".$tel."' limit 0,10";
        $sql="SELECT orders.Fid as Fid,orders.Ftotal as Ftotal,orders.Faddress as Faddress,orders.Fusers as Fusers, orders.Fhours as Fhours,goods.Fnum as Fnum,goods.Fspec as Fspec,goods.Fgoodsname as Fgoodsname, orders.Fticket  FROM tp_wa_orders as orders left JOIN tp_wa_ordergoods as goods ON orders.Fid = goods.Foid WHERE orders.Fstatus='".$status."' AND orders.Fphone='".$tel."' limit 0,10";
        $data=M();
        $res=$data->query($sql);
        $count=count($res);
        if($count>0){
            for ($i=0; $i <$count ; $i++) { 
                $str.='<div class="list_k '.($res[$i]["Fticket"] == '1'?'bg_list':'').'">
                        <div class="phone list_font">';
                $str.=$res[$i]["Fticket"] == '1'?'水票:':'水品:';
                $str.=($res[$i]["Fticket"] == '1'?$res[$i]['Fgoodsname'].'<span class="r_color">【水票】</span>':$res[$i]['Fgoodsname']).'</div>
                        <div class="water list_font">数量:'.$res[$i]['Fnum'].
                        '&nbsp;&nbsp;('.($res[$i]["Fticket"] == '1'?'':$res[$i]['Fspec']).')</div>
                        <div class="price list_font">金额:'.$res[$i]['Ftotal'].'</div>
                        <div class="time list_font">时间:'.$res[$i]['Fhours'].'</div>
                        <div class="place list_font">地址:'.$res[$i]['Faddress'].'</div>
                        <a href="index.php?&g=Wap&m=Wk&a=goods&oid='.$res[$i]['Fid'].'"><div class="'.($res[$i]["Fticket"] == '1'?'more_button_sp':'more_button sd').'">订单详情</div></a>
                        <a href="tel:'.$res[$i]['Fusers'].'"><div class="'.($res[$i]["Fticket"] == '1'?'more_buttonx_sp':'more_buttonx').'">呼叫订户</div></a>
                        <div class="line3"></div>
                    </div>';
            }
        }else{
            $str='<div class="nocontent">暂无内容</div>';
        }
        echo  $str;
    }




    //订单详情
    public function detail($order_id){
        // $sql="SELECT * from tp_wa_ordergoods WHERE Foid='".$order_id."'";
        $sql="SELECT orders.Fid as Fid,orders.Forderid as Forderid,orders.Fordertime as Fcreatetime,orders.Ftype as Ftype,orders.Ftotal as Ftotal,orders.Faddress as Faddress,orders.Fusers as Fusers, orders.Fhours as Fhours,goods.Fnum as Fnum,goods.Fprice as Fprice,goods.Fspec as Fspec,goods.Fgoodsname as Fgoodsname, orders.Fticket  from tp_wa_orders as orders left JOIN tp_wa_ordergoods as goods ON orders.Fid=goods.Foid WHERE orders.Fid='".$order_id."'";
        $data=M();
        $res=$data->query($sql);
        return $res[0];
    }


    // 送水工水站信息
    public function station($tel){
       $sql="SELECT * FROM tp_wa_workers as worker left JOIN tp_wxuser as wx on worker.Ftoken=wx.token WHERE worker.Fphone='".$tel."'" ;
        $data=M();
        $res=$data->query($sql);
        return $res[0];
    }


    // 查询出水站的名称，电话信息
    public function info(){
        $tel=session('Fphone');
        // '13143234534';
        $sql="SELECT wx.wxname ,wx.phone FROM tp_wa_workers as worker left JOIN tp_wxuser as wx on worker.Ftoken=wx.token WHERE worker.Fphone='".$tel."'" ;
        $data=M();
        $res=$data->query($sql);
        return $res[0];
    }



    //修改状态 变为已完成 月结
    public function status($oid){
        $sql="UPDATE tp_wa_orders set Fstatus ='3' WHERE Fid='".$oid."'";

        $data=M();
        $res=$data->query($sql);
        $num=mysql_affected_rows();
        // 修改数量函数
        $this->upnum($oid);
        echo $num;
    }

    //水票支付   修改状态 变为已完成且已付款 $oid
    public function ckstatus($oid){
        $sql="UPDATE tp_wa_orders set Fstatus ='3' , Ftype='1' WHERE Fid='".$oid."'";
        $data=M();
        $res=$data->query($sql);
        $num=mysql_affected_rows();
        // 修改数量函数
        $this->upnum($oid);
        echo $num;
    }


    // 现金支付   修改状态 变为已完成且已付款 $oid  
    public function xjstatus($oid){
        $sql="UPDATE tp_wa_orders set Fstatus ='3' , Ftype='1' ,Fpaytype='1' WHERE Fid='".$oid."'";
        $data=M();
        $res=$data->query($sql);
        $num=mysql_affected_rows();
        // 修改数量函数
        $this->upnum($oid);
        echo $num;
    }

    // 根据用户订单号 查询
    public function user_phone($order_id){
        $sql="SELECT Fusers from tp_wa_orders WHERE Fid='".$order_id."'";
        $data=M();
        $res=$data->query($sql);
        return $res[0]['Fusers'];
    }


    public function upnum($oid){
        // $oid='222';
        $sql="SELECT * FROM tp_wa_orders as orders left JOIN tp_wa_ordergoods as goods on orders.Fid=goods.Foid WHERE orders.Fid='".$oid."'";
        $res=M()->query($sql);
        $worker_id=$res[0]['Fworkerid'];
        $product_id=$res[0]['Fgoodsid'];
        $user_phone=$res[0]['Fusers'];
        $num=$res[0]['Fnum'];

        // 修改送水工送水数
        $sql1="UPDATE tp_wa_workers set Ftotal=Ftotal+'".$num."' where Fid='".$worker_id."'";
        $res1=M()->query($sql1);
        // 修改商品购买量
        $sql2="UPDATE tp_product set salecount=salecount+'".$num."' where id='".$product_id."' ";
        $res2=M()->query($sql2);

        // 修改用户购买量
        $sql3="UPDATE tp_wa_users set Fwnum=Fwnum+ '".$num."' where Fusername='".$user_phone."' ";
        $res3=M()->query($sql3);
    }


    // 查询订单信息
    public function sorder($oid){
        // ='244';
        $sql="SELECT * FROM tp_wa_orders  WHERE Fid='".$oid."'";
        $data=M();
        $res=$data->query($sql);
        echo '订单编号：'.$res[0]['Forderid'];
    }

    // 表单提交  。修改为已完成和支付状态
    public function water_num(){
        $oid=$_POST['order_id'];
        // 0是归还+  1是借出1
        $data['Ftype']=intval($_POST['status']);
        $data['Ftnum'] =intval($_POST['numbers']);
        // 支付方式 0水票支付   1欠费确认  2现金支付
        $type=$_POST['pay_w'];

        if($type=='0'){
             $sql="UPDATE tp_wa_orders set Fstatus ='3' , Ftype='1' WHERE Fid='".$oid."'";
        }

        if($type=='1'){
            $sql="UPDATE tp_wa_orders set Fstatus ='3' WHERE Fid='".$oid."'";
        }

        if($type=='2'){
             $sql="UPDATE tp_wa_orders set Fstatus ='3' , Ftype='1' ,Fpaytype='1' WHERE Fid='".$oid."'";
        }

        if($type=='3'){
            $sql="UPDATE tp_wa_orders set Fstatus ='3' , Ftype='1' ,Fpaytype='0' WHERE Fid='".$oid."'";
            //送水工确认的时候调用
            $db = M('wa_ordergoods');
            $order = $db->field("tp_wa_ordergoods.*, tp_wa_orders.Ftoken, tp_wa_orders.Fusers")->join("left join tp_wa_orders on tp_wa_ordergoods.Foid = tp_wa_orders.Fid")->where(array('tp_wa_ordergoods.Foid'=>$oid))->find();
            $ticket = M('wa_ticket')->where(array('Fgoodsid'=>$order["Fgoodsid"], 'Fuser'=>$order["Fusers"], 'Ftoken'=>$order["Ftoken"]))->find();
            // var_dump($order);exit();
            if(count($ticket)>0){
                M()->query("update tp_wa_ticket set Fnum = Fnum - ".$order["Fnum"]." where Fgoodsid='".$order["Fgoodsid"]."' and Ftoken='".$order["Ftoken"]."' and Fuser='".$order["Fusers"]."'");
            }else{
                $this->error("您的水票不够支付");
                return;
            }
            $ticketlog = array();
            $ticketlog["Fnum"] = "-".$order["Fnum"];
            $ticketlog["Fname"] = $order["Fgoodsname"];
            $ticketlog["Fcreate_time"] = time();
            $ticketlog["Fgoodsid"] = $order["Fgoodsid"];
            $ticketlog["Ftoken"] = $order["Ftoken"];
            $ticketlog["Foid"] = $order["Foid"];
            $ticketlog["Fprice"] = $order["Ftotal"];
            M('wa_ticketlog')->add($ticketlog);
        }
        $res=M()->query($sql);


        // 根据订单号查询用户和送水工信息
        $sql1="SELECT * FROM tp_wa_orders  WHERE Fid='".$oid."'";
        $res1=M()->query($sql1);
        $Fusers=$res1[0]['Fusers'];
        $Fphone=$res1[0]['Fphone'];
        // 增加操作记录
        $data['Fuser']=$Fusers;
        $data['Fworker']=$Fphone;
        $res=M('wa_prolog')->data($data)->add();

         // 增加或减少用户桶的数量
            // 水桶
            if(!empty($_POST['numbers'])){
                // +
               if ($_POST['status']=='1') {
                    $sql2="update tp_wa_users set Fownnum=Fownnum + '".$_POST['numbers']."' where Fusername='".$Fusers."'";
                    $sql3="update tp_wa_workers set Fnum=Fnum + '".$_POST['numbers']."' where Fphone='".$Fphone."'";
                   
                    $data=M();
                    $res3=$data->query($sql2);
                    $res2=$data->query($sql3);
                    
                }

                // -
                if ($_POST['status']=='0') {
                    $sql2="update tp_wa_users set Fownnum= Fownnum - '".$_POST['numbers']."' where Fusername='".$Fusers."'";
                    $sql3="update tp_wa_workers set Fnum= Fnum - '".$_POST['numbers']."' where Fphone='".$Fphone."'";
                    

                    $data=M();
                    $res3=$data->query($sql2);
                    $res2=$data->query($sql3);
                    
                   
                }
            }

    $this->redirect('Wk/order');
    }

}
?>
