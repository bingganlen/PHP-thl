<?php
class RegAction extends WapAction{

    public function _initialize() {
        parent::_initialize();
        // $this->assign('token',session('token'));
        // $this->assign('staticFilePath', str_replace('./','/',THEME_PATH.'common/css/store'));
    }

    //找回密码
    public function lookcode(){
        $token=$_GET['token'];
        $phone=$_GET['phone'];
        $FFqid=$_GET['FFqid'];
        $this->assign('token',$token);
        $this->assign('phone',$phone);
        $this->assign('FFqid',$FFqid);
        
        $this->display();
    }

    public function registercode(){
         if($_GET['Fewm_id']){
            $Fewm_id=$_GET['Fewm_id'];
        }

        if(!empty($_POST['Fewm_id'])){
             $Fewm_id=$_POST['Fewm_id'];
        }

        $name=$this->_post('name');
        $passwd=$this->_post('passwd');
       
        $num=$this->_post('verifyMP');
        $token=$this->_post('token');

         if($name==''||$passwd==''){
            $this->error('请填写完整的用户名密码');
            exit();
         }
        
        if($num!=$_SESSION['verifyMP']){
              $this->error('验证码错误');
          
              exit();
        }
        
        // if($_SESSION['veriphone']!=$name){
        //        $this->error('验证码和手机号不匹配');
          
        //       exit();
        // }
        
  
        $data['Fpassword']=md5($passwd);

        $db=M('wa_users');
        $res=$db->where(array('Fusername'=>$name,'Ftoken'=>$token))->find();
       
        if($res){
          $res2=$db->where(array('Ftoken'=>$token,'Fusername'=>$name))->save($data);

           if($res2){
              //$this->success('更新密码成功');
              $this->redirect('Store/user', array('FFphone' => $name,'FFtoken'=>$token,'FFqid'=>$Fewm_id), 3, '密码更新成功正在跳转...');
           }else{
             $this->error('你的密码没有修改');
           }
        }else{
            $this->error('用户不存在');
        }

    }

    // 水站公共二维码注册
    public function station(){
        if(!empty($_GET['Fewm_id'])){
           $qid=$_GET['Fewm_id'];
        }else{
             $qid=session('FFqid');
        }
        if(!empty($_GET['token'])){
            $token=$_GET['token'];  
        }else{
            $token=$_GET['FFtoken'];  
        }
        if(!$qid && !$token){
           $this->error('未获得站点或用户信息，请扫码后登陆！');
        }
        //是否选择了商品
        if($_GET['product']){
            $this->assign('product',$_GET['product']);            
        }
        if($_GET['productnum']){
            $this->assign('productnum',$_GET['productnum']); 
        }
         //宿舍楼名称        
        $floor=M('Wa_dorm')->where(array('Ftoken'=>$token))->select();
        //判断社会水站或者学校水站
        $wxuser=M('Wxuser')->field('wxname,Ftype,province,city,country')->where(array('token'=>$token))->find();
        $province=D('tn_city')->where(array('Fid'=>$wxuser['province']))->field('Fname')->find();
        $city=D('tn_city')->where(array('Fid'=>$wxuser['city']))->field('Fname')->find();
        $country=D('tn_city')->where(array('Fid'=>$wxuser['country']))->field('Fname')->find();
        $this->assign('wxuser',$wxuser);
        $this->assign('province',$province['Fname']);
        $this->assign('city',$city['Fname']);
        $this->assign('country',$country['Fname']);
        $this->assign('Ftype',$wxuser['Ftype']);
        $this->assign('floor',$floor);
        $this->assign('Fewm_id',$qid);
        $this->assign('token',$token);
        
        //区级选项
        $counties= D('tn_city')->where(array('Flevel'=>2,'Fpid'=>$wxuser['city']))->order('Fid ASC')->select();
        $this->assign('counties',$counties);        
        $this->display();
    }

    // 水站公共二维码注册验证
    public function pbcheck(){
   
        $name=$this->_post('name');
        $passwd=$this->_post('passwd');
        $address2=$this->_post('address');
        $yzm=$this->_post('verifyMP');
        $token=$this->_post('token');
         $floorid=$this->_post('floorid');
             $floorname=M('Wa_dorm')->field('Fname')->where(array('Fid'=>$floorid))->find();
     
        $address=$floorname['Fname'].$address2;
        if($name==''||$passwd==''){
              echo '请填写完整的用户名密码';
              exit();
        }
            //$this->error('请填写完整的用户名密码');
          

        if($yzm!=$_SESSION['verifyMP']){
               echo '验证码错误';
               exit(); 
        }
            //$this->error('验证码错误');
        
        //$data['Fewm_id']= $Fewm_id;
           if($_SESSION['veriphone']!=$name){
               $this->error('验证码和手机号不匹配');
          
              exit();
        }
        
        $data['Fusername']=$name;
        $data['Fpassword']=md5($passwd);
        $data['Faddress']=$address;
        $data['Fremark']=$address2;
        $data['Ftoken']=$token;
        $data['Fcreatetime']=time();

        $db=M('wa_users');
        $data['Fusername']=$name;
        $data['Ffloorid']=$floorid;
        $res=$db->where(array('Fusername'=>$name,'Ftoken'=>$token))->find();
        if($res){
            //$this->error('此用户名已注册');
            echo '此用户名已注册';
            exit();
        }else{
            $where['Fusername']=$name;
            // $data['Fewm_id']=$Fewm_id;
            $res=$db->add($data);
        }


        $_SESSION['FFtoken']=$token;
        $_SESSION['FFphone']=$name;
        echo 'sccuess';
        //$this->redirect(U('Store/goodslist',array('FFtoken'=>$token,'FFphone'=>$name)));
    }

    // 水站公共二维码登录
    public function slogin(){
       if($_GET['product']){
          $this->assign('product',$_GET['product']);
       }
       if($_GET['productnum']){          
          $this->assign('productnum',$_GET['productnum']);
       }
        if(!empty($_GET['token'])){
            $token=$_GET['token'];  
        }else{
            $token=$_GET['FFtoken'];  
        }
        $wxuser=M('Wxuser')->field('wxname')->where(array('token'=>$token))->find();
        $this->assign('wxuser',$wxuser);
        $this->assign('token',$token);
        $this->display();
    }


    // 水站公共二维码登录验证
    public function login_schk(){
        $name=$this->_post('name');
        $passwd=$this->_post('passwd');
        $token=$this->_post('token');
        $product=$this->_post('product');
        $productnum=$this->_post('productnum');
        if($name==''||$passwd==''){
            $this->error('请填写完整的用户名密码');
            exit();
        }               

        $db=M('wa_users');
        $userin=$db->where(array('Fusername'=>$name,'Ftoken'=>$token))->find();
        if(!$userin){
            $this->error('您登录的号码未注册本水站,快去注册吧！',U('Reg/station',array('token'=>$token,'product'=>$product,'productnum'=>$productnum)));
        }
        $where=array('Fusername'=>$name,'Fpassword'=>md5($passwd),'Ftoken'=>$token);
        $res=$db->where($where)->find();
        // echo $db->getlastSql();
        //     $sql="select * from tp_wa_users where Fusername='".$name."' and Fpassword ='".md5($passwd)."' and Ftoken='".$token."'";
        // M()->query($sql);

        if($res){
            $_SESSION['FFtoken']=$token;
            $_SESSION['FFphone']=$name;
            $_SESSION['Fcustom_user']=$name;
            setcookie('Fcustom_user',$name,time()+3600*24);
            if(!empty($_GET['active'])){
               $_SESSION['active']=$_GET['active']; 
            }
            $this->redirect(U('Store/index',array('FFtoken'=>$token,'FFphone'=>$name)));
        }else{
            $this->error('用户名或密码不正确',U('Reg/slogin',array('FFtoken'=>$token)));
        }
    }

   //注册引导页
    public function start(){
        $token=session('FFtoken');
        if($_GET['FFqid']){
            $this->assign('FFqid',$_GET['FFqid']);
        }
        // add by shitao 20161108 start
        if(empty($token)){
            $token = $_GET['FFtoken'];
        }
        // add by shitao 20161108 end
        $this->assign('token',$token);
        $this->display();
   }

    // 家庭单一二维码
    public function reg(){
        if(!empty($_GET['Fewm_id'])){
           $qid=$_GET['Fewm_id'];
        }else{
             $qid=session('FFqid');
        }

        $token=$_GET['token'];
         //宿舍楼名称
        $floor=M('Wa_dorm')->where(array('Ftoken'=>$token))->select();
        
        //判断社会水站或者学校水站
        $Ftype=M('Wxuser')->field('Ftype')->where(array('token'=>$token))->find();
        $this->assign('Ftype',$Ftype['Ftype']);
        $this->assign('floor',$floor);
        $this->assign('Fewm_id',$qid);
        $this->assign('token',$token);
        $this->display();
    }
    /**
     * update by shitao 20161020
     * 抽奖后注册
     * @return [type] [description]
     */
    // public function reg(){
    //     if(!empty($_GET['Fewm_id'])){
    //        $qid=$_GET['Fewm_id'];
    //     }else{
    //          $qid=session('FFqid');
    //     }
    //     $jf = $_GET['jf'];
    //     $phone = $_GET['phone'];
    //     $this->assign('jf',$jf);
    //     $this->assign('phone', $phone);

    //     $token=$_GET['token'];
    //      //宿舍楼名称
    //     $floor=M('Wa_dorm')->where(array('Ftoken'=>$token))->select();
        
    //     //判断社会水站或者学校水站
    //     $Ftype=M('Wxuser')->field('Ftype')->where(array('token'=>$token))->find();
    //     $this->assign('Ftype',$Ftype['Ftype']);
    //     $this->assign('floor',$floor);
    //     $this->assign('Fewm_id',$qid);
    //     $this->display();
    // }


    //一品一码的注册
    public function register(){

        /*if($_GET['Fewm_id']){
            $Fewm_id=$_GET['Fewm_id'];
        }
        if(!empty($_POST['Fewm_id'])){
             $Fewm_id=$_POST['Fewm_id'];
        }*/        
        //add by shitao 20161020 start
        // $jf = $_POST['jf'];
       //dump($_POST);exit;
        $name=$this->_post('name');
        
        $passwd=$this->_post('passwd');
        //$passwd='123456';
       
        $address2=$this->_post('address');
        //省市区
        $Fcity1=$this->_post('city1');
        $Fcity2=$this->_post('city2');
        $Fcity3=$this->_post('city3');
        //$num=$this->_post('num');
        $floorid=$this->_post('floorid');
        //宿舍地址
        if($floorid>0){
        $floorname=M('Wa_dorm')->field('Fname')->where(array('Fid'=>$floorid))->find();        
        $address=$floorname['Fname'].$address2;
        $data['Faddress']=$address;
        $data['Fremark']=$address2;
        }else{
        //社会地址
        $data['Fcity1']=$Fcity1;
        $data['Fcity2']=$Fcity2;
        $data['Fcity3']=$Fcity3;
        $data['Faddress']=$address2;
        }
        
      
        if(!empty($this->_post('num'))){
          $num=$this->_post('num');  
        }
        $yzm=$this->_post('verifyMP');

        if($name==''||$passwd==''){
            //$this->error('请填写完整的用户名密码');
            echo '请填写完整的用户名密码';
            exit();
        }
       
        if($yzm!=$_SESSION['verifyMP']){
            echo '验证码错误';
            exit(); 
        }
        //     //$this->error('验证码错误');
            
        if($_SESSION['veriphone']!=$name){
            echo '验证码和手机号不匹配';          
            exit();
        }
        
        $data['Fusername']=$name;
        $data['Fpassword']=md5($passwd);
        
        $data['Ffloorid']=$floorid;
                
        $data['Fcreatetime']=time();
        $db=M('wa_users');
        //判断扫的码是站点码还是客户码
        $Fewm_id=$_POST['Fewm_id'];
        $token=$_POST['token'];
       
        if($Fewm_id){
        //扫客户码
            if(!$token){
                $token=$this->gettoken($Fewm_id);
                $data['Ftoken']=$token;
            }else{
                $data['Ftoken']=$token;
            }
            
            $data['Fewm_id']= $Fewm_id;
            //判断一个码不能多用户注册
            $erw=$db->field('Fewm_id')->where(array('Fewm_id'=>$Fewm_id))->find();
            if($erw){
                echo '此二维码已被绑定';
                exit();
            }
            //已注册过，更新二维码绑定信息
            $res=$db->where(array('Fusername'=>$name,'Ftoken'=>$token))->find();
            if($res){
                $res1=$db->where(array('Fusername'=>$name,'Ftoken'=>$token))->save($data);
                $_SESSION['FFphone']=$name;
                if($res1){
                    $this->check_status($Fewm_id);
                    $this->assign('token',$token);
                    echo 'index1';//二维码更新成功
                    //echo 'sccuess';
                }
            }else{
                //注册
                $aid=$db->add($data);
                $_SESSION['FFphone']=$name;            
                $this->check_status($Fewm_id);
                $this->assign('token',$token);
                echo 'success';       
            }

        }elseif($token && !$Fewm_id){
        //扫码站点码
            $data['Ftoken']=$token;
            //已注册过的用户
            $res=$db->where(array('Fusername'=>$name,'Ftoken'=>$token))->find();
            if($res){
                echo 'index2';//您已注册该水站，请登录
                
            }else{
                //注册
                $aid=$db->add($data);
                $_SESSION['FFphone']=$name;
                echo 'success';
            }
            //dump('22');exit;
        }else{
           echo "请扫码后注册！";exit;
           
        }       
        
        // 用户已注册过，更新
        
       /*if($res){
            // $this->error('此用户名已注册');
            $data['Fewm_id']=$Fewm_id;

            $res1=$db->where(array('Fusername'=>$name,'Ftoken'=>$token))->save($data);
             $_SESSION['FFphone']=$name;
            if($res1){
               $this->check_status($Fewm_id);
                echo 'sccuess';
            }
            //$this->redirect(U('Store/index',array('FFtoken'=>$token,'FFphone'=>$name)));
           

        }else{
        // 没注册过，添加用户
             //$data['Ftoken']=$token;
            // 提交了送水工编号
            if(!empty($num)){
                // 如果送水工存在
                $where=array('Fworkernum'=>$num,'Ftoken'=>$token);
                $res=M('wa_workers')->where($where)->find();
                // 如果推荐学生存在
                $where0=array('Fid'=>$num,'Ftoken'=>$token);
                $res0=M('wa_recom')->where($where)->find();

                if($res||$res0){
                    // 送水工
                    if($res){
                       $data['Frecom']=$num;
                       $aid=$db->add($data);

                       $result=M('wxuser')->where(array('token'=>$token))->find();
                       $status=$result['status'];
                       $money=$result['money'];
                       if($status=='1'){
                            $sql="update tp_wa_workers set Fmoney=Fmoney+'".$money."' where Fworkernum = '".$num."'";
                           $res1=M()->query($sql);
                  
                           $data1['Fw_id']=$res['Fid'];
                           $data1['Freward']=$money;
                           $data1['Fstyle']='0';
                           $data1['Forderno']=$aid;
                           $data1['Fcreatetime']=time();
                           M('wa_workerlog')->add($data1); 
                       } 
                    }
                    // 推广学生
                    if($res0){
                        $data['Frecom']=$num;
                        $data['Fstatus']='1';
                        $aid=$db->add($data);
                        if($aid){
                             $sql="update tp_wa_recom set Fnum=Fnum+1 where Fid = '".$num."'";
                               $res1=M()->query($sql);
                        }
                    }
                   
                }else{
                // 送水工不存在
                    $aid=$db->add($data);
                }

            }else{
                $aid=$db->add($data);
            }

            //update by shitao 20161107 start
            
            $typesql="SELECT `Ftype` FROM `tp_wxuser` where  `token`='".$FFtoken."' LIMIT 1";
            $types=mysql_query($typesql);
            $typesarray=mysql_fetch_array($types);
            $Ftype = $typesarray['Ftype'];

            if ($Ftype != 0){  //学校水站不送积分
                $integration=M('wa_integration');
                $data2['Fproductid']= -3;
                $data2['Ftotal']=200;
                $data2['Ftoken']=$token;
                $data2['Fphone']=$name;
                $data2['Fcreatetime']=time();
                $c=$integration->add($data2);
            }
            //update by shitao 20161107 end

            $_SESSION['FFphone']=$name;
            if($res){
                $this->check_status($Fewm_id);
            }
            //注册成功后的提示
            //$this->redirect(U('Reg/regsuccess',array('FFtoken'=>$token,'FFphone'=>$name,'FFqid'=>$Fewm_id)));
            //$this->redirect(U('Store/goodslist',array('FFtoken'=>$token,'FFphone'=>$name)));
             echo 'sccuess';
        }*/
       
   }

    //注册成功的提示
   public function regsuccess(){
    $this->display();
   }

    // public function logout(){
    //     session('custom_user',NULL);
    //     session('custom_pd',NULL);
    //     $this->success('登出成功'.session('custom_user'));
    // }

// 登录
    public function login(){
        if($_GET['tokenk']){
            $this->assign('tokenk',$_GET['tokenk']);
        }
        $this->display();
    }


// 登录验证

    public function login_chk(){
        $tokenk= $this->_post('tokenk');
        $name=$this->_post('name');
        $passwd=$this->_post('passwd');
        $token=$_SESSION['FFtoken'];
        if($name==''||$passwd=='')
                $this->error('请填写完整的用户名密码');
        

        $db=M('wa_users');
        $where=array('Ftoken'=>$token,'Fusername'=>$name,'Fpassword'=>md5($passwd));
        $res=$db->where($where)->find();
        if($res){
            if(!empty($tokenk)){
                $data['Fewm_id']=$_SESSION['FFqid'];
                $db->where(array('Ftoken'=>$token,'Fusername'=>$name))->save($data);
                $this->redirect(U('Store/goodslist'));
                // exit();
            }else{
                $_SESSION['FFphone']=$name;
                session('Fcustom_user',$name);
                $this->redirect('Store/userset');
            }
           
        }else{
            $this->error('用户名或密码不正确');
        }
    }

// 修改地址登录
    public function st_login(){
        // if($_GET['tokenk']){
        //     $this->assign('tokenk',$_GET['tokenk']);
        // }
        $this->assign('token',$_SESSION['FFtoken']);
        $this->assign('phone',$_SESSION['FFphone']);
        $this->assign('FFqid',$_GET['FFqid']);
        $this->display();
    }
// 修改地址登录验证

    public function login_st_chk(){
        $token= $this->_post('token');
        $FFphone=$_SESSION['FFphone'];
        $FFtoken=$_SESSION['FFtoken'];
        $name=$this->_post('name');
        $passwd=$this->_post('passwd');
        if($name !=$_SESSION['FFphone']){
             $this->error('用户名错误');
        }

        $FFtoken=$_SESSION['FFtoken'];
        if($name==''||$passwd=='')
                $this->error('请填写完整的用户名密码');
        $db=M('wa_users');
        $where=array('Ftoken'=>$FFtoken,'Fusername'=>$name,'Fpassword'=>md5($passwd));
        $res=$db->where($where)->find();
      
        if($res){
            // if(!empty($token)){
            // $data['Fewm_id']=$_SESSION['FFqid'];
            // $db->where(array('Ftoken'=>$token,'Fusername'=>$name))->save($data);
            session('Fcustom_user',$name);
            $this->redirect(U('Store/userset',array('FFtoken'=>$FFtoken,'FFphone'=>$FFphone)));
            //exit();
            //}else{
            //$_SESSION['FFphone']=$name;
            //$this->redirect(U('Store/userset',array('FFtoken'=>$FFtoken,'FFphone'=>$FFphone)));
            //}  
        }else{
            $this->error('用户名或密码不正确');
        }
    }
    //验证码
    public function verify() {
        $type=isset($_GET['type'])?$_GET['type']:'gif';
        import("@.ORG.Image");
        Image::buildImageVerify(4,1,$type);
    }

    //注册成功，将二维码标记为已用1
    public function check_status($Fewm_id){
        $db=M('qrcode');
        $data['isstatus']='1';
        $where=array('id'=>$Fewm_id);
        $res=$db->where($where)->save($data);
    }

    public function gettoken($Fewm_id){
        $res=M('qrcode')->field('token')->where(array('id'=>$Fewm_id))->find();
        return  $res['token'];
    }


    public function yzm(){
        $verify1=$_POST['verify'];
        $verify=$_SESSION['verify'];
        if(md5($verify1)==$verify){
            echo 1;
        }else{
            echo 0;
        }
    }


    public function add_address(){
        /***
        if(session('custom_user')==''||session('custom_pd')==''){
                        //session('last_url',$_SERVER['REQUEST_URI']);
                        $this->error('您还未登陆，请登陆',U('custom/user',array('token'=>$_GET['token'])));
                }***/
        $id=$this->_get('id');
        $name=$this->_post('name');
        $tel=$this->_post('tel');
        $address=$this->_post('address');

        if($name==''||$tel==''||$address=='')
            $this->error('请填写完整的，收件人，电话和地址');
        $db=M('customer_user_info');
        $data['name']=$name;
        $data['tel']=$tel;
        $data['address']=$address;
        $data['user']=session('custom_user');
        if($id){
            $res=$db->where(array('id'=>$id))->data($data)->save();
        }else{
            $res=$db->where(array('user'=>session('custom_user')))->count();
            if($res==0)
                $data['default']=1;
            $res=$db->add($data);
        }
        $this->redirect("address");
    }
    public function del_address(){
        $id=$this->_get('id');
        $db=M('customer_user_info');
        $where['id']=$id;
        $res=$db->where($where)->delete();
        $this->redirect("address");
    }
    public function user_address(){
        $id=$this->_get('id');
        if($id){
            $db=M('customer_user_info');
            $where['id']=$id;
            $res=$db->where($where)->find();
            $this->assign('info',$res);
        }
        $this->assign('id',$id);
        $this->display();
    }
    public function set_default(){
        $id=$this->_get('id');
        $user=session('custom_user');
        $db=M('customer_user_info');
        $where['user']=$user;
        $d['default']=0;
        $db->where($where)->data($d)->save();
        $where2['id']=$id;
        $d2['default']=1;
        $res=$db->where($where2)->data($d2)->save();
        $this->redirect("address");
        //if($res)
        //  $this->success('设置成功');
        //else
        //  $this->error('设置失败');
    }
    public function address(){
        //session('last_url',$_SERVER['REQUEST_URI']);
        $db=M('customer_user_info');
        $where['user']=session('custom_user');
        $res=$db->where($where)->select();
        $this->assign('addlist',$res);
        $this->assign('last_url',session('last_url'));
        $this->display();
    }

    public function finsh(){
        $this->redirect(U('Store/cart',array('token'=>$_GET['token'])));
    }

    /**
     * 注册前抽奖页面
     * add 2016／10/19 shitao
     * @return [type] [description]
     */
    public function lottery_index(){
        $token=session('FFtoken');
        if($_GET['FFqid']){
            $qqid = $_GET['FFqid'];
            $this->assign('FFqid',$qqid);
            $token=$this->gettoken($qqid);
        }
        $this->assign('token',$token);
        $this->display();
    }

    /**
     * 抽奖
     * add 2016／10/19 shitao
     * @return [type] [description]
     */
    public function lottery(){
        $token=session('FFtoken');
        if($_GET['FFqid']){
            $qqid = $_GET['FFqid'];
            $this->assign('FFqid',$qqid);
            $token=$this->gettoken($qqid);
        }
        $this->assign('token',$token);
        $this->display();
    }

    /**
     * 抽奖跳转
     * add 2016／10/19 shitao
     * @return [type] [description]
     */
    public function lottery_post(){
        $token=session('FFtoken');
        $Fewm_id = '';
        $phone = '';
        if($_GET['Fewm_id']){
            $Fewm_id = $_GET['Fewm_id'];
            $token=$this->gettoken($Fewm_id);
        }
        if($_GET['phone']){
            $phone = $_GET['phone'];
        }

        $jf = 200;
        $passwd='123456';

        $data['Fewm_id']= $Fewm_id;
        $data['Fusername']=$phone;
        $data['Fpassword']=md5($passwd);
        $data['Faddress']='';
        $data['Fremark']='';
        $data['Ffloorid']='';
        $data['Fcreatetime']=time();
        $db=M('wa_users');

        //判断一个码不能多用户注册
        $erw=$db->field('Fewm_id')->where(array('Fewm_id'=>$Fewm_id))->find();
        if($erw){
            echo '此二维码已被绑定';
            exit();
        }
        $res=$db->where(array('Fusername'=>$phone,'Ftoken'=>$token))->find();
        // var_dump($res);
        // exit();
        // 同个水站用户已注册过，更新
        if($res){
            $data['Fewm_id']=$Fewm_id;
            $res=$db->where(array('Fusername'=>$phone,'Ftoken'=>$token))->save($data);
            $_SESSION['FFphone']=$phone;

            if($res){
                $this->check_status($Fewm_id);
                // echo 'sccuess';
                $this->redirect(U('Store/index',array('FFphone' => $phone,'FFtoken'=>$token,'FFqid'=>$Fewm_id,'Fewm_id'=>$Fewm_id)));
            }
        }else{
        // 没注册过，添加用户
            $data['Ftoken']=$token;
            $data['Fstatus']='1';
            $aid=$db->add($data);

            $integration=M('wa_integration');
            $data2['Fproductid']= -3;
            $data2['Ftotal']=200;
            $data2['Ftoken']=$token;
            $data2['Fphone']=$phone;
            $data2['Fcreatetime']=time();
            $c=$integration->add($data2);

            $_SESSION['FFphone']=$phone;
            if($res){
                $this->check_status($Fewm_id);
            }
            $this->redirect(U('Store/index',array('FFphone' => $phone,'FFtoken'=>$token,'FFqid'=>$Fewm_id,'Fewm_id'=>$Fewm_id)));
            //注册成功后的提示
             // echo 'sccuess';
        }
       
    }

}
?>
