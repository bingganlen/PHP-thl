<?php
/*
*周边服务 2016.04.14 author 成龙
*/
    class NativelifeAction extends WapAction{
        //判断是否开启
    	public function index(){
    		$type=$_POST['type'];
    		$token=trim($_POST['token']);
    		$db=M('Wa_near');
    		$res=$db->field('status')->where(array('token'=>$token,'type'=>$type))->find();
    		if(!$res || $res['status']==0){
    			$data['status']='0';
    			
    		}else{
    			$data['status']='1';
    		}
            echo json_encode($data);

    	}
        //周边服务详情
    	public function info(){
            $type=addslashes($_GET['type']);
    		$token=trim(addslashes($_GET['token']));
    		$db=M('Wa_near');
    		$res=$db->field('des,type,phone')->where(array('token'=>$token,'type'=>$type))->find();
    		session('phone',$res['phone']);
    		$this->assign('info',$res);
    		$this->display();
    	}

        public function order(){
             
             // 两分钟内重复下单
            if(!empty(session('createtime')) && session('createtime')+120>time()){
                echo json_encode('2');
                exit();
            }
             //用户不存在
            if(empty(session('FFphone'))){
                 echo json_encode('3'); 
                 exit();
            }
             $type=addslashes($_POST['type']);
             $token=addslashes($_POST['token']);

             $yCode = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J');
             $orderSn = $yCode[intval(date('Y')) - 2011] . strtoupper(dechex(date('m'))) . date('d') . substr(time(), -5) . substr(microtime(), 2, 5) . sprintf('%02d', rand(0, 99));
             //$bossphone
             $ad=M('Wa_users')->field('Faddress')->where(array('Fusername'=>session('FFphone')))->find();
             $db=M('Wa_near');
            
             $address=$ad['Faddress'];
             $data['address']=$address;
             $data['userphone']=session('FFphone');
             $data['token']=$token;
             $data['type']=$type;
             $nativeinfo=$db->field('name,phone')->where(array('token'=>$token,'type'=>$type))->find();
             if(!$nativeinfo){
                //参数有误！
                echo json_encode('4');
                exit();
             }
             $data['bossphone']=$nativeinfo['phone'];
             $data['ordernum']=$orderSn;
             $data['createtime']=time();
             $or=M('Wa_nearorder')->add($data);

             if($or){
                session('createtime',time());
                echo json_encode('1');
             }else{
                echo json_encode('-1');
             }


        }

    public function orderlist(){

        $type=$_GET['type'];
        $token=$_GET['token'];
        $status=!empty($_GET['status'])?$_GET['status']:0;

        $orderlist=M('Wa_nearorder')->where(array('token'=>$token,'userphone'=>session('FFphone'),'status'=>$status))->order('createtime desc')->select();
              switch ($type) {
            case '0':
                $servername='回收';
                break;
            case '1':
                $servername='清洁';
                break;
            case '2':
                $servername='干洗';
                break;
            case '3':
                $servername='常用';
                break;
            
            default:
                 $servername='暂无服务';
                break;
        }
        $this->assign('servername',$servername);
        $this->assign('type',$type);
        // $this->assign('phone',session('phone'));
        if($status=='1'){
          $this->assign('orderlist2',$orderlist);  
        }
        $FFphone=session('FFphone');
        $FFqid=session('FFqid');
        $this->assign('FFphone',$FFphone);
        $this->assign('FFqid',$FFqid);
        $this->assign('orderlist',$orderlist);

        //加载更多
        $cont=M('Wa_nearorder')->field('count(id) as count2')->where(array('token'=>$token,'userphone'=>$FFphone,'status'=>0))->find();
        $cont1=M('Wa_nearorder')->field('count(id) as count2')->where(array('token'=>$token,'userphone'=>$FFphone,'status'=>1))->find();


    $this->assign('cont',$cont['count2']); 
    $this->assign('cont1',$cont1['count2']); 
        $this->display();

    }

//加载更多
public function ordersload(){

 $offset=$_GET['offset'];
 $status=$_GET['status'];
 $token=$_GET['token'];
 $type=$_GET['type'];

 $order=M('Wa_nearorder');
 
    $orderlist=$order->where(array('token'=>$token,'userphone'=>session('FFphone'),'status'=>$status))->limit(0,$offset)->select();
    $this->assign('orders',$orderlist);

    $this->display();

}

public function orders_hander(){
   $type=$_GET['type'];
   $token=$_GET['token'];
   $id=$_GET['id'];

   $orderinfo=M('Wa_nearorder');
   $orders=$orderinfo->where(array('id'=>$id))->find();
   $this->assign('orderinfo',$orders);

   $this->display();
}

//取消订单
public function cancel(){
    $id=$_GET['id'];
    $token=$_GET['token'];
    $res=M('Wa_nearorder')->where(array('id'=>$id))->save(array('status'=>2,'lasttime'=>time()));
    if($res){
         $this->redirect(U('Nativelife/orderlist',array('token'=>$token,'type'=>0,'status'=>0)));
    }else{
        $this->error('错误');
    }

}

//催单  接口为之$url=C('my_api').$token.'/0?warn=-1';
   //$url='api.fangweihao.com:3000/water/'.$token.'/0?warn=-1';
  
 //设置订单催单状态
 public function cd(){
   $id=$_POST['id'];
   
   $token=$_POST['token'];
  
   if(empty(session('cdtime'))){
      $cdtime=time();
      session('cdtime',$cdtime);
   }else{
     if((session('cdtime')+60)>time()){
       
       echo '2';
       exit();
     }
     session('cdtime',time());
   }

   $sta=M('Wa_nearorder')->field('status')->where(array('id'=>$id))->find();
   if($sta['status']!='0'){
      echo '3';
      exit();
   }
   //声音接口
   //$url=C('my_api').$token.'/0?warn=-1';

   //$rest=url_get($url);
   $res=M('Wa_nearorder')->where(array('id'=>$id))->save(array('status'=>3,'lasttime'=>time()));
  
   echo $res;
 }


    }


?>

