<?php 

  /**
  *   2015-12.15  抽奖活动
  *
  *
  **/
class StoreactiveAction extends WapAction{
  
    public function info(){
      $dbset=M('Wa_praisedset');
      $sta=$dbset->field('Fstatus')->find();
      if($sta['Fstatus']=='0'){
        $this->error('此活动已结束');
        exit();
      }
      $this->display(); 
    }

    public function praiseslist(){
      $db=M();
      $dbset=M('Wa_praisedset');
      $sta=$dbset->field('Fendtime,Ftimes')->find();
      $this->assign('endtime',$sta['Fendtime']);
      $token=$_GET['FFtoken'];
      $FFqid=$_GET['FFqid'];

      if(empty(session('Fcustom_user'))){
          $this->redirect(U('Reg/slogin',array('FFtoken'=>$token,'FFqid'=>$FFqid)));
          exit();
      };
      $username=session('Fcustom_user');
     $sql1='select p.Ftype,p.Fsn,p.Fisuse,p.Fcreatetime,s.id,s.name from tp_wa_praised as p left join tp_wa_praised_type as s on s.id=p.Ftype where p.Fusername='.$username.' and p.Ftype=1 and p.Ftoken="'.$token.'"';
    
     $res1=$db->query($sql1);
      $sql2='select p.Ftype,p.Fsn,p.Fisuse,p.Fcreatetime,s.id,s.name from tp_wa_praised as p left join tp_wa_praised_type as s on s.id=p.Ftype where p.Fusername='.$username.' and p.Ftype=2 and p.Ftoken="'.$token.'"';
     $res2=$db->query($sql2);
      $sql3='select p.Ftype,p.Fsn,p.Fisuse,p.Fcreatetime,s.id,s.name from tp_wa_praised as p left join tp_wa_praised_type as s on s.id=p.Ftype where p.Fusername='.$username.' and p.Ftype=3 and p.Ftoken="'.$token.'"';
     $res3=$db->query($sql3);
     if($res1){
     
       $this->assign('bid1','bid1');
     }
     if($res2){

       $this->assign('bid2','bid2');
     }
     if($res3){
     
       $this->assign('bid3','bid3');
     }
     $this->assign('list1',$res1);
     $this->assign('list2',$res2);
     $this->assign('list3',$res3);

     //截止日期
     $praiselog=M('Wa_praised');

      $begintime=strtotime(date('Y-m-d'));
      $where['Fusername']=session('Fcustom_user');
      $where['Ftoken']=$token;
      $where['Fcreatetime']=array('between',array($begintime,time()));
      $praisecount=$praiselog->where($where)->count();

 
     $lasttimes=intval($sta['Ftimes']-$praisecount);
    
     //判断当前订单的次数
   $daybegin=strtotime(date("Ymd"));  
   $dayend=$daybegin+86400;
   $choujwhere['Fusers']=session('Fcustom_user');
   $choujwhere['Fordertime']=array('between',array($daybegin,$dayend));

   //$choujiangcount=M('Wa_orders')->where($choujwhere)->find();

   if($_COOKIE['prizetime']){
       $lasttimes=$lasttimes+2;
   }
  
     $this->assign('praisecount',$praisecount);
     $this->assign('lasttimes',$lasttimes);
     $this->display();
    }

    //开始抽奖
    public function activedo(){

      $username=$_SESSION['Fcustom_user'];
      $token=$_GET['token'];
      $this->assign('username',$username);
      $this->assign('token',$token);
      $this->display();
    }

    public function activeprocess(){
       
       $username=$_POST['username'];
       $token=$_POST['token'];
       $dbset=M('Wa_praisedset');
       $praiselog=M('Wa_praised');

       $set=$dbset->find();

       $sname=$set['Fname'];
       $sstatus=$set['Fstatus'];
       $sendtime=$set['Fendtime'];
       $stimes=$set['Ftimes'];   //下过单的话 次数可能要变
       $sprobability=$set['Fprobability'];

       //活动结束
       if($sendtime<time()){
          echo 'end';
          exit();
       }

      //查询今天抽奖了几次

      $begintime=strtotime(date('Y-m-d'));
      $where['Fusername']=$username;
      $where['Ftoken']=$token;
      $where['Fcreatetime']=array('between',array($begintime,time()));
      $con=$praiselog->where($where)->count();
      
      //判断是否今天 有下单 增加2次

      $order=M('Wa_orders');
      $whereorder['Fordertime']=array('gt',$begintime);
      $whereorder['Fusers']=$username;
      $whereorder['Ftoken']=$token;
      //$ordercount=$order->where($whereorder)->count();
      
      if($_COOKIE['prizetime']){
           $stimes= $stimes+2;
      }
  
     if(($con>=$stimes) || ($con>=3)){
        //今天抽奖次数已到
        echo 'timesend';
        exit();

     }
     

     //设置抽奖概率  60 150 900 850
     //$percentvalue=($sprobability/300)*1000;
     // $unpercentvalue=1000-($percentvalue*3);
    $v1=(60/2000)*1000;
    $v2=(150/2000)*1000;
    $v3=(900/2000)*1000;
    $v4=(890/2000)*1000;

    

    //奖品数组
  $prize_arr = array(   
    '0' => array('id'=>1,'prize'=>'Surprise','v'=>$v1),   
    '1' => array('id'=>2,'prize'=>'Lucky','v'=>$v2),   
    '2' => array('id'=>3,'prize'=>'Happy','v'=>$v3), 
    '3' => array('id'=>4,'prize'=>'下次没准就能中哦','v'=>$v4)  
    );

  foreach ($prize_arr as $key => $val) {   
    $arr[$val['id']] = $val['v'];   
  } 
  $rid = $this->get_rand($arr);
 
  // 抽奖信息log
  $yCode = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J');
  $str=$yCode[array_rand($yCode,1)];
  $Fsn=$str . rand(1000000,9999999);
  //查询抽奖的剩余卡数
  $unums=$praiselog->where(array('Ftype'=>$rid))->count();

 
  if(($rid==1) && ($unums>=60)){
     $rid=4;
  }else if(($rid==2) && ($unums>=150)){
       $rid=4;
  }else if(($rid==3) && ($unums>=900)){
      $rid=4;
  }else{
      $rid=$rid; 
  }


  $praiselog->add(array('Fusername'=>$username,'Ftype'=>$rid,'Fcreatetime'=>time(),'Ftoken'=>$token,'Fsn'=>$Fsn));

  echo $rid;
  // echo $praiselog->getLastSql();
}
   
  //
  public function get_rand($proArr) {   
    $result = '';    
    //概率数组的总概率精度   
    $proSum = array_sum($proArr);    
    //概率数组循环   
    foreach ($proArr as $key => $proCur) {   
        $randNum = mt_rand(1, $proSum);   
        if ($randNum <= $proCur) {   
            $result = $key;   
            break;   
        } else {   
            $proSum -= $proCur;   
        }         
    }   
    unset ($proArr);    
    return $result;   
}

//活动判断水站
public function activeon($token){
  if($token=='gkgosv1442290930'){
      return '1';
  }else{
      return '2';
  }
}
}

?>
