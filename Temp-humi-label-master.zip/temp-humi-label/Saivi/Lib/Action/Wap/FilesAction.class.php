<?php
class FilesAction extends WapAction{

    public function _initialize() {
        parent::_initialize();
        // $this->assign('token',session('token'));
        // $this->assign('staticFilePath', str_replace('./','/',THEME_PATH.'common/css/store'));
    }

//查看是否有存量数据
    public function checkcount(){
    $labelget=$_GET['labelId'];
    $startget=$_GET['startDate'];
    $tbname=$labelget."_".date("Y",$startget);
    
    //判断文件是否存在   
    $filenames=$this->filename('uploads/files');    
    if(!empty($filenames)){        //有文件

        $filearr=array();
        foreach ($filenames as $key => $value) {
            $filearr[]=substr($value,0,strpos($value,'_'));
        }
        
        //有匹配文件
        if(in_array($labelget,$filearr)){
            dump("inarray");
            $redis_o = new Redis() or die("Cannot load Redis module.");
            $redis_o->connect('localhost',6379);
            $auth = $redis_o->auth('redis');//redis改为你的redis密码
            $labelId=$redis_o->get('labelId');
            $startDate=$redis_o->get('startDate');            
            if($labelId==$labelget && $startDate==$startget){
                return $redis_o->get('temps_num');//文件正在处理，返回条数              
            }else{                
                return false;//文件存在但尚未处理，不允许上传
            }
        }elseif(M()->query('show tables like "tp_'.$tbname.'"')){//有数据表，输出数据量
        //dump(M()->query('show tables like "tp_'.$tbname.'"'));        
            $where['time']=array('egt',$startget);
            $count=M()->table('tp_'.$tbname)->where($where)->count();
            dump($count);//数据库中有存量数据，返回条数
            return $count;
        }else{
            dump("表不存在");
            return true;//标签数据未入库,可以上传
        }
    }elseif(M()->query('show tables like "tp_'.$tbname.'"')){
        
        $where['time']=array('egt',$startget);
        $count=M()->table('tp_'.$tbname)->where($where)->count();
        return $count;//有数据表，返回数据量
    }else{
        dump("无此标签");
        return true;//标签无入库数据，可以直接上传
    }
    
    }
    
    protected function filename($dir){

    $handler = opendir($dir);
    while(($filename = readdir($handler))!==false){
        if($filename !="." && $filename !=".."){
            $filenames[]=$filename;            
        }
    }
    closedir($handler);
    return $filenames;
  }
    /**
     * 抽奖跳转
     * add 2016／10/19 shitao
     * @return [type] [description]
     */
    public function lottery_post(){
        $token=session('FFtoken');
        $Fewm_id = '';
        $phone = '';
        if($_GET['Fewm_id']){
            $Fewm_id = $_GET['Fewm_id'];
            $token=$this->gettoken($Fewm_id);
        }
        if($_GET['phone']){
            $phone = $_GET['phone'];
        }

        $jf = 200;
        $passwd='123456';

        $data['Fewm_id']= $Fewm_id;
        $data['Fusername']=$phone;
        $data['Fpassword']=md5($passwd);
        $data['Faddress']='';
        $data['Fremark']='';
        $data['Ffloorid']='';
        $data['Fcreatetime']=time();
        $db=M('wa_users');

        //判断一个码不能多用户注册
        $erw=$db->field('Fewm_id')->where(array('Fewm_id'=>$Fewm_id))->find();
        if($erw){
            echo '此二维码已被绑定';
            exit();
        }
        $res=$db->where(array('Fusername'=>$phone,'Ftoken'=>$token))->find();
        // var_dump($res);
        // exit();
        // 同个水站用户已注册过，更新
        if($res){
            $data['Fewm_id']=$Fewm_id;
            $res=$db->where(array('Fusername'=>$phone,'Ftoken'=>$token))->save($data);
            $_SESSION['FFphone']=$phone;

            if($res){
                $this->check_status($Fewm_id);
                // echo 'sccuess';
                $this->redirect(U('Store/index',array('FFphone' => $phone,'FFtoken'=>$token,'FFqid'=>$Fewm_id,'Fewm_id'=>$Fewm_id)));
            }
        }else{
        // 没注册过，添加用户
            $data['Ftoken']=$token;
            $data['Fstatus']='1';
            $aid=$db->add($data);

            $integration=M('wa_integration');
            $data2['Fproductid']= -3;
            $data2['Ftotal']=200;
            $data2['Ftoken']=$token;
            $data2['Fphone']=$phone;
            $data2['Fcreatetime']=time();
            $c=$integration->add($data2);

            $_SESSION['FFphone']=$phone;
            if($res){
                $this->check_status($Fewm_id);
            }
            $this->redirect(U('Store/index',array('FFphone' => $phone,'FFtoken'=>$token,'FFqid'=>$Fewm_id,'Fewm_id'=>$Fewm_id)));
            //注册成功后的提示
             // echo 'sccuess';
        }
       
    }

}
?>
