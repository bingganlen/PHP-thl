<?php
class RecomAction extends WapAction{
    public function _initialize() {
        parent::_initialize();
        // $this->assign('token',session('token'));
        // $this->assign('staticFilePath', str_replace('./','/',THEME_PATH.'common/css/store'));
    }

    // 注册
    public function reg(){
        $token=$_GET['token'];
        $this->assign('token',$token);
        $this->display();
    }

    // 注册验证
    public function reg_check(){
        $name=$this->_post('name');
        $passwd=$this->_post('passwd');

        $yzm=$this->_post('verifyMP');
        $token=$this->_post('token');

        if($name==''||$passwd=='')
            $this->error('请填写完整的用户名密码');

        if($yzm!=$_SESSION['verifyMP'])
            $this->error('验证码错误');

        $data['Fphone']=$name;
        $data['Fpwd']=md5($passwd);
        
        $data['Ftoken']=$token;
        $data['Fcreate_time']=time();
        $db=M('wa_recom');
        
        $res=$db->where(array('Fphone'=>$name,'Ftoken'=>$token))->find();
        if($res){
            $this->error('此用户名已注册');
        }else{
            // $where['Fusername']=$name;
            // $data['Fewm_id']=$Fewm_id;
            $res=$db->add($data);
            $_SESSION['worker_no']=$db->getLastInsID();;
            $_SESSION['Wtoken']=$token;
            $_SESSION['Wphone']=$name;
        }


        

        $this->redirect(U('Recom/slist',array('Wtoken'=>$token,'Wphone'=>$name)));
    }

    // 登录
    public function login(){
        $token=$_GET['token'];
        $this->assign('token',$token);
        $this->display();
    }


    // 登录验证
    public function login_chk(){
        $name=$this->_post('name');
        $passwd=$this->_post('passwd');
        $token=$this->_post('token');

        if($name==''||$passwd=='')
                $this->error('请填写完整的用户名密码');
        
        $db=M('wa_recom');
        $where=array('Fphone'=>$name,'Fpwd'=>md5($passwd),'Ftoken'=>$token);
        $res=$db->where($where)->find();
        if($res){
            $_SESSION['Wtoken']=$token;
            $_SESSION['Wphone']=$name;
            $_SESSION['worker_no']=$res['Fid'];
            $this->redirect(U('Recom/slist',array('Wtoken'=>$token,'Wphone'=>$name)));
        }else{
            $this->error('用户名或密码不正确');
        }
    }


// 统计列表页
public function slist(){
    $Wtoken=$this->getWtoken();
    $Wphone=$this->getWphone();
    if(empty($Wtoken) || empty($Wphone)){
         $this->redirect(U('Recom/login',array('token'=>$Wtoken)));
         exit();
    }
    $db=M('wa_recom');
    $where=array('Fphone'=>$Wphone,'Ftoken'=>$Wtoken);
    $res=$db->where($where)->find();
    $this->assign('res',$res);
    $sql="SELECT count(Fid) as num ,sum(Fmoney) as money FROM tp_wa_recomlog  where Fworker_no ='".$res['Fid']."' and Fuser ='".$Wphone."'";
    // $where=array('Fworker_num'=>$res['Fid'],'Fuser'=>$Wphone);
    $res1=M('wa_recom')->query($sql);
    $this->assign('res1',$res1[0]);
    $this->display();
}
// 未下单(人数)
public function wdd(){
    $Wtoken=$this->getWtoken();
    $Wphone=$this->getWphone();
    $num=$_SESSION['worker_no'];
    $sql0="SELECT count(*) as count FROM   tp_wa_users  WHERE Fstatus='1' and Frecom='".$num."'";
    $res0=M()->query($sql0);
    $count=$res0[0]['count'];
    if($count>0){
        $sql="SELECT * FROM  tp_wa_users  WHERE Fstatus ='1' and Frecom='".$num."' order by Fcreatetime desc";
        $res=M()->query($sql);
        $this->assign('res',$res);
    }

    $this->assign('token',$Wtoken);
    $this->display();
}

// 已下单（用户）
public function ydd(){
    $Wtoken=$this->getWtoken();
    $Wphone=$this->getWphone();
    $num=$_SESSION['worker_no'];
    $sql0="SELECT count(*) as count FROM   tp_wa_users  WHERE Fstatus='2' and Frecom='".$num."'";
    // $sql0="SELECT count(*) as count FROM tp_wa_recomlog as log left JOIN  tp_wa_users as users on log.Fworker_no=users.Frecom WHERE users.Fstatus='2'";
    $res0=M()->query($sql0);
    $count=$res0[0]['count'];
    if($count > 0){
        $sql="SELECT * FROM  tp_wa_users  WHERE Fstatus ='2' and Frecom='".$num."' order by Fcreatetime desc";
        // $sql="SELECT * FROM tp_wa_recomlog as log left JOIN  tp_wa_users as users on log.Fworker_no=users.Frecom WHERE users.Fstatus='2' order by log.Fcreatetime desc";
        $res=M()->query($sql);
        foreach ($res as $key ) {
            $i=0;
            $res[$i]['money']=$this->getmoney($key['Fusername']);
            $i++;
        }
        $this->assign('res',$res);
    }

    $this->assign('token',$Wtoken);
    $this->display();

}
// 公共函数
// 查询每个推荐学生的奖励总金额
public function getmoney($phone){
     $sql="SELECT sum(Fmoney) as money FROM  tp_wa_recomlog WHERE Fphone='".$phone."' ";
     $res=M()->query($sql);
     $money=$res[0]['money'];
     return $money;
}


public function getWtoken(){
     if(!empty(session('Wtoken'))){
        $Wtoken=session('Wtoken');
      }else if(!empty($_GET['Wtoken'])){
        $Wtoken=$_GET['Wtoken'];
        session('Wtoken',$Wtoken);
      }else if(session('Wtoken') && $_GET['Wtoken']){
        $Wtoken=session('Wtoken');
      }else{
        $Wtoken='';
      }
      return $Wtoken;
}

private function getWphone(){
     if(!empty(session('Wphone'))){
        $Wphone=session('Wphone');
      }else if(!empty($_GET['Wphone'])){
        $Wphone=$_GET['Wphone'];
        session('Wphone',$Wphone);
      }else if(session('Wphone') && $_GET['Wphone']){
        $Wphone=session('Wphone');
      }else{
        $Wphone='';
      }
      return $Wphone;
}


 }
?>
