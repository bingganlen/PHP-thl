<?php
/**
 *网站后台
 *@package 
 *@author 
 **/
class BannerAction extends BackAction{
        public function _initialize() {
                parent::_initialize();
        }

        public function index(){
		if(IS_POST){//var_dump($_FILES);exit();
                        if($_FILES['image']['tmp_name']){
                                if (!file_exists('./uploads/'.date('y-m',time()))){ mkdir ("./uploads/".date('y-m',time()));}
                                if (!file_exists('./uploads/'.date('y-m',time()).'/tmp')){ mkdir ("./uploads/".date('y-m',time())."/tmp");}
                                copy($_FILES['image']['tmp_name'], './uploads/'.date('y-m',time()).$_FILES['image']['tmp_name']);
                        }
                        //var_dump($_FILES);var_dump($_POST);exit();
                        $_POST['logourl'] = '/uploads/'.date('y-m',time()).$_FILES['image']['tmp_name'];
                        $_POST['createtime'] = time();
                        $_POST['uid'] = $_SESSION['userid'];
                        $db = M('wa_distributor_banner');
                        $db->add($_POST);
                        //var_dump($db->getLastSql());exit();
                        $this->success('保存成功');
                }

                $db = M('wa_distributor_banner');
                $data = $db->where(array('uid'=>$_SESSION['userid']))->order('sort')->select();
                //var_dump($data);

                $this->assign('data',$data);

		$this->display();
	}

	public function del(){
                $db = M('wa_distributor_banner');
                $db->where(array('uid'=>$_SESSION['userid'], 'id'=>$_GET['id']))->delete();
                $this->success('删除成功');
        }

        public function set(){
                if(IS_POST){
                        if($_FILES['image']['tmp_name']){
                                if (!file_exists('./uploads/'.date('y-m',time()))){ mkdir ("./uploads/".date('y-m',time()));}
                                if (!file_exists('./uploads/'.date('y-m',time()).'/tmp')){ mkdir ("./uploads/".date('y-m',time())."/tmp");}
                                copy($_FILES['image']['tmp_name'], './uploads/'.date('y-m',time()).$_FILES['image']['tmp_name']);
                                $_POST['logourl'] = '/uploads/'.date('y-m',time()).$_FILES['image']['tmp_name'];
                        }else{
                                unset($_POST['logourl']);
                        }
                        $db = M('wa_distributor_banner');
                        $db->where(array('id'=>$_GET['id']))->save($_POST);
                        $this->success('保存成功', '/index.php?g=Distributor&m=Banner&a=index');
                }

                $db = M('wa_distributor_banner');
                $data = $db->where(array('id'=>$_GET['id']))->find();
                //var_dump($data);

                $this->assign('vo',$data);
                $this->display();
        }
}
