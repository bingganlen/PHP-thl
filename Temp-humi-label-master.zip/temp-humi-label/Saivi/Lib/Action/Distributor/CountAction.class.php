<?php
/**
 *网站后台
 *@package 
 *@author 
 **/
class CountAction extends BackAction{
        public function _initialize() {
                parent::_initialize();
        }

	public function index(){
		//var_dump($_SESSION);
		$wxuser = M('wxuser')->where(array('Fdis_id'=>$_SESSION['userid']))->select();

		
	// 开始时间当天0:0:1
        if(!empty($this->_post('st')))
        {
            $st=strtotime($this->_post('st'))+1;
        }else{
            $st=strtotime(date("Y-m-d",time()))+1;
        }
        
        $e1=$this->_post('e');
        $st1=$this->_post('st');
         if($e1==$st1 && $e1!=''&$st1!=''){
             if(!empty($this->_post('st')))
                {
                    $st=strtotime($this->_post('st'))+1;
                }else{
                    $st=strtotime(date("Y-m-d",time()))+1;
                }
            $e=time();
        }

        // 结束时间当天23:59：59
         if(!empty($this->_post('e')))
        {
            $e=strtotime($this->_post('e'))-1;
        }else{
            // $e=strtotime(date('Y-m-d',time()));
            $e=time();
        }
        $token=$_POST['token'];
        $this->assign('start',$st);
        $this->assign('last',($e+2));

if(IS_POST){
// 注册数统计
        $sql="SELECT count(Fid) as num from tp_wa_users WHERE Ftoken='".$token."' AND Fcreatetime>='".$st."' AND Fcreatetime<='".$e."' ";
        $res=M()->query($sql);
        $cnum= $res[0]['num'];
// 总注册数
        $sql1="SELECT count(Fid) as num from tp_wa_users WHERE Ftoken='".$token."' ";
        $res1=M()->query($sql1);
        $ctotal= $res1[0]['num'];
        $this->assign('cnum',$cnum);
        $this->assign('ctotal',$ctotal);

// 订单数统计

    $sql6="SELECT count(Fid) as num FROM tp_wa_orders WHERE Ftoken='".$token."'  AND Fordertime>='".$st."' AND Fordertime<='".$e."' AND Fstatus !='0'";
    $res6=M()->query($sql6);
    $num= $res6['0']['num'];
    $this->assign('num',$num);


    $time=date('Y-m-d',time());
    $sql5="SELECT count(Fid) as num FROM tp_wa_orders WHERE Ftoken='".$token."'  AND Fcreatetime='".$time."'  AND Fstatus !='0' ";
    $res5=M()->query($sql5);
    $tonum= $res5['0']['num'];
    $this->assign('tonum',$tonum);


// 送水工
        // $sql2="SELECT * from tp_wa_workers as worker left JOIN tp_wa_workerlog as log on log.Fw_id=worker.Fid WHERE worker.Ftoken='".$token."'"
        // $sql2="SELECT * FROM tp_wa_workers WHERE Ftoken ='".$token."'";
        $sql2="SELECT SUM(goods.Fnum) as Fnum ,orders.Fphone FROM tp_wa_orders as orders left JOIN tp_wa_ordergoods as goods on orders.Fid=goods.Foid WHERE orders.Ftoken='".$token."'  AND orders.Fphone !='' AND orders.Fordertime>='".$st."' AND orders.Fordertime<='".$e."' AND orders.Fstatus='3' GROUP BY orders.Fworkerid ";
        $res2=M()->query($sql2);
        $this->assign('res2',$res2);
        



//商品统计 
    // $sql3="SELECT * FROM tp_product WHERE token ='".$token."'";
    $sql3="SELECT SUM(goods.Fnum)as Fnum ,goods.Fgoodsname FROM tp_wa_orders as orders left JOIN tp_wa_ordergoods as goods on orders.Fid=goods.Foid WHERE orders.Ftoken='".$token."'  AND orders.Fordertime>='".$st."' AND orders.Fordertime<='".$e."' AND orders.Fstatus='3' GROUP BY goods.Fgoodsid";
    $res3=M()->query($sql3);
    $this->assign('res3',$res3);
}


		$this->assign('wxuser', $wxuser);
		$this->display();
	}
}
