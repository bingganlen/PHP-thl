<?php
/**
 *网站后台
 *@package 
 *@author 
 **/
class OrderAction extends Action{
    
    	public function _initialize() {
         	define('RES',THEME_PATH.'common');
    }

    public function index(){
    	$userid=$_SESSION['userid'];
        $wxuser=M('Wxuser');
        $tokens=$wxuser->field('wxname,token')->where(array('Fdis_id'=>$userid))->select();
        $token='';

        if(IS_POST){
            $Fordertime=!empty($_POST['Fordertime'])?strtotime(trim($_POST['Fordertime'])):0;
            $Fstatus=$_POST['Fstatus'];
            $this->assign('Fordertime',trim($_POST['Fordertime']));

            $token=$_POST['token'];
            $where = array();
            if($token != NULL && $token!=-1){
                $where['o.Ftoken']=$token;
            }
            if(!empty($Fstatus) && ($Fstatus!=-1)){
                $where['o.Fstatus']=array('eq',$Fstatus);
            }else{
                $where['o.Fstatus']=array('neq',0);
            }

            $Fordertime2=$Fordertime+24*3600;
            if($Fordertime!=0){
                 $where['o.Fordertime']=array('BETWEEN',"$Fordertime,$Fordertime2");
            }
            $where['u.Fdis_id'] = $userid;
           
            $count= M('Wa_orders')->table('tp_wa_orders o')->where($where)->join('tp_wxuser u on o.Ftoken=u.token')->count();
            $Page       = new Page($count,20);
            $orders=M('Wa_orders')->field('u.wxname,o.*')->table('tp_wa_orders o')->where($where)->join('tp_wxuser u on o.Ftoken=u.token',left)->limit($Page->firstRow.','.$Page->listRows)->order(' o.Fordertime desc')->select();
            
        }else{
            $Fordertime=!empty($_GET['Fordertime'])?strtotime(trim($_GET['Fordertime'])):0;
            $Fstatus=$_GET['Fstatus'];
            $this->assign('Fordertime',trim($_GET['Fordertime']));

            $token = $_GET['token'];

            $where = array();
            if($token != NULL && $token!=-1){
                $where['o.Ftoken']=$token;
            }
            if(!empty($Fstatus) && ($Fstatus!=-1)){
                $where['o.Fstatus']=array('eq',$Fstatus);
            }else{
                $where['o.Fstatus']=array('neq',0);
            }

            $Fordertime2=$Fordertime+24*3600;
            if($Fordertime!=0){
                 $where['o.Fordertime']=array('BETWEEN',"$Fordertime,$Fordertime2");
            }
            $where['u.Fdis_id'] = $userid;

            $count= M('Wa_orders')->table('tp_wa_orders o')->where($where)->join('tp_wxuser u on o.Ftoken=u.token')->count();
            $Page       = new Page($count,20);
            $orders=M('Wa_orders')->field('u.wxname,o.*')->table('tp_wa_orders o')->where($where)->join('tp_wxuser u on o.Ftoken=u.token',left)->limit($Page->firstRow.','.$Page->listRows)->order(' o.Fordertime desc')->select();
       
        }

        $show= $Page->show();
        $this->assign('page',$show);
        $this->assign('list',$orders);
        $this->assign('tokens',$tokens);
        $this->assign('select_token',$token);

        $this->assign('Fstatus',$Fstatus);

    	$this->display();
    }



}
?>
