<?php
/**
 *网站后台
 *@package 
 *@author 
 **/
class System2Action extends BackAction{
	public $server_url;
	public $key;
	public $topdomain;
	public $dirtype;
	public function _initialize() {
		parent::_initialize();
		$this->server_url=trim(C('server_url'));
		if (!$this->server_url){
			$this->server_url='http://up.Saivi.cn/';
		}

		$this->key=trim(C('server_key'));
		$this->topdomain=trim(C('server_topdomain'));
		if (!$this->topdomain){
			$this->topdomain=$this->getTopDomain();
		}
		if (file_exists($_SERVER['DOCUMENT_ROOT'].'/Lib')&&is_dir($_SERVER['DOCUMENT_ROOT'].'/Lib')){
			$this->dirtype=2;
		}else {
			$this->dirtype=1;
		}
		$Model = new Model();
		//检查system表是否存在
		$Model->query("CREATE TABLE IF NOT EXISTS `".C('DB_PREFIX')."system_info` (`lastsqlupdate` INT( 10 ) NOT NULL ,`version` VARCHAR( 10 ) NOT NULL) ENGINE = MYISAM CHARACTER SET utf8");
		$Model->query("CREATE TABLE IF NOT EXISTS `".C('DB_PREFIX')."update_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `msg` varchar(600) NOT NULL DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT '',
  `time` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MYISAM DEFAULT CHARSET=utf8");
	}
	public function index(){
		$where['display']=1;
		$where['status']=1;
		$order['sort']='asc';
		$nav=M('node')->where($where)->order($order)->select();
		$this->assign('nav',$nav);
		$this->display();
	}
	
	public function cat(){
		$id=$this->_get('id');
		$db=M('compinfo');
		$where['id']=$id;
		$res=$db->where($where)->find();
		$this->assign('list',$res);
		$this->display();
	}
	public function infodel(){
		$id=$this->_get('id');
                $db=M('compinfo');
                $where['id']=$id;
		$res=$db->where($where)->delete();
		if($res)
                        $this->success('删除成功');
                else
                        $this->error('删除失败');
	}
	public function infosh(){
		$id=$this->_get('id');
		$db=M('compinfo');
		$where['id']=$id;
		$data['sh']=1;
		$res=$db->where($where)->data($data)->save();
		if($res)
			$this->success('审核成功');
		else
			$this->error('审核失败');
	}

	public function userinfo(){
		$name=$this->_post('name');
		$type=$this->_post('type');
		$this->assign('aa',$name.','.$type);
		$db=M('compinfo');
		if($name!=''){
			$where['compName']=$name;
		}
		if($type!=''){
			$where['sh']=$type;
		}
		$res=$db->where($where)->order('date desc')->select();
		$this->assign('info',$res);
		$this->display();
	}

	public function menu(){
		if(empty($_GET['pid'])){
			$where['display']=2;
			$where['status']=1;
			$where['pid']=2;
			$where['level']=2;
			$order['sort']='asc';
			$nav=M('node')->where($where)->order($order)->select();
			$this->assign('nav',$nav);
		}
		$this->display();
	}

	public function main(){
		/*
		require_once('test.php');
		if (!class_exists('test')){
		$canEnUpdate=0;
		}else {
		$canEnUpdate=1;
		}
		*/
		$canEnUpdate=1;
		$this->assign('canEnUpdate',$canEnUpdate);
		//
		//
		$updateRecord=M('System_info')->order('lastsqlupdate DESC')->find();
		if ($updateRecord['lastsqlupdate']>$updateRecord['version']){
			$updateRecord['version']=$updateRecord['lastsqlupdate'];
		}
		$this->assign('updateRecord',$updateRecord);
		$this->display();
	}
	//
	public function _needUpdate(){
		$Model = new Model();
		$updateRecord=M('System_info')->order('lastsqlupdate DESC')->find();
		if (!$updateRecord){
			$Model->query('INSERT INTO `'.C('DB_PREFIX').'system_info` (`lastsqlupdate`, `version`) VALUES(0, \'0\')');
		}
		//
		$key=$this->key;
		$url=$this->server_url.'server.php?key='.$key.'&lastversion='.$updateRecord['version'].'&domain='.$this->topdomain.'&dirtype='.$this->dirtype;
		$remoteStr=@Saivi_getcontents($url);
		//
		$rt=json_decode($remoteStr,1);
		return $rt;
	}
	public function _needSqlUpdate(){
		$updateRecord=M('System_info')->order('lastsqlupdate DESC')->find();
		//
		$key=$this->key;
		$url=$this->server_url.'sqlserver.php?key='.$key.'&lastsqlupdate='.$updateRecord['lastsqlupdate'].'&domain='.$this->topdomain.'&dirtype='.$this->dirtype;
		$remoteStr=Saivi_getcontents($url);
		//
		$rt=json_decode($remoteStr,1);
		return $rt;
	}
	public function checkUpdate(){
		$rt=$this->_needUpdate();
		$needUpdate=0;
		if ($rt['success']<1){
			$sqlrt=$this->_needSqlUpdate();
			if ($sqlrt['success']<1){
			}else {
				$needUpdate=1;
			}
		}else {
			$needUpdate=1;
		}
		$this->assign('needUpdate',$needUpdate);

		$this->display();
	}
	
	protected function deldir($dir){
		$result = true;
		$dh = opendir($dir);
		while($file=readdir($dh)){
			if($file!="." && $file!=".."){
				$fullpath=$dir."/".$file;
				if(!is_dir($fullpath)){
					$result = unlink($fullpath);					
				}else{
					$this->deldir($fullpath);
				}
			}
			rmdir($fullpath);
		}
		closedir($dh);
		return $result;
	}
	
	public function clear(){
		$this->display();
	}
	
	public function del(){
		
		$dir = './Conf/logs';
		$r = $this->deldir($dir);
		if($r){
			$this->success('清除成功',U('index'));
		}else{
			$this->error('清除失败，请检查目录权限',U('index'));
		}
	}
	
	public function doUpdate(){
		$cannotWrite=0;
		if (!class_exists('ZipArchive')){
			$this->error('您的服务器不支持php zip扩展，请配置好此扩展再来升级',U('System/main'));
		}
		if (!isset($_GET['ignore'])){
			if (!is_writable($_SERVER['DOCUMENT_ROOT'].'/saivi')){
				$cannotWrite=1;
				$this->error('您的服务器saivi文件夹不可写入，设置好再升级',U('System/main'));
			}
			if (!is_writable($_SERVER['DOCUMENT_ROOT'].'/saivi/Lib/Action')){
				$cannotWrite=1;
				$this->error('您的服务器/saivi/Lib/Action文件夹不可写入，设置好再升级',U('System/main'));
			}
			if (!is_writable($_SERVER['DOCUMENT_ROOT'].'/tpl')){
				$this->error('您的服务器tpl文件夹不可写入，设置好再升级',U('System/main'));
			}
			if (!is_writable($_SERVER['DOCUMENT_ROOT'].'/tpl/User/default')){
				$this->error('您的服务器/tpl/User/default文件夹不可写入，设置好再升级',U('System/main'));
			}
		}
		/*
		require_once('test.php');
		if (!class_exists('test')){
		$this->success('检查更新',U('System/doSqlUpdate'));
		}
		*/	
		//
		$now=time();
		$updateRecord=M('System_info')->order('lastsqlupdate DESC')->find();
		$key=$this->key;
		$url=$this->server_url.'server.php?key='.$key.'&lastversion='.$updateRecord['version'].'&domain='.$this->topdomain.'&dirtype='.$this->dirtype;
		$remoteStr=@Saivi_getcontents($url);
		//
		$rt=json_decode($remoteStr,1);
		if (intval($rt['success'])<1){
			if (intval($rt['success'])==0){
				if (!isset($_GET['ignore'])){
					$this->success('继续检查更新了,不要关闭,跳是正常的'.$rt['msg'],U('System/doSqlUpdate'));
		        }else {
					$this->success('继续检查更新了,不要关闭,跳是正常的'.$rt['msg'],U('System/doSqlUpdate',array('ignore'=>1)));
				}
			}else {
				$this->success($rt['msg'],U('System/main'));
			}
		}else {
			$locationZipPath=RUNTIME_PATH.$now.'.zip';
			$filename=$this->server_url.'server.php?getFile=1&key='.$key.'&lastversion='.$updateRecord['version'].'&domain='.$this->topdomain.'&dirtype='.$this->dirtype;
			@file_put_contents($locationZipPath,@Saivi_getcontents($filename));
			//
			$zip = new ZipArchive();

			$rs = $zip->open($locationZipPath);
			if($rs !== TRUE)
			{
				$this->error('解压失败_2!Error Code:'. $rs);
			}
			//
			$cacheUpdateDirName='caches_upgrade'.date('Ymd',time());
			if(!file_exists(RUNTIME_PATH.$cacheUpdateDirName)) {
				@mkdir(RUNTIME_PATH.$cacheUpdateDirName,0777);
			}
			//
			$zip->extractTo(RUNTIME_PATH.$cacheUpdateDirName);
			recurse_copy(RUNTIME_PATH.$cacheUpdateDirName,$_SERVER['DOCUMENT_ROOT']);
			$zip->close();
			//delete
			if (!$cannotWrite){
				@deletedir(RUNTIME_PATH.$cacheUpdateDirName);
			}
			@unlink($locationZipPath);
			//record to database
			if ($rt['time']){
				M('System_info')->where(array('version'=>$updateRecord['version']))->save(array('version'=>$rt['time']));
				M('Update_record')->add(array('msg'=>$rt['msg'],'time'=>$rt['time'],'type'=>$rt['type']));
			}
			if (isset($_GET['ignore'])){
				$this->success('进入下一步(不要关闭,等待完成,跳是正常的):'.$rt['msg'],U('System/doUpdate',array('ignore'=>1)));
			}else {
				$this->success('进入下一步(不要关闭,等待完成,跳是正常的):'.$rt['msg'],U('System/doUpdate'));
			}
		}
	}
	public function doSqlUpdate(){
		//
		$now=time();
		$updateRecord=M('System_info')->order('lastsqlupdate DESC')->find();
		$key=$this->key;
		$url=$this->server_url.'sqlserver.php?key='.$key.'&excute=1&lastsqlupdate='.$updateRecord['lastsqlupdate'].'&domain='.$this->topdomain.'&dirtype='.$this->dirtype;
		$remoteStr=Saivi_getcontents($url);
		
		$rt=json_decode($remoteStr,1);
		if (intval($rt['success'])<1){
			if (intval($rt['success'])==0){
				$this->success('升级完成',U('System/main'));
			}else {
				$this->error($rt['msg'],U('System/main'));
			}
		}else {
			$Model = new Model();
			error_reporting(0);
			@mysql_query(str_replace('{tableprefix}',C('DB_PREFIX'),$rt['sql']));
			//record to database
			if ($rt['time']){
				M('System_info')->where(array('lastsqlupdate'=>$updateRecord['lastsqlupdate']))->save(array('lastsqlupdate'=>$rt['time']));
			}
			if (!isset($_GET['ignore'])){
				$this->success('进入下一步(不要关闭,耐心等待完成,跳是正常的):'.$rt['msg'],U('System/doSqlUpdate'));
			}else {
				$this->success('进入下一步(不要关闭,耐心等待完成,跳是正常的):'.$rt['msg'],U('System/doSqlUpdate',array('ignore'=>1)));
			}
		}
	}
	function rollback(){
		//20140312
		$time=substr($_GET['time'],0,8);
		$year=substr($time,0,4);
		$month=substr($time,4,2);
		$day=substr($time,6,2);
		//exit($day);
		$timeStamp=mktime(0,0,0,$month,$day,$year);
		$updateRecord=M('System_info')->order('lastsqlupdate DESC')->find();
		M('System_info')->where(array('lastsqlupdate'=>$updateRecord['lastsqlupdate']))->save(array('lastsqlupdate'=>$timeStamp,'version'=>$timeStamp));
		$this->success('您可以重新进行升级了',U('System/main'));
	}
	function curlGet($url){
		$ch = curl_init();
		$header = "Accept-Charset: utf-8";
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$temp = curl_exec($ch);
		return $temp;
	}
	function getTopDomain(){
		$host=$_SERVER['HTTP_HOST'];
		$host=strtolower($host);
		if(strpos($host,'/')!==false){
			$parse = @parse_url($host);
			$host = $parse['host'];
		}
		$topleveldomaindb=array('com','edu','gov','int','mil','net','org','biz','info','pro','name','museum','coop','aero','xxx','idv','mobi','cc','me');
		$str='';
		foreach($topleveldomaindb as $v){
			$str.=($str ? '|' : '').$v;
		}
		$matchstr="[^\.]+\.(?:(".$str.")|\w{2}|((".$str.")\.\w{2}))$";
		if(preg_match("/".$matchstr."/ies",$host,$matchs)){
			$domain=$matchs['0'];
		}else{
			$domain=$host;
		}
		return $domain;
	}

	//广告管理
	public function banner(){
       $db=D('Storeflash');
       $wx=M('Wxuser');
       $count=$db->where($where)->count();
	   $page=new Page($count,25);
       $list=$db->field('id,info,img,url,attr,token')->order('id DESC')->limit($page->firstRow.','.$page->listRows)->select();
       foreach($list as $k=>$v){
       	 $wxs=$wx->field('wxname')->where(array('token'=>$v['token']))->find();
       
         if(empty($v['token'])){
         $list[$k]['wxname']="总管理";
         }else{
         	 $list[$k]['wxname']= $wxs['wxname'];
         }

       }
        
     
       $this->assign('page',$page->show());
       $this->assign('list',$list);
	   $this->display();
	}



	public function banneradd(){

		$this->display();
	}

	public function bannerdo(){
		 $info=$_POST['info'];
		 $url=$_POST['url'];
		 $attr=$_POST['attr'];
         //C('site_url')
         $upfile="banner/".basename($_FILES['img']['name']);
    
         if($_FILES['img']['name']){
         	if(is_uploaded_file($_FILES['img']['tmp_name'])){
         		 if(!move_uploaded_file($_FILES['img']['tmp_name'], $upfile)){  
				   echo '移动文件失败';
			  }  
         	}  
         }
            $upfile='/'.$upfile;
         $data=array('info'=>$info,'url'=>$url,'img'=>$upfile,'attr'=>$attr,'token'=>'admin');
         $res=M('Storeflash')->add($data);
         if($res){
         	$this->success('成功');

         }else{
         	$this->error('失败');
         }


	}


	public function banneredit(){

		$id=$_GET['id'];
		$info=M('Storeflash')->where(array('id'=>$id))->find();
		$this->assign('info',$info);
		 $this->display();
	}

	public function bannereditdo(){
      $id=$_POST['id'];
      $info=$_POST['info'];
  
      $url=$_POST['url'];
      $img2=$_POST['img2'];
   
      $attr=!empty($_POST['attr']) ?$_POST['attr']:0;
          $db=M('Storeflash');
       $upfile="banner/".basename($_FILES['img']['name']);
    
         if($_FILES['img']['name']){
         	if(is_uploaded_file($_FILES['img']['tmp_name'])){
         		 if(!move_uploaded_file($_FILES['img']['tmp_name'], $upfile)){  
				   echo '移动文件失败';
			  }  
         	}  
         }
      $upfile='/'.$upfile;
       if(empty(basename($_FILES['img']['name']))){
       	$img=$img2;
       }else{
       	$img=$upfile;
       }
     
      $res=$db->where(array('id'=>$id))->save(array('info'=>$info,'url'=>$url,'attr'=>$attr,'img'=>$img));
      if($res){
      	$this->success('成功');
      }else{
      	$this->error('失败');
      }
   
	}

	public function bannerdel(){
		$id=$_GET['id'];
		$db=M(Storeflash);
		$re=$db->where(array('id'=>$id))->delete();
		if($re){
			$this->success('成功');
		}else{
			 $this->error('失败');
		}
	}
}
function recurse_copy($src,$dst) {  // 原目录，复制到的目录
	$dir = opendir($src);
	@mkdir($dst);
	while(false !== ( $file = readdir($dir)) ) {
		if (( $file != '.' ) && ( $file != '..' )) {
			if ( is_dir($src . '/' . $file) ) {
				recurse_copy($src . '/' . $file,$dst . '/' . $file);
			}
			else {
				copy($src . '/' . $file,$dst . '/' . $file);
			}
		}
	}
	closedir($dir);
}
function deletedir($dirname){
	$result = false;
	if(! is_dir($dirname)){
		echo " $dirname is not a dir!";
		exit(0);
	}
	$handle = opendir($dirname); //打开目录
	while(($file = readdir($handle)) !== false) {
		if($file != '.' && $file != '..'){ //排除"."和"."
			$dir = $dirname.DIRECTORY_SEPARATOR.$file;
			//$dir是目录时递归调用deletedir,是文件则直接删除
			is_dir($dir) ? deletedir($dir) : unlink($dir);
		}
	}
	closedir($handle);
	$result = rmdir($dirname) ? true : false;
	return $result;
}
function Saivi_getcontents($url){
	if (function_exists('curl_init')){
		$ch = curl_init();
		$header = "Accept-Charset: utf-8";
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$temp = curl_exec($ch);
		$errorno=curl_errno($ch);
		if ($errorno) {
			exit('curl发生错误：错误代码'.$errorno.'，如果错误代码是6，您的服务器可能无法连接我们升级服务器');
		}else {
			return $temp;
		}
	}else {
		$str=file_get_contents($url);
		return $str;
	}
}
?>
