<?php
/**
 *网站后台
 *@package 
 *@author 
 **/
class UserAction extends Action{
    
    	public function _initialize() {
         	define('RES',THEME_PATH.'common');
    }

    public function index(){
    	$userid=$_SESSION['userid'];
        $wxuser=M('Wxuser');
        $tokens=$wxuser->field('wxname,token')->where(array('Fdis_id'=>$userid))->select();
        $token='';

        if(IS_POST){
          $token=$_POST['token'];
          if ($token != NULL && $token != '-1'){
             //每个水站只能属于一个经销商不必联合查询
            $count      = M('Wa_users')->where(array('Fdis_id'=>$userid,'Ftoken'=>$token))->count();
            $Page       = new Page($count,20);
           //$users=M('Wa_users')->where(array('Ftoken'=>$token))->limit($Page->firstRow.','.$Page->listRows)->select();
            $users=M('Wa_users')->field('u.wxname,w.*')->table('tp_wa_users w')->where(array('u.Fdis_id'=>$userid,'w.Ftoken'=>$token))->join('tp_wxuser u on w.Ftoken=u.token',left)->limit($Page->firstRow.','.$Page->listRows)->order('Fid desc')->select();
           //echo M('Wa_users')->getlastSql();
          } else {
            $count= M('Wa_users')->table('tp_wa_users w')->where(array('u.Fdis_id'=>$userid))->join('tp_wxuser u on w.Ftoken=u.token')->count();
            $Page       = new Page($count,20);
            $users=M('Wa_users')->field('u.wxname,w.*')->table('tp_wa_users w')->where(array('u.Fdis_id'=>$userid))->join('tp_wxuser u on w.Ftoken=u.token',left)->limit($Page->firstRow.','.$Page->listRows)->order('Fid desc')->select();
          }
        }else{
          $token = $_GET['token'];
          if ($token != NULL && $token != '-1'){
            $count= M('Wa_users')->table('tp_wa_users w')->where(array('u.Fdis_id'=>$userid,'w.Ftoken'=>$token))->join('tp_wxuser u on w.Ftoken=u.token')->count();
            $Page       = new Page($count,20);
            $users=M('Wa_users')->field('u.wxname,w.*')->table('tp_wa_users w')->where(array('u.Fdis_id'=>$userid,'w.Ftoken'=>$token))->join('tp_wxuser u on w.Ftoken=u.token',left)->limit($Page->firstRow.','.$Page->listRows)->order('Fid desc')->select();
          }else {
            $count= M('Wa_users')->table('tp_wa_users w')->where(array('u.Fdis_id'=>$userid))->join('tp_wxuser u on w.Ftoken=u.token')->count();
            $Page       = new Page($count,20);
            $users=M('Wa_users')->field('u.wxname,w.*')->table('tp_wa_users w')->where(array('u.Fdis_id'=>$userid))->join('tp_wxuser u on w.Ftoken=u.token',left)->limit($Page->firstRow.','.$Page->listRows)->order('Fid desc')->select();
          }
        }
        $show= $Page->show();
        $this->assign('page',$show);
        $this->assign('list',$users);
        $this->assign('tokens',$tokens);
        $this->assign('select_token',$token);
//var_dump($_SESSION);
    	$this->display();
    }

	public function down(){
	        //$host = 'http://m.cloud315.org/pr/?q=';
	        header('Content-type: application/octet-stream');
	        header('Content-Disposition: attachment; filename=user.csv');
	        echo iconv('utf-8', 'gb2312', "手机号,二维码号,水站,地址,注册时间\r\n");
	
	        $con = mysql_connect(C('DB_HOST'),C('DB_USER'),C('DB_PWD'));
	        if (!$con){
	            die('Could not connect: ' . mysql_error());
	        }
	
	        mysql_select_db(C('DB_NAME'), $con);
		mysql_query("SET NAMES 'utf8'");
	
	        $sql = "SELECT a.Fusername, a.Fewm_id, b.wxname, a.Faddress, FROM_UNIXTIME(a.Fcreatetime, '%Y-%m-%d %H:%i') AS Fcreatetime FROM tp_wa_users a LEFT JOIN tp_wxuser b ON a.Ftoken = b.token WHERE b.Fdis_id = ".$_SESSION['userid'];
	        $result = mysql_query($sql);
	
	        while($v = mysql_fetch_array($result)){
	            echo iconv('utf-8', 'gb2312', $v["Fusername"].",".$v["Fewm_id"].",".$v["wxname"].",".str_replace(array("\r\n", "\r", "\n"), "", $v["Faddress"]).",".$v["Fcreatetime"]."\r\n");
	        }
	
        	mysql_close($con);
	}

}
?>
