<?php
/**
 *网站后台
 *@package 
 *@author 
 **/
class WaterAction extends BackAction{
        public function _initialize() {
		parent::_initialize();
        }

        public function index(){
		$userid=$_SESSION['userid'];
        	$wxuser=M('Wxuser');
        	$tokens=$wxuser->field('id,wxname,token')->where(array('Fdis_id'=>$userid))->select();
                
		$this->assign('tokens',$tokens);
		$this->display();
        }

	public function setpasswd(){
		$wxuser=M('Wxuser');
		$info=$wxuser->field('id,uid,wxname,token')->where(array('token'=>$_GET['token']))->find();

		if(IS_POST){
			
			$sql = 'UPDATE tp_users SET password = md5("'.$_POST['setpasswd'].'") WHERE id = '.$info['uid'];
			M('Users')->where(array('id'=>$info['uid']))->data(array('password'=>md5($_POST['setpasswd'])))->save();
			$this->success('更新成功', '/index.php?g=Distributor&m=Water&a=index');
		}
		
		$this->assign('info',$info);
		$this->display();
	}
}
