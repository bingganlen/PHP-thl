<?php
/**
 *网站后台
 *@package 
 *@author 
 **/
class UseradminAction extends Action{
    
    	public function _initialize() {
         	define('RES',THEME_PATH.'common');
    }

    public function index(){
    	$db=M('Wa_distributor');
    
    	$username=$_SESSION['username'];
    	$userid=$_SESSION['userid'];
    	$res=$db->where(array('Fid'=>$userid))->find();
        $this->assign('info',$res);
    	$this->display();
    }

    public function editdo(){
    	$Fusername=$_POST['username'];
    	$Fpassword=$_POST['password'];
    	$data['Fusername']=$Fusername;
    	$data['Fpassword']=md5($Fpassword);
    	$Fid=$_POST['id'];
    	$db=M('Wa_distributor');
    	$res=$db->where(array('Fid'=>$Fid))->save($data);
    	if($res){
    		$this->success('更新成功');
    	}else{
    		$this->error('更新失败');
    	}
    }


}
?>
