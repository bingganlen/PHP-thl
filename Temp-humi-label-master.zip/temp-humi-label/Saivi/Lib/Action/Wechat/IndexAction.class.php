<?php
/**
 * 微信入口类，做分发
 * @author  shitao
 * @version  1.0
 * @since  1.0
 */
//namespace app\wechat\controller;

//use think\Db;
use EasyWeChat\Message\Text;
use EasyWeChat\Message\Image;
use EasyWeChat\Message\Voice;
use EasyWeChat\Message\News;
use EasyWeChat\Foundation\Application;
use EasyWeChat\Server\Guard;

//use app\admin\model\Station as StationModel;

class IndexAction extends WeBaseAction
{

    public function _initialize()
    {
        parent::_initialize();
		// //微信平台
  //       $config=config('we_options');
  //       simplexml_load_string($config,  'SimpleXMLElement', LIBXML_NOCDATA | LIBXML_NOBLANKS);
  //       // phpinfo();
  //       if(!empty($config)) $this->options=array_merge($this->options,$config);
  //       $this->app = new Application($this->options);
  //       config('app_debug',false);
  //       config('app_trace',false);
  //       if(input('echostr') && $this->checkSignature()){
  //           //验证token
  //           return input('echostr');
  //       }

        // parent::_initialize();
        //微信平台
        $config=config('we_options');
        dump(123);
        // delete by shitao 20170523 
        // simplexml_load_string($config,  'SimpleXMLElement', LIBXML_NOCDATA | LIBXML_NOBLANKS);
        if(!empty($config)) $this->options=array_merge($this->options,$config);
        $this->app = new Application($this->options);
        config('app_debug',false);
        config('app_trace',false);
        if(input('echostr') && $this->checkSignature()){
            //验证token
            return input('echostr');
        }
    }

    /**
     * 主要入口控制器
     * @author shitao.tommy
     * @since   2017-03-14T13:29:21+0800
     * @version 1.0
     * @return  [type]                   [description]
     */
	public function index()
    {
        //消息处理
        $echoStr = $_GET["echostr"];

        //valid signature , option
        if($this->checkSignature()){
            echo $echoStr;   
                    
            exit;
        }

        $this->responseMsg();
    

        /*$this->app->server()->setMessageHandler(function ($message) {
            switch ($message->MsgType) {
                case 'event':
                    # 事件消息...
                    switch ($message->Event) {
                        case 'subscribe':
                            # code...
                            $we_reply_list=Db::name('we_reply')->where('we_reply_key','subscribe')->find();
                            if($we_reply_list){
                                switch ($we_reply_list['we_reply_type']) {
                                    case 'text'://回复文本
                                        $text = new Text(['content' => $we_reply_list['we_replytext_content']]);
                                        return $text;
                                        break;
                                    case 'image'://回复图片
                                        $new= new Image(['media_id' => $we_reply_list['we_replyimage_mediaid']]);
                                        return $new;
                                        break;
                                    case 'voice'://回复语音
                                        $new=new Voice(['media_id' => $we_reply_list['we_replyvoice_mediaid']]);
                                        return $new;
                                        break;
                                    case 'news'://回复图文消息
                                        $news=json_decode($we_reply_list['we_replynews'],true);
                                        $new=new News($news);
                                        return $new;
                                        break;
                                    default:
                                        $text = new Text(['content' => '亲，不明白您想说什么']);
                                        return $text;
                                        break;
                                }
                            }
                            break;
                        case 'unsubscribe':
                            # code...
                            //取消关注
                            break;
                        case 'CLICK':
                            # code...
                            //点击自定义click菜单
                            switch ($message->EventKey) {
                                case 'key1'://如果为key1菜单,执行
                                    break;
                                default :
                                    # code...
                                    break;
                            }
                            break;
                        default :
                            # code...
                            break;
                    }
                    break;
                case 'text':
                    # 文字消息...
                    $we_reply_list=Db::name('we_reply')->where('we_reply_key','like','%'.$message->Content.'%')->find();
                    if (empty($we_reply_list)){
                        $text = new Text(['content' => '亲，不明白您想说什么']);
                        return $text;
                    }else{
                        switch ($we_reply_list['we_reply_type']) {
                            case 'text'://回复文本
                                $text = new Text(['content' => $we_reply_list['we_replytext_content']]);
                                return $text;
                                break;
                            case 'image'://回复图片
                                $new= new Image(['media_id' => $we_reply_list['we_replyimage_mediaid']]);
                                return $new;
                                break;
                            case 'voice'://回复语音
                                $new=new Voice(['media_id' => $we_reply_list['we_replyvoice_mediaid']]);
                                return $new;
                                break;
                            case 'news'://回复图文消息
                                $news=json_decode($we_reply_list['we_replynews'],true);
                                $new=new News($news);
                                return $new;
                                break;
                            default:
                                $text = new Text(['content' => '亲，不明白您想说什么']);
                                return $text;
                                break;
                        }
                    }
                    break;
                case 'image':
                    # 图片消息...
                    break;
                case 'voice':
                    # 语音消息...
                    break;
                case 'video':
                    # 视频消息...
                    break;
                case 'location':
                    # 坐标消息...
                    break;
                case 'link':
                    # 链接消息...
                    break;
                // ... 其它消息
                default:
                    # code...
                    break;
            }
        });
        $this->app->server->serve()->send();*/
	}

    /**
     * 检查签名验证
     * @author shitao.tommy
     * @since   2017-03-14T13:28:13+0800
     * @version 1.0
     * @return  [boolean]        [是否通过验证]
     */
    private function checkSignature()
    {
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce = $_GET["nonce"];    
                
        $token = $this->options['token'];
        $tmpArr = array($token, $timestamp, $nonce);
        sort($tmpArr);
        $tmpStr = implode( $tmpArr );
        $tmpStr = sha1( $tmpStr );
        
        if( $tmpStr == $signature ){
            return true;
        }else{
            return false;
        }
    }

    public function responseMsg()
    {
        //get post data, May be due to the different environments
        $postStr = $GLOBALS["HTTP_RAW_POST_DATA"];
        dump($postStr);
        //extract post data
        if (!empty($postStr)){
                
                $postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
                $fromUsername = $postObj->FromUserName;
                $toUsername = $postObj->ToUserName;
                $keyword = trim($postObj->Content);
                $time = time();
                $textTpl = "<xml>
                            <ToUserName><![CDATA[%s]]></ToUserName>
                            <FromUserName><![CDATA[%s]]></FromUserName>
                            <CreateTime>%s</CreateTime>
                            <MsgType><![CDATA[%s]]></MsgType>
                            <Content><![CDATA[%s]]></Content>
                            <FuncFlag>0</FuncFlag>
                            </xml>";             
                if(!empty( $keyword ))
                {
                    $msgType = "text";
                    $contentStr = "欢迎进入订水公众号";
                    $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                    echo $resultStr;
                }else{
                    echo "抱歉，公众号正在维修";
                }

        }else {
            echo "";
            exit;
        }
    }

    public function log_list()
    {
        $data=Db::name('we_msg_log')->order('log_id desc')->paginate(config('paginate.list_rows'));
        $show=$data->render();
        $show=preg_replace("(<a[^>]*page[=|/](\d+).+?>(.+?)<\/a>)","<a href='javascript:ajax_page($1);'>$2</a>",$show);

        $this->assign('data', $data);
        $this->assign('page',$show);


        $stationModel = new StationModel;
        $stationList = $stationModel->get_all_list();
        $this->assign('station_list',$stationList);


        if(request()->isAjax()){
            return $this->fetch('ajax_log_list');
        }else{
            return $this->fetch();
        }
    }

    //Add red packet list,by Chenyuanyuan 20170829
    public function redpacket_list()
    {
        $where = [];
        $start_time=input('start_time/s','');
        $end_time = input('end_time/s','');
        if(!empty($start_time) && !empty($end_time)){
            $where['create_time'] = array(array('egt',$start_time),array('elt',$end_time),'AND');
        }

        $this->assign('start_time',$start_time);
        $this->assign('end_time',$end_time);
        
        $staff_user = input('staff_user');        
        if(!empty($staff_user)){
            $where['s.staff_no|u.user_name'] = ['like','%'.$staff_user.'%'];
        }
        $this->assign('val',$staff_user);
        /*$user_type=input("user_type");
        if($user_type>2){
            $where['s.staff_no|u.user_name'] = ['like','%'.$staff_user.'%'];
        }
        $this->assign('val',$staff_user);*/
         $data = Db::name('red_envelope_log')->alias('r')
                    ->join('user u', 'r.user_id = u.user_id', 'left')
                    ->join('staff s', 'u.staff_id = s.staff_id','left')
                    ->where($where)
                    ->field('r.*, u.user_name, s.staff_id, s.staff_name')
                    ->order('r.red_id desc')->paginate(config('paginate.list_rows'),false,['query'=>get_query()]);
        $show=$data->render();
        $show=preg_replace("(<a[^>]*page[=|/](\d+).+?>(.+?)<\/a>)","<a href='javascript:ajax_page($1);'>$2</a>",$show);

        $this->assign('data', $data);
        $this->assign('page',$show);

        if(request()->isAjax()){
            return $this->fetch('ajax_redpacket_list');
        }else{
            return $this->fetch();
        }
    }

    /**
     * 发送微信模板消息
     * @return [type] [description]
     */
    public function send_wechat_msg()
    {
        $we = new WeBase();
        $app = $we->get_app();
        $notice = $app->notice;

        $userService = $app->user;
        
        //默认天长站
        $station_id = input('station_id', 8);
        // $station_id = input('station_id', 1);
        $temp_id = input('temp_id');

        // $user_list = Db::name('user')->where('station_id', $station_id)->where('is_subscribe',1)->select();//发送给关注的人
        $user_list = Db::name('user')->where('station_id', $station_id)->select();//发送给关注的人

        // $templateId = 'mqResOlxy6dv85ZeeTnUFJ9q6vxxA30yPppdAa05nN4';  //测试环境
        $templateId = 'oHPQ11j08hQOIGwPHuzyLt8NzlGVtuJhKBLx7IFXaxY'; //正式环境
        
        switch ($temp_id) {
            case '1':
                $url = 'https://hqwell.com/m/goods/produce.html?gid=223';
                $data = array(
                     "first"  => array("谁说蓝色经典只有白酒？“维达”为您讲述一段蓝色经典的柔美故事。3联包、三层、130抽，加送15% 仅仅12元，价格几乎是苏果的一半。这段经典故事，您会拒绝吗？\n",'#FF4500'),
                     "keyword1"   => array('维达蓝色经典软抽','#555555'),
                     "keyword2"  => array('12元','#555555'),
                     "keyword3" => array('黄雀精灵','#555555'),
                     "keyword4"  => array('2017年9月18日','#555555'),
                     "remark"  => array("\n点击查看详情",'#555555'),
                );
                $content = '谁说蓝色经典只有白酒？“维达”为您讲述一段蓝色经典的柔美故事。3联包、三层、130抽，加送15% 仅仅12元，价格几乎是苏果的一半。这段经典故事，您会拒绝吗？商品名称：维达蓝色经典软抽，售出价格：12元，发布人：黄雀精灵，发布时间：2017年9月18日。 ';
                break;
            case '2':
                $url = 'https://hqwell.com/m/goods/produce.html?gid=225';
                $data = array(
                     "first"  => array("都说金纺好，其中奥妙知多少？奥妙+金纺，香飘熏衣草，柔软芬芳人不老，3kg 50元，还比华联少十块， 谁能不说好？\n",'#FF4500'),
                     "keyword1"   => array('奥妙全自动金纺温和馨香精华深层洁净洗衣液','#555555'),
                     "keyword2"  => array('50元','#555555'),
                     "keyword3" => array('黄雀精灵','#555555'),
                     "keyword4"  => array('2017年9月18日','#555555'),
                     "remark"  => array("\n点击查看详情",'#555555'),
                );
                $content = '都说金纺好，其中奥妙知多少？奥妙+金纺，香飘熏衣草，柔软芬芳人不老，3kg 50元，还比华联少十块， 谁能不说好？商品名称：维达蓝色经典软抽，售出价格：12元，发布人：黄雀精灵，发布时间：2017年9月18日。 ';
                break;
            case '3':
                $url = 'https://hqwell.com/m/goods/produce.html?gid=266';
                $data = array(
                     "first"  => array("海天盛宴咱去不了，但海天酱油俺还是玩得起的，天猫、京东9.9，黄雀今天仅9元，俺给你“海天”，“盛宴”你自己搞。\n",'#FF4500'),
                     "keyword1"   => array('海天酱油500ml','#555555'),
                     "keyword2"  => array('9元','#555555'),
                     "keyword3" => array('黄雀精灵','#555555'),
                     "keyword4"  => array('2017年9月18日','#555555'),
                     "remark"  => array("\n点击查看详情",'#555555'),
                );
                $content = '海天盛宴咱去不了，但海天酱油俺还是玩得起的，天猫、京东9.9，黄雀今天仅9元，俺给你“海天”，“盛宴”你自己搞。商品名称：维达蓝色经典软抽，售出价格：12元，发布人：黄雀精灵，发布时间：2017年9月18日。 ';
                break;
            
            default:
                $url = 'https://hqwell.com/m/goods/produce.html?gid=266';
                $data = array(
                     "first"  => array("海天盛宴咱去不了，但海天酱油俺还是玩得起的，天猫、京东9.9，黄雀今天仅9元，俺给你“海天”，“盛宴”你自己搞。\n",'#FF4500'),
                     "keyword1"   => array('海天酱油500ml','#555555'),
                     "keyword2"  => array('9元','#555555'),
                     "keyword3" => array('黄雀精灵','#555555'),
                     "keyword4"  => array('2017年9月18日','#555555'),
                     "remark"  => array("\n点击查看详情",'#555555'),
                );
                $content = '海天盛宴咱去不了，但海天酱油俺还是玩得起的，天猫、京东9.9，黄雀今天仅9元，俺给你“海天”，“盛宴”你自己搞。商品名称：维达蓝色经典软抽，售出价格：12元，发布人：黄雀精灵，发布时间：2017年9月18日。 ';
                break;
        }

        $arr = [];

        $cnt = 0;
        foreach ($user_list as $v) {
            if($v['open_id'] == 'oIRPA0Z1s2x4YGr8TDqy0-wpuzU0'){
                // $userId = $v['open_id'];
                $userId = 'oIRPA0Z1s2x4YGr8TDqy0-wpuzU0';
                $u = $userService->get($userId);
                $is_subscribe = $u['subscribe'];
                // dump($is_subscribe);
                if($is_subscribe == 1){
                    $result = $notice->uses($templateId)->withUrl($url)->andData($data)->andReceiver($userId)->send();

                    $cnt ++;
                }
            }
            // $userId = $v['open_id'];
            // $u = $userService->get($userId);
            // $is_subscribe = $u['subscribe'];
            // if($is_subscribe == 1){
            //     $result = $notice->uses($templateId)->withUrl($url)->andData($data)->andReceiver($userId)->send();
                
            //     $cnt ++;
            // }
        }
        // $cnt = count($user_list);
        $arr[] = [
                'user_name' => '发送了'.$cnt.'人',
                // 'open_id' => $v['open_id'],
                'open_id' => '',
                'temp_id' => $templateId,
                'content' => $content,
                'send_time' => date('Y-m-d H:i:s')
            ];
        Db::name('we_msg_log')->insertAll($arr);
        $this->success('操作成功！共发送了'.$cnt.'人');
    }
    //模板消息模板列表
    public function wechat_msg_list()
    {
        $we = new WeBase();
        $app = $we->get_app();
        $notice = $app->notice;
        //获得微信中的模板
        $template = $notice->getPrivateTemplates();        
        $data=$template->template_list;
        //dump($data);
        $this->assign('data',$data);
        
        $stationModel = new StationModel;
        $stationList = $stationModel->get_all_list();
        $this->assign('station_list',$stationList);       
        return $this->fetch();        
    }

    //信息发送
    public function msg_cont_send(){
        //获取填写的数据
        $template_id = input('template_id');
        $station_id = input('station_id', 8);
        $msg_url = input('msg_url');
        $line_num=input('line_num/d');

        // $user_list = Db::name('user')->where('station_id', $station_id)->where('is_subscribe',1)->select();//发送给关注的人
        $user_list = Db::name('user')->where('station_id', $station_id)->select();//发送给关注的人

        $data = array();
        $content = '';
        for($i = 0; $i < $line_num; $i++){
            if($i == 0){
                $data[input('key'.$i)]= array(input('val'.$i)."\n", '#FF4500');
            }elseif ($i == $line_num -1) {
                $data[input('key'.$i)]= array("\n".input('val'.$i), '#555555');
            }else{
                $data[input('key'.$i)]= array(input('val'.$i), '#555555');
            }
            $content= $content.input('key'.$i).':'.input('val'.$i).'。';
        }
   
        $arr = [];

        $we = new WeBase();
        $app = $we->get_app();
        $notice = $app->notice;

        $userService = $app->user;
        
        $cnt = 0;
        foreach ($user_list as $v) {
            if($v['open_id'] == 'o6emv1YBzXc4fqYvJW46HbiarOyo'){
                $userId = 'o6emv1YBzXc4fqYvJW46HbiarOyo';
                $u = $userService->get($userId);
                $is_subscribe = $u['subscribe'];
                // dump($is_subscribe);
                if($is_subscribe == 1){
                    $result = $notice->uses($template_id)->withUrl($msg_url)->andData($data)->andReceiver($userId)->send();

                    $cnt ++;
                }
            }
            // $userId = $v['open_id'];
            // $u = $userService->get($userId);
            // $is_subscribe = $u['subscribe'];
            // if($is_subscribe == 1){
            //     $result = $notice->uses($templateId)->withUrl($url)->andData($data)->andReceiver($userId)->send();
                
            //     $cnt ++;
            // }
        }
        // $cnt = count($user_list);
        $arr[] = [
                'user_name' => '发送了'.$cnt.'人',
                // 'open_id' => $v['open_id'],
                'open_id' => '',
                'temp_id' => $template_id,
                'content' => $content,
                'send_time' => date('Y-m-d H:i:s')
            ];
        Db::name('we_msg_log')->insertAll($arr);
        $this->success('操作成功！共发送了'.$cnt.'人');
    }
}
