<?php

class LoginAction extends Action {
    public function index(){
		
		$this->display('index');
    }
	Public function verify(){
		import('ORG.Util.Image');
		//Image::buildImageVerify(4,5,'png');	
		Image::buildImageVerify(4,1,'png',0,28,'verify');
		//$this->error("Image::buildImageVerify(4,1,'png',0,28,'verify');");
	}
	public function login(){
		if(!IS_POST) halt('Page not found');
		if(I('code','','md5')!=session(verify)){
			$this->error(验证码错误);
		}
		$username = I('username');
		p($username);
		$pwd = I('password','','');
		p($pwd);
		$user=M('user')->where(array('username'=>$username))->find();
		if(!$user||$user['password']!=$pwd){
			p($user['password']);
			$this->error('账号密码错误');	
		}	
		session('uid',$user[id]);
		session('username',$user[username]);
		
		
		$this->redirect('Admin/Index/index');	
	}
}