<?php
class IndexAction extends BaseAction{
	public $includePath;
	protected function _initialize(){
		parent::_initialize();
		$this->home_theme=$this->home_theme?$this->home_theme:'default';
		$this->includePath='./tpl/Home/'.$this->home_theme.'/';
		
		$this->assign('includeHeaderPath',$this->includePath.'Public_header.html');
		$this->assign('includeFooterPath',$this->includePath.'Public_footer.html');
		
	}
	public function clogin()
	{
		$cid = isset($_GET['cid']) ? intval($_GET['cid']) : 0;
		$k = isset($_GET['k']) ? $_GET['k'] : '';
		$this->assign('cid', $cid);
		$this->assign('k', $k);
		$this->display($this->home_theme.':Index:'.ACTION_NAME);
	}
	//关注回复
	public function index(){
		$where['status']=1;
		if (C('agent_version')){
			$where['agentid']=$this->agentid;
		}
		$links=D('Links')->where($where)->select();
		$seo = M('Seo');
		$data =$seo->field('id,title')->limit('10')->select();
		$this->assign('data',$data);

		$this->assign('links',$links);
		header("Location: /index.php?g=Home&m=Index&a=login");
		// echo $this->home_theme.':Index:'.ACTION_NAME;
		// $this->display($this->home_theme.':Index:'.ACTION_NAME);
	}
    // 用户登出
    public function logout() {
		session(null);
		session_destroy();
		unset($_SESSION);
        // redirect("s.fangweihao.com");
        $this->redirect('index');
		
    }
    //标签查询
public function search_detail(){	
    $cid=$this->_get('id');
    if(!$cid){
    	$this->error("查询错误");
    }
    	$where=array();
    	if(IS_POST){    		
    		if($_POST['username']){
    			$where['username'] = array('like','%'.$_POST['username'].'%');   			
    		}
    		if($_POST['uptime']){
    			$st=strtotime($_POST['uptime']);
    			$end=$st+86400;
    			$where['uptime'] = array('between',array($st,$end));
    		}
    		if($_POST['isover']>-1){
    			$where['isover'] = $_POST['isover'];			
    		}
    		//dump($where);
    	}
    	
    	$label_confs=M('confset')->where(array('id'=>$cid))->find();
        //一个配置多条上传
        $where['labelId']=$label_confs['labelId'];
        $where['confId']=$label_confs['confId'];	
        //dump($where);
        $records=M('recordset')->where($where)->order('id desc')->select();
        
        if(!$records){
          $this->error('没有数据',U('Index/login'));
        }
        //绘制图表信息，默认最新一次上传的数据
        $chart_st=$records[0]['startDate'];
        $chart_end=$records[0]['endDate'];
        $tb=strtoupper($label_confs['labelId']).'_'.date("Y",$label_confs['deliveryTime']);
        $map['time']=array('between',array($chart_st,$chart_end));
        $chart=M()->table('tp_'.$tb)->where($map)->select();
        $echart=json_encode($chart);
        //基线数据
        $markline=M('confset')->field('humLowLimit,humUpLimit,temLowLimit,temUpLimit')->where(array('id'=>$cid))->find();    
        $this->assign('markline',json_encode($markline));       
        //$this->assign('barcode',$label_confs);
        $this->assign('records',$records);
        $this->assign('chart_st',$chart_st);
        $this->assign('chart_end',$chart_end);
        $this->assign('echart',$echart);        
        $this->assign('label_sel',$label_confs['barCode']);
		$this->assign('labelid',$label_confs['labelId']);
    	$this->display();
    }
//按时间查询数据
    public function timechart(){
    	//cid是confset表的id     	
    	$cid=$_POST['cid'];        
    	$st=$_POST['starttime'];
    	$end=$_POST['endtime'];
        $conf=M('confset')->field('labelId,confId,deliveryTime')->where(array('id'=>$cid))->find();
        
    	$record=M('recordset')->field('labelId,startDate,endDate')->where(array('labelId'=>$conf['labelId'],'confId'=>$conf['confId']))->select();
    	//$tn=$record['labelId'].'_'.date('Y',$record['uptime']);
        $first=$record[0]['startDate'];
        $last=$record[count($record)-1]['endDate'];
        if($st>$first-24*3600 && $st<$last+24*3600){
            $tb=$conf['labelId'].'_'.date('Y',$conf['deliveryTime']);
            
            $inmap=array('cid'=>$cid);
            $inmap['time']=array('between',array($st,$end));
            $indata=M()->table('tp_'.$tb)->where($inmap)->select();
            if($indata){
            //    echo '111';
            $this->ajaxReturn($indata,'JSON');
            }else{
                //echo 'data error';
                $this->ajaxReturn(['code'=>0,'info'=>'data error']);
            }
        }else{
            //echo 
            $str='本运单记录区间是'.date('Y-m-d H:i:s',$first).'至'.date('Y-m-d H:i:s',$last);
            $this->ajaxReturn(['code'=>0,'info'=>$str]);
        }

    }
   //上传记录画图
    public function chartline(){
    	//rid是recordset表id,cid是confset表的id 
    	$rid=$_POST['id'];
    	$cid=$_POST['cid'];        
    	
    	$record=M('recordset')->field('labelId,startDate,endDate,batchtime')->where(array('id'=>$rid))->find();
    	$tn=$record['labelId'].'_'.date('Y',$record['batchtime']);
        //echo $tn;
    	$where=array('cid'=>$cid);
    	$where['time']=array('between',array($record['startDate'],$record['endDate']));
    	//$this->ajaxReturn($where,'JSON');
    	$data=M()->table('tp_'.$tn)->where($where)->select();
    	
    	if($data){
    		$this->ajaxReturn($data,'JSON');
    	}else{
    		echo 'data error';
    	}
    	
    }
    //配置信息页面
    public function conf_detail(){
        $id=$_GET['id'];
        $list=M('confset')->where(array('id'=>$id))->find();        
        $this->assign('list',$list);
    	$this->display();
    }
    //记录信息页面
    public function record_detail(){
        $id=$_GET['id'];
        $record=M('recordset')->where(array('id'=>$id))->find();
        //绘制图表
        $chart_st=$record['startDate'];
        $chart_end=$record['endDate'];
        $tb=strtoupper($record['labelId']).'_'.date("Y",$record['batchtime']);
        $map['time']=array('between',array($chart_st,$chart_end));
        $chart=M()->table('tp_'.$tb)->where($map)->select();
        
        $echart=json_encode($chart);
        //基线数据
        $markline=M('confset')->field('humLowLimit,humUpLimit,temLowLimit,temUpLimit')->where(array('id'=>$chart[0]['cid']))->find(); 
        $this->assign('markline',json_encode($markline));
        $this->assign('echart',$echart);
        $this->assign('list',$record);
    	$this->display();
    }
    //记录信息生成pdf
    public function pdf_export($str){
    	vendor('tcpdf.tcpdf','','.php');
    	$pdf=new TCPDF('P','mm','A4',true,'UTF-8',false);
    	$pdf->SetCreator('Megain');
    	$pdf->SetAuthor('Megain_customer');
    	$pdf->SetTitle('Label record infomation');
    	$pdf->SetSubject('Label record items');
    	$pdf->SetKeywords('TCPDF,PDF,PHP');
    	//设置页眉页脚
    	$pdf->SetHeaderData('logo1.png',0,'www.megian.com','美佳音智能物联管理系统',array(0,64,255),array(0,64,128));
    	$pdf->setFooterData(array(0.64,0),array(0,64,128));
    	$pdf->setHeaderFont(array('stsongstdlight','','10'));
    	$pdf->setFooterFont(array('helvetica','','8'));
    	//设置默认等宽字体
    	$pdf->SetDefaultMonospacedFont('courier');
    	//设置间距
    	$pdf->SetMargins(15,27,15);
    	$pdf->SetHeaderMargin(5);
    	$pdf->SetFooterMargin(10);
    	//设置分页 
    	$pdf->SetAutoPageBreak(TRUE,25);
        $pdf->setImageScale(1.25);
        $pdf->setFontSubsetting(true);
        $pdf->SetFont('stsongstdlight','',14);
        $pdf->AddPage();
        //$str1="欢迎使用TCPDF";
        $pdf->writeHTML($str,true,false,false,false,'');
        $imgurl='http://tt.cloud315.org/'.session('baseimg');
        $pdf->Image($imgurl,'','',200,0,'','','',false,300,'',false,false,1,false,false,false);

        $pdf->Output('t.pdf','I');
    }
    //pdf内容
    public function pdf_file(){
    	if($_POST['baseimg']){
    		$picinfo=$_POST['baseimg'];   		
    		if(preg_match('/^(data:\s*image\/(\w+);base64,)/', $picinfo,$result)){
    			$stfile=date('Ymdhis').rand(100,999);
    			$path="uploads/temp/";
    		    $stFilename=$path.$stfile.".png";
    		    //清空文件夹
    		    $arr=scandir($path);
                foreach ($arr as $val) {
                	if($val !="." && $val !=".."){
                		unlink($path.$val);
                	}
                }
    		    //将图片放进文件夹
    		    if(file_put_contents($stFilename, base64_decode(str_replace($result[1], '', $picinfo)))){
    		    	session('baseimg',$stFilename);
                    $this->ajaxReturn($stFilename);
    		    }else{
    		    	$this->ajaxReturn('error');
    		    }
    		}else{
    			$this->ajaxReturn('error1');
    		}
    		 		
    	}
       $id=$_GET['id'];
       $list=M('recordset')->where(array('id'=>$id))->find();
       $conf=M('confset')->where(array('labelId'=>$list['labelId'],'confId'=>$list['confId']))->find();
       $workStatus=($list['workStatus']=='3')?'正常':'测试';
       if($list['isover']=='0'){$isover='无';}elseif($list['isover']=='1'){$isover='有';}else{$isover='已处理';}
       $str = "<p>标签的上传记录信息</p><table cellspacing='0'><tr><td>记录信息</td><td>固件信息</td></tr><tr><td>标签编号：".$list['labelId']."</td><td>APP版本：".$list['appVersion']."</td></tr><tr><td>标签类型：".$list['labelType']."</td><td>闪存容量：".$list['flashCapacity']."KB</td></tr><tr><td>上传定位：".$list['uploadAddr']."</td><td>帧 容 量：".$list['frameCapacity']."KB</td></tr><tr><td>湿度高于上限时长：".$list['cumHumMax']."分钟</td><td>硬件版本：".$list['hardwareVersion']."</td></tr><tr><td>湿度低于下限时长：".$list['cumHumMin']."分钟</td><td>固件版本：".$list['remoteFirmware']."</td></tr><tr><td>温度高于上限时长：".$list['cumTemMax']."分钟</td><td>STC版本：".$list['stcFirmware']."</td></tr><tr><td>温度低于下限时长：".$list['cumTemMin']."分钟</td><td>传输速度：".$list['transmitVelocity']."kpbs</td></tr><tr><td>采样起始时间：".date('Y-m-d H:m:s',$list['startDate'])."</td><td>工作状态：".$workStatus."</td></tr><tr><td>采样终止时间：".date('Y-m-d H:m:s',$list['endDate'])."</td><td>剩余电压：".$list['dumpEnergy']."V</td></tr><tr><td>最大湿度：".$list['humMax']."%</td><td></td></tr><tr><td>最小温度：".$list['tempMin']."℃</td><td></td></tr><tr><td>最小湿度：".$list['humMin']."%</td><td></td></tr><tr><td>采样时长：".$list['humTime']."小时</td><td></td></tr><tr><td>最大温度：".$list['tempMax']."℃</td><td></td></tr><tr><td>是否报警：".$isover."</td></tr><tr><td>上传时间：".date('Y-m-d H:m:s',$list['uptime'])."</td></tr><tr><td></td></tr><tr><td>配置信息</td></tr><tr><td>货物单号：".$conf['barCode']."</td></tr><tr><td>运单时间：".date('Y-m-d H:m:s',$conf['deliveryTime'])."</td></tr><tr><td>公司名称：".$conf['company']."</td></tr><tr><td>产品名称：".$conf['article']."</td></tr><tr><td>创建人：".$conf['configBy']."</td></tr><tr><td>发货地址：".$conf['shippingAddr']."</td></tr><tr><td>收货地址：".$conf['shipTo']."</td></tr><tr><td>延迟时间：".$conf['startDelay']."分钟</td></tr><tr><td>采样间隔时间：".$conf['frequency']."分钟</td></tr><tr><td>温度警戒上限：".$conf['temUpLimit']."℃</td></tr><tr><td>温度警戒下限：".$conf['temLowLimit']."℃</td></tr><tr><td>湿度警戒上限：".$conf['humUpLimit']."RH</td></tr><tr><td>湿度警戒下限：".$conf['humLowLimit']."RH</td></tr><tr><td>配置备注：".$conf['remark']."</td></tr></table>";
             
       $this->pdf_export($str);
}
//导出csv方法    
    public function exportcsv(){
      $cid=$_GET['cid'];
      $linfo=M('confset')->where(array('id'=>$cid))->find();
      $rinfo=M('recordset')->where(array('confId'=>$linfo['confId']))->order('id desc')->find();
      $pitem=array("标签配置信息"=>'',"标签ID"=>$linfo['labelId'],"货物单号"=>$linfo['barCode'],"运单时间"=>date('Y-m-d H:i:s',$linfo['deliveryTime']),"公司名称"=>$linfo['company'],"产品名称"=>$linfo['article'],"创建人"=>$linfo['configBy'],"发货地址"=>$linfo['shippingAddr'],"收货地址"=>$linfo['shipTo'],"延迟时间"=>$linfo['startDelay']."分钟","采样间隔"=>$linfo['frequency']."分钟","温度警戒上限"=>$linfo['temUpLimit']."℃","温度警戒下限"=>$linfo['temLowLimit']."℃","湿度警戒上限"=>$linfo['humUpLimit']."RH","湿度警戒下限"=>$linfo['humLowLimit']."RH","备注"=>$linfo['remark'],""=>'',"固件信息"=>'',"固件版本"=>$rinfo['remoteFirmware'],"最大容量"=>$rinfo['flashCapacity']."KB","最大速率"=>$rinfo['transmitVelocity']."kpbs","硬件版本"=>$rinfo['hardwareVersion'],"电量状态"=>$rinfo['dumpEnergy']."V","单片机版本"=>$rinfo['stcFirmware']);     
      $dtitle=array('时间','温度(℃)','湿度(%)');
      //$where['time']=array('between',array($linfo['startDate'],$linfo['endDate']));
      $tb=$linfo['labelId'].'_'.date('Y',$linfo['deliveryTime']);
      $data=M()->table('tp_'.$tb)->where(array('cid'=>$cid))->select();
      $filename=date("YmdHis",time()).".csv";
      header('Content-Type: application/vnd.ms-excel');
      header('Content-Disposition: attachment;filename='.$filename);
      header('Cache-Control: max-age=0');
      $file=fopen('php://output', "a");
      //写入配置固件信息
      foreach ($pitem as $k => $v) {
        $ck=iconv('UTF-8', 'GB2312//IGNORE', $k);
      	$cv=iconv('UTF-8', 'GB2312//IGNORE', $v);
      	$carr=array($ck,$cv);
      	fputcsv($file, $carr);
      }
      unset($carr);
      //写入数据标题
      foreach ($dtitle as $v) {
      	$tv=iconv('UTF-8', 'GB2312//IGNORE', $v);
      	$ttarr[]=$tv;
      }
      fputcsv($file, $ttarr);
      //写入数据
      foreach ($data as $key => $value) {
      	$darr=array(date('Y-m-d H:i:s',$value['time']),$value['temps'],$value['hums']);
      	fputcsv($file, $darr);
      }
      unset($data);
      fclose($file);
    }
	public function verify(){
		Image::buildImageVerify(4,1,'png',0,28,'verify');
	}
	public function verifyLogin(){
		Image::buildImageVerify(4,1,'png',0,28,'loginverify');
	}
	public function resetpwd(){
		$uid=$this->_get('uid','intval');
		$code=$this->_get('code','trim');
		$rtime=$this->_get('resettime','intval');
		$info=M('Users')->find($uid);
		if( (md5($info['uid'].$info['password'].$info['email'])!==$code) || ($rtime<time()) ){
			$this->error('非法操作',U('Index/index'));
		}
		$this->assign('uid',$uid);
		$this->display($this->home_theme.':Index:'.ACTION_NAME);
	}
	public function fc(){
		$this->display($this->home_theme.':Index:'.ACTION_NAME);
	}
	public function about(){
		$this->display($this->home_theme.':Index:'.ACTION_NAME);
	}
	public function price(){
		$groupWhere=array();
		$groupWhere['status']=1;
		if (C('agent_version')){
			$groupWhere['agentid']=$this->agentid;
		}
		$groups=M('User_group')->where($groupWhere)->order('id ASC')->select();
		$this->assign('groups',$groups);
		$count=count($groups);
		$this->assign('count',$count);
		//
		$prices=array();
		$isCopyright=array();
		$wechatNums=array();
		$diynums=array();
		$connectnums=array();
		$activitynums=array();
		$create_card_nums=array();
		if ($groups){
			foreach ($groups as $g){
				array_push($prices,$g['price']);
				array_push($isCopyright,$g['copyright']);
				array_push($wechatNums,$g['wechat_card_num']);
				array_push($diynums,$g['diynum']);
				array_push($connectnums,$g['connectnum']);
				array_push($activitynums,$g['activitynum']);
				array_push($create_card_nums,$g['create_card_num']);
			}
		}
		$this->assign('prices',$prices);
		$this->assign('copyrights',$isCopyright);
		$this->assign('wechatNums',$wechatNums);
		$this->assign('diynums',$diynums);
		$this->assign('connectnums',$connectnums);
		$this->assign('activitynums',$activitynums);
		$this->assign('create_card_nums',$create_card_nums);
		//
		if (C('agent_version')&&$this->agentid){
			$funs=M('Agent_function')->where(array('status'=>1,'agentid'=>$this->agentid))->order('gid DESC')->select();
		}else {
			$funs=M('Function')->where(array('status'=>1))->order('gid DESC')->select();
		}
		if ($funs){
			$i=0;
			foreach ($funs as $f){
				$funs[$i]['access']=array();
				if ($groups){
					foreach ($groups as $g){
						if ($f['gid']>$g['id']){
							$canUse=0;
						}else {
							$canUse=1;
						}
						array_push($funs[$i]['access'],$canUse);
					}
				}
				$i++;
			}
		}
		$this->assign('funs',$funs);
		//
		$this->display($this->home_theme.':Index:'.ACTION_NAME);
	}
	public function help(){
		$this->display($this->home_theme.':Index:'.ACTION_NAME);
	}

	public function show(){
		$where['id'] = $this->_get('id');
		$seo = M('Seo');
		$data = $seo->where($where)->find();
		$content = stripslashes(htmlspecialchars_decode($data['content']));
		$this->assign('data',$data);
		$this->assign('content',$content);
		
		$this->display();
	}
	function think_encrypt($data, $key = '', $expire = 0) {
		$key  = md5(empty($key) ? C('DATA_AUTH_KEY') : $key);
		$data = base64_encode($data);
		$x    = 0;
		$len  = strlen($data);
		$l    = strlen($key);
		$char = '';

		for ($i = 0; $i < $len; $i++) {
			if ($x == $l) $x = 0;
			$char .= substr($key, $x, 1);
			$x++;
		}

		$str = sprintf('%010d', $expire ? $expire + time():0);

		for ($i = 0; $i < $len; $i++) {
			$str .= chr(ord(substr($data, $i, 1)) + (ord(substr($char, $i, 1)))%256);
		}
		return str_replace('=', '',base64_encode($str));
	}
	function text(){
		$domain=$_GET['domain'];
		$domains=explode('.',$domain);

		echo '<a href="http://'.$domain.'/index.php?g=Home&m=T&a=test&n='.$this->think_encrypt($domains[1].'.'.$domains[2]).'" target="_blank">http://'.$domain.'/index.php?g=Home&m=T&a=test&n='.$this->think_encrypt($domains[1].'.'.$domains[2]).'</a><br>';
		echo '<a href="http://'.$domain.'/index.php?g=User&m=Create&a=index" target="_blank">http://'.$domain.'/index.php?g=User&m=Create&a=index</a><br>';
	}
	function common(){
		$where['status']=1;
		if (C('agent_version')){
			$where['agentid']=$this->agentid;
		}
		$cases=M('Case')->where($where)->order('id DESC')->select();
		$this->assign('cases',$cases);
		$this->display($this->home_theme.':Index:'.ACTION_NAME);
	}
}