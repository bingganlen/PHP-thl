<?php
	include_once("CCPRestSmsSDK.php");
	//include_once("Image.class.php");

  session_start();//开启缓存
    if (isset($_SESSION['time']))//判断缓存时间
    {
        session_id();
        $_SESSION['time'];
    }
    else
    {
        $_SESSION['time'] = date("Y-m-d H:i:s");
    }
    $_SESSION['mcode']=$_GET['mcode'];//将content的值保存在session中


/**
  * 发送模板短信
  * @param to 手机号码集合,用英文逗号分开
  * @param datas 内容数据 格式为数组 例如：array('Marry','Alon')，如不需替换请填 null
  * @param $tempId 模板Id,测试应用和未上线应用使用测试模板请填写1，正式应用上线后填写已申请审核通过的模板ID
  */   
	 function sendTemplateSMS($to,$datas,$tempId, $appId='8a48b55149896cfd0149ac7ae787199c')
	{
			// update by shitao 20171213 
		 // 初始化REST SDK
		 global $accountSid,$accountToken,$serverIP,$serverPort,$softVersion;
		 //主帐号,对应开官网发者主账号下的 ACCOUNT SID
		$accountSid= 'aaf98f89499d24b50149ac797b8009a2';
		// $accountSid= '8aaf0708604403ca01604db14973047c';
		
		//主帐号令牌,对应官网开发者主账号下的 AUTH TOKEN
		$accountToken= 'ca9fb2e7c5144fcea8d11743eb434490';
		// $accountToken= 'd3defed2567b527b66f84f706117508c';
		
		//应用Id，在官网应用列表中点击应用，对应应用详情中的APP ID
		//在开发调试的时候，可以使用官网自动为您分配的测试Demo的APP ID
		// $appId='8a48b55149896cfd0149ac7ae787199c';
		
		//请求地址
		//沙盒环境（用于应用开发调试）：sandboxapp.cloopen.com
		//生产环境（用户应用上线使用）：app.cloopen.com
		$serverIP='app.cloopen.com';
		
		
		//请求端口，生产环境和沙盒环境一致
		$serverPort='8883';
		
		//REST版本号，在官网文档REST介绍中获得。
		$softVersion='2013-12-26';

		 $rest = new REST($serverIP,$serverPort,$softVersion);
		 $rest->setAccount($accountSid,$accountToken);
		 $rest->setAppId($appId);
		
		 // 发送模板短信
		 //echo "Sending TemplateSMS to $to <br/>";
		 $result = $rest->sendTemplateSMS($to,$datas,$tempId);

		 if($result == NULL ) {
			 //echo "result error!";
			 break;
		 }
		 if($result->statusCode!=0) {
			 //echo "error code :" . $result->statusCode . "<br>";
			 //echo "error msg :" . $result->statusMsg . "<br>";
			 //TODO 添加错误处理逻辑
		 }else{
			 //echo "Sendind TemplateSMS success!<br/>";
			 // 获取返回信息
			 $smsmessage = $result->TemplateSMS;

			 //echo "dateCreated:".$smsmessage->dateCreated."<br/>";
			 //echo "smsMessageSid:".$smsmessage->smsMessageSid."<br/>";
			 //TODO 添加成功处理逻辑
			 return "tr";
		 }
	}
class UsersAction extends BaseAction{
	public function index(){
		header("Location: /");
	}
//单独短信发送 
	public function test(){
		//dump($_SESSION);
		if(session('msgtime')){
			$stmptime=time()-session('msgtime');
			if($stmptime<=60){
				echo '1';
				exit;
			}
		}
		session('msgtime',time());
		$code =rand(100000,999999) ;
		$result = sendTemplateSMS($this->_post('sms_mp'),array($code,'1'),'37426');
        //防止重复验证
        $message=M('Message');
		if($result=='tr'){
		  $data2['Fphone']=$this->_post('sms_mp');
		  $data2['Fstatus']=1;
		  $data2['Fis_valid']=1;
		  $data2['Fcreate_time']=time();
		  $data2['Fcode']=$code;
		  $w['Fphone']=$this->_post('sms_mp');
		  $message->where($w)->data(array('Fisvalued'=>0,'Fupdate_time'=>time()))->save();
          
          $message->add($data2);
		}else{
          $data2['Fphone']=$this->_post('sms_mp');
		  $data2['Fstatus']=0;
		  $data2['Fis_valid']=1;
		  $data2['Fcreate_time']=time();
		  $data2['Fcode']=$code;		
          $message->add($data2);
		}
        //没用过的，状态为1
		$where=array('Fphone'=>$this->_post('sms_mp'),'Fis_valid'=>'1','Fstatus'=>'1');
        $m1=$message->where($where)->order('Fcreate_time desc')->find();
        //确保session值是短信发送成功的最新值
        $_SESSION['verifyMP'] = $m1['Fcode'];
        $_SESSION['veriphone']=$this->_post('sms_mp');
	}



// 群发短信


	public function qunfa(){
		$tpl=$this->_post('opt');
		$chk=$this->_post('chk');
		$this->messend($chk,$tpl);

	}
	public function messend($phone,$tpl){
		$code =rand(100000,999999) ;
		// update by shitao 20171213
		$result = sendTemplateSMS($phone,array($code,'1'),$tpl,$appId='8a48b55151a365840151a48f10ea0401');
		// $result = sendTemplateSMS($phone,array($code,'1'),$tpl,$appId='8a216da86044e67d01604db9fccf040f');
        //防止重复验证
        $message=M('Message');
		if($result=='tr'){
		  $data2['Fphone']=$phone;
		  $data2['Fstatus']=1;
		  $data2['Fis_valid']=1;
		  $data2['Fcreate_time']=time();
		  $data2['Fcode']=$code;
		  $w['Fphone']=$phone;
		  $message->where($w)->data(array('Fisvalued'=>0,'Fupdate_time'=>time()))->save();
          
          $message->add($data2);
		}else{
          $data2['Fphone']=$phone;
		  $data2['Fstatus']=0;
		  $data2['Fis_valid']=1;
		  $data2['Fcreate_time']=time();
		  $data2['Fcode']=$code;		
          $message->add($data2);
		}
        //没用过的，状态为1
		$where=array('Fphone'=>$phone,'Fis_valid'=>'1','Fstatus'=>'1');
        $m1=$message->where($where)->order('Fcreate_time desc')->find();
        //确保session值是短信发送成功的最新值
        $_SESSION['verifyMP'] = $m1['Fcode'];
        $_SESSION['veriphone']=$phone;
	}





	public function companylogin() {
		$dbcom = D('Company');
		$where['username'] = $this->_post('username','trim');
		$cid = $where['id'] = $this->_post('cid', 'intval');
		$k = $this->_post('k','trim, htmlspecialchars');
		if (empty($k) || $k != md5($where['id'] . $where['username'])) {
			$this->error('帐号密码错误',U('Home/Index/clogin', array('cid' => $cid, 'k' => $k)));
		}

		$pwd = $this->_post('password','trim,md5');
		$company = $dbcom->where($where)->find();
	
		if($company && ($pwd === $company['password'])){
			if ($wxuser = D('Wxuser')->where(array('token' => $company['token']))->find()) {
				$uid = $wxuser['uid'];
				$db = D('Users');
				$res = $db->where(array('id' => $uid))->find();
			} else {
				$this->error('帐号密码错误',U('Home/Index/clogin', array('cid' => $cid, 'k' => $k)));
			}
			session('companyk', $k);
			session('companyLogin', 1);
			session('companyid', $company['id']);
			session('token', $company['token']);
			session('uid',$res['id']);
			session('gid',$res['gid']);
			session('uname',$res['username']);
			$info=M('user_group')->find($res['gid']);
			session('diynum',$res['diynum']);
			session('connectnum',$res['connectnum']);
			session('activitynum',$res['activitynum']);
			session('viptime',$res['viptime']);
			session('gname',$info['name']);
			//每个月第一次登陆数据清零
			$now=time();
			$month=date('m',$now);
			if($month!=$res['lastloginmonth']&&$res['lastloginmonth']!=0){
				$data['id']=$res['id'];
				$data['imgcount']=0;
				$data['diynum']=0;
				$data['textcount']=0;
				$data['musiccount']=0;
				$data['connectnum']=0;
				$data['activitynum']=0;
				$db->save($data);
				//
				session('diynum',0);
				session('connectnum',0);
				session('activitynum',0);
			}
			//登陆成功，记录本月的值到数据库

			//
			$db->where(array('id'=>$res['id']))->save(array('lasttime'=>$now,'lastloginmonth'=>$month,'lastip'=>$_SERVER['REMOTE_ADDR']));//最后登录时间
			$this->success('登录成功',U('User/Repast/index',array('cid' => $cid)));
		} else{
			$this->error('帐号密码错误',U('Home/Index/clogin', array('cid' => $cid, 'k' => $k)));
		}
	}

	public function companyLogout()
	{
		$cid = session('companyid');
		$k = session('companyk');
		session(null);
		session_destroy();
		unset($_SESSION);
        if(session('?'.C('USER_AUTH_KEY'))) {
            session(C('USER_AUTH_KEY'),null);

            redirect(U('Home/Index/clogin', array('cid' => $cid, 'k' => $k)));
        } else {
            $this->success('已经登出！', U('Home/Index/clogin', array('cid' => $cid, 'k' => $k)));
        }


	}

	// 登录验证
	public function checklogin(){
		
		// if (isset($_POST['verifycode2'])){
		// 	$verifycode=$this->_post('verifycode2','intval,md5',0);
		// 	if($verifycode != $_SESSION['loginverify']){
		// 		$this->error('验证码错误',U('Index/login'));
		// 	}
		// }
		$db=D('Users');
		$where['username']=$this->_post('username','trim');

		// if($db->create()==false)
			// $this->error($db->getError());
		$pwd=$this->_post('password','trim,md5');
		//dump($pwd);
		$res=$db->where($where)->find();
		
		if($res&&($pwd==$res['password'])){

			// if($res['status']==0){
			// 	$this->error('请联系在线客户，为你人工审核帐号');exit;
			// }
			session('uid',$res['id']);
			// session('gid',$res['gid']);
			session('uname',$res['username']);
			// $info=M('user_group')->find($res['gid']);
			// session('diynum',$res['diynum']);
			// session('connectnum',$res['connectnum']);
			// session('activitynum',$res['activitynum']);
			session('viptime',$res['viptime']);
			// session('gname',$info['name']);
			//每个月第一次登陆数据清零
			 $now=time();
			 $month=date('m',$now);
			// if($month!=$res['lastloginmonth']&&$res['lastloginmonth']!=0){
			// 	$data['id']=$res['id'];
			// 	$data['imgcount']=0;
			// 	$data['diynum']=0;
			// 	$data['textcount']=0;
			// 	$data['musiccount']=0;
			// 	$data['connectnum']=0;
			// 	$data['activitynum']=0;
			// 	$db->save($data);
			// 	//
			// 	session('diynum',0);
			// 	session('connectnum',0);
			// 	session('activitynum',0);
			//}
			//登陆成功，记录本月的值到数据库			
			$result=$db->where(array('id'=>$res['id']))->save(array('lasttime'=>$now,'lastloginmonth'=>$month,'lastip'=>htmlspecialchars(trim(get_client_ip()))));//最后登录时间
			
			//查看是否创建商城，没有则跳转到创建商城页，有则跳转到首页
			// 查询到token
			$token=$this->select_shop();
			session('token',$token);

            setCookie("adminname",$_POST['username'],time()+680400);
            setCookie("adminpw",$_POST['password'],time()+680400);
			
			if(!empty($token)){
				dump($token);
				$this->redirect(U('User/Wlist/index',array('token'=>$token)));
				//$this->success('登录成功',U('User/Index/frame',array('token' => $token )));
			}
			// }else{
			// 	$this->redirect(U('User/Index/add'));
			// 	//$this->success('创建商城',U('User/Index/add'));
			// }
			//$this->success('登录成功',U('User/Index/index'));
		}else{
			$this->error('帐号密码错误',U('Index/login'));
		}
	}
    //标签查询
    public function searchlb(){
    	$lbid=$_POST['labelid'];
    	$deliveryid=$_POST['deliveryid'];
    	if(!$lbid || !$deliveryid){
    		echo '请输入正确的标签号和运单号';
    	}else{
    		$confid=M('confset')->where(array('labelId'=>$lbid,'barCode'=>$deliveryid))->find();
    		if(!$confid){
    			echo "请输入正确的标签号和运单号";
    		}else{
    			echo $confid['id'];
    			//$this->redirect(U('User/Store/detail',array('labelid'=>$confid['labelId'])));
    		}
    	}
    }
 
	//检查是否创建商城
	public function select_shop(){
		$wxuser = M('wxuser');
        $where = array('uid' => session('uid'));
		$shop = $wxuser->where($where)->find();
		session('token',$shop['token']);
		return  $shop['token'];
     
	}

	public function randStr($randLength){
		$randLength=intval($randLength);
		$chars='abcdefghjkmnpqrstuvwxyz';
		$len=strlen($chars);
		$randStr='';
		for ($i=0;$i<$randLength;$i++){
			$randStr.=$chars[rand(0,$len-1)];
		}
		return $randStr;
	}
	
	public function randNum($randLength){
		$randLength=intval($randLength);
		$chars='0123456789';
		$len=strlen($chars);
		$randNum='';
		for ($i=0;$i<$randLength;$i++){
			$randStr.=$chars[rand(0,$len-1)];
		}
		return $randNum;
	}
	Public function verify(){
		import('ORG.Util.Image');
		Image::buildImageVerify(4,1,'png');
	}

	// 注册验证
	public function checkreg(){
		
		$db=D('Users');
		$info=M('User_group')->find(1);
		$verifycode=$this->_post('verifycode','intval,md5',0);
		$verifycodeMP =$this->_post(verifyMP); $_SESSION['verifyMP'];

		if (isset($_POST['verifyMP'])){
			if($verifycodeMP != $_SESSION['verifyMP']){
				//dump($_SESSION);
				$this->error('手机验证码错误',U('Index/login'));
			}
		}
		if (isset($_POST['sms_mp'])){
			if (!preg_match('/^13[0-9]{9}$|^15[0-9]{9}$|^18[0-9]{9}$/',trim($_POST['sms_mp']))){
				$this->error('手机号填写不正确',U('Index/login'));
			}
		}
		if ($this->isAgent){
			$_POST['agentid']=$this->thisAgent['id'];
		}
		if (isset($_POST['invitecode'])){
			//$_POST['invitecode']=$this->_get('invitecode');
			$inviteCode=$this->_post('invitecode');
			if ($inviteCode&&!ctype_alpha($inviteCode)){
				exit('invitecode colud not include other letter');
			}
			$inviter=$db->where(array('invitecode'=>$inviteCode))->find();
			$_POST['inviter']=intval($inviter['id']);
		}else {
			$_POST['inviter']=0;
		}
		$_POST['invitecode']=$this->randStr(6);
		
		if($db->create()){
			$id=$db->add();
			if($id){
				Sms::sendSms('admin','有新用户注册了',$this->adminMp);
				if ($this->isAgent){
				    $usercount=M('Users')->where(array('agentid'=>$this->thisAgent['id']))->count();
				    M('Agent')->where(array('id'=>$this->thisAgent['id']))->save(array('usercount'=>$usercount));
				}
				if($this->reg_needCheck){
					$gid=$this->minGroupid;
					$this->redirect(U('User/Index/add'));
					$this->success('注册成功,请联系在线客服审核帐号',U('User/Index/add'));
				}else{
					$viptime=time()+intval($this->reg_validDays)*24*3600;
					$gid=$this->minGroupid;
					if ($this->reg_groupid){
						$gid=intval($this->reg_groupid);
					}
					$db->where(array('id'=>$id))->save(array('mp'=>$_POST['sms_mp'],'viptime'=>$viptime,'status'=>1,'gid'=>$gid));
				}

				session('uid',$id);
				session('gid',$gid);
				session('uname',$_POST['username']);
				session('diynum',0);
				session('connectnum',0);
				session('activitynum',0);
				session('gname',$info['name']);

				$this->success('注册成功',U('User/Index/add'));
			}else{
				$this->error('注册失败',U('Index/login'));
			}
		}else{
			$this->error($db->getError(),U('Index/login'));
		}
	}

	public function checkpwd(){

		$where['username']=$this->_post('username');
		$where['email']=$this->_post('email');
		$db=D('Users');
		$list=$db->where($where)->find();
		if($list==false) $this->error('邮箱和帐号不正确',U('Index/regpwd'));

		$smtpserver = C('email_server');
		$port = C('email_port');
		$smtpuser = C('email_user');
		$smtppwd = C('email_pwd');
		$mailtype = "TXT";
		$sender = C('email_user');
		$smtp = new Smtp($smtpserver,$port,true,$smtpuser,$smtppwd,$sender);
		$to = $list['email'];
		$subject = C('pwd_email_title');
		$code = C('site_url').U('Index/resetpwd',array('uid'=>$list['id'],'code'=>md5($list['id'].$list['password'].$list['email']),'resettime'=>time()));
		$fetchcontent = C('pwd_email_content');
		$fetchcontent = str_replace('{username}',$where['username'],$fetchcontent);
		$fetchcontent = str_replace('{time}',date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']),$fetchcontent);
		$fetchcontent = str_replace('{code}',$code,$fetchcontent);
		$body=$fetchcontent;
		//$body = iconv('UTF-8','gb2312',$fetchcontent);inv
		$send=$smtp->sendmail($to,$sender,$subject,$body,$mailtype);
		$this->success('请访问你的邮箱 '.$list['email'].' 验证邮箱后登录!<br/>');

	}

	public function resetpwd(){
		$where['id']=$this->_post('uid','intval');
		$where['password']=$this->_post('password','md5');
		if(M('Users')->save($where)){
			$this->success('修改成功，请登录！',U('Index/login'));
		}else{
			$this->error('密码修改失败！',U('Index/index'));
		}
	}
}




