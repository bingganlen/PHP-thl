<?php
class AgentAction extends BackAction{
    public $agent_db;
    public function _initialize(){
        parent :: _initialize();
        $this -> wxuser = M('wxuser');
    }
    // 水站列表
    public function index(){
        $count = $this -> wxuser -> count();
        $page = new Page($count, 20);
        $info = $this -> wxuser ->limit($page -> firstRow . ',' . $page -> listRows) -> select();
        $this -> assign('info', $info);
        $this -> assign('page', $page -> show());
        $this -> display('index');
    }




    public function custom(){
        $token=$_GET['token'];
        $where['Ftoken']=$token;
        $count = M('wa_users')->where($where)-> count();
        $page = new Page($count, 20);
        $info = M('wa_users') ->where($where)-> limit($page -> firstRow . ',' . $page -> listRows) -> select();
        $this -> assign('info', $info);
        $this -> assign('page', $page -> show());
        $this -> display();
    }























    // 统计水站客户数
    public function cus($token){
        $where=array('Ftoken'=>intval($token));
        $count= M('wa_users')->where($where)->count();
        if($count >0){
             return $count;
         }else{
            return 0;
         }
       
    }


    public function add(){
        if (isset($_GET['id'])){
            $thisAgent = $this -> wxuser -> where(array('id' => intval($_GET['id']))) -> find();
        }
        if(isset($_POST['dosubmit'])){
            if (strlen($_POST['password'])){
                $password = trim($_POST['password']);
                $salt = rand(111111, 999999);
                $_POST['salt'] = $salt;
                $password = md5(md5($password) . $salt);
                $_POST['password'] = $password;
            }else{
                if ($thisAgent){
                    unset($_POST['password']);
                }else{
                    $this -> error('请设置密码!');
                }
            }
            if (!$thisAgent){
                $_POST['time'] = time();
            }
            $_POST['endtime'] = strtotime($_POST['endtime']);
            if($this -> wxuser -> create()){
                if ($thisAgent){
                    $this -> wxuser -> where(array('id' => $thisAgent['id'])) -> save($_POST);
                    $this -> success('修改成功！', U('Agent/index'));
                }else{
                    $agentid = $this -> wxuser -> add();
                    if($agentid){
                        $this -> success('添加成功！', U('Agent/index'));
                    }else{
                        $this -> error('添加失败!');
                    }
                }
            }else{
                $this -> error($this -> wxuser -> getError());
            }
        }else{
            if (!$thisAgent){
                $thisAgent['endtime'] = time() + 365 * 24 * 3600;
            }
            $this -> assign('info', $thisAgent);
            $this -> display();
        }
    }
    // public function del(){
    //     $id = $this -> _get('id', 'intval');
    //     if($this -> agent_db -> delete($id)){
    //         $this -> success('操作成功', $_SERVER['HTTP_REFERER']);
    //     }else{
    //         $this -> error('操作失败', U(MODULE_NAME . '/index'));
    //     }
    // }
    // public function deleteUser(){
    //     $id = intval($_GET['id']);
    //     $thisUser = M('Users') -> where(array('agentid' => $this -> thisAgent['id'], 'id' => $id)) -> find();
    //     if (!$thisUser){
    //         $this -> error('没有此用户');
    //     }
    //     $rt = M('Users') -> where(array('id' => $id)) -> delete();
    //     if ($rt){
    //         M('Agent') -> where($this -> agentWhere) -> setDec('usercount');
    //         M('Wxuser') -> where(array('uid' => $id)) -> delete();
    //     }
    //     $this -> success('删除成功！', U('Users/index'));
    // }
    // public function deleteWxUser(){
    //     $id = intval($_GET['id']);
    //     $thisUser = M('Wxuser') -> where(array('agentid' => $this -> thisAgent['id'], 'id' => $id)) -> find();
    //     if (!$thisUser){
    //         $this -> error('没有此公众号');
    //     }
    //     $rt = M('Wxuser') -> where(array('id' => $id)) -> delete();
    //     M('Agent') -> where($this -> agentWhere) -> setDec('wxusercount');
    //     $this -> success('删除成功！', U('Users/wxusers'));
    // }
}
?>