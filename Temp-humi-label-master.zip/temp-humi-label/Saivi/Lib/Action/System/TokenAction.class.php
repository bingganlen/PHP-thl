<?php
class TokenAction extends BackAction{
    public function index(){
        $map = array();
        
        $UserDB = D('Wxuser');
        /*if (isset($_GET['agentid'])){
            $map=array('agentid'=>intval($_GET['agentid']));
        }*/
        if($this->isPost()){
            if($_POST['wxname']){
                //$map['wxname']=$_POST['wxname'];               
                $map['wxname']=array('like','%'.$_POST['wxname'].'%');
            }
            if($_POST['wxphone']){
                //$map['phone']=$_POST['wxphone']; 
                $map['phone']=array('like','%'.$_POST['wxphone'].'%');   
            }     
            // if($_POST['qr_require']>=0){
            //     $map['qrcode_req']=$_POST['qr_require'];            
            // }
            // if($_POST['latitude']>0){
            //     $map['latitude']=array('gt',0);          
            //  }elseif($_POST['latitude']==0){
            //     $map['latitude']=array('EXP','is NULL');
            //  }        
        }        
        $count = $UserDB->where($map)->count();     
        $Page       = new Page($count,10);// 实例化分页类 传入总记录数
        // 进行分页数据查询 注意page方法的参数的前面部分是当前的页数使用 $_GET[p]获取
        $nowPage = isset($_GET['p'])?$_GET['p']:1;
        $show    = $Page->show();// 分页显示输出
        $list = $UserDB->where($map)->limit($Page->firstRow.','.$Page->listRows)->order('id desc')->select();
        
        /*foreach($list as $key=>$value){
            //水站登录用户名和级别注释20180413 chenyuanyuan
            //$user=M('Users')->field('id,gid,username')->where(array('id'=>$value['uid']))->find();
            //if($user){
            //  $list[$key]['user']['username']=$user['username'];
            //  $list[$key]['user']['gid']=$user['gid']-1;
            //}
            //二维码申请状态            
            $qrcode_req=M('qrcode_log')->where(array('Ftoken'=>$value['token']))->order('Fcreatetime desc')->find();           
            if($qrcode_req){
                $list[$key]['qrcode_req']=$qrcode_req['Fstate'];                
            }else{
                $list[$key]['qrcode_req']='2';
            }            
        }*/     
        $this->assign('list',$list);
        $this->assign('page',$show);// 赋值分页输出
        $this->display();   
        
    }
    //水站表保存排序
    public function sort_save(){
        $token=$_GET['id'];
        $member_code=$_GET['member_code'];
        if($token && $member_code){
          $res=M('wxuser')->where(array('token'=>$token))->save(array('member_code'=>$member_code));
          if($res){
            $this->ajaxReturn('success');
          }else{
            $this->ajaxReturn('error');
          }
        }
        
    }
    public function del(){
        $id=$this->_get('id','intval',0);
        $wx=M('Wxuser')->where(array('id'=>$id))->find();
        if ($wx['agentid']){
            M('Agent')->where(array('id'=>$wx['agentid']))->setDec('wxusercount');
        }
        M('Img')->where(array('token'=>$wx['token']))->delete();
        M('Text')->where(array('token'=>$wx['token']))->delete();
        M('Lottery')->where(array('token'=>$wx['token']))->delete();
        M('Keyword')->where(array('token'=>$wx['token']))->delete();
        M('Photo')->where(array('token'=>$wx['token']))->delete();
        M('Home')->where(array('token'=>$wx['token']))->delete();
        M('Areply')->where(array('token'=>$wx['token']))->delete();
        $diy=M('Diymen_class')->where(array('token'=>$wx['token']))->delete();
        M('wa_soft_annual')->where(array('token'=>$wx['token']))->delete();
        M('Wxuser')->where(array('id'=>$id))->delete();
        M('users')->where(array('id'=>$wx['uid']))->delete();
        $this->success('操作成功');
    }

    public function endqrcode(){
        $id=$_GET['qrcode'];
        $order=$_GET['order'];
        $num=$_GET['batch'];
        $token=$_GET['token'];
        $prid=$_GET['prid'];
        if($order==''){
                $gt='egt';
                //$order='desc';
        }else{
                $gt='elt';
                //$order='';
        }
        $data=M('qrcode');
        /*$res=$data->where(array('id'=>$id))->field('id,token')->find();        
        if(!$res['id']){
            $this->ajaxReturn('1','xml');//$this->error('您输入的码段不在数据库');
        }else if($res['token']){
            $this->ajaxReturn('2','xml');//$this->error('您输入的码段已绑定水站');
        }*/
        $where=array('token'=>'','product_id'=>0,'id'=>array($gt,$id));
        $dd=$data->where($where)->order('id '.$order)->limit($num)->select();
        $this->assign('aa',$dd[$num-1]['id']);
        /*if($dd){
            $this->ajaxReturn($dd[$num-1]['id']);
        }else{
            $this->ajaxReturn('3','xml');//$this->error('查询码段不存在');
        }*/
        
    $this->display();
    }

    public function batchqrcode(){

        $num = $this->_get('batch');
        $token = $this->_get('token');
    $start = $this->_get('start');
    $end = $this->_get('end');
        $data = D('qrcode');
        $d['token'] = $token;

        $where=array('token'=>'','product_id' => '0',);
    if($start!=""){
        $where['id']=array('egt',$start);
        $where02=array('token'=>'','product_id' => '0','id'=>$start);
        $stmpst=$data->where($where02)->find();
        $res=$data->where($where02)->count();
        #echo $data->getLastSql();
         
        if($res==0){
            $this->error("非法操作，没有该起始id，或该二维码id已使用");
        }//else{
        //  $res=$data->where($where)->count();
        //  $this->error($res);
        //}
    }else{
        $this->error('请输入起始id');
    }
        //$condition['product_id'] ='0';
        if($num < 10000)
        {
            $result =  $data->where($where)->limit($num)->save($d);

            if($result !== false){
        $stmpd['start']=$start;
        $stmpd['end']=$end;
        $stmpd['num']=$num;
        $stmpd['token']=$token;
        if($stmpst['underQrcode']=='')
            $stmpd['fl']=0;
        else
            $stmpd['fl']=1;
        $stmpd['time']=date('Y-m-d H:i:s',time());
        M('qrcode_bin')->add($stmpd);
        //echo M('qrcode_bin')->getLastSql();
                $this->success('新增成功');
            }else{
                $this->error('新增失败');
            }
        }
        else{
            $this->error('超过10000');
        }

    }

    public function qrcode(){
        $id = $this->_get('id');
        $this->assign('token',$id);
    $data=M('qrcode_bin')->where(array('token'=>$id))->select();
    $this->assign('list',$data);
        $this->display();
    }
    
    //二维码记录
    public function qrcode_log(){
        $id = $this->_get('id');
        $wxname=$this->_get('wxname');
        $qrcode_log=M('qrcode_log')->where(array('Ftoken'=>$id))->order('Fid desc')->select();
        $this->assign('wxname',$wxname);
        $this->assign('qrcode',$qrcode_log);
        $this->display();
    }
    //二维码申请通过
    public function qrcode_pass(){
        $Fid=$_GET['Fid'];
        $logquery=M('qrcode_log')->where(array('Fid'=>$Fid))->field('Ftoken')->find();
        
        $log=M('qrcode_log')->where('Fid='.$Fid)->setField('Fstate',1);
        $wxuser=M('wxuser')->where(array('token'=>$logquery['Ftoken']))->setField('qrcode_req',2);        
        
        if($log && $wxuser){
            //$this->ajaxReturn('success');
            //echo 'success';
            $this->success('申请通过');
        }else{
            //echo 'error';
            //$this->ajaxReturn('error');
            $this->error('对不起，状态更新失败');
        }
        
        
        //if($log && $wxuser){
          //  echo '1';
        //}
    }
    //二维码申请不通过
    public function qrcode_refuse(){
        $Fid=$_GET['Fid'];
        $logquery=M('qrcode_log')->where(array('Fid'=>$Fid))->field('Ftoken')->find();        
        //wxuser状态已取消，删除log记录
        $wxuser=M('wxuser')->where(array('token'=>$logquery['Ftoken']))->setField('qrcode_req',3);        
        $log=M('qrcode_log')->where('Fid='.$Fid)->delete();
        if($log && $wxuser){
            //$this->ajaxReturn('success');
            //echo 'success';
            $this->success('二维码申请已取消');
        }else{
            //echo 'error';
            //$this->ajaxReturn('error');
            $this->error('对不起，申请取消失败');
        }
    }
//新增用户从users转到token,因为是用户功能
    // 添加用户
    public function adds(){
        $UserDB = D("Users");
        $platform=M('wa_platform')->field('id,annual_fee')->select(); 
        $this->assign('platform',$platform);
        if(isset($_POST['dosubmit'])) {
            
            $password = $_POST['password'];
            $repassword = $_POST['repassword'];
            $st_time=time();
            $end_time=strtotime($_POST['viptime']);
            if(empty($password) || empty($repassword)){
                $this->error('密码必须填写！');
            }
            if($password != $repassword){
                $this->error('两次输入密码不一致！');
            }
            if($_POST['is_vip']>0){
                if($_POST['annual_fee']<0 || $end_time<=0){
                    $this->error('请填写会员费用和时间信息');
                }
            }
            $_POST['viptime']=strtotime($_POST['viptime']);            
            //根据表单提交的POST数据创建数据对象           
            if($UserDB->create()){              
                $user_id = $UserDB->add();
                
                if($user_id){
                //创建企业用户wxuser表信息
                    $token=$this->getToken();
                    $createtime=time();
                    $data=array(
                    'uid'=>$user_id,
                    'wxname'=>$_POST['wxname'],
                    'username'=>$_POST['username'],
                    'token'=>$token,
                    'createtime'=>$createtime,
                    'phone'=>$_POST['mp'],
                    'waddress'=>$_POST['address'],
                    'smsuser'=>$_POST['user']
                        );
                    //设置会员
                    if($_POST['is_vip']>0){
                        $data['is_vip']=1;
                        $annual_fee=$_POST['annual_fee'];                       
                        $arr=array('token'=>$token,'annual_fee'=>$annual_fee,'start_time'=>$st_time,'end_time'=>$end_time,'createtime'=>$createtime);
                        D('wa_soft_annual')->add($arr);
                        D('wa_soft_annual_copy')->add($arr);
                    }
                    $res=M('wxuser')->add($data);           
                    if($res){
                        $this->success('添加成功！',U('Token/index'));
                    }else{
                        $this->error('公司用户添加失败!');
                    }
                                        
                }else{
                    $this->error('用户添加失败!');
                }
            }else{
                $this->error($UserDB->getError());
            }
        }else{
            $map=array('status'=>1);
            if (C('agent_version')){
                $map['agentid']=array('lt',1);
            }
            $role = M('User_group')->field('id,name')->where($map)->select();
            $this->assign('role',$role);
            $this->assign('tpltitle','添加');
            $this->display();
        }
    }
    private function getToken(){
        $randLength=6;
        $chars='abcdefghijklmnopqrstuvwxyz';
        $len=strlen($chars);
        $randStr='';
        for ($i=0;$i<$randLength;$i++){
            $randStr.=$chars[rand(0,$len-1)];
        }
        $tokenvalue=$randStr.time();
        return $tokenvalue;
    }    
    // 编辑用户
    public function edits(){
         $UserDB = D("Users");
        if(isset($_POST['dosubmit'])) {
            $password = $this->_post('password','trim',0);
            $repassword = $this->_post('repassword','trim',0);
            $users=M('Users')->field('gid')->find($_POST['id']);
            if($password != $repassword){
                $this->error('两次输入密码不一致！');
            }
            if($password==false){ 
                unset($_POST['password']);
                unset($_POST['repassword']);
            }else{
                $_POST['password']=md5($password);
            }
            unset($_POST['dosubmit']);
            unset($_POST['__hash__']);
            //根据表单提交的POST数据创建数据对象
                $_POST['viptime']=strtotime($_POST['viptime']);
                if($UserDB->save($_POST)){
                    if($_POST['gid']!=$users['gid']){
                        $fun=M('Function')->field('funname,gid,isserve')->where('`gid` <= '.$_POST['gid'])->select();
                        foreach($fun as $key=>$vo){
                            $queryname.=$vo['funname'].',';
                        }
                        $open['queryname']=rtrim($queryname,',');
                        $uid['uid']=$_POST['id'];
                        $token=M('Wxuser')->field('token')->where($uid)->select();
                        if($token){
                            $token_db=M('Token_open');
                            foreach($token as $key=>$val){
                                $wh['token']=$val['token'];
                                $token_db->where($wh)->save($open);
                            }
                        }
                    }
                    $this->success('编辑成功！',U('Token/index'));
                }else{
                     $this->error('编辑失败!');
                }
            
        }else{
            $id = $this->_get('id','intval',0);
            if(!$id)$this->error('参数错误!');
            $map=array('status'=>1);
            if (C('agent_version')){
                $map['agentid']=array('lt',1);
            }
            $role = M('User_group')->field('id,name')->where($map)->select();
            $info = $UserDB->find($id);
            $inviteCount=$UserDB->where(array('inviter'=>$id))->count();
            $this->assign('inviteCount',$inviteCount);
            $this->assign('tpltitle','编辑');
            $this->assign('role',$role);
            $this->assign('info',$info);
            $this->display('adds');
        }
    }

    public function edit(){
        if(IS_POST){
            $this->all_save();
        }else{
            $id=$this->_get('id','intval',0);
            if($id==0)$this->error('非法操作');
            $this->assign('tpltitle','编辑');
            $fun=M('Function')->where(array('id'=>$id))->find();
            $this->assign('info',$fun);
            $group=D('User_group')->getAllGroup('status=1');
            $this->assign('group',$group);
            $this->display('add');
        }
    }

//设置
    public function set(){
        $token = $this->_get('id');
        $uid = $this->_get('uid');
        //会员起止时间
        $vipdate=M('wa_soft_annual')->where(array('token'=>$token))->find();        
        if($_POST){
            $address=$this->_post('address');
            $phone=$this->_post('mp');
            $user=$this->_post('user');
            $password=$this->_post('password');
            $repassword=$this->_post('repassword');
            $token=$this->_post('token');   
            if($password && $password!==$repassword){
            $this->error("确认密码和新密码不一致");
            }     
            $pwd=md5($password);
            //年费时间
            $start_time=strtotime($this->_post('st_time'));
            $end_time=strtotime($this->_post('end_time'));
            $annual_fee=$this->_post('annual_fee');            
            $is_vip=$this->_post('is_vip');
            $createtime=time();
            if($is_vip>0){
                if($annual_fee<0 || $start_time<=0 || $end_time<=0){
                    $this->error('请填写会员费用和时间信息');
                }
            }
            if($password){
                $map=array('mp'=>$phone,'password'=>$pwd,'address'=>$address,'user'=>$user,'viptime'=>$end_time);
            }else{
                $map=array('mp'=>$phone,'address'=>$address,'user'=>$user,'viptime'=>$end_time);
            }

            $res0=M('users')->where(array('id'=>$uid))->save($map);
            
            $res=M('wxuser')->where(array('token'=>$token))->save(array('phone'=>$phone,'waddress'=>$address,'is_vip'=>$is_vip,'smsuser'=>$user));

            //增加年费记录
            if($vipdate){
             //if($start_time>$vipdate['start_time']){
                //更新年费表并增加copy表记录
                $viptime=M('wa_soft_annual')->where(array('token'=>$token))->save(array('start_time'=>$start_time,'end_time'=>$end_time,'annual_fee'=>$annual_fee));
                if($viptime){
                $log['token']=$token;
                $log['annual_fee']=$annual_fee;
                $log['createtime']=$createtime;
                $log['start_time']=$start_time;
                $log['end_time']=$end_time;                
                $feelog=M('wa_soft_annual_copy')->add($log);
                }
             //}
            }else{
                $viptime=M('wa_soft_annual')->add(array('token'=>$token,'annual_fee'=>$annual_fee,'start_time'=>$start_time,'end_time'=>$end_time,'createtime'=>$createtime));                
                if($viptime){
                $log['token']=$token;
                $log['annual_fee']=$annual_fee;
                $log['createtime']=$createtime;
                $log['start_time']=$start_time;
                $log['end_time']=$end_time;                
                $feelog=M('wa_soft_annual_copy')->add($log);
                }
            }           
            if($res0 || $res || $feelog){
                $this->success('更新成功');
            }else{
                $this->error('更新失败');
            }
        }else{
            $list=M('wxuser')->where(array('token'=>$token))->field('wxname,token,phone,smsuser,username,waddress,is_vip')->find();
            
            //$res1=M('wxuser')->where(array('token'=>$token))->find();
            $platform=M('wa_platform')->field('id,annual_fee')->select();                     
        }

        $this->assign('platform',$platform);
        $this->assign('token',$token);
        $this->assign('list',$list);        
        $this->assign('vipdate',$vipdate);        
         $this->display();
    }
    //设置老板经纬度
    public function getlat(){
        $token=$this->_get('id');
        $lng=$_GET['lng'];
        $lat=$_GET['lat'];

        $res=M('wxuser')->where(array('token'=>$token))->save(array('longitude'=>$lng,'latitude'=>$lat));
        if($res){
            $this->ajaxReturn('success');
        }else{
            $this->ajaxReturn("error");
        }
    }
//会员过期
    public function overdate(){
        $token = $this->_get('id');
        $res=M('wxuser')->where(array('token'=>$token))->setField('is_vip',0);
        if($res){
            $this->ajaxReturn('success');
        }
    }
//会员记录
    public function viplog(){
        $token = $this->_get('id');

        $result=M('wa_soft_annual_copy')->where(array('token'=>$token))->order('id desc')->select();
       
        foreach ($result as $k =>$v){      
           echo "<tr><td>".date('Y-m-d',$v['start_time'])." —— ".date('Y-m-d',$v['end_time'])."</td><td>".$v['annual_fee']."</td><td>".date('Y-m-d',$v['createtime'])."</td></tr>";
           
        }
    }
// 总金额每个水站奖励
    public function wcount(){
        $token=$_GET['id'];
        $sql="SELECT * from tp_wa_orders as orders left JOIN tp_wa_ordergoods as goods on orders.Fid=goods.Foid WHERE orders.Frid='1' and orders.Ftoken='".$token."'";
        $res=M()->query($sql);
        $this->assign('res',$res);
        $this->display();
    }

//送水工的奖励日志 
    public function workercount(){
        $db=M('Wa_workers');
        $token=$_GET['id'];
        $beginThismonth=mktime(0,0,0,date('m'),1,date('Y'));
        $endThismonth=mktime(23,59,59,date('m'),date('t'),date('Y'));
        $where=array(
          'Ftoken'=>$token,
          'Flasttime'=> array('between',$beginThismonth,$endThismonth)
        );
        $count= $db->where($where)->count();
        $Page = new Page($count,10);

        // $sql2="SELECT Fname,Fphone,Fmoney,Fnum FROM tp_wa_workers WHERE Ftoken ='".$token."' and Flasttime>='".$beginThismonth."' and '".$endThismonth."'";
        // $res2=M()->query($sql2);
        $res2=$db->where($where)->limit($Page->firstRow.','.$Page->listRows)->select();
        $show= $Page->show();
        $this->assign('page',$show);
        $this->assign('list',$res2);
        $this->display();
    }


    //水站消费者奖励设置

    public function rem_set(){
       
        $rem_type=!empty($_POST['rem_type']) ?$_POST['rem_type']:0;
        $rem_money=!empty($_POST['rem_money']) ?$_POST['rem_money']:0;
        $rem=M('wxuser');
        $res=$rem->where(array('winxintype'=>1))->save(array('rem_type'=>$rem_type,'rem_money'=>$rem_money));
       
        if($res){
            $this->success('设置成功');
        }else{
            $this->error('设置失败');
        }
    } 

    public function ew(){
      $file=fopen('mb2.csv','r');
      fgets($file);
      $data=array();
      $db=M('Qrcode');
   while(!feof($file)){
            $stmp= fgets($file);
            $stmps=explode(',',mb_convert_encoding($stmp,'utf-8','gb2312'));
            if($stmp!=""){
                $data=array('id'=>'20151127'.trim($stmps[0]),'qrcode'=>$stmps[1],'underQrcode'=>'','isCheckQR'=>1,'isCheckUnder'=>1,'isBan'=>0,'date'=>'2015-11-27 10:23:09','dateUnder'=>'0000-00-00 00:00:00','changebind'=>0,'remark3'=>0,'product_id'=>'0','bindtime'=>'0000-00-00 00:00:00','number'=>'20151127'.trim($stmps[0]),'token'=>'','isSall'=>'0','backup01'=>0,'backup02'=>0,'backup03'=>0,'backup04'=>0,'backup05'=>0,'backup06'=>0,'backup07'=>0,'backup08'=>0);
             $res=$db->add($data);
            if($res){
                echo '成功'.$data['id'];
            }else{
               echo '失败';
            }
           //var_dump($data);
            }
            
               
    }


}
}




?>
