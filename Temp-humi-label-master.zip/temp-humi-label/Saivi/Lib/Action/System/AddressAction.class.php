<?php
class AddressAction extends BackAction{
    public function index(){
        $UserDB = D('Wxuser');
        $res = $UserDB->field('id,wxname,token')->where($map)->order('id desc')->select();
        $this->assign('res',$res);
        $db=M('Wa_dorm');
        if($_POST){
           

            $token=trim($this->_post('token'));
            $Fname=trim($this->_post('Fname'));
            $Fremark=trim($this->_post('Fremark'));
          }else{
              $token=trim($this->_get('token'));
            $Fname=trim($this->_get('Fname'));
            $Fremark=trim($this->_get('Fremark'));
          }
           $this->assign('to',$token);
            if($token!=-1){
            $where=array('dorm.Ftoken'=>$token);
             $where2=array('Ftoken'=>$token);    
            $count= $db->where($where2)->count();
            $Page = new Page($count,10);   
            $show = $Page->show();
            $list=$db->field('dorm.*,user.wxname')->where($where)->table('tp_wa_dorm dorm')->join('tp_wxuser user on dorm.Ftoken= user.token','left')->limit($Page->firstRow.','.$Page->listRows)->order('Fid desc')->select();
              $this->assign('page',$show); 
              $this->assign('list',$list);
            }

            
       
     
       $this->display(); 
    }





// 删除操作
    public function del(){
        $id=$this->_get('id','intval',0);
        $dorm=M('wa_dorm')->where(array('Fid'=>$id))->find();
        if ($dorm['Fid']){
            M('wa_dorm')->where(array('Fid'=>$id))->delete();
             $this->success('操作成功');
        }else{
            $this->error('操作失败');
        }

    }

    public function add(){
       
        if($_POST){
        $token=!empty($_POST['token'])?trim($_POST['token']):'-1';
        $Fname=!empty($_POST['Fname'])?trim($_POST['Fname']):'';
        $Fremark=$_POST['Fremark'];
        
        $floor=M('wa_dorm')->where(array('Ftoken'=>$token,'Fname'=>$Fname))->find();
        if($floor){
            echo '2';
            exit;
        }

        if($token!=-1 && $Fname!=''){
            $data['Ftoken']=$token;
            $data['Fname']=$Fname;
            $data['Fremark']=$Fremark;
            $res=M('wa_dorm')->add($data);
            if($res){


                $wxname=M('Wxuser')->where(array('token'=>$token))->field('wxname')->find();
               
                $str="<tr><td width='113px'>水站:</td><td width='113px'>". $wxname['wxname']."</td><td width='113px'>寝室楼：</td><td width='113px'>".$Fname."</td><td width='113px'>注备：</td><td width='113px'>".$Fremark."</td></tr>";
                echo $str;
            }
        }else{
             echo '1';
        }
    }
    }

    public function edit(){
       $Fid=$_GET['id'];
       $db=M('wa_dorm');
       $UserDB = D('Wxuser');
        $res = $UserDB->field('wxname,token')->where($map)->select();
        $this->assign('res',$res);
       $list=$db->where(array('Fid'=>$Fid))->find();

       $this->assign('list',$list);
      $this->display();
    }

    public function editdo(){
         $db=M('wa_dorm');
     
         $token=$_POST['token'];
         $Fname=$_POST['Fname'];
         $Fremark=$_POST['Fremark'];
         $Fid=$_POST['Fid'];
         $res=$db->where(array('Fid'=>$Fid))->save(array('Ftoken'=>$token,'Fname'=>$Fname,'Fremark'=>$Fremark));
         if($res){
            $this->success('更新成功');
         }else{
            $this->error('更新失败');
         }
    }



}


?>
