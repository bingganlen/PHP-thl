<?php
/**
 * 商品库管理
 */
class GoodsAction extends BackAction{
    public $agent_db;

    public function _initialize(){
        parent :: _initialize();
        $this -> wxuser = M('wxuser');
    }
    // 商品库
    public function index(){
        $map=array();
        if($this->isPost()){
           // $FproductName = $_POST['FproductName'];
           //$FisOk = $_POST['FisOk'];
           //$Ftype = $_POST['Ftype'];
           $typeid = $_POST['typeid']; 
           // $map['l.FproductName']=array('like', '%'.$FproductName.'%');
       
            if($typeid!= -1){
               $map['id']=$typeid;
            }
        }
        $type = M('product_type')->where($map)->select();
    	//$db = M('wa_product_lib');	
    	//$count = M('wa_product_lib')->alias('l')->where($map)->count();
        //$Page = new Page($count,10);
        //$show = $Page->show();
    	//$list = M('wa_product_lib')->alias('l')->join('left join tp_product_type AS t ON l.typeid=t.id')->field('l.*,t.tagtype')->where($map)->order('l.Flibid desc')->limit($Page->firstRow.','.$Page->listRows)->select();        
        $this->assign('type',$type);
        //$this->assign('list', $list);
        //$this->assign('page',$show);// 赋值分页输出
        $this->display();

    }
    public function goods_add(){
        $FproductName=$_POST['FproductName'];
        $typeid=$_POST['typeid'];
        $Fspec = $_POST['Fspec'];
        //$Fcategory = $_POST['Fcategory'];
        // if($Fcategory<0){
            // $this->error('请选择商品类型');
        // }
        //获得图片路径
        $filename=$_FILES['Fimg'];
        // $savepath='img/img/list/';
        $savepath='uploads/goods/';
        // $imgurl = $this->uploadimg($savepath,$filename);
        $imgurl = parent::uploadimg($savepath,$filename);
        
        //需要添加的数据
        $saveurl='http://'.$_SERVER['HTTP_HOST'].'/'.$imgurl;
        //dump($saveurl);exit;
        $data=array();
        $data['FproductName']=$FproductName;
        $data['Fimg']=$saveurl;
        $data['Fspec']=$Fspec;
        $data['FisOk']='1';
        $data['typeid']=$typeid;
        $data['FcreateTime']=time();        
        $product_lib = M('wa_product_lib');
        $res=$product_lib->data($data)->add();
        if($res){
        	$this->success('商品添加成功');
        }else{
        	$this->error('商品添加失败！');
        }        
    }
    //商品编辑
    public function edit(){
    	$id = $_GET['id'];
    	$db=M('wa_product_lib');
    	$item = $db->where('Flibid='.$id)->find();
        $type=M('product_type')->select();
        $this->assign('type',$type);
        $this->assign('res',$item);
        // $this->ajaxReturn($item);
        $this->display();
    }
    public function goods_edit_save(){
    	$Flibid = $_POST['Flibid'];
    	$FproductName = $_POST['FproductName'];
        $Fspec = $_POST['Fspec'];
        $typeid = $_POST['typeid'];
        $filename = $_FILES['Fimg'];
        // $savepath='img/img/list/';
        $savepath='uploads/goods/';
        $data = array();       
        if($filename['name']){
        	$imgurl = parent::uploadimg($savepath,$filename);
            $saveurl = 'http://'.$_SERVER['HTTP_HOST'].'/'.$imgurl;
			$data['Fimg'] = $saveurl;            
        }         
        $data['FproductName']=$FproductName;        
        $data['Fspec']=$Fspec;
        $data['typeid']=$typeid;        
        $res=M('wa_product_lib')->where('Flibid='.$Flibid)->setField($data);        
        if($res){
            $this->assign("jumpUrl",U('Goods/index'));
        	$this->success('商品修改成功');
        }else{
        	$this->error('商品修改失败！');
        }  
    }
    //删除
    public function goods_del(){
    	$id = $_GET['proid'];
    	
    	if(!empty($id)){		
	        $res=M('wa_product_lib')->where('Flibid='.$id)->delete();
	        if($res){
	        	$this->ajaxReturn($res);
	        }else{
	        	$this->error('商品删除失败！');
	        }  
    	}else{
    		$this->error('未获得商品信息');
    	}

    }
    // 是否可用
    public function check(){
        $id = $_GET['proid'];
        $isok = $_GET['isok'];
        if(!empty($id)){
            $data['FisOk'] = $isok;
            $res=M('wa_product_lib')->where('Flibid='.$id)->save($data);
            
            $this->ajaxReturn($res);
             
        }else{
            $this->error('未获得商品信息');
        }

    }
    
    //上传图片方法
    // protected function uploadimg($savepath,$filename){
    //     $upload = new UploadFile();// 实例化上传类
	   //  $upload->maxSize = 2097152 ;// 设置附件上传大小
	   //  $upload->exts    = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
	   //  $upload->rootPath= ''; // 设置附件上传根目录
	   //  $upload->savePath= $savepath; // 设置附件上传（子）目录
	   //  // 上传文件 
	   //  $info = $upload->uploadOne($filename);
	   //  //var_dump($info);exit;
	   //  if(!$info) {// 上传错误提示错误信息
	   //    echo $upload->getErrorMsg();
	   //  }else{// 上传成功
	   //      //$this->success('上传成功！');
	   //     return $imgurl=$info[0]['savepath'].$info[0]['savename'];	        
	   //  }
    // }
    public function type_add(){
        $type=$_POST['type'];
        $des=$_POST['des'];
        if($type){
            $id=D('product_type')->add(array('tagtype'=>$type,'regular'=>$des));
            if($id){
                echo 'success';
            }else{
                echo 'error';
            }
        }else{
            echo 'error';
        }
    }
    public function type_del(){
        $id=$_GET['id'];
        if($id){
            $del=D('product_type')->delete($id);
            if($del){
                echo 'success';
            }else{
                echo 'error';
            }
        }else{
            echo 'error';
        }
    }
    public function type_edit(){
        $id=$_POST['id'];
        $typename=$_POST['typename'];
        $regular=$_POST['regular'];
        if($id){
            $edit=D('product_type')->where(array('id'=>$id))->save(array('tagtype'=>$typename,'regular'=>$regular));
            if($edit){
                echo 'success';
            }else{
                echo 'error';
            }
        }else{
            echo 'error';
        }
    }
}
?>