<?php
class PraisedAction extends BackAction{
     
     public function set(){
        $db=M('Wa_praisedset');
        $info=$db->find();
        $this->assign('info',$info);
      
        $this->display();
     }

     public function setdo(){
        $db=M('Wa_praisedset');
        
        $status=$_POST['status'];

        $name=$_POST['name'];
        $probability=$_POST['probability'];
        $endtime=strtotime($_POST['endtime']);
        $id=!empty($_POST['id'])?$_POST['id']:0;
        $times=$_POST['times'];
       $data=array('Fname'=>$name,'Fprobability'=>$probability,'Fendtime'=>$endtime,'Fstatus'=>$status,'Ftimes'=>$times);
       if($id==0){
         $res=$db->add($data);
       
         if($res){
             $this->success('修改成功');
         }
       }else{
          $res=$db->where(array('Fid'=>$id))->save($data);
            
           if($res){
             $this->success('修改成功');
         }
       }
     }


}
?>