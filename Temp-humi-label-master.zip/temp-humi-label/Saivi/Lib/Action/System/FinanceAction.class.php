<?php
class FinanceAction extends BackAction{
    public $agent_db;

    public function _initialize(){
        parent :: _initialize();
        $this -> wxuser = M('wxuser');
    }
    // 财务管理 水站的现金提现申请
    public function index(){
    	$where=array();
    	$where['fc.FmerType']=2;
    	$where['fc.Ftype']=2;
        if(IS_POST){
            if($_POST['Fwxname']){
                $where['u.wxname']=array('like','%'.$_POST['Fwxname'].'%');
            }
            if($_POST['FapplyTime']){

                $postdate=strtotime($_POST['FapplyTime']);
                $postdate1=strtotime($_POST['FapplyTime'])+24*3600;
                
                $where['fc.FapplyTime']=array('between',array($postdate,$postdate1));
                
            }
            if($_POST['Fstatus']&&$_POST['Fstatus']>0){
                $where['fc.Fstatus']=$_POST['Fstatus'];
            }            
        }
    	//分页
    	//$count=M('wa_finance_capital')->alias('fc')->where($where)->count();    	
    	//$page=new Page($count,25);
    	//$show=$page->show();
    	$list=M('wa_finance_capital')->alias('fc')->join('tp_wxuser AS u ON fc.FshopId=u.id')->where($where)->field('fc.*, u.id, u.wxname')->order('fc.FapplyTime desc')->select();
        //limit($Page->firstRow.','.$Page->listRows)
        //dump($list);
        $this->assign('lists',$list);
    	//$this->assign('page',$show);// 赋值分页输出
        $this->display();
    }
    //微信支付已支付订单
    public function wxincome(){
        $map=array();
        $map['o.Fpaytype']=2;//微信支付
        $map['o.Ftype']=1;//已支付
        //条件搜索
        if(IS_POST){
            if($_POST['Fwxname']){
                $map['u.wxname']=array('like','%'.$_POST['Fwxname'].'%');
            }
            if($_POST['Forderid']){
                $map['o.Forderid']=array('like','%'.$_POST['Forderid'].'%');
            }
            if($_POST['Fphone']){
                $map['o.Fphone']=array('like','%'.$_POST['Fphone'].'%');
            }
            if($_POST['Fordertime']){
                $postdate=strtotime($_POST['Fordertime']);
                $postdate1=strtotime($_POST['Fordertime'])+24*3600;                
                $map['o.Fordertime']=array('between',array($postdate,$postdate1));
            }
            if($_POST['Fstatus']>-1){
                $map['o.Fticket']=$_POST['Fstatus'];
            }
        }
        $lists=M('wa_orders')->alias('o')->join('tp_wxuser AS u ON o.Ftoken=u.token')->where($map)->field('o.*,u.id,u.wxname')->order('o.Fordertime desc')->select();
        $this->assign('lists',$lists);
        $this->display();
    }
    //提现审核
    public function check_cash(){
        $id=$_GET['Fid'];
        $status=$_GET['Fstatus'];       
        $data=array('FupdateTime'=>time(),'Fstatus'=>$status);
        //防止重复审核
        $shopid=M('wa_finance_capital')->where(array('Fid'=>$id))->field('FshopId,Fproject,Fmoney,FupdateTime')->find();
        if($shopid['FupdateTime']>0){
            $this->error('不能重复审核');
            return false;
        }
        //审核通过减提现金额
        if($status==2){            
            if($shopid['Fproject']==1){//现金账户
                M('wxuser')->where(array('id'=>$shopid['FshopId']))->setDec('cash_account',$shopid['Fmoney']);
            }elseif($shopid['Fproject']==2){//水票账户
                M('wxuser')->where(array('id'=>$shopid['FshopId']))->setDec('ticket_account',$shopid['Fmoney']);
            }            
        }
        $res=M('wa_finance_capital')->where(array('Fid'=>$id))->save($data);      
        if($res){
            $this->ajaxReturn('success');
        }else{
            $this->ajaxReturn('error');
        }

    }
}
?>