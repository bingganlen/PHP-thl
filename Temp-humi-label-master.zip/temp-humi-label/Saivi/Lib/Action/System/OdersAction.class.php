<?php
/**
 *网站后台
 *@package 
 *@author 
 **/
class OdersAction extends BackAction{
	
	public function index(){

		$db=M('Wa_orders');
		$dbs=M('Wxuser');
		$dbgood=M('Wa_ordergoods');
		$waternames=$dbs->field('wxname,token,id')->order('id desc')->select();

        if(IS_POST){
            
            $token=trim($_POST['token']);
            $Fordertime=!empty($_POST['Fordertime'])?strtotime(trim($_POST['Fordertime'])):0;
             $Fstatus=$_POST['Fstatus'];

             $this->assign('Fordertime',trim($_POST['Fordertime']));
         }else{
            
		$_GET['Fordertime'] = '20'.date('y-m-d', time());
         	$token=trim($_GET['token']);
            $Fordertime=!empty($_GET['Fordertime'])?strtotime(trim($_GET['Fordertime'])):0;
             $Fstatus=$_GET['Fstatus'];

              $this->assign('Fordertime',trim($_GET['Fordertime']));
         }

            $Fordertime2=$Fordertime+24*3600;
            $where=array();
             $where2=array();
           
           
            if($token!=-1){
            	$where['o.Ftoken']=$token;
            	$where2['Ftoken']=$token;

            }
            if(!empty($Fstatus) && ($Fstatus!=-1)){
               $where['o.Fstatus']=array('eq',$Fstatus);
               $where2['Fstatus']=array('eq',$Fstatus);
            }else{
               
                $where['o.Fstatus']=array('neq',0);
                 $where2['Fstatus']=array('neq',0);
            }
           
      
            if($Fordertime!=0){
            	 $where['o.Fordertime']=array('BETWEEN',"$Fordertime,$Fordertime2");
                 $where2['Fordertime']=array('BETWEEN',"$Fordertime,$Fordertime2");

            }
            $count= $db->where($where2)->count();
            
          
            $Page = new Page($count,10);   
            $show = $Page->show();

            $res=$db->field('o.Fid,o.Forderid,o.Fordertime,o.Ftotal,o.Fstatus,o.Fusers,o.Faddress,w.Fname, o.Fticket,o.Fphone,o.Ftoken')
                    ->table('tp_wa_orders o')->where($where)
                    ->join('tp_wa_workers w on o.Fworkerid=w.Fid', 'left')
                    // ->join('tp_wxuser u on o.Ftoken=u.token', 'left')
                    ->limit($Page->firstRow.','.$Page->listRows)->order('o.Fordertime desc')->select();
            
            foreach($res as $key=>$v){
               //echo $v['Fid'];
            	$goodsinfo=$dbgood->field('Fgoodsname,Fnum')->where(array('Foid'=>$v['Fid']))->find();
                $dbss=$dbs->field('wxname')->where(array('token'=>$v['Ftoken']))->find();
                $res[$key]['Fgoodsname']=$goodsinfo['Fgoodsname'];
                $res[$key]['Fnum']=$goodsinfo['Fnum'];
                $res[$key]['wxname']=$dbss['wxname'];
            }

          $this->assign('count', $count);
          
           $this->assign('to',$token);
    
           $this->assign('Fstatus',$Fstatus);
          $this->assign('list',$res);
          $this->assign('page',$show); 
       $this->assign('waternames',$waternames);
        // }else{
        //     $count= $db->where(array('Fstatus'=>array('neq', '0')))->count();
        //       $Page = new Page($count,10);       
        //     $res=$db->field('o.Fid,o.Forderid,o.Fordertime,o.Ftotal,o.Fstatus,o.Fusers,o.Faddress,w.Fname, o.Fticket,o.Fphone')->table('tp_wa_orders o')->where("Fstatus != 0")->join('tp_wa_workers w on o.Fworkerid=w.Fid', 'left')->limit($Page->firstRow.','.$Page->listRows)->order('o.Fordertime desc')->select();           
        // }        
        $this->display();
		
	}

    public function overtime(){
        //显示下单半小时后未派单的的订单，按照下单时间离现在的时间间隔从大到小排序
        $map=array();
        $map['Fstatus']=1;
        $etime=time()-30*60;
        $stime=strtotime(date("Y-m-d",time()));
        $map['Fordertime']=array('BETWEEN',"$stime,$etime");
        $count= M('Wa_orders')->where($map)->count();      
        $Page = new Page($count,10);   
        $show = $Page->show();
        $list=M('Wa_orders')->field('Fid,Forderid,Fordertime,Ftotal,Fstatus,Fusers,Faddress, Fticket,Fphone,Ftoken')->where($map)->order('Fordertime asc')->limit($Page->firstRow.','.$Page->listRows)->select();  
        $dbgood=M('Wa_ordergoods'); 
        $dbs=M('Wxuser');     
            foreach($list as $key=>$v){
               //echo $v['Fid'];
                $goodsinfo=$dbgood->field('Fgoodsname,Fnum')->where(array('Foid'=>$v['Fid']))->find();
                $dbss=$dbs->field('wxname')->where(array('token'=>$v['Ftoken']))->find();
                $list[$key]['Fgoodsname']=$goodsinfo['Fgoodsname'];
                $list[$key]['Fnum']=$goodsinfo['Fnum'];
                $list[$key]['wxname']=$dbss['wxname'];
            }
        $this->assign('count', $count);
        $this->assign('page',$show);
        $this->assign('list',$list);
        $this->display();
    }

}
?>
