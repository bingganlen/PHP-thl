<?php
/**
 * 商品库管理
 */
class SetinfoAction extends BackAction{
    public $agent_db;

    public function _initialize(){
        parent :: _initialize();
        $this -> wxuser = M('wxuser');
    }
    //物料及微信图片设置
    public function setimg(){
        //微信推广图片
        $wlist=M('wa_template')->where(array('Ftype'=>1))->order('Fid asc')->select();
        //宣传单
        $xlist=M('wa_template')->where(array('Ftype'=>2))->order('Fid asc')->select();
        //易拉宝
        $ylist=M('wa_template')->where(array('Ftype'=>3))->order('Fid asc')->select();
        //车贴
        $clist=M('wa_template')->where(array('Ftype'=>4))->order('Fid asc')->select();
        $this->assign('wlist',$wlist);
        $this->assign('xlist',$xlist);
        $this->assign('ylist',$ylist);
        $this->assign('clist',$clist);
        $this->display();
    }
    //公司简介页面
    public function profile(){
        $about=M('wa_aboutus')->where(array('id'=>1))->find();
        $this->assign('about',$about);
        if(IS_POST){
            $content=$_POST['content'];
            $hotline=$_POST['hotline'];
            $corp_name=$_POST['corp_name'];
            if(!$content || !$hotline || !$corp_name){
                $this->error('不能保存空值。');
            }else{
                $info=array('content'=>$content,'hotline'=>$hotline,'corp_name'=>$corp_name);
                $res=M('wa_aboutus')->where(array('id'=>1))->save($info);
                if($res){
                    $this->success('信息更新成功');
                }
            }
        }
        $this->display();
    }
    //年费设置
    public function feeset(){
        $fee=M('wa_platform')->field('id,annual_fee,content1')->order('id asc')->select();
        $this->assign('fee',$fee);
       
        if(IS_POST){
            $feeid0=$_POST['feeid0'];
            $feeid1=$_POST['feeid1'];
            $feeid2=$_POST['feeid2'];
            $content1=$_POST['content1'];
            if($feeid0){
                $res0=M('wa_platform')->where(array('id'=>0))->save(array('annual_fee'=>$feeid0));
            }
            if($feeid1){
                $res1=M('wa_platform')->where(array('id'=>1))->save(array('annual_fee'=>$feeid1));
            }
            if($feeid2){
                $res2=M('wa_platform')->where(array('id'=>2))->save(array('annual_fee'=>$feeid2));
            }
            if($content1){
                $res3=M('wa_platform')->where(array('id'=>0))->save(array('content1'=>$content1));
            }
           
            if($res0 || $res1 ||$res2 ||$res3){
                $this->success('年费修改成功');
            }else{
                $this->error('无需修改');
            }
        }
        $this->display();
    }
    //保存图片方法
    public function imgsave(){
        $id=$_GET['Fid'];
        $type=$_POST['Ftype'];
        
        $filename=$_FILES['img'.$id];//原图
        $filenamed=$_FILES['dimg'.$id];//预览图
        $savepath='uploads/setinfo/';
        $data = array();
        //dump($_FILES);
        //dump($filename);exit;
        if($filename['name']){
            $imgurl = parent::uploadimg($savepath,$filename);            
            $saveurl = 'http://'.$_SERVER['HTTP_HOST'].'/'.$imgurl;
            $data['Fimgurl'] = $saveurl;            
        } 
        if($filenamed['name']){
            $imgurl_d = parent::uploadimg($savepath,$filenamed);            
            $saveurl_d = 'http://'.$_SERVER['HTTP_HOST'].'/'.$imgurl_d;
            $data['Fpreview'] = $saveurl_d;            
        } 
        //dump($saveurl);exit;
        $data['Ftype']=$type;
        $data['Fcreatetime']=time();
        $res=M('wa_template')->where(array('Fid'=>$id))->save($data);
        if($res){
            $this->success('图片保存成功');
            //echo 'success';            
        }else{
            $this->error('图片保存失败');
        }
    }
    //删除图片
    function imgdel(){
        $id=$_GET['Fid'];
        $item=M('wa_template')->where(array('Fid'=>$id))->find();
        $docroot=$_SERVER["DOCUMENT_ROOT"];
        if($item['Fimgurl']){
            $url=str_replace('http://www.eyuanonline.com',$docroot,$item['Fimgurl']);
            $res=unlink($url);  
        }else{
            $this->error('无可删除的图片');
        }
        
        if($item['Fpreview']){
            $purl=str_replace('http://www.eyuanonline.com',$docroot,$item['Fpreview']);
            $pres=unlink($purl);
        }       
              
        $data=array();
        $data['Fimgurl']='';
        $data['Fpreview']='';
        $data['Fcreatetime']='';
        $res1=M('wa_template')->where(array('Fid'=>$id))->save($data);
        
        if($res&&$res1){
            $this->success('图片已删除');
        }else{
            $this->success('图片删除失败');
        }
    }
    
    // 状态审核
    public function check(){
        $id = $_GET['id'];
        $isok = $_GET['isok'];
        if(!empty($id)){
            $data['Fstatus'] = $isok;
            $res=M('wa_extension_all_net')->where('Fid='.$id)->save($data);
            if($res){
                $this->ajaxReturn($res);
            }else{
                $this->error('状态修改失败！');
            }  
        }else{
            $this->error('未获得站点信息');
        }

    }
    //全网推广列表
    public function spread()
    {        
        $UserDB = D('Wxuser');  
        $Extension=M('wa_extension_all_net');      
        if($this->isPost()){

            $map = array();
            if($_POST['wxname']){
                //$map['u.wxname']=$_POST['wxname'];    
                $map['u.wxname']=array('like','%'.$_POST["wxname"].'%');
            }
            if($_POST['wxphone']){
                //$map['u.phone']=$_POST['wxphone'];
                $map['u.phone']=array('like','%'.$_POST['wxphone'].'%');     
            }     
            if($_POST['status']>=0){
                $map['e.Fstatus']=$_POST['status'];            
            } 
            
        }   
        $count=$Extension->alias('e')->join('left join tp_wxuser AS u ON e.Ftoken=u.token')->where($map)->count();        
        $Page       = new Page($count,15);// 实例化分页类 传入总记录数
        // 进行分页数据查询 注意page方法的参数的前面部分是当前的页数使用 $_GET[p]获取
        $nowPage = isset($_GET['p'])?$_GET['p']:1;
        $show    = $Page->show();// 分页显示输出
        $field='e.Fcreatetime,e.Ftoken,e.Fstatus,u.wxname,u.phone';
        $list=$Extension->alias('e')
                        ->field($field)
                        ->join('left join tp_wxuser AS u ON e.Ftoken=u.token')
                        ->where($map)
                        ->limit($Page->firstRow.','.$Page->listRows)
                        ->order('e.Fid desc')
                        ->select();  
            
        $this->assign('list',$list);
        $this->assign('page',$show);// 赋值分页输出
        
        $this->display();
    }
    public function spd_img(){
        $token=$_GET['id'];
        $name=$_GET['name'];
        $item=M('wa_extension_all_net')->where(array('Ftoken'=>$token))->find();
        $this->assign('name',$name);
        $this->assign('item',$item);
        $this->display();
    }
    
}
?>