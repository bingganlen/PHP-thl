<?php
class MallAction extends BackAction{
    public $agent_db;

    public function _initialize(){
        parent :: _initialize();
        $this -> wxuser = M('wxuser');
    }
    // 合作商城管理
    public function index(){
    	$city11 = $this->_post('city11');
    	$city22 = $this->_post('city22');
        $this->assign('city11', $city11);
        $this->assign('city22', $city22);

        $city1 = D('tn_city')->where("Flevel = 0")->order('Fid ASC')->select();
        $this->assign('city1', $city1);

        $nowPage = isset($_GET['p'])?$_GET['p']:1;
        // $coshops = D('wa_co_shop')->where([])->order('Fshopid Desc')->select();
        $map = [];
        if($city22){
        	$map['Fcity2'] = $city22;
        }
        if($city11){
	        $city2 = D('tn_city')->where("Fpid=".$city11)->order('Fid ASC')->select();
	        $this->assign('city2', $city2);
        }

        $coshops = M('wa_co_shop')->table('tp_wa_co_shop wcs')
                ->field('wcs.*, c1.Fname as cityname1, c2.Fname as cityname2')
                ->join('tp_tn_city c1 on wcs.Fcity1=c1.Fid', 'left')
                ->join('tp_tn_city c2 on wcs.Fcity2=c2.Fid', 'left')
                ->where($map)->order('wcs.Fshopid Desc')->page($nowPage.','.C('PAGE_NUM'))->select();
        $this->assign('coshops', $coshops);
        
        $this->display();
    }

    /**
     * 新增合作商城
     * @return [type] [description]
     */
    public function coshop_runadd()
    {
    	$link = $this->_post('link');
    	// $img = $this->_post('img');
    	$shop_name = $this->_post('shop_name');
    	$start_time = $this->_post('start_time');
    	$end_time = $this->_post('end_time');
    	$position = $this->_post('position');
    	$city1 = $this->_post('city1');
    	$city2 = $this->_post('city2');

        //获得图片路径
        $filename=$_FILES['shop_img'];
        $savepath='uploads/shop/';
        $imgurl = parent::uploadimg($savepath,$filename);

        $data = array();
        $data['FshopName'] = $shop_name;
		$data['Fimg'] = $imgurl;
		$data['Flink'] = $link;
		$data['FstartTime'] = strtotime($start_time." 00:00:00");
		$data['FendTime'] = strtotime($end_time." 23:59:59");
		$data['Fposition'] = $position;
		// $data['Fcity'] = 
		$data['FcreateTime'] = time();
		$data['Fcity1'] = $city1;
		$data['Fcity2'] = $city2;
		$data['Fstatus'] = 0;

        $shop = M('wa_co_shop');

        $res=$shop->data($data)->add();
        if($res){
        	$this->success('商城添加成功');
        }else{
        	$this->error('商城添加失败！');
        }  
    }

    /**
     * 编辑
     * @return [type] [description]
     */
    public function coshop_edit()
    {
    	$shop_id = $this->_get('shop_id');
    	$map['Fshopid'] = $shop_id;
        $shop = M('wa_co_shop')->table('tp_wa_co_shop wcs')
                ->field('wcs.*')
                ->where($map)->find();
        $this->assign('shop', $shop);

        $city1 = D('tn_city')->where("Flevel = 0")->order('Fid ASC')->select();
        $this->assign('city1', $city1);
        $city2 = D('tn_city')->where("Fpid=".$shop['Fcity1'])->order('Fid ASC')->select();
        $this->assign('city2', $city2);

        $this->display();
    }
    public function coshop_runedit()
    {
    	$shop_id = $this->_post('shop_id');
    	$link = $this->_post('link');
    	// $img = $this->_post('img');
    	$shop_name = $this->_post('shop_name');
    	$start_time = $this->_post('start_time');
    	$end_time = $this->_post('end_time');
    	$position = $this->_post('position');
    	$city1 = $this->_post('city1');
    	$city2 = $this->_post('city2');

        $data = array();
        //获得图片路径
        $filename=$_FILES['shop_img'];
        if(!empty($filename)){
	        $savepath='uploads/shop/';
	        $imgurl = parent::uploadimg($savepath,$filename);
			$data['Fimg'] = $imgurl;
	    }

        $data['FshopName'] = $shop_name;
		$data['Flink'] = $link;
		$data['FstartTime'] = strtotime($start_time." 00:00:00");
		$data['FendTime'] = strtotime($end_time." 23:59:59");
		$data['Fposition'] = $position;
		// $data['Fcity'] = 
		// $data['FcreateTime'] = time();
		$data['Fcity1'] = $city1;
		$data['Fcity2'] = $city2;
		$data['Fstatus'] = 0;

        $shop = M('wa_co_shop');

        $res=$shop->where(array('Fshopid'=>$shop_id))->save($data);
        if($res){
        	$this->assign("jumpUrl",U('Mall/index'));
        	$this->success('商城添加成功');
        }else{
        	$this->error('商城添加失败！');
        } 
    }

    public function coshop_del()
    {
    	$id = $_GET['proid'];
    	
    	if(!empty($id)){		
	        $res=M('wa_co_shop')->where('Fshopid='.$id)->delete();
	        if($res){
	        	$this->ajaxReturn($res);
	        }else{
	        	$this->error('商品修改失败！');
	        }  
    	}else{
    		$this->error('未获得商品信息');
    	}
    }
}
?>