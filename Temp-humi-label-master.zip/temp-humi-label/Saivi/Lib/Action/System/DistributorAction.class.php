<?php
class DistributorAction extends BackAction{
    /**
     * 列表
     * @return [type] [description]
     */
    public function index(){
        $db=M('Wa_distributor');
        if(IS_POST){
             //$Fusername=$_POST['Fusername'];
            $keyword=$_POST['keyword'];
            //var_dump($keyword);exit;
            $map['wd.Fusername'] = array('like','%'.$keyword.'%');
            $count      = $db->where($map)->count();
            $Page       = new Page($count,10);
            $res=$db->table('tp_wa_distributor wd')
                    ->field('wd.*, u.username, c1.Fname as cityname1, c2.Fname as cityname2, c3.Fname as cityname3')
                    ->join('tp_user u on wd.Fco_user_id = u.id', 'left')
                    ->join('tp_tn_city c1 on wd.Fcity1=c1.Fid', 'left')
                    ->join('tp_tn_city c2 on wd.Fcity2=c2.Fid', 'left')
                    ->join('tp_tn_city c3 on wd.Fcity3=c3.Fid', 'left')
                    ->where($map)->order('wd.Fid desc')->limit($Page->firstRow.','.$Page->listRows)->select();
             //$res=$db->where($map)->order('Fid desc')->page($_GET['p'].',10')->select();
        }else{
            $count      = $db->count();
            $Page       = new Page($count,10);
            $res=$db->table('tp_wa_distributor wd')
                    ->field('wd.*, u.username, c1.Fname as cityname1, c2.Fname as cityname2, c3.Fname as cityname3')
                    ->join('tp_user u on wd.Fco_user_id = u.id', 'left')
                    ->join('tp_tn_city c1 on wd.Fcity1=c1.Fid', 'left')
                    ->join('tp_tn_city c2 on wd.Fcity2=c2.Fid', 'left')
                    ->join('tp_tn_city c3 on wd.Fcity3=c3.Fid', 'left')
                    ->order('wd.Fid desc')->limit($Page->firstRow.','.$Page->listRows)->select();
            // $res=$db->order('Fid desc')->page($_GET['p'].',10')->select();
        }

        // 获取城市合伙人列表
        $cousers = D('User')->where('role = 1')->order('id DESC')->select();
        $this->assign('cousers', $cousers);
        $city1 = D('tn_city')->where("Flevel = 0")->order('Fid ASC')->select();
        $this->assign('city1', $city1);

        $show       = $Page->show();
        $this->assign('res',$res);
        $this->assign('page',$show);
        $this->display(); 
    }

    /**
     * 删除
     * @return [type] [description]
     */
    public function del(){
        $id=$this->_get('id','intval',0);
        $dorm=M('Wa_distributor')->where(array('Fid'=>$id))->find();
        if ($dorm['Fid']){
            M('Wa_distributor')->where(array('Fid'=>$id))->delete();
             $this->success('操作成功');
        }else{
            $this->error('操作失败');
        }

    }

    /**
     * 新增经销商
     */
    public function add(){
        if($_POST){
            $Fusername=!empty($_POST['Fusername'])?trim($_POST['Fusername']):'';
            $Fpassword=$_POST['Fpassword'];
            $Fusername=trim($Fusername);
            $Fpassword=trim($Fpassword);
            $yCode = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J');
            $str=$yCode[array_rand($yCode,1)];
            $Fsn=$str . rand(1000000,9999999);
            //add by shitao 20171218
            $Fco_user_id = $_POST['co_user_id']?$_POST['co_user_id']:0;
            $Fcity1 = $_POST['city1']?$_POST['city1']:0;
            $Fcity2 = $_POST['city2']?$_POST['city2']:0;
            $Fcity3 = $_POST['city3']?$_POST['city3']:0;
            
            $ex=M('Wa_distributor')->where(array('Fusername'=>$Fusername))->find();
            if($ex){
                echo '2';
                exit();
            }
            if($Fusername!=''){
                $data['Fusername']=$Fusername;
                $data['Fpassword']=md5($Fpassword);
                $data['Fcode']=$Fsn;
                // add by shitao 20171218
                $data['Fco_user_id'] = $Fco_user_id;
                $data['Fcity1'] = $Fcity1;
                $data['Fcity2'] = $Fcity2;
                $data['Fcity3'] = $Fcity3;
                $data['FcreateTime'] = time();

                $res=M('Wa_distributor')->add($data);
                exit();
                if($res){             
                    $str="<tr><td width='113px'>用户名:</td><td width='113px'>". $Fusername."</td><td width='113px'>".$Fsn."</td></tr>";
                    echo $str;
                }
            }else{
                 echo '1';
            }
        }
    }

    /**
     * 编辑
     * @return [type] [description]
     */
    public function edit(){
        $Fid=$_GET['id'];
        $db=M('Wa_distributor');
        $res = $db->where(array('Fid'=>$Fid))->find();

        // 获取城市合伙人列表
        $cousers = D('User')->where('role = 1')->order('id DESC')->select();
        $this->assign('cousers', $cousers);
        $city1 = D('tn_city')->where("Flevel = 0")->order('Fid ASC')->select();
        $this->assign('city1', $city1);
        if($res['Fcity1']){
            $city2 = D('tn_city')->where("Fpid=".$res['Fcity1'])->order('Fid ASC')->select();
            $this->assign('city2', $city2);
        }
        if($res['Fcity2']){
            $city3 = D('tn_city')->where("Fpid=".$res['Fcity2'])->order('Fid ASC')->select();
            $this->assign('city3', $city3);
        }

        $this->assign('res',$res);
        $this->display();
    }
    public function editdo(){
        $Fid=$_POST['Fid'];
        $data = [];
        $Fusername=trim($_POST['Fusername']);
        $Fpassword=trim($_POST['Fpassword']);
        $Fco_user_id = $_POST['co_user_id']?$_POST['co_user_id']:0;
        $Fcity1 = $_POST['city1']?$_POST['city1']:0;
        $Fcity2 = $_POST['city2']?$_POST['city2']:0;
        $Fcity3 = $_POST['city3']?$_POST['city3']:0;

        $data['Fusername'] = $Fusername;
        if($Fpassword){
            $data['Fpassword'] = md5($Fpassword);
        }
        $data['Fco_user_id'] = $Fco_user_id;
        $data['Fcity1'] = $Fcity1;
        $data['Fcity2'] = $Fcity2;
        $data['Fcity3'] = $Fcity3;
         
        $db=M('Wa_distributor');
        $res=$db->where(array('Fid'=>$Fid))->save($data);
        if($res){
            $this->assign("jumpUrl",U('Distributor/index'));
            $this->success('更新成功');
        }else{
            $this->error('更新失败');
        }
    }

   public function info(){
    $Fid=$_GET['Fid'];
    $db=M('Wa_distributor');
    $order=M('Wa_orders');
    // $fcode=$db->field('Fcode')->where(array('Fid'=>$Fid))->find();
    $list=M('Wxuser')->where(array('Fdis_id'=>$Fid))->order($o)->select();
    $this->assign('res',$list);
    if(IS_POST){  
        $time1=!empty($_POST['time'])?strtotime(trim($_POST['time'])):0;
        if($time==0){
            $time2=time();   
        }else{
            $time2=$time1+24*3600; 
        }
       
        $where['u.Fcreatetime']=array('BETWEEN',"$time1,$time2");
        $where['w.Fdis_id']=array('eq',$Fid);
        $where2['o.Fordertime']=array('BETWEEN',"$time1,$time2");
        $where2['w.Fdis_id']=array('eq',$Fid);
        //注册量createtime
        if($_POST['act']=='reg'){
       
        $regnum=M('Wa_users')->table('tp_wa_users u')->where($where)->join('tp_wxuser w on w.token=u.Ftoken')->count();
        $orercount=$order->table('tp_wa_orders o')->where(array('w.Fdis_id'=>$Fid))->join('tp_wxuser w on o.Ftoken=w.token', 'left')->count();
        }else{
          $regnum=M('Wa_users')->table('tp_wa_users u')->where(array('w.Fdis_id'=>$Fid))->join('tp_wxuser w on w.token=u.Ftoken')->count();
        $orercount=$order->table('tp_wa_orders o')->where($where2)->join('tp_wxuser w on o.Ftoken=w.token', 'left')->count();  
        }
        //订单量
       
        //echo $order->getlastSql();
        $this->assign('time',$_POST['time']);
    }else{
        $regnum=M('Wa_users')->table('tp_wa_users u')->where(array('w.Fdis_id'=>$Fid))->join('tp_wxuser w on w.token=u.Ftoken')->count();
        $orercount=$order->table('tp_wa_orders o')->where(array('w.Fdis_id'=>$Fid))->join('tp_wxuser w on o.Ftoken=w.token', 'left')->count();
    }
    $this->assign('regnum',$regnum);
    $this->assign('orercount',$orercount);
    $this->display();
   }

}


?>
