<?php
/**
 *网站后台
 *@package 
 *@author 
 **/
class WateruserAction extends BackAction{
	
	public function index(){

		$db=M('Wa_users');
		$dbs=M('Wxuser');
        $ord=M();
        //$waternames=$dbs->field('wxname,token')->select();
        $waternames=$dbs->field('wxname,token,id')->order('id desc')->select();
        

        
        if(IS_POST){
            $token=trim($_POST['token']);
            $Fcreatetime=!empty($_POST['Fcreatetime'])?strtotime(trim($_POST['Fcreatetime'])):0;
            $Fcreatetime2=$Fcreatetime+24*3600;
             $this->assign('Fcreatetime',trim($_POST['Fcreatetime']));
        }else{
              $token=trim($_GET['token']);
            $Fcreatetime=!empty($_GET['Fcreatetime'])?strtotime(trim($_GET['Fcreatetime'])):0;
            $Fcreatetime2=$Fcreatetime+24*3600; 
             $this->assign('Fcreatetime',trim($_GET['Fcreatetime']));  
        }
            $where=array();
            $where2=array();
            if($token!=-1){
                $where['u.Ftoken']=$token;
                $where2['Ftoken']=$token;

            }
          
            if($Fcreatetime!=0){
                 $where['u.Fcreatetime']=array('BETWEEN',"$Fcreatetime,$Fcreatetime2");
                 $where2['Fcreatetime']=array('BETWEEN',"$Fcreatetime,$Fcreatetime2");

            }

            $count= $db->where($where2)->count();
            $Page = new Page($count,10);   
if(IS_POST){
             $res=$db->field('u.*,w.wxname')->table('tp_wa_users u')->where($where)->join('tp_wxuser w on u.Ftoken=w.token', 'left')->limit($Page->firstRow.','.$Page->listRows)->order('Fcreatetime desc')->select();  
}
          
        // }else{

        //    $count= $db->count();
        //    $Page = new Page($count,10);       
        //    $res=$db->field('u.*,w.wxname')->table('tp_wa_users u')->join('tp_wxuser w on u.Ftoken=w.token', 'left')->limit($Page->firstRow.','.$Page->listRows)->order('Fcreatetime desc')->select();

          
          
        // }
         //欠款
           foreach($res as $k=>$v){
                
               // $sql="SELECT sum(Ftotal) as Ftotal from tp_wa_orders where Fusers='".$v['Fusername']."' and Fstatus=3 and Ftype=0";
             $money1=M('Wa_prolog')->field('SUM(Fmoney) as Fmoney,SUM(Ftnum) as Ftnum')->where(array('Ftoken'=>$token,'Fstatus'=>1,'Fuser'=>$v['Fusername']))->select();    
             $money2=M('Wa_prolog')->field('SUM(Fmoney) as Fmoney,SUM(Ftnum) as Ftnum')->where(array('Ftoken'=>$token,'Fstatus'=>0,'Fuser'=>$v['Fusername']))->select();
            if(($money1[0]['Fmoney']-$money2[0]['Fmoney'])<=0){
                $moneyw=0;
            }else{
              $moneyw=$money1[0]['Fmoney']-$money2[0]['Fmoney'];
            }
              //$ordindos=$ord->query($sql);
              //$res[$k]['total']=!empty($ordindos[0]['Ftotal'])?$ordindos[0]['Ftotal']:0;
  
              $res[$k]['total']=$moneyw;
             
            }
        $this->assign('to',$token);
        $this->assign('waternames',$waternames);
        $show = $Page->show();

        $this->assign('list',$res);
        $this->assign('page',$show);
        $this->display();
		
	}

     public function getticket(){
        $id = $_GET["id"];
        $token = $_GET["token"];

        $where = array('Fuser'=>$id, 'Ftoken'=>$token);
        $db = M('wa_ticket');
        $ticket = $db->field('tp_wa_ticket.*, tp_product.name gname')->where($where)->join('left join tp_product on tp_product.id = tp_wa_ticket.Fgoodsid')->select();
        if($ticket){
        
        foreach($ticket as $k=>$v){
           $infos='<tr>';
           $infos.='<td style="text-align: left;">'.$v[gname].'</td>';
           $infos.='<td style="text-align: right;">'.$v[Fnum].'张</td> ';   
           $infos.= '</tr>';   
          echo $infos;
        }
       
     }else{
        echo '无';
     }
}

public function useradd(){

    $token=$_POST['token'];
    $Fusername=$_POST['Fusername'];
    $Fpassword=$_POST['Fpassword'];
    $addressinfo=$_POST['addressinfo'];
    $Ffloorid=$_POST['Ffloorid'];
    $Fewm_id=$_POST['Fewm_id'];
    if(empty($Fusername)){
        $this->error('请填写用户名');
        exit();
    }

    if(empty($Fpassword)){
        $this->error('请填写密码');
        exit();
    }
    if($token=='-1'){
        $this->error('请选择水站');
        exit();
    }

     if($Ffloorid=='-1'){
        $this->error('请选择宿舍楼');
        exit();
    }

    $fllor=M('Wa_dorm')->field('Fname')->where(array('Fid'=>$Ffloorid))->find();
   $Faddress=$fllor['Fname'].'-'.$addressinfo;
   $db=M('Wa_users');
   $res=$db->add(array('Fusername'=>$Fusername,'Fpassword'=>$Fpassword,'Faddress'=>$Faddress,'Ftoken'=>$token,'Fewm_id'=>$Fewm_id));
   if($res){
     $this->success('添加成功');
   }else{
  $this->error('失败');
   }
}

public function getfloor(){
    $token=$_GET['token'];
    $db=M('Wa_dorm');
    $fllor=$db->field('Fname,Fid')->where(array('Ftoken'=>$token))->select();
    foreach ($fllor as $k =>$v){
      
       echo "<option value='".$v['Fid']."'>".$v['Fname']."</option>";
    }

}

public function checkerm(){
    $Fewm_id=$_GET['Fewm_id'];
    $db=M('Wa_users');
    $res=$db->where(array('Fewm_id'=>$Fewm_id))->find();
    if($res){
        echo '1';
    }else{
        echo '2';
    }
}


    /**
     *  批量上传商品2015.06.26
     */
    public function uploaduser(){
        $db=M('Wa_users');
        if(empty($_FILES['file']['tmp_name'])){
            $this->error('请你上传刚下载填好数据的模板');
            exit();
        }
        $file=fopen($_FILES['file']['tmp_name'],'r');
        fgets($file);
        $data=array();
        while(! feof($file)){
            $stmp= fgets($file);
            $stmps=explode(',',mb_convert_encoding($stmp,'utf-8','gb2312'));
            if($stmp!=""){
                $d=array('Fusername'=>trim($stmps[0]),'Fewm_id'=>$stmps[1],'Ftoken'=>$stmps[2],'Fpassword'=>md5($stmps[3])
                    ,'Ffloorid'=>$stmps[4],'Faddress'=>$stmps[5],'Fcreatetime'=>time());
             
                $db->add($d);
            }
        }
        $this->success('添加完成');

    }


    public function integration(){
	$size = 10;
    	$page = $_GET['p']-1;
		if($page < 0){
			$page = 0;
		}
		$_GET['p'] = $page + 1;
		$sql = "SELECT 
		a.Ftotal,
		a.Fcreatetime,
		a.Fproductid,
		b.name
	FROM tp_wa_integration a
	LEFT JOIN tp_product b
	ON a.Fproductid = b.id
	WHERE a.Ftoken = '%s' AND a.Fphone = '%s'
	ORDER BY Fcreatetime DESC
	LIMIT %s, ".$size;

		$sql = sprintf($sql, $_GET['token'], $_GET['Fphone'], $page*$size);
		$data = M()->query($sql);

		$totalsql = "SELECT SUM(a.Ftotal) AS n, COUNT(1) AS count
	FROM tp_wa_integration a
	WHERE a.Ftoken = '%s' AND a.Fphone = '%s'";

		$totalsql = sprintf($totalsql, $_GET['token'], $_GET['Fphone']);
		$total = M()->query($totalsql);

		$this->assign('data', $data);
		$this->assign('total', $total[0]['n']?$total[0]['n']:'0');


        $Page = new Page($total[0]['count'],10);  
        $show = $Page->show(); 
        $this->assign('page',$show);

    	$this->display();
    }
}
?>
