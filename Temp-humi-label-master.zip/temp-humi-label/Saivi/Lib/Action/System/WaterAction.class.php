<?php
class WaterAction extends BackAction{
    public function count() {
        $db=M();
        $sql='select id, wxname, token from tp_wxuser';
        $res=$db->query($sql);
        $this->assign('cus',$res);
        if(IS_POST){

            if($_POST["cus"]){
                $sql="select count(*) c from tp_wa_users where Fewm_id in (select id from tp_qrcode where token = '".$_POST['cus']."')";
                $res=$db->query($sql);
                $this->assign('zc',$res);
            }
            if($_POST["start"]){
                $sql = $sql." and Fcreatetime >= ".strtotime($_POST["start"]);
            }
            if($_POST["end"]){
                $sql = $sql." and Fcreatetime <= ".strtotime($_POST["end"]." 23:59:59");
            }
            $res=$db->query($sql);
            $this->assign('izc',$res);

            $sql = 'select count(*) c from tp_wa_orders where Ftoken = "'.$_POST["cus"].'" and Fstatus = 3';
            if($_POST["start"]){
                $sql = $sql." and Fordertime >= ".strtotime($_POST["start"]);
            }
            if($_POST["end"]){
                $sql = $sql." and Fordertime <= ".strtotime($_POST["end"]." 23:59:59");
            }
            $res=$db->query($sql);
            $this->assign('order',$res);

            $sql = 'select sum(Ftotal) c, sum(Fnum) n from tp_wa_ordergoods where Foid in (select Fid from tp_wa_orders where Ftoken = "'.$_POST["cus"].'" and Fstatus = 3)';
            if($_POST["product"]!="-1"){
                $sql .= " and Fgoodsid = '".$_POST["product"]."'";
            }
            if($_POST["start"]){
                $sql = $sql." and Fcreate_time >= ".strtotime($_POST["start"]);
            }
            if($_POST["end"]){
                $sql = $sql." and Fcreate_time <= ".strtotime($_POST["end"]." 23:59:59");
            }
            $res=$db->query($sql);
            $this->assign('pamount',$res);

            $sql = 'select sum(Fprice*Fnum-Ftotal) c, sum(round((Fprice*Fnum-Ftotal)/Fprice)) n from tp_wa_ordergoods where Foid in (select Fid from tp_wa_orders where Ftoken = "'.$_POST["cus"].'" and Fstatus = 3 and Frid = 1)';
            if($_POST["product"]!="-1"){
                $sql .= " and Fgoodsid = '".$_POST["product"]."'";
            }
            if($_POST["start"]){
                $sql = $sql." and Fcreate_time >= ".strtotime($_POST["start"]);
            }
            if($_POST["end"]){
                $sql = $sql." and Fcreate_time <= ".strtotime($_POST["end"]." 23:59:59");
            }
            $res=$db->query($sql);
            $this->assign('plus',$res);
            // var_dump($res);
            // var_dump($db->getLastSQL());

            $sql = 'select Fstyle, sum(Freward) r from tp_wa_workerlog where Forderno in (select Forderid from tp_wa_orders where Ftoken = "'.$_POST["cus"].'" and Fstatus = 3)';
            if($_POST["start"]){
                $sql = $sql." and Fcreatetime >= ".strtotime($_POST["start"]);
            }
            if($_POST["end"]){
                $sql = $sql." and Fcreatetime <= ".strtotime($_POST["end"]." 23:59:59");
            }
            $sql = $sql." group by Fstyle";
            $res=$db->query($sql);
            $this->assign('reward',$res);
        }


        $this->display();
    }

    public function total(){
    	if($_POST['start'] && $_POST['end']){
    		$tokens = 'SELECT wxname, token FROM tp_wxuser';
    		$tokens = M()->query($tokens);

		    header("Content-type:text/csv");   
		    header("Content-Disposition:attachment;filename=".str_replace("+", "%20", urlencode("芯片数据统计表(".$_POST['start']."至".$_POST['end'].").csv")));   
		    header('Cache-Control:must-revalidate,post-check=0,pre-check=0');   
		    header('Expires:0');   
		    header('Pragma:public'); 
        //confset时间条件  
        $datewhere1 = " AND deliveryTime>='".strtotime($_POST['start'].' 00:00:00')."' AND deliveryTime<='".strtotime($_POST['end'].' 23:59:59')."'";
        //recordset时间条件
		    $datewhere = " AND uptime>='".strtotime($_POST['start'].' 00:00:00')."' AND uptime<='".strtotime($_POST['end'].' 23:59:59')."'";

    		foreach ($tokens as $key => $value) {
    			$username = $value['wxname'];
          
    			$salenum = "SELECT COUNT(DISTINCT(labelId)) AS n FROM tp_confset WHERE token = '".$value['token']."'".$datawhere1;
    			$salenum = M()->query($salenum)[0]["n"];
    			$upnum = "SELECT COUNT(*) AS n FROM tp_recordset WHERE token = '".$value['token']."'".$datewhere;
    			$upnum = M()->query($upnum)[0]["n"];

//     			$data = "SELECT 
// 	a.renum,
// 	b.onum,
// 	IFNULL(a.createtime, b.createtime2) AS createtime
// FROM (
// SELECT 
// 	COUNT(1) AS renum,
// 	FROM_UNIXTIME(Fcreatetime, '%Y-%m-%d') AS createtime
// FROM tp_wa_users
// WHERE Ftoken = '".$value['token']."'
// GROUP BY createtime) a
// LEFT JOIN (
// SELECT 
// 	COUNT(1) AS onum,
// 	FROM_UNIXTIME(Fordertime, '%Y-%m-%d') AS createtime2
// FROM tp_wa_orders
// WHERE Ftoken = '".$value['token']."' AND Fstatus!=0
// GROUP BY createtime2) b
// ON a.createtime = b.createtime2
// WHERE createtime >= '".$_POST['start']."' AND createtime <= '".$_POST['end']."'
// UNION
// SELECT 
// 	IFNULL(b.renum, 0) AS renum, 
// 	a.* 
// FROM (
// SELECT 
// 	b.onum,
// 	createtime
// FROM (
// SELECT 
// 	COUNT(1) AS onum,
// 	FROM_UNIXTIME(Fordertime, '%Y-%m-%d') AS createtime
// FROM tp_wa_orders
// WHERE Ftoken = '".$value['token']."' AND Fstatus!=0
// GROUP BY createtime) b
// WHERE createtime >= '".$_POST['start']."' AND createtime <= '".$_POST['end']."'
// ORDER BY createtime DESC) a
// LEFT JOIN (
// SELECT 
// 	COUNT(1) AS renum,
// 	FROM_UNIXTIME(Fcreatetime, '%Y-%m-%d') AS createtime
// FROM tp_wa_users
// WHERE Ftoken = '".$value['token']."'
// GROUP BY createtime) b
// ON a.createtime = b.createtime
// ORDER BY createtime DESC;";
// 				$data = M()->query($data);

				$titl = '企业名,内容,';
				$a = $username.',上传标签个数,';
				$b = $username.',上传次数,';
				// $c = $watername.',新增注册人数,';
				// $d = $watername.',二次下单,';
				// $e = $watername.',今日下单数量,';
				// $f = $watername.',百分比【自动计算】,';
				//foreach ($data as $k => $v) {
					//$titl .= $v['createtime'].',';
					$a .= $salenum.',';
					$b .= $upnum.',';
					// $c .= $v['renum'].',';
					// $d .= ',';
					// $e .= $v['onum'].',';
					// $f .= ($v['onum']/$allrenum*100).'%,';
				//}

				echo iconv('utf-8','gb2312',$titl)."\n";
				echo iconv('utf-8','gb2312',$a)."\n";
				echo iconv('utf-8','gb2312',$b)."\n";
				// echo iconv('utf-8','gb2312',$c)."\n";
				// echo iconv('utf-8','gb2312',$d)."\n";
				// echo iconv('utf-8','gb2312',$e)."\n";
				// echo iconv('utf-8','gb2312',$f)."\n\n\n\n";
    		}
    		return;
    	}else{
        //没有提交数据三个指标
        //dump('没有条件查询');
        $cpnum=M('wxuser')->count();
        $salenum=M('confset')->count('distinct(labelId)');
        $upnum=M('recordset')->count();
        $this->assign('cpnum', $cpnum);
        $this->assign('salenum', $salenum);
        $this->assign('upnum', $upnum);
      }

    	$now = '20'.date('y-m-d',time());
    	// $last = '20'.date('y-m-d', time()-604800);
    	// $month = substr('20'.date('y-m-d',time()), 0, 7).'-01';
      $tjtime=M('wxuser')->field('createtime')->order('id asc')->select();
      $tjday=date('Y-m-d',$tjtime[0]['createtime']);      
      $this->assign('tjtime',$tjday);
    	$this->assign("now", $now);
    	// $this->assign("last", $last);
    	// $this->assign("month", $month);
    	$this->display();
    }
//统计页查询数据
    public function total_search(){
      $start=strtotime($_POST['st']);
      $end=strtotime($_POST['end'])+86399;
      $cpmap=array('createtime'=>array('BETWEEN',"$start,$end"));
      $cpnum=M('wxuser')->where($cpmap)->count();
      $salmap=array('deliveryTime'=>array('BETWEEN',"$start,$end"));
      $salenum=M('confset')->where($salmap)->count('distinct(labelId)');
      $upmap=array('uptime'=>array('BETWEEN',"$start,$end"));
      $upnum=M('recordset')->where($upmap)->count();      
      $this->ajaxReturn(array('cpnum'=>$cpnum,'salenum'=>$salenum,'upnum'=>$upnum));
    }
    public function product(){
        $token = $_GET["token"];
        $db=M();
        $sql='select id, name, token from tp_product where token = "'.$token.'"';
        $res=$db->query($sql);
        $this->assign('product',$res);


        $this->display();
    }

    public function floorcount(){
        //$cus=M('Wa_dorm')->select();
       $cus=M('Wxuser')->order('id desc')->select();
      
       $this->assign('cus',$cus);
       $this->assign('floor',$floor);
        if($_POST){
           $token=$_POST['cus'];
           $floorid=$_POST['floorid'];
           $where=array(
             'Ftoken'=>$token,
             'Ffloorid'=>$floorid
            );
          if(!empty($_POST['start'])){
            $where['Fordertime']=array('gt',strtotime(trim($_POST['start'])));
          }
          if(!empty($_POST['end'])){
            $where['Fordertime']=array('lt',strtotime(trim($_POST['end'])));
          }
          $where['Fstatus']=3;

           $cont=M('Wa_orders')->field('COUNT(Fid) AS count')->where($where)->find();
          $floor=M('Wa_dorm')->where(array('Ftoken'=>$token))->select();
          $this->assign('floor', $floor);
          $this->assign('token',$token);
          $this->assign('f',$floorid);
          $this->assign('cont',$cont['count']);
        }
       $this->display();
    }


    public function floor(){
        $token=$_GET['token'];
     
         $floor=M('Wa_dorm')->where(array('Ftoken'=>$token))->select();

         $this->assign('floor',$floor);
        $this->display();

    }


// 列出水站会员列表
    public function message(){
        // 查询水站列表

       $cus=M('Wxuser')->select();
       $db=M('Wa_users');
// post提交数据查询列表
       if($_POST['nums']!='-1'){
                $nums=$_POST['nums'];
                $this->assign('nums',$nums);
                if($nums=='10'){
                    $where['Fordernum']=array('lt','10');
                }elseif($nums=='1'){
                    $where['Fordernum']=array('lt','1');
                }else{
                     $where['Fordernum']=array('gt','10');
                }
             }

       if(!empty($_POST['cus']) && $_POST['cus']!='-1'){
           $where['Ftoken']=$_POST['cus'];
        // $where['Ftoken']='gkkziy1447122160';
           $count=$db->where($where)->count();
           $page=new Page($count,100);
           $page->listRows=50;
           $res=$db->where($where)->limit($page->firstRow.','.$page->listRows)->select();
           $this->assign('token',$_POST['cus']);
           $this->assign('list',$res);
           $this->assign('page',$page->show());
       }

// get获取
       if(!empty($_GET['token'])){
            $wh['Ftoken']=$_GET['token'];
           $count=$db->where($wh)->count();
           $page=new Page($count,100);
           $page->listRows=50;
           $res=$db->where($wh)->limit($page->firstRow.','.$page->listRows)->select();
           $this->assign('token',$_GET['token']);
           $this->assign('list',$res);
           $this->assign('page',$page->show());
       }
      if(isset($nums)){
        $liat=$nums;
      }else{
        $liat='-1';
      }

       $this->assign('liat',$liat);
       $this->assign('cus',$cus);

       $this->display();
    }




// 加载用户下单记录
public function orderlist(){
    $phone=$_GET['phone'];
    $token=$_GET['token'];
    if(!empty($phone)&& !empty($token)){
        $where['Fuser']=$phone;
        $where['Ftoken']=$token;
        $count=M('Wa_orders')->where($where)->count();
        $page=new Page($count,10);

        $list=M('Wa_orders')->where($where)->order("Fid desc")->limit($page->firstRow.','.$page->listRows)->select();
        $this->assign('page',$page->show());
        $this->assign('list',$list);
         $this->assign('token',$token);
    }
     $this->display();
   }
}
?>
