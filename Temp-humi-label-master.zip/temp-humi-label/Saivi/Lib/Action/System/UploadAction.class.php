<?php
/**
 * 商品库管理
 */
header("Access-Control-Allow-Origin: *");
class UploadAction extends BackAction{
	 public function _initialize(){
		echo "";
           }
     public function upload(){
        //获得图片路径
        $filename=$_FILES['img'];


        $savepath='uploads/goods/';
        $imgurl = self::uploadimg($savepath,$filename);
        //需要添加的数据
        $saveurl='http://'.$_SERVER['HTTP_HOST'].'/'.$imgurl;
        $result=array(
                "path"=>$saveurl
                );
       $this->ajaxReturn($saveurl);

    }
    public function uploadimg($savepath,$filename){
        $upload = new UploadFile();// 实例化上传类
	    $upload->maxSize = 2097152 ;// 设置附件上传大小
	    $upload->exts    = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
	    $upload->rootPath= ''; // 设置附件上传根目录
	    $upload->savePath= $savepath; // 设置附件上传（子）目录
	    // 上传文件 
	    $info = $upload->uploadOne($filename);
	    //var_dump($info);exit;
	    if(!$info) {// 上传错误提示错误信息
	      echo $upload->getErrorMsg();
	    }else{// 上传成功
	        //$this->success('上传成功！');
	       return $imgurl=$info[0]['savepath'].$info[0]['savename'];	        
	    }
    }

}