<?php
/**
 *项目公共配置
 *@package Jhcms
 *@author Jhcms
 **/
return array(
	'LOAD_EXT_CONFIG' 		=> 'db,info,email,safe,upfile,cache,route,app,alipay,sms,rippleos_key',		
	'APP_AUTOLOAD_PATH'     =>'@.ORG',
	'OUTPUT_ENCODE'         =>  true, 			//页面压缩输出
	'PAGE_NUM'				=> 15,
	/*Cookie配置*/
	'COOKIE_PATH'           => '/',     		// Cookie路径
    'COOKIE_PREFIX'         => '',      		// Cookie前缀 避免冲突
	/*定义模版标签*/
	'TMPL_L_DELIM'   		=>'{Saivi:',			//模板引擎普通标签开始标记
	'TMPL_R_DELIM'			=>'}',				//模板引擎普通标签结束标记
	 'my_url'			=>'www.eyuanonline.com:8010',
	 //'my_url'			=>'114.215.100.254',
	 //'my_url'			=>'http://www.eyuanonline.com:8010/store.php',

	 'my_api'=>'http://www.eyuanonline.com:3000/water/',
	 // add by shitao 20171225
	 // 'AUTOLOAD_NAMESPACE' => array(
		//     'EasyWeChat'     => APP_PATH.'EasyWeChat',
		// )

     //'my_api'=>'api.fangweihao.com:3000/water/',
    'DATA_CACHE_PREFIX' => 'Redis_',//缓存前缀  
    'DATA_CACHE_TYPE'=>'Redis',//默认动态缓存为Redis  
    'REDIS_RW_SEPARATE' => true, //Redis读写分离 true 开启  
    'REDIS_HOST'=>'112.74.169.41', //redis服务器ip，多台用逗号隔开；读写分离开启时，第一台负责写，其它[随机]负责读；  
    'REDIS_PORT'=>'6379',//端口号
    'REDIS_TIMEOUT'=>'300',//超时时间  
    'REDIS_PERSISTENT'=>false,//是否长连接 false=短连接  
    'REDIS_AUTH'=>'',//AUTH认证密码
);
?>
