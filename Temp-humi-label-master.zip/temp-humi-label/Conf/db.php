<?php
return array (
  'DB_TYPE' => 'mysql',
  'DB_HOST' => '127.0.0.1',
  'DB_PORT' => '3306',
  'DB_NAME' => 'iot',
  'DB_USER' => 'root',
  'DB_PWD' => 'root123',
  'DB_PREFIX' => 'tp_',
  'DB_CHARSET' => 'utf8',
  'agent_version' => 1,
);
?>
