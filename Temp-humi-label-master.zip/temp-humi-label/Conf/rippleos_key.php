<?php 
return array (
  'rptk_node_api_id' => '7b99437b5df1a229',
  'rptk_node_api_key' => '267513fae725a910fd5dc1e51a8113de',
  'rptk_wx_auth_api_id' => 'kKANWdYI',
  'rptk_wx_auth_api_key' => 'pTFoXLYVPWilLwqE',
);