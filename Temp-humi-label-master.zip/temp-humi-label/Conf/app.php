<?php
return array(
	'qq'=>array(
		'id' => '100370896',
        'secret' => '13b058d3bae990a019c24bc0ae774166',
	),
	'sina'=>array(
		'id' => '2070871330',
		'secret' => '0f6a1170ed3fd5a8c8dc595884281108',
	),
	'tweibo'=>array(
		'id' => '801312217',
        'secret' => 'e2a3c79826953b70ebab48784bcdd6c2',
	),
	'baidu'=>array(
		'id' => 'ptHojgnRNf8vXnH4koFFMbcy',
        'secret' => 'kvPBt1z9wIBM4ffu2n3Nim2GBVMT6igW',
	),
	'360'=>array(
		'id' => '9f27bc91bbe042f6750cf4a5171190b1',
        'secret' => '3afe24e21595de9ef0ae4c626d48e058',
	),
	'163'=>array(
		'id' => 'yKaDegptKluarca0',
        'secret' => '1ktimIzcJVUhEbB8Ss7OI0iJwj2imoIr',
	),
	'sohu'=>array(
		'id' => 'npXD5HCSYrCPdLk53QNq',
        'secret' => '5j5Ttq8Nq)Uspp7rr!lyFOpISqE$6JSP%f9BX04x',
	),
	'douban'=>array(
		'id' => '06807208f9e50c451381561aedaf24cf',
        'secret' => 'f85e05ce208e75ab',
	),
	'taobao'=>array(
		'id' => '21384541',
        'secret' => '4d273b331d74168564d8fc9ded45e058',
	),
	'tianyi'=>array(
		'id' => 'dummy_id',
        'secret' => 'dummy_secret',
	),
	'renren'=>array(
		'id' => '86d5c22ab0594f1ab5a86ac9b1f888be',
        'secret' => '149ff08caa564503b0f9f12b7eb7a86b',
	),
	'10086'=>array(
		'id' => '0ed01c59e5e229ea1788e75199a89283',
        'secret' => '16e29aab31bf9a55aaa5022ca173d187',
	),
	'feixin'=>array(
		'id' => 'nokey',
        'secret' => 'nosecret',
	),
	'kaixin'=>array(
		'id' => 'nokey',
        'secret' => 'nosecret',
	),
	'duoshuo'=>array(
		'id' => 'dummy_id',
        'secret' => 'dymmy_secret',
	),
);