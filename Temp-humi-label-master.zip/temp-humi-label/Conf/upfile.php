<?php 
return array (
  'upload_type' => 'local',
  'up_bucket' => '',
  'up_form_api_secret' => '',
  'up_username' => '185951958@qq.com',
  'up_password' => '123456qazc',
  'up_domainname' => '',
  'up_exts' => 'jpeg,jpg,png,mp3,gif.php',
  'up_size' => '2048',
  'up_path' => './upload',
  'connectnum' => '系统维护中',
);