<?php if (!defined('THINK_PATH')) exit(); if(strpos($_SERVER['HTTP_USER_AGENT'], 'Mobile')==false){ ?>

<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
<title>友情提示</title> 
<meta name="viewport" content="width=device-width,height=device-height,inital-scale=1.0,maximum-scale=1.0,user-scalable=no;">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="format-detection" content="telephone=no">
<meta charset="utf-8">
<link href="/tpl/static/tip.css" rel="stylesheet" type="text/css">
</head> 
<body>
	<div class="errorbg"><img src="/tpl/static/tip2.jpg"></div>
	<div class="tu">
        <img src="<?php if(isset($message)): ?>/tpl/static/success.png<?php else: ?>/tpl/static/error.png<?php endif; ?>">
        <div class="msg" style="margin-top:15px">
            <?php if(isset($message)): echo($message); else: echo($error); endif; ?>
        </div>
        <div class="msg" style="color:#999999;font-size:12px;margin-top: 50px">
            <span id="wait"><?php echo($waitSecond); ?></span>秒后自动跳转<a id="href" style="display:block; color:red" href="<?php echo($jumpUrl); ?>">点击手动跳转</a>
        </div>
    </div>
<script type="text/javascript">

(function(){
var wait = document.getElementById('wait'),href = document.getElementById('href').href;
var interval = setInterval(function(){
	var time = --wait.innerHTML;
	if(time == 0) {
		location.href = href;
		clearInterval(interval);
	};
}, 1000);
})();

</script>
</body></html>

<?php }else{ ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,height=device-height, user-scalable=no,initial-scale=1, minimum-scale=1, maximum-scale=1">
<title>友情提示</title>
<link rel=" stylesheet" type="text/css" href="css/css_home_my.css" />
</head>
<body style="max-width: 700px;margin: auto;">
    <img style="width:100%;" src="/tpl/static/tip.png"/>
    <img style="width:60%; margin-left:20%;" src="<?php if(isset($message)): ?>/tpl/static/success.png<?php else: ?>/tpl/static/error.png<?php endif; ?>"/>
    <div style="width:100%; height:30px; line-height:30px; text-align:center; font-size:30px; color:#f00; margin-top:20px;">"&nbsp;<?php if(isset($message)): echo($message); else: echo($error); endif; ?>&nbsp;"</div>

    <div style="display: none">
        <div class="msg" style="margin-top:15px">
            <?php if(isset($message)): echo($message); else: echo($error); endif; ?>
        </div>
        <div class="msg" style="color:#999999;font-size:12px"><span id="wait"><?php echo($waitSecond); ?></span>秒后自动跳转<a id="href" style="display:block; color:red" href="<?php echo($jumpUrl); ?>">点击手动跳转</a>
        </div>
    </div>

</body>
<script type="text/javascript">
    var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
    if (/Android (\d+\.\d+)/.test(ua)){
        var version = parseFloat(RegExp.$1);
        if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
        }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
    } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}

    (function(){
    var wait = document.getElementById('wait'),href = document.getElementById('href').href;
    var interval = setInterval(function(){
        var time = --wait.innerHTML;
        if(time == 0) {
            location.href = href;
            clearInterval(interval);
        };
    }, 1000);
    })();
</script>

</html>

<?php } ?>