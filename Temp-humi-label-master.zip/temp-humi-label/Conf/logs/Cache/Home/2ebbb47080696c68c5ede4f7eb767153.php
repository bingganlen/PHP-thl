<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/css_home_pc.css"/>
<title>智能物联管理系统</title>
<!-- <link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/themes/default/default.css" /> -->
<!-- <script src="<?php echo STATICS;?>/kindeditor/lang/zh_CN.js" type="text/javascript"></script> -->
<script type="text/javascript" src="<?php echo RES;?>/js/jquery-1.10.1.min.js"></script>
<script src="/tpl/static/echart/dist/echarts.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/shop_guan_li_info_sz.css"/>
</head>
<body>
  <div class="cj_header">
  <img class="logo_size" src="img/logo1.png" alt="logo"/><span class="logo_font">智能物联网管理系统</span>    
</div>
<div class="tk"><div class="tmap" id="container"></div><img src="img/gb.png" id="close"></div>
<div class="jscgl_nr" style="height:660px">
  <div class="jtjb2">上传记录信息  
    
    <input class="jlogo_sc_sc b_b" type="button" value="返回上一级" onClick="javascript:history.back()"/>  
    <span class="btn" id="pdffile">pdf加载中<b>4</b>秒</span>    
  </div>
  <div style="width:50%;float: left">
    <div class="jscmc">标签编号：<span><?php echo ($list["labelId"]); ?></span></div>
    <!-- <div class="jscmc">上传账号：<span><?php echo ($list["username"]); ?></span></div>  -->
    <div class="jscmc">标签类型：<span><?php echo ($list["labelType"]); ?></span></div>
    <div class="jscmc">上传定位：<span id="addr"><?php echo ($list["uploadAddr"]); ?></span><span class="btn" style="display: inline-block;" onclick="loadmap(<?php echo ($list["latitude"]); ?>,<?php echo ($list["longitude"]); ?>)">查看地图</span></div>
    <div class="jscmc">APP版本：<span><?php echo ($list["appVersion"]); ?></span></div>
    <div class="jscmc">闪存容量：<span><?php echo ($list["flashCapacity"]); ?></span></div>
    <div class="jscmc">帧 容 量：<span><?php echo ($list["frameCapacity"]); ?></span></div>
    <div class="jscmc">硬件版本：<span><?php echo ($list["hardwareVersion"]); ?></span></div>
    <div class="jscmc">固件版本：<span><?php echo ($list["remoteFirmware"]); ?></span></div>
    <div class="jscmc">STC 版本：<span><?php echo ($list["stcFirmware"]); ?></span></div>
    <div class="jscmc">传输速度：<span><?php echo ($list["transmitVelocity"]); ?></span></div>
    <div class="jscmc">工作状态：<span><?php if($list["workStatus"] > 2): ?>正常<?php else: ?>测试<?php endif; ?></span></div>
    <div class="jscmc">剩余电压：<span><?php echo ($list["dumpEnergy"]); ?></span></div>
  </div>
  <div> 
    <div class="jscmc">湿度高于上限时长：<span><?php echo ($list["cumHumMax"]); ?>分钟</span></div>
    <div class="jscmc">湿度低于下限时长：<span><?php echo ($list["cumHumMin"]); ?>分钟</span></div>
    <div class="jscmc">温度高于上限时长：<span><?php echo ($list["cumTemMax"]); ?>分钟</span></div>
    <div class="jscmc">温度低于下限时长：<span><?php echo ($list["cumTemMin"]); ?>分钟</span></div>
    <div class="jscmc">采样起始时间：<span><?php echo (date("Y-m-d H:i:s",$list["startDate"])); ?></span></div>
    <div class="jscmc">采样终止时间：<span><?php echo (date("Y-m-d H:i:s",$list["endDate"])); ?></span></div>
    <div class="jscmc">最大湿度：<span><?php echo ($list["humMax"]); ?> %</span></div>
    <div class="jscmc">最小湿度：<span><?php echo ($list["humMin"]); ?> %</span></div>
    <div class="jscmc">最大温度：<span><?php echo ($list["tempMax"]); ?> ℃</span></div>
    <div class="jscmc">最小温度：<span><?php echo ($list["tempMin"]); ?> ℃</span></div>
    <div class="jscmc">采样时长：<span><?php echo ($list["humTime"]); ?></span></div>
    <div class="jscmc">是否报警：<span><?php if($list["isover"] < 1): ?>无<?php elseif($list["isover"] == 1): ?>有<?php else: ?>已处理<?php endif; ?></span></div>
    <div class="jscmc">上传时间：<span><?php echo (date("Y-m-d H:i:s",$list["uptime"])); ?></span></div>
  </div>
</div>
<div id="main" style="width:84%;margin-left:8%;height:300px;margin-top:50px"></div>
<script type="text/javascript" src="http://api.map.baidu.com/api?v=1.3"></script>
<script type="text/javascript">
  $(document).ready(function(){     
        var echartx=<?php echo ($echart); ?>;    
        var markline=<?php echo ($markline); ?>;       
    //console.log(markline['humLowLimit']);
    var time=[];
    var temps=[];
    var hums=[];
    $.each(echartx,function(index,item){
        //console.log(timeFormat(parseInt(item.time)*1000));        
        time.push(timeFormat(parseInt(item.time)*1000));
        temps.push(item.temps);
        hums.push(item.hums);
    })
    
    var mltdata=[];
    var mlhdata=[];
    mltdata.push([{name:'温度下限:'+markline['temLowLimit'],yAxis:markline['temLowLimit'],xAxis:time[0]},{yAxis:markline['temLowLimit'],xAxis:time[time.length-1]}],[{name:'湿度上限:'+markline['temUpLimit'],yAxis:markline['temUpLimit'],xAxis:time[0]},{yAxis:markline['temUpLimit'],xAxis:time[time.length-1]}]);
    mlhdata.push([{name:'湿度下限:'+markline['humLowLimit'],yAxis:markline['humLowLimit'],xAxis:time[0]},{yAxis:markline['humLowLimit'],xAxis:time[time.length-1]}],[{name:'湿度上限:'+markline['humUpLimit'],yAxis:markline['humUpLimit'],xAxis:time[0]},{yAxis:markline['humUpLimit'],xAxis:time[time.length-1]}]);
    //console.log(mlhdata[0]);
    require.config({
        paths: {
            echarts: '/tpl/static/echart/dist'
        }
    });
    
    // Step:4 require echarts and use it in the callback.
    // Step:4 动态加载echarts然后在回调函数中开始使用，注意保持按需加载结构定义图表路径
    require(
        [
            'echarts', 
            'echarts/chart/bar',
            'echarts/chart/line'
        ],
        function (ec) {
            var myChart = ec.init(document.getElementById('main'));
            var ecConfig = require('echarts/config');
            
            var option = {
                
                title : {
                        text: '标签数据',
                        subtext: '<?php echo ($labelid); ?>'
                    },
                tooltip : {
                    trigger: 'axis'
                },
                dataZoom:[{type:'slider',start:0,end:100},
                          {type:'inside',start:0,end:100}
                ],
                legend: {
                    data:['温度','湿度']
                },
                toolbox: {
                    show : true,
                    feature : {                        
                        saveAsImage : {show: true}
                    }
                },
                xAxis: [{
                        type : 'category',                        
                        data :time              
                    }],
                yAxis: [
                {
                        type : 'value',
                        splitArea : {show : true}
                    }],
                series: [
                    {
                        name:'温度',
                        type:'line',                        
                        data:temps,
                        markLine:{
                            itemStyle:{
                              normal:{
                                type:'dash',width:2
                              },
                              label:{
                                formatter:'温度限值',
                                textStyle:{fontSize:16}
                              }
                            },
                            data:mltdata        
                        }
                        
                    },
                    {
                        name:'湿度',
                        type:'line',                        
                        data:hums,
                        markLine:{
                            itemStyle:{
                              normal:{
                                type:'dash',width:2
                              },
                              label:{
                                formatter:'温度限值',
                                textStyle:{fontSize:16}
                              }
                            },                   
                            data:mlhdata                   
                        }                                       
                    },                    
                    ],                
            };
            myChart.setOption(option,true);
            setTimeout(function(){
            var picinfo=myChart.getDataURL();
            //console.log(picinfo);
            if(picinfo){
             $.ajax({
                type:"post",
                data:{'baseimg':picinfo},
                url:"<?php echo U('Index/pdf_file');?>",
                success:function(data){
                    console.log(data);
                },
                error:function(err){
                    console.log('图片保存失败');
                }
              })
            }else{
                alert('图片获取失败');
            }
            },3000);
            
        }
        ); 
    
    function destime(val,sec){
        if(sec<=0){
            val.html("<a href=\"<?php echo U('Index/pdf_file',array('id'=>$list['id']));?>\">pdf文件下载</a>");
        }else{
            sec--;
            val.find("b").html(sec);            
        }
    }
    var intid=setInterval(function(){
        var secin=$("#pdffile").find("b").html();
        
        if(secin && parseInt(secin)>=0){
            destime($("#pdffile"),secin);
        }else{
            window.clearInterval(intid);
        }
    },1000);
})   
    function loadmap(lat,lon){
        var addr=$("#addr").html();
        $(".tk").show();
        $(".tmap").show();        
      var map = new BMap.Map("container");
      var point = new BMap.Point(lon,lat);      
      var marker= new BMap.Marker(point);
      var opts={width:25,height:55,title:"上传所在地点：<hr />"}
      var infoWindow = new BMap.InfoWindow(addr,opts);
      marker.enableDragging();//启用拖拽事件
      map.addControl(new BMap.NavigationControl());
      map.enableScrollWheelZoom();
      map.enableKeyboard();
      map.centerAndZoom(point, 13);//绘制地图
      map.addOverlay(marker);
      map.openInfoWindow(infoWindow, map.getCenter());      
    }
    $("#close").click(function(){
      $(".tk").hide();
      $(".tmap").hide();  
    })
    function add0(m){return m<10?'0'+m:m }
    function timeFormat(timestamp){
            var time = new Date(timestamp);
            var year = time.getFullYear();
            var month = time.getMonth()+1;
            var date = time.getDate();
            var hours = time.getHours();
            var minutes = time.getMinutes();
            var seconds = time.getSeconds();
            var str=year+""+add0(month)+""+add0(date)+"/"+add0(hours)+":"+add0(minutes)+":"+add0(seconds);
            return str;
        }
</script>
<div class="d_public_e">Copyright © 2018 www.megian.com &nbsp;All Rights Reserved</div>
</body>
</html>