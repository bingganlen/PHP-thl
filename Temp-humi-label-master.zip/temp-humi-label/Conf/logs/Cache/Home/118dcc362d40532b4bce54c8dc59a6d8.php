<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/css_home_pc.css"/>
<title>智能物联管理系统</title>
<!-- <link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/themes/default/default.css" /> -->
<!-- <script src="<?php echo STATICS;?>/kindeditor/lang/zh_CN.js" type="text/javascript"></script> -->
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/shop_guan_li_info_sz.css"/>
</head>
<body>
  <div class="cj_header">
  <img class="logo_size" src="img/logo1.png" alt="logo"/><span class="logo_font">智能物联网管理系统</span>    
</div>
<div class="jscgl_nr" style="height:500px">
  <div class="jtjb2">配置信息  
    <input class="jlogo_sc_sc b_b" type="button" value="返回上一级" onClick="javascript:history.back()"/>
    <a href="<?php echo U('Index/exportcsv',array('cid'=>$list['id']));?>"><span class="btn">导出数据csv</span></a>  
  </div>
  <div style="width:50%;float: left">
    <div class="jscmc">标签编号：<span><?php echo ($list["labelId"]); ?></span></div>
    <div class="jscmc">上传账号：<span><?php echo ($list["username"]); ?></span></div> 
    <div class="jscmc">货物名称：<span><?php echo ($list["article"]); ?></span></div>
    <div class="jscmc">货物单号：<span><?php echo ($list["barCode"]); ?></span></div>
    <div class="jscmc">公司名称：<span><?php echo ($list["company"]); ?></span></div>
    <div class="jscmc">配 置 人：<span><?php echo ($list["configBy"]); ?></span></div>
    <div class="jscmc">订单时间：<span><?php echo (date("Y-m-d H:i:s",$list["deliveryTime"])); ?></span></div>
    <div class="jscmc">发货地址：<span><?php echo ($list["shippingAddr"]); ?></span></div>
    <div class="jscmc">收货地址：<span><?php echo ($list["shipTo"]); ?></span></div>
  </div>
  <div> 
    <div class="jscmc">采样间隔：<span><?php echo ($list["frequency"]); ?>分钟</span></div>
    <div class="jscmc">采集湿度：<span><?php if($list["humNeed"] > 0): ?>是<?php else: ?>否<?php endif; ?></span></div>    
    <div class="jscmc">延迟启动：<span><?php echo ($list["startDelay"]); ?>分钟</span></div>
    <div class="jscmc">湿度上限：<span><?php echo ($list["humUpLimit"]); ?> %</span></div>
    <div class="jscmc">湿度下限：<span><?php echo ($list["humLowLimit"]); ?> %</span></div>
    <div class="jscmc">温度上限：<span><?php echo ($list["temUpLimit"]); ?> ℃</span></div>
    <div class="jscmc">温度下限：<span><?php echo ($list["temLowLimit"]); ?> ℃</span></div>
    <div class="jscmc">备注信息：<span><?php echo ($list["remark"]); ?></span></div>
  </div>
</div>
<div class="d_public_e">Copyright © 2018 www.megian.com &nbsp;All Rights Reserved</div>
</body>
</html>