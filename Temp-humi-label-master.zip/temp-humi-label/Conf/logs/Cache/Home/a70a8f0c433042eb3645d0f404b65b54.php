<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>登陆</title>

<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/css_home_pc.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/new_login.css"/>

<script type="text/javascript" src="<?php echo RES;?>/js/jquery-1.10.1.min.js"></script>
<script language="javascript" type="text/javascript">                            
function sendMsg(){
    var num = document.getElementById('sms_mp').value;
        //var reg=/^0{0,1}(13[0-9]|145|15[0-9]|18[0-9])[0-9]{8}$/i;
    var reg=/^0{0,1}(13[0-9]|14[0-9]|16[0-9]|17[0-9]|15[0-9]|18[0-9])[0-9]{8}$/i;
        if( num == '' || !reg.test(num)){
            alert('请输入正确的手机号！');
            return false;
        }

       if (confirm("我们会将会发送验证码到 "+num)){
            jQuery(function($) {
                $.ajax({
                    url:"<?php echo U('Users/test');?>",
                    type:"post",
                    data:"sms_mp="+num,
                    success:function(data){
                        $("#a_verify").css({"background":"#ccc","borderColor":"#ccc"});
                        fun_timedown(60);
                      }
                });
            });
        }
    }

function fun_timedown(time){
    if(time=='undefined'){
        time = 60;
    }

    $("#a_verify").html(time+"秒后可重新获取");
    
    time = time-1;
    if(time>=0){
        setTimeout("fun_timedown("+time+")",1000);
    }else{
        $("#a_verify").css({"background":"#fff","borderColor":"#007DDB"});
        $("#a_verify").html('<a href="javascript:sendMsg();" id="Button1" >获取验证码</a>');
    }
}
</script>
</head>
<body style="">
  <img class="bg_katong" src="<?php echo RES;?>/images/img/login_bg.jpg" style=""/>  
    <!-- <div class="gif">
      <img class="logo_dl" src="<?php echo RES;?>/images/img/dl_logo.png"/>
      <img src="<?php echo RES;?>/images/img/a1.gif"/>
    </div> -->
    <!-- <div class="middle_top"></div> -->
    <!--<div class="middle_k" >
         <form action="<?php echo U('Users/checkreg');?>"  onsubmit="return onpost()"  name="register" method="post">
            <input name="step" value="2" type="hidden"/>
            <input name="invite" value="" type="hidden"/>
           <div class="r_b">
              <img src="<?php echo RES;?>/images/img/dl.png"/>
            </div> 
        <div class="dl_ne_r">
            <div class="zcmc" style="margin-top:40px;">
                &nbsp;&nbsp;用&nbsp;&nbsp;&nbsp;&nbsp;户&nbsp;&nbsp;&nbsp;&nbsp;名&nbsp;:&nbsp;&nbsp;
                <input class="zpmc_sr" type="text" placeholder="&nbsp;&nbsp;字母、数字或者英文符号" name="username"/>
             </div>
             <div class="tu_ts">&nbsp;&nbsp;</div>
             <div class="zcmc" style="margin-top:5px;">
                &nbsp;&nbsp;密&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;码&nbsp;:&nbsp;&nbsp;
                <input class="zpmc_sr" type="password" placeholder="&nbsp;&nbsp;长度为6~16位字符" name="password" id="password"/>
             </div>
             <div class="tu_ts">&nbsp;&nbsp;</div>
             <div class="zcmc" style="margin-top:5px;">
                &nbsp;&nbsp;确&nbsp;&nbsp;认&nbsp;&nbsp;密&nbsp;&nbsp;码&nbsp;:
                <input class="zpmc_sr" type="password" name="repassword" id="repassword"/>
             </div>
             <div class="zcmc">
                &nbsp;&nbsp;手&nbsp;&nbsp;机&nbsp;&nbsp;号&nbsp;&nbsp;码&nbsp;:
                <input class="zpmc_sr" type="text" name="sms_mp" id="sms_mp"/>
             </div>
             <div class="zcmc">
                &nbsp;&nbsp;手&nbsp;机&nbsp;验&nbsp;证&nbsp;码:
                <input class="logo_sc b_b" type="button" value="获取手机验证码" name="verifyMP" onclick="javascript:sendMsg();"/>
                 <input class="zpmc_sr" style="width:180px; vertical-align: middle;" type="text" id="a_verify" name="verifyMP"/>
                
             </div>
             <input class="dl_sp_anniu g_b" type="submit" style=" margin-left:144px;margin-top:30px;" value="注&nbsp;&nbsp;册" id="regirest"/>
        </div>
        </form>

    </div>-->
    
    <div class="middle_k2">
        <img src="<?php echo RES;?>/images/img/login_box.png" width="100%" height="330px" id="box_bg"/>
      <div class="r_b2"><p style="float: left;" id="loginbtn"></p><p style="float: right;" id="srchbtn"></p></div>
        <!-- <div class="togbtns"></div> -->  
        
        <!-- 登陆框 -->
        <div class="dl_ne_l" id="loginform">
             <form action="<?php echo U('Users/checklogin');?>" method="post" name="login">
                <div class="scmc">
                    <span>用&nbsp;户&nbsp;名&nbsp;:&nbsp;&nbsp;</span>
                     <input class="spmc_sr" type="text" name="username" value="<?php echo ($_COOKIE['adminname']); ?>" />
                 </div>
                 <div class="scmc" style="margin-top:36px;">
                    <span>密&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;码&nbsp;:&nbsp;&nbsp;</span>
                     <input class="spmc_sr" type="password" name="password" value="<?php echo ($_COOKIE['adminpw']); ?>" />
                 </div>
                 <input class="dl_sp_anniu g_b" type="submit" value="登&nbsp;&nbsp;录" />
                 <span class="wjmm" style="display:none;">忘记密码?</span>
             </form>
        </div>
        <!-- 查询框 -->
        <div class="dl_ne_l" id="srchform" style="display: none">
             <form action="<?php echo U('Users/');?>" method="post">
                <div class="scmc">
                    <span>标&nbsp;签&nbsp;ID&nbsp;:&nbsp;&nbsp;</span>
                     <input class="spmc_sr" type="text" name="labelid" value="" />
                 </div>
                 <div class="scmc" style="margin-top:36px;">
                    <span>运&nbsp;单&nbsp;号&nbsp;:&nbsp;&nbsp;</span>
                     <input class="spmc_sr" type="text" name="deliveryid" value="" />
                 </div>
                 <input class="dl_sp_anniu g_b" type="button" id="srchsubmit" value="查&nbsp;&nbsp;询" />                 
             </form>
        </div>
    </div>
    <!-- <div class="middle_bot"></div>
    <a target="_blank" href="http://www.miitbeian.gov.cn"><p class="copyright">
          © 2014-2017 版权所有 沪ICP备16008729号-1
        </p></a> -->
</body>
<script>

$(document).ready(function(){
  $("#repassword").change(function(){
    value1=$("#password").val();
    value2=$("#repassword").val();
    if (value1 != value2){
        alert("2次密码输入不一致！");
    }
})
//切换
  $("#loginbtn").click(function(){
    $("#box_bg").attr('src','<?php echo RES;?>/images/img/login_box.png');
    $("#srchform").hide();
    $("#loginform").show();    
    })    
  $("#srchbtn").click(function(){
    $("#box_bg").attr('src','<?php echo RES;?>/images/img/search_box.png');   
    $("#loginform").hide();
    $("#srchform").show();
    })  

})
$("#srchsubmit").click(function(){
    var lbid=$("input[name='labelid']").val();
    var delivid=$("input[name='deliveryid']").val();
    if(!lbid || !delivid){
        alert("标签号和运单号必须填写");
        return false;
    }
    
    $.ajax({
       url:"<?php echo U('Users/searchlb');?>",
       data:{'labelid':lbid,'deliveryid':delivid},
       type:'post',
       success:function(res){
           console.log(res);
           if(res>0){
            var confid=res;            
            window.location.href="<?php echo U('Index/search_detail');?>&id="+confid;
           }else{
            alert(res);
           }

       },
       error:function(err){
        alert(err);
       }
    })
})
</script>
</html>