<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>智能物联网管理系统</title>
    <meta name="keywords" content="<?php echo ($f_siteName); ?>-Saivi后台管理系统" />
    <meta name="description" content="<?php echo ($f_siteName); ?>-Saivi后台管理系统" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />    
    
    <link href="<?php echo RES;?>/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo RES;?>/css/bootstrap-responsive.min.css" rel="stylesheet" />
    
    <link href="<?php echo RES;?>/css/font-awesome.css" rel="stylesheet" />
    
    <link href="<?php echo RES;?>/css/adminia.css" rel="stylesheet" /> 
    <link href="<?php echo RES;?>/css/adminia-responsive.css" rel="stylesheet" /> 
    
    <link href="<?php echo RES;?>/css/pages/dashboard.css" rel="stylesheet" /> 
    <link href="<?php echo RES;?>/css/pages/faq.css" rel="stylesheet" />

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="<?php echo RES;?>/js/html5.js"></script>
    <![endif]-->
	<script src="<?php echo RES;?>/js/jquery-1.7.2.min.js"></script>
	<!-- <script src="<?php echo STATICS;?>/kindeditor/kindeditor.js"></script>
	<script src="<?php echo STATICS;?>/kindeditor/lang/zh_CN.js"></script>
	<script src="<?php echo STATICS;?>/kindeditor/plugins/code/prettify.js"></script>
	<link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/themes/default/default.css" />
	<link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/plugins/code/prettify.css" />  -->
    <!--日期-->
    <link rel="stylesheet" type="text/css" href="./tpl/static/date/hDate.css"/>
    <script type="text/javascript" src="./tpl/static/date/hDate.js"></script>

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- <script type="text/javascript">
	$(function(){

		var str = $(".widget-header h3").html();
		// alert(str.indexOf("&gt;"));
		var hstr = $.trim(str.substr(0, str.indexOf("&gt;")));
		var num = '';
		if(hstr == "站点设置")
			num = '1';
		else if(hstr == '用户管理')
			num = '2';
		else if(hstr == '内容管理')
			num = '3';
		else if(hstr == '公众号管理')
			num = '4';
		else if(hstr == '功能管理')
			num = '5'
		else if(hstr == '扩展管理')
			num = '6';

		var current = '#collapse' + num;
		$(current).css('height','auto').removeClass('collapse').addClass('in');

	})
</script> -->
</head>

<body>
	
<div class="navbar">
	
	<!-- <div class="navbar-inner"> -->
		
		<div class="container">
			
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> 
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span> 				
			</a>
			
			<a class="brand" href="<?php echo U('System/Water/total');?>"><img src="img/megain.png" class="clogo"><img src="img/logo1.png" alt="logo" class="plogo">&nbsp;&nbsp;智能物联网管理系统</a>
			
			<div class="nav-collapse">			
				<ul class="nav pull-right">					
					<!-- <li class="divider-vertical"></li> -->
					<li class="nav_btn"><img src="img/admin.png" alt=""><span>hello ! <?php echo ($_SESSION['username']); ?></span></li>
					<li class="nav_btn">
						<a href="<?php echo U('System/Adminsaivi/logout');?>" style="padding:3px 0px 10px 10px"><img src="img/logout.png" style="height: 38px" alt="退出系统"></a>
					</li>
					<!-- <li class="dropdown">
						
						<a data-toggle="dropdown" class="dropdown-toggle " href="#">
							退出系统 <b class="caret"></b>							
						</a>
						
						<ul class="dropdown-menu">
					<li>
								<a href="./change_password.html"><i class="icon-lock"></i> 密码修改</a>
							</li>
							
							<li class="divider"></li>
							
						</ul>
					</li> -->
				</ul>
				
			</div> <!-- /nav-collapse -->
			
		</div> <!-- /container -->
		
	<!--</div> /navbar-inner  -->
	
</div> <!-- /navbar -->

<style type="text/css">
.table tr td{ vertical-align: middle;}
.search_bar p,.search_bar1 p{font-size: 16px;padding:0 20px;}  
.search_bar p span,.search_bar1 p span{margin: 0 28px}
/*.shbtn{padding:7px 50px;margin:0 10px 2px;background: #ddd;border:1px solid #ccc;color:#555;border-radius: 3px;cursor: pointer;}*/
.iput{width:160px;margin:0 6px;}
.inpbtn{margin:5px;padding:4px 10px;}
</style>
<div id="content">

    <div class="container">

        <div class="row">

            <div class="span3">
				
				<ul id="main-nav" class="nav nav-tabs nav-stacked">
                    <li class="active accordion-group" id="Water">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Water/total');?>'">
		                <i class="icon-bar-chart"></i>
		                统计信息管理
		              </a>
                      <!-- <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Water/count');?>'">
                      		                  <i class="icon-share-alt"></i>
                      		                  水站统计
                      		              </a> -->
					</li>
					<li class="active accordion-group" id="Token">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Token/index');?>'">
		                <i class="icon-user"></i>
		                企业用户管理
		              </a>
					</li>	
                    <li class="active accordion-group" id="Goods">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Goods/index');?>'">
		                <i class="icon-tag"></i>
		                标签类型管理
		              </a>
					</li>
                    <li class="active accordion-group" id="Setinfo">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Setinfo/feeset');?>'">
		                <i class="icon-cog"></i>
		                会员费用设置
		              </a>
					</li>
				</ul>			
				<br />		
			</div> <!-- /span3 -->
<script type="text/javascript">
	$(document).ready(function(){
      var ref=window.location.href;
      var mod=ref.match(/m=[a-z]*/i);
      var str=mod[0].substr(2);
      console.log(str);
      $("#"+str).removeClass("active");
})
	
</script>


            <div class="span9">

                <div class="widget widget-table">

                    <div class="widget-header">
                        <i class="icon-th-list"></i>
                        <h3>统计信息 >> 数据统计</h3>
                    </div> <!-- /widget-header -->

                    <div class="widget-content">
        <div class="search_bar">
            <p><span id="cp">入驻企业数量：<?php echo ($cpnum); ?> 家</span></p>
        </div>
        <div class="search_bar1">
            <p><span id="sale">使用的芯片数量：<?php echo ($salenum); ?> 张</span></p>
        </div>
        <div class="search_bar">
            <p><span id="up">数据上传次数：<?php echo ($upnum); ?> 次</span></p>
        </div>
        <form method="post" action="">
            <table class="table table-striped table-bordered" style="margin-top:10px;">
                <tr>
                    <td>起止时间：</td>
                    <td><input name="start" id="start" class="iput" type="text" value="<?php echo ($tjtime); ?>"  onClick="calendar.show({ id: this })">-<input name="end" id="end" class="iput" type="text" value="<?php echo ($now); ?>"  onClick="calendar.show({ id: this })">
                    <input type="button" onclick="thismonth()" value="本月" class="inpbtn">
                    <input type="button" onclick="fastsearch(6)" value="最近7天" class="inpbtn">
                    </td>
                </tr>                
                <tr>
                    <td></td>
                    <td>
                        <input type="button" onclick="search()" class="inpbtn" style="padding:4px 52px" value="查 询">
                        <input type="submit" value="导出" class="inpbtn">                                  
                    </td>
                </tr>
            </table>
       </form>

              
                    </div> <!-- /widget-content -->
              
                </div> <!-- /widget -->

            </div> <!-- /span9 -->


        </div> <!-- /row -->

    </div> <!-- /container -->

</div> <!-- /content -->
<script type="text/javascript">
    function search(){
        var start=$("#start").val();
        var end=$("#end").val();
        
    if(start!="" && end!=""){
        //alert(start+"--"+end);
        $.ajax({
            url:"<?php echo U('Water/total_search');?>",
            type:'POST',
            data:{'st':start,'end':end},
            success:function(res){
              //alert(res);
              var json=eval('('+res+')');
              $("#cp").html("入驻企业数量："+json.cpnum+"家");
              $("#sale").html("使用的芯片数量："+json.salenum+"张");
              $("#up").html("数据上传次数："+json.upnum+"次");
            }
        })
    }else{alert('起止时间不正确')}
        
    }
    //最近几天统计函数
    function fastsearch(days){
        var now=new Date();
        var day=now.toLocaleDateString();
        var nowtime=day.replace(/\//g,'-');
        var now2=new Date(now);
        now2.setDate(now.getDate()-days);
        var bfday=now2.toLocaleDateString();
        var beforetime=bfday.replace(/\//g,'-');
        $("#start").val(beforetime);
        $("#end").val(nowtime);
        search();        
    }
//本月统计函数
    function thismonth(){
        var now=new Date();
        var day=now.toLocaleDateString();
        var nowtime=day.replace(/\//g,'-');
        var monthday=now.getFullYear()+'-'+(now.getMonth()+1)+'-1';
        $("#start").val(monthday);
        $("#end").val(nowtime);
        search();
    }
</script>
<div class="navbar navbar-fixed-bottom">
	<div class="navbar-inner" style="text-align: right;color:#fff;">
	智能物联网管理系统
	</div>
</div>

<!-- <script type="text/javascript" src="https://select2.github.io/dist/js/select2.min.js"></script> -->
<!-- <link href="https://select2.github.io/dist/css/select2.min.css" type="text/css" rel="stylesheet" /> -->
<!-- <style>.select2-search__field{height:30px;}</style> -->
<!-- <script>$("select").select2();</script> -->
    

<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->

<!-- <script src="<?php echo RES;?>/js/excanvas.min.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.pie.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.orderBars.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.resize.js"></script>
<script src="<?php echo STATICS;?>/artDialog/jquery.artDialog.js?skin=default"></script>
<script src="<?php echo STATICS;?>/artDialog/plugins/iframeTools.js"></script> -->


<!-- <script src="<?php echo RES;?>/js/water.js"></script> -->
<script src="<?php echo RES;?>/js/bootstrap.js"></script>
<!-- <script src="<?php echo RES;?>/js/charts/bar.js"></script> -->
  </body>

</html>