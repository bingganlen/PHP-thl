<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>智能物联网管理系统</title>
    <meta name="keywords" content="<?php echo ($f_siteName); ?>-Saivi后台管理系统" />
    <meta name="description" content="<?php echo ($f_siteName); ?>-Saivi后台管理系统" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />    
    
    <link href="<?php echo RES;?>/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo RES;?>/css/bootstrap-responsive.min.css" rel="stylesheet" />
    
    <link href="<?php echo RES;?>/css/font-awesome.css" rel="stylesheet" />
    
    <link href="<?php echo RES;?>/css/adminia.css" rel="stylesheet" /> 
    <link href="<?php echo RES;?>/css/adminia-responsive.css" rel="stylesheet" /> 
    
    <link href="<?php echo RES;?>/css/pages/dashboard.css" rel="stylesheet" /> 
    <link href="<?php echo RES;?>/css/pages/faq.css" rel="stylesheet" />

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="<?php echo RES;?>/js/html5.js"></script>
    <![endif]-->
	<script src="<?php echo RES;?>/js/jquery-1.7.2.min.js"></script>
	<!-- <script src="<?php echo STATICS;?>/kindeditor/kindeditor.js"></script>
	<script src="<?php echo STATICS;?>/kindeditor/lang/zh_CN.js"></script>
	<script src="<?php echo STATICS;?>/kindeditor/plugins/code/prettify.js"></script>
	<link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/themes/default/default.css" />
	<link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/plugins/code/prettify.css" />  -->
    <!--日期-->
    <link rel="stylesheet" type="text/css" href="./tpl/static/date/hDate.css"/>
    <script type="text/javascript" src="./tpl/static/date/hDate.js"></script>

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- <script type="text/javascript">
	$(function(){

		var str = $(".widget-header h3").html();
		// alert(str.indexOf("&gt;"));
		var hstr = $.trim(str.substr(0, str.indexOf("&gt;")));
		var num = '';
		if(hstr == "站点设置")
			num = '1';
		else if(hstr == '用户管理')
			num = '2';
		else if(hstr == '内容管理')
			num = '3';
		else if(hstr == '公众号管理')
			num = '4';
		else if(hstr == '功能管理')
			num = '5'
		else if(hstr == '扩展管理')
			num = '6';

		var current = '#collapse' + num;
		$(current).css('height','auto').removeClass('collapse').addClass('in');

	})
</script> -->
</head>

<body>
	
<div class="navbar">
	
	<!-- <div class="navbar-inner"> -->
		
		<div class="container">
			
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> 
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span> 				
			</a>
			
			<a class="brand" href="<?php echo U('System/Water/total');?>"><img src="img/megain.png" class="clogo"><img src="img/logo1.png" alt="logo" class="plogo">&nbsp;&nbsp;智能物联网管理系统</a>
			
			<div class="nav-collapse">			
				<ul class="nav pull-right">					
					<!-- <li class="divider-vertical"></li> -->
					<li class="nav_btn"><img src="img/admin.png" alt=""><span>hello ! <?php echo ($_SESSION['username']); ?></span></li>
					<li class="nav_btn">
						<a href="<?php echo U('System/Adminsaivi/logout');?>" style="padding:3px 0px 10px 10px"><img src="img/logout.png" style="height: 38px" alt="退出系统"></a>
					</li>
					<!-- <li class="dropdown">
						
						<a data-toggle="dropdown" class="dropdown-toggle " href="#">
							退出系统 <b class="caret"></b>							
						</a>
						
						<ul class="dropdown-menu">
					<li>
								<a href="./change_password.html"><i class="icon-lock"></i> 密码修改</a>
							</li>
							
							<li class="divider"></li>
							
						</ul>
					</li> -->
				</ul>
				
			</div> <!-- /nav-collapse -->
			
		</div> <!-- /container -->
		
	<!--</div> /navbar-inner  -->
	
</div> <!-- /navbar -->

<style type="text/css">	
    .imgdiv{float:left;width:106px;margin-left: 10px}   
    .fl{float: left}
    .imgtable{width:100%;border-bottom: 2px solid #ccc;}
</style>
<!-- <script src="tpl/System/common/ueditor/ueditor.config.js" type="text/javascript" charset="utf-8"></script> -->
<!-- <script src="tpl/System/common/ueditor/ueditor.all.min.js" type="text/javascript" charset="utf-8"></script> -->
<div id="content">
  
  <div class="container">
    
    <div class="row">
      
      <div class="span3">
				
				<ul id="main-nav" class="nav nav-tabs nav-stacked">
                    <li class="active accordion-group" id="Water">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Water/total');?>'">
		                <i class="icon-bar-chart"></i>
		                统计信息管理
		              </a>
                      <!-- <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Water/count');?>'">
                      		                  <i class="icon-share-alt"></i>
                      		                  水站统计
                      		              </a> -->
					</li>
					<li class="active accordion-group" id="Token">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Token/index');?>'">
		                <i class="icon-user"></i>
		                企业用户管理
		              </a>
					</li>	
                    <li class="active accordion-group" id="Goods">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Goods/index');?>'">
		                <i class="icon-tag"></i>
		                标签类型管理
		              </a>
					</li>
                    <li class="active accordion-group" id="Setinfo">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Setinfo/feeset');?>'">
		                <i class="icon-cog"></i>
		                会员费用设置
		              </a>
					</li>
				</ul>			
				<br />		
			</div> <!-- /span3 -->
<script type="text/javascript">
	$(document).ready(function(){
      var ref=window.location.href;
      var mod=ref.match(/m=[a-z]*/i);
      var str=mod[0].substr(2);
      console.log(str);
      $("#"+str).removeClass("active");
})
	
</script>

        
      <div class="span9">

        <div class="widget widget-table">
                    
          <div class="widget-header">
            <i class="icon-th-list"></i>
            <h3>码上生活信息设置 >> 软件年费设置</h3>
          </div> <!-- /widget-header -->
          
<div class="widget-content">
<form action="<?php echo U('Setinfo/feeset');?>" method="post" accept-charset="utf-8">
  <div style="margin:15px">
  <span>软件年费设置： </span><span style="color:#eb6100;font-size:12px"> 填写说明：请填写带单位的格式，以数字+月为单位。示例: 500元/12个月；可按需填写1-3个值。</span>
  <p>
  <input type="text" name="feeid0" value="<?php echo ($fee[0]["annual_fee"]); ?>">
  </p>
  <p>
  <input type="text" name="feeid1" value="<?php echo ($fee[1]["annual_fee"]); ?>">
  </p>
  <p>
  <input type="text" name="feeid2" value="<?php echo ($fee[2]["annual_fee"]); ?>">
  </p>
  </div> 
  <!-- <textarea id="container" name="content1"><?php echo ($fee[0]["content1"]); ?></textarea> -->
  <input type="submit" style="margin:0 15px" value="保存修改">
  
</form>
  <!-- <script type="text/javascript">
        var ue=UE.getEditor('container',{
          autoHeightEnabled:true,
          autoFloatEnabled:true,
          initialFrameWidth:690,
          initalFrameHeight:885
        })
  </script> -->
</div> <!-- /widget-content -->
          
        </div> <!-- /widget -->
      
      </div> <!-- /span9 -->
      
      
    </div> <!-- /row -->
    
  </div> <!-- /container -->

</div> <!-- /content -->

<div class="navbar navbar-fixed-bottom">
	<div class="navbar-inner" style="text-align: right;color:#fff;">
	智能物联网管理系统
	</div>
</div>

<!-- <script type="text/javascript" src="https://select2.github.io/dist/js/select2.min.js"></script> -->
<!-- <link href="https://select2.github.io/dist/css/select2.min.css" type="text/css" rel="stylesheet" /> -->
<!-- <style>.select2-search__field{height:30px;}</style> -->
<!-- <script>$("select").select2();</script> -->
    

<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->

<!-- <script src="<?php echo RES;?>/js/excanvas.min.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.pie.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.orderBars.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.resize.js"></script>
<script src="<?php echo STATICS;?>/artDialog/jquery.artDialog.js?skin=default"></script>
<script src="<?php echo STATICS;?>/artDialog/plugins/iframeTools.js"></script> -->


<!-- <script src="<?php echo RES;?>/js/water.js"></script> -->
<script src="<?php echo RES;?>/js/bootstrap.js"></script>
<!-- <script src="<?php echo RES;?>/js/charts/bar.js"></script> -->
  </body>

</html>