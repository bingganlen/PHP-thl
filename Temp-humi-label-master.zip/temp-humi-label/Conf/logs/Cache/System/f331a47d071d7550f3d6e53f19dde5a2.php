<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>智能物联网管理系统</title>
    <meta name="keywords" content="<?php echo ($f_siteName); ?>-Saivi后台管理系统" />
    <meta name="description" content="<?php echo ($f_siteName); ?>-Saivi后台管理系统" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />    
    
    <link href="<?php echo RES;?>/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo RES;?>/css/bootstrap-responsive.min.css" rel="stylesheet" />
    
    <link href="<?php echo RES;?>/css/font-awesome.css" rel="stylesheet" />
    
    <link href="<?php echo RES;?>/css/adminia.css" rel="stylesheet" /> 
    <link href="<?php echo RES;?>/css/adminia-responsive.css" rel="stylesheet" /> 
    
    <link href="<?php echo RES;?>/css/pages/dashboard.css" rel="stylesheet" /> 
    <link href="<?php echo RES;?>/css/pages/faq.css" rel="stylesheet" />

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="<?php echo RES;?>/js/html5.js"></script>
    <![endif]-->
	<script src="<?php echo RES;?>/js/jquery-1.7.2.min.js"></script>
	<!-- <script src="<?php echo STATICS;?>/kindeditor/kindeditor.js"></script>
	<script src="<?php echo STATICS;?>/kindeditor/lang/zh_CN.js"></script>
	<script src="<?php echo STATICS;?>/kindeditor/plugins/code/prettify.js"></script>
	<link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/themes/default/default.css" />
	<link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/plugins/code/prettify.css" />  -->
    <!--日期-->
    <link rel="stylesheet" type="text/css" href="./tpl/static/date/hDate.css"/>
    <script type="text/javascript" src="./tpl/static/date/hDate.js"></script>

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- <script type="text/javascript">
	$(function(){

		var str = $(".widget-header h3").html();
		// alert(str.indexOf("&gt;"));
		var hstr = $.trim(str.substr(0, str.indexOf("&gt;")));
		var num = '';
		if(hstr == "站点设置")
			num = '1';
		else if(hstr == '用户管理')
			num = '2';
		else if(hstr == '内容管理')
			num = '3';
		else if(hstr == '公众号管理')
			num = '4';
		else if(hstr == '功能管理')
			num = '5'
		else if(hstr == '扩展管理')
			num = '6';

		var current = '#collapse' + num;
		$(current).css('height','auto').removeClass('collapse').addClass('in');

	})
</script> -->
</head>

<body>
	
<div class="navbar">
	
	<!-- <div class="navbar-inner"> -->
		
		<div class="container">
			
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> 
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span> 				
			</a>
			
			<a class="brand" href="<?php echo U('System/Water/total');?>"><img src="img/megain.png" class="clogo"><img src="img/logo1.png" alt="logo" class="plogo">&nbsp;&nbsp;智能物联网管理系统</a>
			
			<div class="nav-collapse">			
				<ul class="nav pull-right">					
					<!-- <li class="divider-vertical"></li> -->
					<li class="nav_btn"><img src="img/admin.png" alt=""><span>hello ! <?php echo ($_SESSION['username']); ?></span></li>
					<li class="nav_btn">
						<a href="<?php echo U('System/Adminsaivi/logout');?>" style="padding:3px 0px 10px 10px"><img src="img/logout.png" style="height: 38px" alt="退出系统"></a>
					</li>
					<!-- <li class="dropdown">
						
						<a data-toggle="dropdown" class="dropdown-toggle " href="#">
							退出系统 <b class="caret"></b>							
						</a>
						
						<ul class="dropdown-menu">
					<li>
								<a href="./change_password.html"><i class="icon-lock"></i> 密码修改</a>
							</li>
							
							<li class="divider"></li>
							
						</ul>
					</li> -->
				</ul>
				
			</div> <!-- /nav-collapse -->
			
		</div> <!-- /container -->
		
	<!--</div> /navbar-inner  -->
	
</div> <!-- /navbar -->



<div id="content">
  
  <div class="container">
    
    <div class="row">
      
      <div class="span3">
				
				<ul id="main-nav" class="nav nav-tabs nav-stacked">
                    <li class="active accordion-group" id="Water">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Water/total');?>'">
		                <i class="icon-bar-chart"></i>
		                统计信息管理
		              </a>
                      <!-- <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Water/count');?>'">
                      		                  <i class="icon-share-alt"></i>
                      		                  水站统计
                      		              </a> -->
					</li>
					<li class="active accordion-group" id="Token">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Token/index');?>'">
		                <i class="icon-user"></i>
		                企业用户管理
		              </a>
					</li>	
                    <li class="active accordion-group" id="Goods">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Goods/index');?>'">
		                <i class="icon-tag"></i>
		                标签类型管理
		              </a>
					</li>
                    <li class="active accordion-group" id="Setinfo">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Setinfo/feeset');?>'">
		                <i class="icon-cog"></i>
		                会员费用设置
		              </a>
					</li>
				</ul>			
				<br />		
			</div> <!-- /span3 -->
<script type="text/javascript">
	$(document).ready(function(){
      var ref=window.location.href;
      var mod=ref.match(/m=[a-z]*/i);
      var str=mod[0].substr(2);
      console.log(str);
      $("#"+str).removeClass("active");
})
	
</script>

        
      <div class="span9">

        <div class="widget widget-table">
                    
          <div class="widget-header">
            <i class="icon-th-list"></i>
            <h3>企业用户管理 >> 用户<?php echo ($tpltitle); ?></h3>
          </div> <!-- /widget-header -->
          
          <div class="widget-content">

<?php if(($info["id"]) > "0"): ?><script src="./tpl/User/default/common/js/date/WdatePicker.js"></script>
			<form action="<?php echo U('Token/edits');?>" method="post" name="form" id="myform">
			<input type="hidden" name="id" value="<?php echo ($info["id"]); ?>">
		<?php else: ?>
			<form action="<?php echo U('Token/adds');?>" method="post" name="form" id="myform"><?php endif; ?>
			<table width="100%" border="0" cellspacing="0" cellpadding="0" id="addn">	
                <tr>
					<td height="48" align="right"><i style="color:#FF0000">* </i><strong>用 户 名：</strong></td>
					<td colspan="3" class="lt">
						<input type="text" name="username" class="ipt" size="45" value="">
					</td>
				</tr>		 
				<tr>
					<td height="48" align="right"><i style="color:#FF0000">* </i><strong>公司名称：</strong></td>
					<td colspan="3" class="lt">
						<input type="text" name="wxname" class="ipt" size="45" value="">
					</td>
				</tr>
				<tr>
					<td height="48" align="right"><i style="color:#FF0000">* </i><strong>公司地址：</strong></td>
					<td colspan="3" class="lt">
						<input type="text" name="address" class="ipt" size="45" value="">
					</td>
				</tr>
                <tr>
                    <td height="48" align="right"><i style="color:#FF0000">* </i><strong>负 责 人：</strong></td>
                    <td colspan="3" class="lt">
                        <input type="text" name="user" class="ipt" size="45" value="">
                    </td>
                </tr>
				<tr>
					<td height="48" align="right"><i style="color:#FF0000">* </i><strong>手 机 号：</strong></td>
					<td colspan="3" class="lt">
						<input type="text" name="mp" class="ipt" size="45" value="" />
					</td>
				</tr>
				<!-- <tr>
					<td height="48" align="right"><strong>邮箱：</strong></td>
					<td colspan="3" class="lt">
						<input type="text" name="email" class="ipt" size="45" value="<?php echo ($info["email"]); ?>" />
					</td>
				</tr> -->
				<tr>
					<td height="48" align="right"><i style="color:#FF0000">* </i><strong>密　　码：</strong></td>
					<td colspan="3" class="lt">
						<input type="password" name="password" class="ipt" size="45" value="">
					</td>
				</tr>
				<tr>
					<td height="48" align="right"><i style="color:#FF0000">* </i><strong>确认密码：</strong></td>
					<td colspan="3" class="lt">
						<input type="password" name="repassword" class="ipt" size="45"/>
					</td>
				</tr>
				<!-- <tr>
					<td height="48" align="right"><strong>用户角色：</strong></td>
					<td colspan="3" class="lt">
						<select name="gid" style="width:136px">
							<?php if(is_array($role)): $i = 0; $__LIST__ = $role;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["id"]); ?>" <?php if(($vo["id"]) == $info["gid"]): ?>selected=""<?php endif; ?> ><?php echo ($vo["name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
						</select>
					</td>
				</tr> -->				
				<tr>
                    <td height="48" align="right"><i style="color:#FF0000">* </i><strong>是否会员：</strong></td>
                    <td><select name="is_vip" id="is_vip">
                        <!-- <option value="-1"></option> -->
                          <option value ="1">是</option>
                          <option value ="0">否</option>
                    </select></td>
                </tr>
                <tr>
                    <td height="48" align="right"><strong>费   用：</strong></td>
                    <td><select name="annual_fee" id="feechange">
                        <option value="-1">年费选择</option>
                        <?php if(is_array($platform)): $i = 0; $__LIST__ = $platform;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["annual_fee"]); ?>"><?php echo ($vo["annual_fee"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                    </select>
                    <i style="color:#FF0000">如果是会员请选择会员费用</i>
                </td>
                </tr>
                <tr>
                    <td height="48" align="right"><strong>会员到期时间：</strong></td>
                    <td>
                    <input type="hidden" name="st_time" value="">
                    <input name="viptime" type="text" id="st_time" onClick="calendar.show({ id: this })" value="<?php echo (date('Y-m-d',$vipdate["start_time"])); ?>"> </td>
                    <!-- <td><input name="end_time" type="text" id="end_time" onClick="calendar.show({ id: this })" value="<?php echo (date('Y-m-d',$vipdate["end_time"])); ?>"></td> -->
                    
                </tr>
				<tr>
					<td height="48" align="right"><strong>备注说明：</strong></td>
					<td colspan="3" class="lt">
						<input type="text" name="remark" class="ipt" size="45" value=""/>
					</td>
				</tr>
				
				<!-- <tr>
					<td height="48" align="right"><strong>邀请列表：</strong></td>
					<td colspan="3" class="lt">
					<a href="?g=System&m=Users&a=index&inviter=<?php echo ($info["id"]); ?>">点击查看邀请列表（共<?php echo ($inviteCount); ?>人）</a>
					</td>
				</tr> -->
				<tr>
				    <td height="48" align="right"></td>
					<td colspan="4">
						<?php if(($info["id"]) > "0"): ?><input class="bginput" type="submit" name="dosubmit" value="修 改" >
							<?php else: ?>
							<input class="bginput" type="submit" name="dosubmit" value="添 加"><?php endif; ?>
						&nbsp;
						<input class="bginput" type="button" onclick="javascript:history.back(-1);" value="返 回" ></td>
				</tr>
</table>
</form>
			                     
          
          </div> <!-- /widget-content -->
          
        </div> <!-- /widget -->
      
      </div> <!-- /span9 -->
      
      
    </div> <!-- /row -->
    
  </div> <!-- /container -->
  
</div> <!-- /content -->
<script type="text/javascript">
	//选择年费后时间自动计算
	$("#feechange").on('change',function () {
		var val=$(this).val();
		var months=parseInt(val.substr(val.indexOf('/')+1));
		var fdate=futuremonth(months);		
		$("#st_time").val(fdate);
	})
	function futuremonth(months){
		var time = new Date();
		time.setDate(time.getDate());
		var y=time.getFullYear();
		var m=time.getMonth()+months+1;
		var d=time.getDate();
		if(m/12>0){
			y=y+parseInt(m/12);
			m=m%12;
		}	
		return y+"-"+m+"-"+d;
	}
</script>
<div class="navbar navbar-fixed-bottom">
	<div class="navbar-inner" style="text-align: right;color:#fff;">
	智能物联网管理系统
	</div>
</div>

<!-- <script type="text/javascript" src="https://select2.github.io/dist/js/select2.min.js"></script> -->
<!-- <link href="https://select2.github.io/dist/css/select2.min.css" type="text/css" rel="stylesheet" /> -->
<!-- <style>.select2-search__field{height:30px;}</style> -->
<!-- <script>$("select").select2();</script> -->
    

<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->

<!-- <script src="<?php echo RES;?>/js/excanvas.min.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.pie.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.orderBars.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.resize.js"></script>
<script src="<?php echo STATICS;?>/artDialog/jquery.artDialog.js?skin=default"></script>
<script src="<?php echo STATICS;?>/artDialog/plugins/iframeTools.js"></script> -->


<!-- <script src="<?php echo RES;?>/js/water.js"></script> -->
<script src="<?php echo RES;?>/js/bootstrap.js"></script>
<!-- <script src="<?php echo RES;?>/js/charts/bar.js"></script> -->
  </body>

</html>