<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>码上订水后台管理系统</title>
    <meta name="keywords" content="<?php echo ($f_siteName); ?>-Saivi后台管理系统" />
    <meta name="description" content="<?php echo ($f_siteName); ?>-Saivi后台管理系统" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />    
    
    <link href="<?php echo RES;?>/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo RES;?>/css/bootstrap-responsive.min.css" rel="stylesheet" />
    
    <link href="<?php echo RES;?>/css/font-awesome.css" rel="stylesheet" />
    
    <link href="<?php echo RES;?>/css/adminia.css" rel="stylesheet" /> 
    <link href="<?php echo RES;?>/css/adminia-responsive.css" rel="stylesheet" /> 
    
    <link href="<?php echo RES;?>/css/pages/dashboard.css" rel="stylesheet" /> 
    <link href="<?php echo RES;?>/css/pages/faq.css" rel="stylesheet" />

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="<?php echo RES;?>/js/html5.js"></script>
    <![endif]-->
	<script src="<?php echo RES;?>/js/jquery-1.7.2.min.js"></script>
	<script src="<?php echo STATICS;?>/kindeditor/kindeditor.js"></script>
	<script src="<?php echo STATICS;?>/kindeditor/lang/zh_CN.js"></script>
	<script src="<?php echo STATICS;?>/kindeditor/plugins/code/prettify.js"></script>
	<link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/themes/default/default.css" />
	<link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/plugins/code/prettify.css" /> 
    <!--日期-->
    <link rel="stylesheet" type="text/css" href="./tpl/static/date/hDate.css"/>
    <script type="text/javascript" src="./tpl/static/date/hDate.js"></script>

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript">
	$(function(){

		var str = $(".widget-header h3").html();
		// alert(str.indexOf("&gt;"));
		var hstr = $.trim(str.substr(0, str.indexOf("&gt;")));
		var num = '';
		if(hstr == "站点设置")
			num = '1';
		else if(hstr == '用户管理')
			num = '2';
		else if(hstr == '内容管理')
			num = '3';
		else if(hstr == '公众号管理')
			num = '4';
		else if(hstr == '功能管理')
			num = '5'
		else if(hstr == '扩展管理')
			num = '6';

		var current = '#collapse' + num;
		$(current).css('height','auto').removeClass('collapse').addClass('in');

	})
</script>
</head>

<body>
	
<div class="navbar navbar-fixed-top">
	
	<div class="navbar-inner">
		
		<div class="container">
			
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> 
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span> 				
			</a>
			
			<a class="brand" href="<?php echo U('System/System/index');?>">码上订水</a>
			
			<div class="nav-collapse">
			
				<ul class="nav pull-right">

					
					<li class="divider-vertical"></li>
					
					<li class="dropdown">
						
						<a data-toggle="dropdown" class="dropdown-toggle " href="#">
							管理 <b class="caret"></b>							
						</a>
						
						<ul class="dropdown-menu">
<!-- 							
							<li>
								<a href="./change_password.html"><i class="icon-lock"></i> 密码修改</a>
							</li> -->
							
							<li class="divider"></li>
							<li>
								<a href="<?php echo U('System/Adminsaivi/logout');?>">&nbsp;退出系统</a>
							</li>
						</ul>
					</li>
				</ul>
				
			</div> <!-- /nav-collapse -->
			
		</div> <!-- /container -->
		
	</div> <!-- /navbar-inner -->
	
</div> <!-- /navbar -->


<div id="content">

  <div class="container">

    <div class="row">

      <div class="span3">
				
				<ul id="main-nav" class="nav nav-tabs nav-stacked">
					
					<!-- <li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse1">
		                <i class="icon-home"></i>
		                站点设置
		              </a>

		              <div id="collapse1" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" href="" onclick="javascript:window.location.href = '<?php echo U('System/Site/index', array('pid'=>6, 'level'=>3));?>'">
		                  <i class="icon-share-alt"></i>
		                  基本设置
		                </a>
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Node/index', array('pid'=>11, 'level'=>3));?>'">
		                  <i class="icon-share-alt"></i>
		                  节点管理
		                </a>
		              </div>
					</li> -->

					<!-- <li class="active accordion-group">
							              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse2">
							                <i class="icon-user"></i>
							                权限管理
							              </a>
					
							              <div id="collapse2" class="accordion-body collapse" style="height: 0px; ">
							                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/User/index', array('pid'=>18, 'level'=>3));?>'">
							                  <i class="icon-share-alt"></i>
							                  权限管理
							                </a>
							                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Group/index', array('pid'=>25, 'level'=>3));?>'">
							                  <i class="icon-share-alt"></i>
							                  管理组
							                </a>
							                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/User_group/index', array('pid'=>48, 'level'=>3));?>'">
							                  <i class="icon-share-alt"></i>
							                  会员组
							                </a>
							                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Users/index', array('pid'=>50, 'level'=>3));?>'">
							                  <i class="icon-share-alt"></i>
							                  前台用户
							                </a>
							              </div>
					</li> -->

					<!-- <li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse3">
		                <i class="icon-file"></i>
		                内容管理
		              </a>

		              <div id="collapse3" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Article/index', array('pid'=>38, 'level'=>3));?>'">
		                  <i class="icon-share-alt"></i>
		                  微信图文
		                </a>
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Text/index', array('pid'=>57, 'level'=>3));?>'">
		                  <i class="icon-share-alt"></i>
		                  微信文本
		                </a>
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Custom/index', array('pid'=>60, 'level'=>3));?>'">
		                  <i class="icon-share-alt"></i>
		                  自定义页面
		                </a>
		              </div>
					</li> -->

					<li class="active accordion-group">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Token/index');?>'">
		                <i class="icon-user"></i>
		                企业用户管理
		              </a>

		              <!--  <div id="collapse4" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" >
		                  <i class="icon-share-alt"></i>
		                  水站列表
		                </a>
		               <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Address/index',array('pid'=>81, 'level'=>3));?>'">
		                  <i class="icon-share-alt"></i>
		                  水站地址列表
		                </a> 
		              </div>-->
					</li>	

					<li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse14">
		                <i class="icon-comment"></i>
		                用户管理
		              </a>

		              <div id="collapse14" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Wateruser/index');?>'">
		                  <i class="icon-share-alt"></i>
		                  用户列表
		                </a>
		              </div>
					</li>

					<li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse13">
		                <i class="icon-list"></i>
		                订单管理
		              </a>

		              <div id="collapse13" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Oders/index');?>'">
		                  <i class="icon-share-alt"></i>
		                  订单列表
		                </a>
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Oders/overtime');?>'">
		                  <i class="icon-share-alt"></i>
		                  超时订单
		                </a>
		              </div>
					</li>

					<!-- <li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse5">
		                <i class="icon-th"></i>
		                功能管理
		              </a>

		              <div id="collapse5" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Function/index', array('pid'=>46, 'level'=>3));?>'">
		                  <i class="icon-share-alt"></i>
		                  功能模块
		                </a>
		              </div>
					</li>	 -->

					<!-- <li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse6">
		                <i class="icon-share"></i>
		                扩展管理
		              </a>

		              <div id="collapse6" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Records/index', array('pid'=>64, 'level'=>3));?>'">
		                  <i class="icon-share-alt"></i>
		                  充值记录
		                </a>
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Case/index', array('pid'=>66, 'level'=>3));?>'">
		                  <i class="icon-share-alt"></i>
		                  用户案例
		                </a>
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Links/index', array('pid'=>73, 'level'=>3));?>'">
		                  <i class="icon-share-alt"></i>
		                  友情链接
		                </a>

		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Seo/index', array('pid'=>88, 'level'=>3));?>'">
		                  <i class="icon-share-alt"></i>
		                  文章管理
		                </a>
		              </div>
					</li> -->
<!-- 
					<li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse7">
		                <i class="icon-th"></i>
		                代理商管理
		              </a>

		              <div id="collapse7" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Agent/index', array('pid'=>85, 'level'=>3));?>'">
		                  <i class="icon-share-alt"></i>
		                  代理商管理
		                </a>
		              </div>
					</li>
 -->

					<!-- <li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse8">
		                <i class="icon-th"></i>
		                系统管理
		              </a>

		              <div id="collapse8" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/System/clear');?>'">
		                  <i class="icon-share-alt"></i>
		                  清除缓存
		                </a>
		              </div>
					</li>		 -->				
					<!-- <li class="active accordion-group">
                              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse9">
                                <i class="icon-th"></i>
                                客户信息管理
                              </a>

                              <div id="collapse9" class="accordion-body collapse" style="height: 0px; ">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/System/userinfo');?>'">
                                  <i class="icon-share-alt"></i>
                                  客户信息管理
                                </a>
                              </div>
                                        </li> -->
                    <li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse22">
		                <i class="icon-th"></i>
		                码上生活信息设置
		              </a>

		              <div id="collapse22" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Setinfo/profile');?>'">
		                  <i class="icon-share-alt"></i>
		                  公司简介设置
		                </a>
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Setinfo/feeset');?>'">
		                  <i class="icon-share-alt"></i>
		                  软件年费设置
		                </a>
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Setinfo/setimg');?>'">
		                  <i class="icon-share-alt"></i>
		                  物料及微信图片设置
		                </a>
		              </div>
					</li>
                    <li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse10">
		                <i class="icon-bar-chart"></i>
		                统计管理
		              </a>

		              <div id="collapse10" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Water/count');?>'">
		                  <i class="icon-share-alt"></i>
		                  水站统计
		                </a>
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Water/total');?>'">
		                  <i class="icon-share-alt"></i>
		                  数据统计
		                </a>
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Water/floorcount');?>'">
		                  <i class="icon-share-alt"></i>
		                  宿舍楼统计
		                </a>
		              </div>

					</li>		


					<li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse11">
		                <i class="icon-picture"></i>
		                广告管理
		              </a>

		              <div id="collapse11" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/System/banner');?>'">
		                  <i class="icon-share-alt"></i>
		                  广告列表
		                </a>
		              </div>
					</li>
					

					<!-- <li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse12">
		                <i class="icon-th"></i>
		                水站地址管理
		              </a>

		              <div id="collapse12" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Address/index');?>'">
		                  <i class="icon-share-alt"></i>
		                  水站地址管理
		                </a>
		              </div>
					</li> -->


					<!-- <li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse15">
		                <i class="icon-th"></i>
		                宿舍楼统计
		              </a>

		              <div id="collapse15" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Water/floorcount');?>'">
		                  <i class="icon-share-alt"></i>
		                  宿舍楼统计
		                </a>
		              </div>
					</li> -->


						<!-- <li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse16">
		                <i class="icon-th"></i>
		                活动设置
		              </a>

		              <div id="collapse16" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Praised/set');?>'">
		                  <i class="icon-share-alt"></i>
		                  活动设置
		                </a>
		              </div>
					</li> -->
					

					<li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse17">
		                <i class="icon-envelope"></i>
		                发送短信
		              </a>

		              <div id="collapse17" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Water/message');?>'">
		                  <i class="icon-share-alt"></i>
		                  发送短信
		                </a>
		              </div>
					</li>
                    
                    <li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse18">
		                <i class="icon-star"></i>
		                经销商管理
		              </a>

		              <div id="collapse18" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Distributor/index');?>'">
		                  <i class="icon-share-alt"></i>
		                  经销商管理
		                </a>
		              </div>
					</li>

					<li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse19">
		                <i class="icon-list-alt"></i>
		                财务管理
		              </a>
		              <div id="collapse19" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Finance/index');?>'">
		                  <i class="icon-share-alt"></i>
		                  提现申请记录
		                </a>		              
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Finance/wxincome');?>'">
		                  <i class="icon-share-alt"></i>
		                  微信收入记录
		                </a>
		                </div>		              
					</li>

					<li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse20">
		                <i class="icon-th-large"></i>
		                商品库管理
		              </a>

		              <div id="collapse20" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Goods/index');?>'">
		                  <i class="icon-share-alt"></i>
		                  商品列表
		                </a>
		              </div>
					</li>

                    <li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse23">
		                <i class="icon-volume-up"></i>
		                全网推广信息
		              </a>

		              <div id="collapse23" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Setinfo/spread');?>'">
		                  <i class="icon-share-alt"></i>
		                  全网推广信息
		                </a>
		              </div>
					</li>

					<li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse21">
		                <i class="icon-edit"></i>
		                合作商城管理
		              </a>

		              <div id="collapse21" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Mall/index');?>'">
		                  <i class="icon-share-alt"></i>
		                  合作商城列表
		                </a>
		              </div>
					</li>
				</ul>	
			
				<br />
		
			</div> <!-- /span3 -->


      <div class="span9">

        <div class="widget widget-table">

          <div class="widget-header">
            <i class="icon-th-list"></i>
            <h3>全网推广信息 >> 全网推广</h3>
          </div> <!-- /widget-header -->
          <div>
            
              <form action="<?php echo U('Setinfo/spread');?>" method="post">
                <div style="margin-top:10px">
                  <span>水站名称：<input name="wxname" value="" type="text"><span>
                  <span>注册手机：<input name="wxphone" value="" type="text"></span>                  
                </div>
                <div>
                  <span>审核状态：<select name="status">
                            <option value="-1">请选择</option>
                            <option value="2">审核不通过</option>
                            <option value="1">审核通过</option>
                            <option value="0">未审核</option>
                  </select></span>
                  <span><input value="查询" type="submit" style="width:100px;height:30px;margin-left:10px"></span>
                </div>
              </form>           
          </div>
          <div class="widget-content">
	<table class="table table-striped table-bordered" style="margin-top:10px;" id="set_table">
	  <tr>
		<td >水站ID</td>
		<td>水站名称</td>		
		<td>注册手机</td>
    <td>上传时间</td>
    <td>审核状态</td>    
		<td>管理操作</td>    
	  </tr>
	   <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
				<td align='center'><?php echo ($vo["Ftoken"]); ?></td>
				<td ><?php echo ($vo["wxname"]); ?></td>				
        <td><?php echo ($vo["phone"]); ?></td>
        <td align='center'><?php echo (date('Y-m-d',$vo["Fcreatetime"])); ?></td>
        <td>
          <?php switch($vo['Fstatus']): case "0": ?>未审核<?php break;?>
          <?php case "1": ?>审核通过<?php break;?>
          <?php case "2": ?>审核不通过<?php break; endswitch;?>
        </td>        
        <td align='center'><a href="<?php echo U('Setinfo/spd_img',array('id'=>$vo['Ftoken'],'name'=>$vo['wxname']));?>">查看审核</a></td>
				
        <!-- <script type="text/javascript">
            function test(){
                var test = document.getElementById("batch").value;
                //alert(test);
                document.getElementById("aaa").href="<?php echo U('Token/qrcode',array('token'=>$vo['token']));?>&batch="+test;
            }
        </script> -->
      </tr><?php endforeach; endif; else: echo "" ;endif; ?>
		<tr bgcolor="#FFFFFF">
      <td colspan="7"><div class="listpage"><?php echo ($page); ?></div></td>
    </tr>
	</table>
      </div> <!-- /widget-content -->
        </div> <!-- /widget -->
      </div> <!-- /span9 -->
    </div> <!-- /row -->
  </div> <!-- /container -->
</div> <!-- /content -->
<div class="navbar navbar-fixed-bottom">
	<div class="navbar-inner" style="text-align: right;color:#fff;">
		码上订水平台
	</div>
</div>

<!-- <script type="text/javascript" src="https://select2.github.io/dist/js/select2.min.js"></script> -->
<!-- <link href="https://select2.github.io/dist/css/select2.min.css" type="text/css" rel="stylesheet" /> -->
<!-- <style>.select2-search__field{height:30px;}</style> -->
<!-- <script>$("select").select2();</script> -->
    

<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->

<script src="<?php echo RES;?>/js/excanvas.min.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.pie.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.orderBars.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.resize.js"></script>
<script src="<?php echo STATICS;?>/artDialog/jquery.artDialog.js?skin=default"></script>
<script src="<?php echo STATICS;?>/artDialog/plugins/iframeTools.js"></script>


<!-- <script src="<?php echo RES;?>/js/water.js"></script> -->
<script src="<?php echo RES;?>/js/bootstrap.js"></script>
<script src="<?php echo RES;?>/js/charts/bar.js"></script>
  </body>

</html>