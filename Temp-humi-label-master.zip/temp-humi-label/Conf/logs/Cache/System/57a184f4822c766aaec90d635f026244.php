<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>智能物联网管理系统</title>
    <meta name="keywords" content="<?php echo ($f_siteName); ?>-Saivi后台管理系统" />
    <meta name="description" content="<?php echo ($f_siteName); ?>-Saivi后台管理系统" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />    
    
    <link href="<?php echo RES;?>/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo RES;?>/css/bootstrap-responsive.min.css" rel="stylesheet" />
    
    <link href="<?php echo RES;?>/css/font-awesome.css" rel="stylesheet" />
    
    <link href="<?php echo RES;?>/css/adminia.css" rel="stylesheet" /> 
    <link href="<?php echo RES;?>/css/adminia-responsive.css" rel="stylesheet" /> 
    
    <link href="<?php echo RES;?>/css/pages/dashboard.css" rel="stylesheet" /> 
    <link href="<?php echo RES;?>/css/pages/faq.css" rel="stylesheet" />

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="<?php echo RES;?>/js/html5.js"></script>
    <![endif]-->
	<script src="<?php echo RES;?>/js/jquery-1.7.2.min.js"></script>
	<!-- <script src="<?php echo STATICS;?>/kindeditor/kindeditor.js"></script>
	<script src="<?php echo STATICS;?>/kindeditor/lang/zh_CN.js"></script>
	<script src="<?php echo STATICS;?>/kindeditor/plugins/code/prettify.js"></script>
	<link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/themes/default/default.css" />
	<link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/plugins/code/prettify.css" />  -->
    <!--日期-->
    <link rel="stylesheet" type="text/css" href="./tpl/static/date/hDate.css"/>
    <script type="text/javascript" src="./tpl/static/date/hDate.js"></script>

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- <script type="text/javascript">
	$(function(){

		var str = $(".widget-header h3").html();
		// alert(str.indexOf("&gt;"));
		var hstr = $.trim(str.substr(0, str.indexOf("&gt;")));
		var num = '';
		if(hstr == "站点设置")
			num = '1';
		else if(hstr == '用户管理')
			num = '2';
		else if(hstr == '内容管理')
			num = '3';
		else if(hstr == '公众号管理')
			num = '4';
		else if(hstr == '功能管理')
			num = '5'
		else if(hstr == '扩展管理')
			num = '6';

		var current = '#collapse' + num;
		$(current).css('height','auto').removeClass('collapse').addClass('in');

	})
</script> -->
</head>

<body>
	
<div class="navbar">
	
	<!-- <div class="navbar-inner"> -->
		
		<div class="container">
			
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> 
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span> 				
			</a>
			
			<a class="brand" href="<?php echo U('System/Water/total');?>"><img src="img/megain.png" class="clogo"><img src="img/logo1.png" alt="logo" class="plogo">&nbsp;&nbsp;智能物联网管理系统</a>
			
			<div class="nav-collapse">			
				<ul class="nav pull-right">					
					<!-- <li class="divider-vertical"></li> -->
					<li class="nav_btn"><img src="img/admin.png" alt=""><span>hello ! <?php echo ($_SESSION['username']); ?></span></li>
					<li class="nav_btn">
						<a href="<?php echo U('System/Adminsaivi/logout');?>" style="padding:3px 0px 10px 10px"><img src="img/logout.png" style="height: 38px" alt="退出系统"></a>
					</li>
					<!-- <li class="dropdown">
						
						<a data-toggle="dropdown" class="dropdown-toggle " href="#">
							退出系统 <b class="caret"></b>							
						</a>
						
						<ul class="dropdown-menu">
					<li>
								<a href="./change_password.html"><i class="icon-lock"></i> 密码修改</a>
							</li>
							
							<li class="divider"></li>
							
						</ul>
					</li> -->
				</ul>
				
			</div> <!-- /nav-collapse -->
			
		</div> <!-- /container -->
		
	<!--</div> /navbar-inner  -->
	
</div> <!-- /navbar -->

<style type="text/css">
	.kjnav{font-size: 12px;}
    .kjnav input{width:140px;height: 16px;margin-right: 10px;margin-top: 5px;}
    .kjnav select{width:110px;height:26px;margin-right: 10px;margin-top: 5px;padding:2px;}
    .imgdiv{float:left;width:30%;margin-left: 4%}
    .form-group{width:50%;float:right;}
</style>
<div id="content">  
  <div class="container">    
    <div class="row-fluid">      
      <div class="span3">
				
				<ul id="main-nav" class="nav nav-tabs nav-stacked">
                    <li class="active accordion-group" id="Water">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Water/total');?>'">
		                <i class="icon-bar-chart"></i>
		                统计信息管理
		              </a>
                      <!-- <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Water/count');?>'">
                      		                  <i class="icon-share-alt"></i>
                      		                  水站统计
                      		              </a> -->
					</li>
					<li class="active accordion-group" id="Token">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Token/index');?>'">
		                <i class="icon-user"></i>
		                企业用户管理
		              </a>
					</li>	
                    <li class="active accordion-group" id="Goods">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Goods/index');?>'">
		                <i class="icon-tag"></i>
		                标签类型管理
		              </a>
					</li>
                    <li class="active accordion-group" id="Setinfo">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Setinfo/feeset');?>'">
		                <i class="icon-cog"></i>
		                会员费用设置
		              </a>
					</li>
				</ul>			
				<br />		
			</div> <!-- /span3 -->
<script type="text/javascript">
	$(document).ready(function(){
      var ref=window.location.href;
      var mod=ref.match(/m=[a-z]*/i);
      var str=mod[0].substr(2);
      console.log(str);
      $("#"+str).removeClass("active");
})
	
</script>
        
      <div class="span9">
        <div class="widget widget-table">                    
          <div class="widget-header">
            <i class="icon-th-list"></i>
            <h3>标签类型管理 >> 列表</h3>
          </div> <!-- /widget-header -->          
          <div class="widget-content">           
<body class="warp">
<div id="artlist">
<div class="kjnav search_bar">
    <form method="post" action="<?php echo U('Goods/index');?>">    
        <div>
            <!-- 标签名称：<input name="FproductName" type="text">-->
            <!-- 标签状态：<select name="FisOk" id="FisOk"> 
                   <option value="-1">请选择</option> 
                   <option value="0">未修正</option> 
                   <option value="1">修正通过</option> 
                   </select>  -->           
            标签类型：<select name="typeid" id="typeid"> 
                       <option value="-1">请选择</option>
                       <?php if(is_array($type)): $i = 0; $__LIST__ = $type;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><option value="<?php echo ($v['id']); ?>"><?php echo ($v["tagtype"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                    </select>
            <button class="btn btn-default" type="submit">查询</button>
            <!-- <span id="GoodsAdd" class="btn btn-default">新增标签</span> -->
            <span id="TagType" class="btn btn-default">新增标签类型</span>
            <span id="TypeEdit" class="btn btn-default">修改标签类型</span>
        </div>
        </form>   
    </div>      
</div>
	<table class="table table-striped table-bordered" style="margin-top:10px;" id="set_table">
	    <tr>
			<!-- <th width="150">标签图片</th> -->
			<!-- <th width="300">标签名称</th> -->
      <th width="200">标签类型</th>
		  <th>标签规格</th>
		  <!-- <th width="200">是否可用</th>			 -->
			<th>操作</th>
	    </tr>
	    <?php if(is_array($type)): $i = 0; $__LIST__ = $type;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
  			  <!-- <td><img src="<?php echo ($vo['Fimg']); ?>" width="50px" height="50px"></td> -->
  				<!-- <td align='center'><?php echo ($vo["FproductName"]); ?></td> -->
          <td>
            <!-- <?php if($vo['Fcategory'] == 0): ?>桶装水
            <?php elseif($vo["Fcategory"] == 1): ?>瓶装水
            <?php else: ?>其他<?php endif; ?> -->
            <span><?php echo ($vo["tagtype"]); ?></span>
          </td>
  				<td><?php echo ($vo["regular"]); ?></td>
  	      <!-- <td>
            <label class="radio-inline">
              <input type="radio" name="FisOk<?php echo ($vo['Flibid']); ?>" id="<?php echo ($vo['Flibid']); ?>y" value="1" style="display:inline" <?php if($vo['FisOk'] == 1): ?>checked="checked"<?php endif; ?>> 可用
            </label>
            <label class="radio-inline">
              <input type="radio" name="FisOk<?php echo ($vo['Flibid']); ?>" id="<?php echo ($vo['Flibid']); ?>n" value="0" style="display:inline" <?php if($vo['FisOk'] == 0): ?>checked="checked"<?php endif; ?>> 不可用
            </label>
          </td> -->           
  				<td align='center'>
  					<!-- <a href="javascript:void(0)"><span id="TypeEdit" class="btn btn-default">修改</span></a> -->
  					<a href="javascript:void(0)" onclick="return confirmdel(<?php echo ($vo["id"]); ?>,'确定删除该商品吗?')"><span class="btn btn-default">删除</span></a>
            <!-- <?php if($vo['FisOk'] == '0'): ?><a href="javascript:void(0)" onclick="return check(<?php echo ($vo["Flibid"]); ?>,'确定审核通过该商品吗?',1)"><span class="btn btn-default">通过</span></a>
            <?php else: ?>
              <a href="javascript:void(0)" onclick="return check(<?php echo ($vo["Flibid"]); ?>,'确定关闭不显示该商品吗?',0)"><span class="btn btn-default">不通过</span></a><?php endif; ?> -->
  				</td>
  			</tr><?php endforeach; endif; else: echo "" ;endif; ?>
	 <tr bgcolor="#FFFFFF"> 
	  <td colspan="8"><div class="listpage"><?php echo ($page); ?></div></td>
	  <td></td>
	</tr>
	</table>      
          
          </div> <!-- /widget-content -->          
        </div> <!-- /widget -->      
      </div> <!-- /span9 -->     
    </div> <!-- /row -->    
  </div> <!-- /container -->
<!--   新增功能模态框 
<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" id="GoodsAddModal" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
    <form action="<?php echo U('Goods/goods_add');?>" method="post" accept-charset="utf-8" enctype="multipart/form-data">      
      
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">新建标签产品</h4>
      </div>
      <div class="modal-body">
        <div class="imgdiv"><img src="uploads/goods/noimg.png" alt="" id="imgthumb"></div>
        <div class="form-group">          
          <label class="control-label">标签名称：</label>
          <input type="text" value="" placeholder="单行输入" name="FproductName" required="required"> 
          <label class="control-label">标签类型：</label>
          <select name="typeid" required>
            <option value="-1">请选择</option>
            <?php if(is_array($type)): $i = 0; $__LIST__ = $type;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><option value="<?php echo ($v['id']); ?>"><?php echo ($v['tagtype']); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>            
          </select>
        </div>
        <div class="form-group">
          <label class="control-label">标签规格：</label>
          <input type="text" value="" placeholder="单行输入" name="Fspec" required>
        </div>
        <div class="form-group">
          <label class="control-label">标签图片：</label>
          <input type="file" name="Fimg" onchange="readURL(this,'imgthumb');" required/>
        </div>        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">取消</button>
        <button type="submit" class="btn btn-primary" id="addsave">保存</button>
      </div>
    </form>
    </div>
  </div>
</div>--><!-- /model -->

<!--   编辑功能模态框 -->  
<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" id="TypeEditModal" aria-hidden="true" style="width:auto">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">修改标签类型</h4>
      </div>
      <div class="modal-body">
    <table class="table table-bordered">
      <thead style="background:#eee">
        <tr>
          <th>类型名称</th>
          <th>类型描述</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody id="type_body">        
        <?php if(is_array($type)): $i = 0; $__LIST__ = $type;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
          <td><input type="text" value="<?php echo ($vo['tagtype']); ?>" id="<?php echo ($vo['id']); ?>" required></td>
          <td><input type="text" value="<?php echo ($vo['regular']); ?>" id="<?php echo ($vo['id']); ?>des" required></td>
          <td><button type="button" class="btn btn-default" data-id="<?php echo ($vo['id']); ?>" onclick="type_del(this)">删除</button>
              <button type="submit" class="btn btn-primary" data-id="<?php echo ($vo['id']); ?>" onclick="type_edit(this)">确认修改</button></td>
        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
      </tbody>
    </table>
    </div>
    </div>
  </div>
</div><!-- /model -->
<!-- 标签类型管理模态框 -->
<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" id="TagTypeModal" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
    <!-- <form action="<?php echo U('Goods/goods_edit_save');?>" method="post" accept-charset="utf-8" enctype="multipart/form-data">       -->
      <!-- <input type="hidden" value="" id="editid" name="Flibid"> -->
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">新增标签类型</h4>
      </div>
      <div class="modal-body">
        <!-- <div class="imgdiv"><img src="uploads/goods/noimg.png" alt="" id="imgthumb2" width="180px"></div> -->
        <div style="padding:15px;text-align:center">
          <label style="display:inline">类型名称：</label>
          <input type="text" placeholder="单行输入" id="type_name">          
        </div>
        <div style="padding:15px;text-align:center">
          <label style="display:inline">类型规格：</label>
          <input type="text" placeholder="单行输入" id="type_des">          
        </div>
        <div style="padding:15px;text-align:center">          
          <button class="btn btn-primary" style="margin:0 0 7px 15px" id="addtype">确认添加</button>
        </div>
        <div>
        </div>        
      </div> 
      <div class="modal-footer"><span style="font-size:12px;color:#eb6100">*说明：新添加的类型请刷新后操作删除和修改</span></div>     
    <!-- </form> -->
    </div>
  </div>
</div><!-- /model -->
</div> <!-- /content -->
<script type="text/javascript">
	$('#GoodsAdd').click(function(){
       $("#GoodsAddModal").modal("show");
    });
    $('#TypeEdit').click(function(){
       $("#TypeEditModal").modal("show");
    });
    $('#TagType').click(function(){
       $("#TagTypeModal").modal("show");
    });
   //图片预览
    function readURL(input,imgid) {
		if (input.files && input.files[0]) {  
		var reader = new FileReader();  
		  
		reader.onload = function (e) {  
		$("#"+imgid).attr('src', e.target.result).width(180);  
		}; 
		reader.readAsDataURL(input.files[0]);  
		}  
	}  
  //类型添加
  $("#addtype").click(function(){
    var tagname = $("#type_name").val();
    var tagdes = $("#type_des").val();
    if(!tagname){   
      return false;
    }else{      
      $.ajax({
      url:"<?php echo U('Goods/type_add');?>",
      data:{'type':tagname,'des':tagdes},
      type:"POST",      
      success:function(data){     
        if(data=='success'){
          //$("#type_body").append("<tr><td><input type='text' value='"+tagname+"' required></td><td><button type='button' class='btn btn-default'>删除</button> <button class='btn btn-primary'>确认修改</button></td></tr>")
          window.location.reload();
        }        
      }
      })
    }
  })
  //类型删除
  function type_del(button){
    var id=button.getAttribute("data-id");
    //console.log(id);
    $.ajax({
      url:"<?php echo U('Goods/type_del');?>",
      data:{'id':id},
      type:"GET",      
      success:function(data){     
        if(data=='success'){
          console.log(data);
          $(button).parent().parent("tr").hide();
        }
      }
    })
  }
  //类型修改
  function type_edit(btn){
    var id=btn.getAttribute("data-id");
    var val = $("#"+id).val();
    var des = $("#"+id+"des").val();    
    $.ajax({
      url:"<?php echo U('Goods/type_edit');?>",
      data:{'id':id,'typename':val,'regular':des},
      type:"POST",      
      success:function(data){     
        if(data=='success'){
          window.location.reload();          
        }
      },
      error:function(res){
        alert(res);
      }
    })
  }
	// function editinfo(id){
	// 	 $("#GoodsEditModal").modal("show");
	// 	$.ajax({
	// 		url:"<?php echo U('Goods/goods_edit');?>",
	// 		data:{id},
	// 		type:"POST",
	// 		dataType:"JSON",
	// 		success:function(data){			
	// 			var objjson=eval('('+data+')');
	// 			//console.log(objjson);
 //                $("#FproductName").val(objjson.FproductName);
 //                $("#Fspec").val(objjson.Fspec);
 //                $("#imgthumb2").attr('src',objjson.Fimg);
 //                $("#editid").val(objjson.Flibid);
	// 		}
	// 	});       
	// }
	//删除
	function confirmdel(proid,info){
		var res = confirm(info);		
		if(res==true)
	    {
		    $.ajax({
				url:"<?php echo U('Goods/type_del');?>",
				data:{'id':proid},
				type:"GET",				
	      success:function(res){			
					window.location.reload();
				},
        error:function(resu){
          alert(resu);
        }
			});
	    }		
	} 
  function check(proid,info, isok){
    var res = confirm(info);    
    if(res==true)
      {
        $.ajax({
        url:"<?php echo U('Goods/check');?>",
        data:{'proid':proid,'isok':isok},
        type:"GET",       
        success:function(res){
          window.location.reload();
        }
      });
      }   
  } 
//设置可用与不可用
$("input[type='radio']").click(function(){
var id=parseInt(this.id);
//alert(id);return false;
var name=$(this).attr("name");
var val=$("input[name="+name+"]:checked").val();
//alert(val);
$.ajax({
  url:"<?php echo U('Goods/check');?>",
  data:{'proid':id,'isok':val},
  type:"GET",  
  success:function(res){
    window.location.reload();
  }
})
})


</script>
<div class="navbar navbar-fixed-bottom">
	<div class="navbar-inner" style="text-align: right;color:#fff;">
	智能物联网管理系统
	</div>
</div>

<!-- <script type="text/javascript" src="https://select2.github.io/dist/js/select2.min.js"></script> -->
<!-- <link href="https://select2.github.io/dist/css/select2.min.css" type="text/css" rel="stylesheet" /> -->
<!-- <style>.select2-search__field{height:30px;}</style> -->
<!-- <script>$("select").select2();</script> -->
    

<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->

<!-- <script src="<?php echo RES;?>/js/excanvas.min.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.pie.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.orderBars.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.resize.js"></script>
<script src="<?php echo STATICS;?>/artDialog/jquery.artDialog.js?skin=default"></script>
<script src="<?php echo STATICS;?>/artDialog/plugins/iframeTools.js"></script> -->


<!-- <script src="<?php echo RES;?>/js/water.js"></script> -->
<script src="<?php echo RES;?>/js/bootstrap.js"></script>
<!-- <script src="<?php echo RES;?>/js/charts/bar.js"></script> -->
  </body>

</html>