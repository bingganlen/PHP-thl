<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>智能物联网管理系统</title>
    <meta name="keywords" content="<?php echo ($f_siteName); ?>-Saivi后台管理系统" />
    <meta name="description" content="<?php echo ($f_siteName); ?>-Saivi后台管理系统" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />    
    
    <link href="<?php echo RES;?>/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo RES;?>/css/bootstrap-responsive.min.css" rel="stylesheet" />
    
    <link href="<?php echo RES;?>/css/font-awesome.css" rel="stylesheet" />
    
    <link href="<?php echo RES;?>/css/adminia.css" rel="stylesheet" /> 
    <link href="<?php echo RES;?>/css/adminia-responsive.css" rel="stylesheet" /> 
    
    <link href="<?php echo RES;?>/css/pages/dashboard.css" rel="stylesheet" /> 
    <link href="<?php echo RES;?>/css/pages/faq.css" rel="stylesheet" />

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="<?php echo RES;?>/js/html5.js"></script>
    <![endif]-->
	<script src="<?php echo RES;?>/js/jquery-1.7.2.min.js"></script>
	<!-- <script src="<?php echo STATICS;?>/kindeditor/kindeditor.js"></script>
	<script src="<?php echo STATICS;?>/kindeditor/lang/zh_CN.js"></script>
	<script src="<?php echo STATICS;?>/kindeditor/plugins/code/prettify.js"></script>
	<link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/themes/default/default.css" />
	<link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/plugins/code/prettify.css" />  -->
    <!--日期-->
    <link rel="stylesheet" type="text/css" href="./tpl/static/date/hDate.css"/>
    <script type="text/javascript" src="./tpl/static/date/hDate.js"></script>

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- <script type="text/javascript">
	$(function(){

		var str = $(".widget-header h3").html();
		// alert(str.indexOf("&gt;"));
		var hstr = $.trim(str.substr(0, str.indexOf("&gt;")));
		var num = '';
		if(hstr == "站点设置")
			num = '1';
		else if(hstr == '用户管理')
			num = '2';
		else if(hstr == '内容管理')
			num = '3';
		else if(hstr == '公众号管理')
			num = '4';
		else if(hstr == '功能管理')
			num = '5'
		else if(hstr == '扩展管理')
			num = '6';

		var current = '#collapse' + num;
		$(current).css('height','auto').removeClass('collapse').addClass('in');

	})
</script> -->
</head>

<body>
	
<div class="navbar">
	
	<!-- <div class="navbar-inner"> -->
		
		<div class="container">
			
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> 
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span> 				
			</a>
			
			<a class="brand" href="<?php echo U('System/System/index');?>"><img src="img/logo1.png" alt="logo">&nbsp;&nbsp;智能物联网管理系统</a>
			
			<div class="nav-collapse">			
				<ul class="nav pull-right">					
					<!-- <li class="divider-vertical"></li> -->
					<li class="nav_btn"><img src="img/admin.png" alt=""><span>hello !  Admin</span></li>
					<li class="nav_btn">
						<a href="<?php echo U('System/Adminsaivi/logout');?>" style="padding:5px 0px 10px 10px"><img src="img/logout.png" width="77px" alt="退出系统"></a>
					</li>
					<!-- <li class="dropdown">
						
						<a data-toggle="dropdown" class="dropdown-toggle " href="#">
							退出系统 <b class="caret"></b>							
						</a>
						
						<ul class="dropdown-menu">
					<li>
								<a href="./change_password.html"><i class="icon-lock"></i> 密码修改</a>
							</li>
							
							<li class="divider"></li>
							
						</ul>
					</li> -->
				</ul>
				
			</div> <!-- /nav-collapse -->
			
		</div> <!-- /container -->
		
	<!--</div> /navbar-inner -->
	
</div> <!-- /navbar -->


<div id="content">
	
	<div class="container">
		
		<div class="row-fluid">
			
			<div class="span3">
				
				<ul id="main-nav" class="nav nav-tabs nav-stacked">
                    <li class="active accordion-group">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Water/total');?>'">
		                <i class="icon-bar-chart"></i>
		                统计信息管理
		              </a>
                      <!-- <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('System/Water/count');?>'">
                      		                  <i class="icon-share-alt"></i>
                      		                  水站统计
                      		              </a> -->
					</li>
					<li class="active accordion-group">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Token/index');?>'">
		                <i class="icon-user"></i>
		                企业用户管理
		              </a>
					</li>	
                    <li class="active accordion-group">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Goods/index');?>'">
		                <i class="icon-tag"></i>
		                标签产品管理
		              </a>
					</li>
                    <li class="active accordion-group">
		              <a class="accordion-toggle" onclick="javascript:window.location.href = '<?php echo U('System/Setinfo/feeset');?>'">
		                <i class="icon-cog"></i>
		                系统信息设置
		              </a>
					</li>
				</ul>			
				<br />		
			</div> <!-- /span3 -->

				
			<div class="span9">

				<div class="widget widget-table">
										
					<div class="widget-header">
						<i class="icon-th-list"></i>
						<h3>智能物联管理系统</h3>
					</div> <!-- /widget-header -->
					
					<div class="widget-content">
					
						<ol class="faq-list">
							
							<li>
								<div class="faq-icon"><div class="faq-number">1</div></div>
								<div class="faq-text">
									<h4>欢迎使用智能物联管理系统</h4>
									<p>系统版本v1.0</p>	
									
								</div>
									
							</li>
							
						</ol>						
					
					</div> <!-- /widget-content -->
					
				</div> <!-- /widget -->
			
			</div> <!-- /span9 -->
			
			
		</div> <!-- /row -->
		
	</div> <!-- /container -->
	
</div> <!-- /content -->
					
	
<div class="navbar navbar-fixed-bottom">
	<div class="navbar-inner" style="text-align: right;color:#fff;">
	智能物联网管理系统
	</div>
</div>

<!-- <script type="text/javascript" src="https://select2.github.io/dist/js/select2.min.js"></script> -->
<!-- <link href="https://select2.github.io/dist/css/select2.min.css" type="text/css" rel="stylesheet" /> -->
<!-- <style>.select2-search__field{height:30px;}</style> -->
<!-- <script>$("select").select2();</script> -->
    

<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->

<script src="<?php echo RES;?>/js/excanvas.min.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.pie.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.orderBars.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.resize.js"></script>
<script src="<?php echo STATICS;?>/artDialog/jquery.artDialog.js?skin=default"></script>
<script src="<?php echo STATICS;?>/artDialog/plugins/iframeTools.js"></script>


<!-- <script src="<?php echo RES;?>/js/water.js"></script> -->
<script src="<?php echo RES;?>/js/bootstrap.js"></script>
<script src="<?php echo RES;?>/js/charts/bar.js"></script>
  </body>

</html>