<?php if (!defined('THINK_PATH')) exit();?>
<!--   编辑功能模态框 -->  
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
    <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">      
      <input type="hidden" value="" id="editid" name="Flibid">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"
                aria-hidden="true" onclick="c_a()">×
        </button>
        <h4 class="modal-title">商城修改</h4>
      </div>
      <div class="modal-body">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">取消</button>
        <button type="submit" class="btn btn-primary" id="addsave">保存</button>
      </div>
    </form>
    </div>
  </div>