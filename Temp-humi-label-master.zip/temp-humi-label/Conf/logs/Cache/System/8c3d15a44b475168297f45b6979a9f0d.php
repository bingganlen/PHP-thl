<?php if (!defined('THINK_PATH')) exit();?><form method="post" action="<?php echo U('Address/editdo');?>">
             水站：<select name="token">
                      <option value="-1">请选择</option>
                      <?php if(is_array($res)): $i = 0; $__LIST__ = $res;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$res): $mod = ($i % 2 );++$i;?><option value="<?php echo ($res["token"]); ?>" <?php if($list["Ftoken"] == $res["token"] ): ?>selected="selected"<?php endif; ?>><?php echo ($res["wxname"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                   </select>
             寝室楼：<input name="Fname" type="text" id="Fname" value="<?php echo ($list["Fname"]); ?>">
             备注：<input name="Fremark"  type="text" id="Fremark" value="<?php echo ($list["Fremark"]); ?>">
               <input name="Fid"  type="hidden" id="Fid" value="<?php echo ($list["Fid"]); ?>" >

                        
                <input type="submit" value="提交">
</form>