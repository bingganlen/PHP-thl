<?php if (!defined('THINK_PATH')) exit();?>﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>溯云帮助</title>
<style type="text/css">
body,td,th {
	font-family: "微软雅黑", Arial, "Arial Black";
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
.top001 {
	background-color: #fff;
	position: fixed;
	top: 0;
	left: 0;
	width: 100%; z-index:999;
}
.biaoti {
	font-size: 22px;
	font-weight: normal;
	color: #435867;
	background-color: #ECECFB;
}
.shuomin001 {
	font-family: "微软雅黑", Arial, "Arial Black";
	font-size: 14px;
	color: #435867;
}
a {
	font-family: "微软雅黑", Arial, "Arial Black";
	font-size: 14px;
	color: #FFF;
}
#top002 {
	width: 100%;
	height: 154px;
}
#weizhi001 {
	position: static;
	width: 100%;
}
.maodian {
	top: 165px;
}
a:visited {
	color: #FFF;
	text-decoration: none;
}
a:hover {
	color: #FFF;
	text-decoration: none;
}
a:active {
	color: #FFF;
	text-decoration: none;
}
a:link {
	text-decoration: none;
}
a.tc:hover{ cursor:pointer;}
/*footer*/ 
 .d_public{padding-top:25px;width:365px;margin:auto; overflow:hidden; margin-bottom:15px; color:#6B6B6B;}
 .d_public_one{float:left;padding:0 16px; border-right:1px solid #6B6B6B;}
 .d_public_two{float:left;padding:0 16px; border-right:1px solid #6B6B6B;}
 .d_public_three{float:left;padding:0 16px; border-right:1px solid #6B6B6B;}
 .d_public_four{float:left;padding:0 16px; border-right:0px solid #6B6B6B;}
 
 .d_public_e{text-align:center;color:#6B6B6B;}
 .d_public_n{text-align:center;line-height:30px;margin-bottom:140px;color:#6B6B6B;}
</style>
</head>

<body style=" padding-top:165px">
<div class="top001">
  <table width="960" border="0" align="center" cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td height="110">
          <a href="http://www.fangweihao.com">
            <img src="./tpl/User/default/img/images/logo.jpg" width="187" height="62" alt=""/>
          </a>
          <!-- <a class="tc" style="margin-left:700px; color:#f00; font-size:16px;" onclick="javascript:history.back();" style="display:none;">退出帮助</a> -->
        </td>
      </tr>
    </tbody>
  </table>
  <table width="100%" border="0" cellspacing="0" cellpadding="0" background="./tpl/User/default/img/images/bg.jpg">
    <tbody>
      <tr>
        <td height="34"><table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
          <tbody>
            <tr>
              <td align="center"><a href="#a001">注册登录</a></td>
              <td align="center"><a href="#002">建立微商城</a></td>
              <td align="center"><a href="#003">购买溯云服务</a></td>
              <td align="center"><a href="#004">商品管理</a></td>
              <td align="center"><a href="#005">在线支付设置</a></td>
              <td align="center"><a href="#007">选择商城模版</a><a href="#006"></a></td>
              <td align="center"><a href="#008">管理商城订单</a></td>
              <td align="center"><a href="#006">绑定二维码</a></td>
              <td align="center"><a href="#009">销售商管理</a></td>
              <td align="center"><a href="#010">绑定微信公众号</a></td>
              </tr>
          </tbody>
        </table></td>
      </tr>
    </tbody>
  </table>
</div>
<div id="weizhi001">
  <table width="1053" border="0" align="center" cellpadding="1" cellspacing="1" bgcolor="#ddd">
    <tbody>
    <tr>
      <td width="1049" bgcolor="#FCFBFB"><table width="100%" border="0" cellpadding="20" cellspacing="0" class="biaoti">
        <tr>
          <td style=" position:relative;">注册登录溯云微商城管理系统
          <a style=" position:absolute; left:0; top:-170px;" name="a001" id="a001"></a>
          </td>
        </tr>
      </table>
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="20" class="shuomin001">
         
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/dlzc002.jpg" width="640" height="465"></td>
            <td valign="top"><p>登录http://www.fangweihao.com<br>
            如果尚未注册，可点击右侧的注册按钮，进入注册页面 </p></td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/dlzc003.jpg" width="640" height="465"></td>
            <td valign="top">按要求填写相应信息，完成注册</td>
          </tr>
        </table>
        <table width="100%" border="0" cellpadding="20" cellspacing="0" class="biaoti">
          <tr>
            <td style=" position:relative;">建立微商城<a style=" position:absolute; left:0; top:-170px;" name="002"id="002"></a></td>
          </tr>
        </table>
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="20" class="shuomin001">
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/cjsc001.jpg" width="640" height="296"></td>
            <td valign="top"><p>第一次登录溯云帐号，需创建微商城</p>
              <p>1.填写商城名称</p>
              <p>2.上传商城LOGO图片<br>
                （建议上传方形图片）</p>
              <p>3.选择商城类型，<br>
                生产型企业可以添加下级销售商，销售型企业不能添加下级销售商<br>
                （ 商城类型选择确定后不能修改）</p></td>
          </tr>
          <tr>
            <td><img src="./tpl/User/default/img/images/cjsc002.jpg" width="640" height="248"></td>
            <td valign="top">进入商城管理后，可点击首页的商城LOGO图片，进入修改页面，修改商城基本信息</td>
          </tr>
        </table>
        <table width="100%" border="0" cellpadding="20" cellspacing="0" class="biaoti">
          <tr>
            <td style=" position:relative;">购买溯云服务<a style=" position:absolute; left:0; top:-170px;" name="003"id="003"></td>
          </tr>
        </table>
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="20" class="shuomin001">
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/gmfw001.jpg" width="640" height="248"></td>
            <td valign="top"><p>如果试用效果满意，可以在试用期内（7天）在线购买，也可以联系代理商线下购买。</p>
              <p>在线购买溯云服务流程</p>
              <p>1） ： 进入首页，在线点击&ldquo;购买溯云服务&rdquo;</p></td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/gmfw002.jpg" width="640" height="548"></td>
            <td valign="top"><p>    第一步： 进入后，选择需要购买的服务，点击购买<br>
              溯云提供两种套餐服务<br>
              A：溯云移动商城套餐：只是单纯建立线上移动商城<br>
              B：防伪溯源移动商城套餐：主推产品，建立线上移动商城，并实现产品防伪溯源，打通线上线下</p></td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/gmfw003.jpg" width="640" height="625"></td>
            <td valign="top"><p>第二步：填写详细信息，完成企业注册<br>
              A：需要完整填写【企业名称，地址，电话，注册号】，提交文件和联系人信息，部分信息会自动作为企业产品防伪溯源信息的一部分</p></td>
          </tr>
          <tr>
            <td><img src="./tpl/User/default/img/images/gmfw006.jpg" width="640" height="208"><br>
              <img src="./tpl/User/default/img/images/gmfw005.jpg" width="640" height="223"></td>
            <td valign="top">提交的信息经公司审核员审核过后，审核结果将在前台页面上体现出来</td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/gmfw004.jpg" width="640" height="510"></td>
            <td valign="top"><p>  第三步： 填写合同并上传</p>
              <p>A：在线下载对应的合同，填写完成后上传。<br>
                B：点击&ldquo;完成在线购买&rdquo;<br>
                C：查看信息变成&ldquo;审核中...&quot;，请等待审核</p>
              <p>&nbsp;</p>
              <p>2）填写完成，信息传递到平台后台，溯云会专人审核信息。审核通过，会专人通知客户，客户也可以自行在此页面查看进度</p></td>
          </tr>
        </table>
        <table width="100%" border="0" cellpadding="20" cellspacing="0" class="biaoti">
          <tr>
            <td style=" position:relative;">商品管理<a style=" position:absolute; left:0; top:-170px;" name="004"id="004"></td>
          </tr>
        </table>
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="20" class="shuomin001">
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/spgl001.jpg" width="640" height="327"></td>
            <td valign="top">第一项：产品管理<br>
在商城中增减产品分类，在分类中增减产品，设置产品信息，设置产品防伪溯源信息等</td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/spgl002.jpg" width="640" height="238"></td>
            <td valign="top"><p>首先：新增分类<br>
                1）点击&ldquo;新增分类&rdquo; ：此分类是提供使用者的一级分类，使用者可以根据产品情况自行将同种产品分类。后期我们会直接给出已经设定好的分类，用户只需要选择就可<br>
              </p></td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/spgl003.jpg" width="640" height="430"></td>
            <td valign="top"><p>2）分类需要填写名称，带有红色星号的为必填。分类图片是显示分类时的缩略图。排序则是当多个分类同时的排序设置。以数字大小排序</p></td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/spgl004.jpg" width="640" height="196"></td>
            <td valign="top">其次：新增产品<br>
1）分类完成后，可以在分类中看到<br>
2）点击分类中右侧的&ldquo;商品管理&rdquo;，进入<br></td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/spgl006.jpg" width="640" height="191"></td>
            <td valign="top"><p>3）选择&ldquo;添加商品&rdquo;，在基本信息中填写<br>
              4）除开手动添加，也可以采用选择文件的方法构建产品：点击&ldquo;下载模板&rdquo;，根据模板填写自己的产品信息。完成后保存，点击&ldquo;选择文件&rdquo;，然后点击&ldquo;上传商品&rdquo;即可实现。<br>
              </p></td>
          </tr>
          <tr>
            <td><img src="./tpl/User/default/img/images/spgl007.jpg" width="640" height="1085"></td>
            <td valign="top"><p>5）填写产品名称，价格【售价】等，库存也尽量写。<br>
              6）产品图片：此为商城中产品展示的缩略图。<br>
              7）展示图可以多张，最少1张。是进入产品页面后的轮播展示图，类似产品banner。展示按照图的先后顺序展示<br>
              8）排序：各个不同产品的排序，也是按照填写的数字大小。相同数字的随机排列<br>
              9）详情：图文展示区，用于产品的细节展示，类似淘宝的产品详情。可以插入图片，声音等</p></td>
          </tr>
          <tr>
            <td><img src="./tpl/User/default/img/images/spgl008.jpg" width="640" height="460"></td>
            <td valign="top"><p>第三：添加防伪溯源的信息<br>
              1）点击&ldquo;防伪溯源&rdquo;<br>
              2）在基本防伪信息中，自动展示部分信息，此信息来自客户填写的厂商信息，无法修改<br>
              3）使用者根据自己产品的特点，增加需要展示的溯源信息【原生产厂可以填写防伪，非生产上只能叫做溯源】。<br>
              溯源属性x【属性名称，比如重量】【溯源信息，比如10kg】 </p></td>
          </tr>
          <tr>
            <td><img src="./tpl/User/default/img/images/spgl009.jpg" width="640" height="265"></td>
            <td valign="top"><p>第四：扫码页面链接设置<br>
              1）我们的二维码防伪标签，扫码后可以展示各种不同功能按键给消费者，这些功能的设定在此处<br>
              2）&ldquo;商城地址&rdquo;：消费者点击此按键，可以直接进入我们建立的这个商城，由此查看更多的商家产品。此处设置按键链接的地址。用户可以直接点击右侧的&ldquo;自动添加地址&rdquo;自动获取。也可以填写比如自己的淘宝店地址<br>
              3）&ldquo;购买地址&rdquo;：消费者点击此按键，可以直接进入购买的产品在此商城中的购买页面，方便二次购买。此处设置按键链接的地址。用户可以直接点击右侧的&ldquo;自动添加地址&rdquo;自动获取<br>
              4）说明地址：点击&ldquo;自建说明书&rdquo;可以自己生成一个展示页面，将地址传递给按键，也可以任意填写 </p></td>
          </tr>
        </table>
        <table width="100%" border="0" cellpadding="20" cellspacing="0" class="biaoti">
          <tr>
            <td style=" position:relative;">在线支付设置<a style=" position:absolute; left:0; top:-170px;" name="005"id="005"></td>
          </tr>
        </table>
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="20" class="shuomin001">
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/zxzf001.jpg" width="640" height="327"></td>
            <td valign="top"><p>在线支付设置：</p>
              <p> </p></td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/zxzf002.jpg" width="640" height="841"></td>
            <td valign="top">1）使用者可以采用多种支付方式，但是每种支付都需要使用者去申请。比如像淘宝申请支付宝...<br></td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/zxzf003.jpg" width="640" height="425"></td>
            <td valign="top">2）将申请下来的账户信息填写开通即可</td>
          </tr>
        </table>
       
        <table width="100%" border="0" cellpadding="20" cellspacing="0" class="biaoti">
          <tr>
            <td style=" position:relative;">选择商城模版<a style=" position:absolute; left:0; top:-170px;" name="007"id="007"></td>
          </tr>
        </table>
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="20" class="shuomin001">
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/moban001.jpg" width="640" height="354"></td>
            <td valign="top">选择商城模版，确定商城首页样式</td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/moban002.jpg" width="640" height="486"></td>
            <td valign="top"><p>商城模版分为三类<br>
            1）有商城首页幻灯片的模版，这类模版需要上传首页幻灯片才能达到最佳展示效果（如：模版133、98、97、96、95、92、91、87、77、27、16、10、8等）<br>
            2）有商城
            轮播背景图的模版，这类模版需要上传轮播背景图才能达到最佳展示效果（如：模版104、42、15、14、13等）<br>
            3）
            无幻灯片务轮播图模版，这类模版无需幻灯片和轮播图即可正常展示（如：模版125、11等）</p>
              <p>要上传商城首页幻灯片或商城轮播背景图，请点击模版上方的按钮<br>
              </p></td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/moban003.jpg" width="640" height="248"></td>
            <td valign="top">进入幻灯片管理界面，点击添加幻灯片，不限添加数量</td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/moban004.jpg" width="640" height="374"></td>
            <td valign="top"><p>按照网页中的输入框填入相应信息，保存后即可添加成功。（请注意图片大小要求）</p>
              <p>商城轮播背景图上传方法与此相同</p></td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/moban005.jpg" width="640" height="465"></td>
            <td valign="top">商城模版及轮播图、幻灯片设置完成后，可点击页面右侧的商城预览，预览商城效果</td>
          </tr>
          <tr>
            <td><img src="./tpl/User/default/img/images/moban006.jpg" width="640" height="459"></td>
            <td valign="top">可用手机扫描右侧的二维码，在手机上预览商城效果，感觉更佳</td>
          </tr>
        </table>
        <table width="100%" border="0" cellpadding="20" cellspacing="0" class="biaoti">
          <tr>
            <td style=" position:relative;">管理商城订单<a style=" position:absolute; left:0; top:-170px;" name="008"id="008"></td>
          </tr>
        </table>
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="20" class="shuomin001">
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/ddgl001.jpg" width="640" height="275"></td>
            <td valign="top"><p>商城购物的订单管理：</p>
              <p> </p></td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/ddgl002.jpg" width="640" height="300"></td>
            <td valign="top">1）可以看到目前的全部订单</td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/ddgl003.jpg" width="640" height="421"></td>
            <td valign="top">2）可以处理，查看详情</td>
          </tr>
        </table>
         <table width="100%" border="0" cellpadding="20" cellspacing="0" class="biaoti">
          <tr>
            <td style=" position:relative;">绑定二维码<a style=" position:absolute; left:0; top:-170px;" name="006"id="006"></td>
          </tr>
        </table>
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="20" class="shuomin001">
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/bdewm001.jpg" width="640" height="413"></td>
            <td valign="top"><p>绑定二维码：</p>
              <p>         1）我们提供给使用者的二维码，用于防伪溯源。需要在这里将二维码和产品一一绑定【赋码】，达到真正一品一码的作用<br>
                2）点击首页菜单的&ldquo;绑定二维码&rdquo;<br>
              </p></td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/bdewm002.jpg" width="640" height="386"></td>
            <td valign="top"><p>3）所有的已经分配给使用者的二维码都可以在下面显示出来，其中&ldquo;未绑定二维码&rdquo;是尚未使用的二维码，而&ldquo;绑定分销商&rdquo;是已经绑定使用的二维码，可以在这里绑定和修改分销商<br>
4）首先选择需要绑码的品牌分类和产品，点击&ldquo;确认选择&rdquo;<br>
5）其次在下面的二维码中输入需要绑定的二维码，可以有几种方法<br>
A:批量顺序绑码，输入起始号，数量，自动得到截至号，选择绑定日期，按下面的&ldquo;批量绑码&rdquo;实现<br>
B:选择绑码，点击左侧的选择框，可以单选，多选，点击下面的绑定选中的标签，实现</p></td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/bdewm003.jpg" width="640" height="366"></td>
            <td valign="top"><p>绑定分销商：</p>
              <p>  1）点击进入&ldquo;绑定分销商&ldquo;，可以查看已经绑定的二维码，可以将二维码分配给下级代理经销商。<strong> </strong></p></td>
          </tr>
        </table>
        <table width="100%" border="0" cellpadding="20" cellspacing="0" class="biaoti">
          <tr>
            <td style=" position:relative;">销售商管理<a style=" position:absolute; left:0; top:-170px;" name="009"id="009"></td>
          </tr>
        </table>
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="20" class="shuomin001">
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/xssgl001.jpg" width="640" height="272"></td>
            <td valign="top"><p>销售商管理：</p>
              <p>  1）使用者可能有自己的销售渠道，包括下级分销商，可以在此处管理<br>
              </p></td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/xssgl002.jpg" width="640" height="553"></td>
            <td valign="top">2）分为&rdquo;代理商&ldquo;和&rdquo;渠道商&ldquo;，目前均暂定为&rdquo;代理商&ldquo;<br>
3）填写分销商的名称和token【即此分销商的商城唯一标识号】<br></td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/xssgl003.jpg" width="640" height="457"></td>
            <td valign="top">4）上级商家可以方便的分配产品，标签给分销商<strong></strong></td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/xssgl004.jpg" width="640" height="331"></td>
            <td valign="top"><p>5）分配按照类别进行，将来可以根据产品单选</p></td>
          </tr>
        </table>
        <table width="100%" border="0" cellpadding="20" cellspacing="0" class="biaoti">
          <tr>
            <td style=" position:relative;">绑定微信公众号<a style=" position:absolute; left:0; top:-170px;" name="010"id="010"></td>
          </tr>
        </table>
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="20" class="shuomin001">
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/gzwx001.jpg" width="640" height="548"></td>
            <td valign="top"><p>绑定微信：</p>
              <p> 如果需要将建立的移动商城和微信号绑定，成为微信商城，可以根据下面的说明进行</p></td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/gzwx002.jpg" width="640" height="371"></td>
            <td valign="top">点击设置微信公众号-关注时自动回复，可设置用户关注公众号时自动发动给他的信息</td>
          </tr>
          <tr>
            <td width="640"><img src="./tpl/User/default/img/images/gzwx004.jpg" width="640" height="600"></td>
            <td valign="top">关注时回复信息，可以是文本、也可以是图文混编信息，可根据具体需求自行选择</td>
          </tr>
        </table></td>
    </tr>
  </tbody>
</table>
  <br>
  <hr>
  <br>
  <table width="960" border="0" align="center" cellpadding="0" cellspacing="0" class="shuomin001">
    <tr>
      <td align="center"><!--公共底-->

        <div class="d_public">
    <div class="d_public_one"><a href="http://www.fangweihao.com/index.php?g=Home&m=Index&a=about" style=" color:#f00;">关于溯云</a></div>
    <div class="d_public_two"><a href="<?php echo U('Index/helpcen');?>" style=" color:#f00;">帮助中心</a></div>
    <div class="d_public_three"><a href="http://www.fangweihao.com/index.php?g=Home&m=Index&a=contact" style=" color:#f00;">联系我们</a></div>
    <div class="d_public_four"><a href="#" style=" color:#f00;">常见问题</a></div>
</div>
<div class="d_public_e">Copyright  2015 cloud315.org All Rights Reserved</div>
<div class="d_public_n">copyright@cloud315.org</div></td>
    </tr>
  </table>
  <p>&nbsp;</p>
</div>
</body>
</html>