<?php if (!defined('THINK_PATH')) exit();?><style type="text/css">
  
  .g_b {
  cursor: pointer;
  height: 30px;
  background: #44BB00;
  border: none;
  border-radius: 1px;
  color: #fff;
}
</style>
<form action="<?php echo U('Worder/ordertimesdo');?>" method="post">
  每天下单次数:<input type="text" name="ordertimes" style="height:30px;margin-top:50px" value="<?php echo ($ordertims["Fordertimes"]); ?>">
  <input type="submit" value="提交" class="g_b"  />
</form>