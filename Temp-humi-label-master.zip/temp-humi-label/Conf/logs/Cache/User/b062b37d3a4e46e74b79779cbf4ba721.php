<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/css_home_pc.css"/>
<title>智能物联管理系统企业中心</title>
<script type="text/javascript" src="<?php echo RES;?>/js/jquery.min.js"></script>
<script src="<?php echo RES;?>/js/layer.js"></script>
<style>
.wel{cursor: pointer;position: relative;}
.wel:hover .move_b{opacity: 1;top:18px;}
.move_b {width: 80px;height:58px;background:#435867;position: absolute;opacity: 0;top:-5px;left:35px;transition:0.5s;-webkit-transition:.5s;-moz-transition:.5s;}
.move_b a{text-align: center;line-height: 26px;font-size: 14px;color: #fff;display: block;} 
.active{background:#fff; color:#435867;border-top:1px solid #435867;}
</style>
</head>
<body>
<!--header-->
<!--
<div class="mengceng_bq"></div>
-->
<div class="cj_header">
  <img class="logo_size" src="img/logo1.png" alt="logo"/><span class="logo_font">智能物联网管理系统</span>
    <div class="cj_h_r">
        <div class="wel">欢迎，<?php echo (session('uname')); ?>
        <div class="move_b">
        <a href="<?php echo U('Index/edit', array('token' => $token));?>">修改</a>
        <a href="/index.php?g=Home&m=Index&a=logout">退出</a>
        </div>
    </div>
        <div class="fw_time">服务到期时间:<?php echo (date("Y-m-d",$thisUser["viptime"])); ?></div>
    </div>
</div>
<div class="cj_nav">
  <div class="f1_line"></div>
    <div class="nav_k">
        <a class="nav_font" href="<?php echo U('Wlist/index', array('token' => $token));?>" id="Wlist">统计报表</a>
        <a class="nav_font" href="<?php echo U('Store/product', array('token' => $token));?>" id="Store">标签管理</a>
        <a class="nav_font" href="<?php echo U('Work/index', array('token' => $token));?>" id="Work">用户管理</a>
        <!-- <a class="nav_font nav_c " href="<?php echo U('Wlist/index', array('token' => $token));?>">统计信息</a> 企业中心Index/frame          -->
        
    </div>
  </div>       

</div>
<script>
$(document).ready(function(){
var url=window.location.href;
var reg=/m=[a-z]*/i;
var arr=url.match(reg);
var str=arr[0].substr(2);
$("#"+str).addClass("active");
})
function drop_confirm(msg, url){
    if(confirm(msg)){
        window.location = url;
    }
}
</script>

<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/shou_ye.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/shangpin_guan_li.css"/>
<script src="/tpl/static/echart/dist/echarts.js"></script>
<script type="text/javascript" src="./tpl/static/laydate/laydate.js"></script>
<!--内容-->
<div class="sy_nr">  
   <div class="tjb">标签详情-<?php echo ($labelid); ?></div>

   <div class="sx">
    <!-- <form method="post" action=""> -->
    <span class="sx_time">运单批号：</span>
    <select class="lx_xl" id="barcode" name="barcode">        
        <option value="" style="background:#1e90ff"><?php echo ($label_sel); ?></option>
        <?php if(is_array($barcode)): $i = 0; $__LIST__ = $barcode;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?><option value="<?php echo ($list["confId"]); ?>"><?php echo ($list["barCode"]); ?>-<?php echo ($list["id"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
    </select>
    <span class="logo_sc b_b" id="conf_info" style="padding:5px 10px">运单配置/数据导出</span>
      <!-- <span class="sx_time">筛选日期：</span> -->
        <input class="logo_sr" type="text" value="<?php echo (date("Y-m-d",$chart_st)); ?>" id="s" onclick="laydate()" style="text-indent:5px" />
        <span style="vertical-align:middle; padding:0 5px;">至</span>
        <input class="logo_sr" type="text" value="<?php echo (date("Y-m-d",$chart_end)); ?>" id="e" onclick="laydate()" style="text-indent:5px"/>
        <span class="g_b" id="tse" style="width:80px;margin-left:16px;text-align: center;display:inline-block;line-height: 28px" >查询</span>
    <!-- </form> -->       
        <!--<input class="logo_sc b_b" type="button" value="昨&nbsp;&nbsp;天" onclick="a('<?php echo ($zt); ?>','20<?php echo ($now); ?>')"/>
        <input class="logo_sc b_b" type="button" value="最近7天" onclick="a('<?php echo ($zw); ?>','20<?php echo ($now); ?>')"/>
        <input class="logo_sc b_b" type="button" value="最近30天" onclick="a('<?php echo ($zm); ?>','20<?php echo ($now); ?>')"/>-->   
   </div>
<div class="sx_product">
    <form method="post" action="">
    <span class="sx_time"><strong>高级查询：</strong></span>
        <input class="logo_sr" type="text" name="username" value="" placeholder="上传人查询">
        <input class="logo_sr" style="margin-left:22px;" type="text" value="" id="uptime" name="uptime" placeholder="上传时间查询" onclick="laydate()"/>    
        <select class="lx_xl" style="margin-left:22px;" id="isover" name="isover">
        <option value="-1">有无报警</option>
        <option value="1">有</option>
        <option value="0">无</option>
        <option value="2">已处理</option>
        </select>
    <input class="find_anniu g_b" type="submit" style="" value="查询"/>
    </form>
    <div class="table_b_tu"  id="dismain" style="text-align:center;line-height:440px;" >暂无数据</div>
</div>



<!-- 新增当日查看 -->
  <!-- <div style="height:50px; line-height:50px; width:auto;">
    <div style="width:25%; height:50px; line-height:50px;float:left;">
        <input type="button" value="今日订单数:<?php echo (($total)?($total):"0"); ?>" style="border:1px solid #oof; width:200px; height=50px; line-height:48px;">
    </div>
    <div style="width:25%; height:50px; line-height:50px;float:left;">
        <input type="button" value="等待派单数：<?php echo (($num1)?($num1):"0"); ?>" style="border:1px solid #oof; width:200px; height=50px; line-height:48px;">
    </div>
    <div style="width:25%; height:50px; line-height:50px;float:left;">
         <input type="button" value="配送中数：<?php echo (($num2)?($num2):"0"); ?>" style="border:1px solid #oof; width:200px; height=50px; line-height:48px;">
    </div>
     <div style="width:25%; height:50px; line-height:50px;float:left;">
        <input type="button" value="已完成数：<?php echo (($num3)?($num3):"0"); ?>" style="border:1px solid #oof; width:200px; height=50px; line-height:48px;">
    </div>
  </div> -->

<!--表格--> 
  <!-- <div class="table_1" > -->
     <table class="spgl_table">
        <tr>
        <th class="spgl_t_b">上传账号</th>
        <th class="spgl_t_b">上传时间</th>
        <th class="spgl_t_b">采样起始时间</th>
        <th class="spgl_t_b">采样截至时间</th>
        <th class="spgl_t_b">是否报警</th>        
        <th class="spgl_t_b">记录和固件</th>
        <th class="spgl_t_b">本次数据</th>
        </tr>
        <?php if(is_array($records)): $i = 0; $__LIST__ = $records;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr class="h_bg">
            <td class="spgl_t_b"><?php echo ($vo["username"]); ?></td>
            <td class="spgl_t_b"><?php echo (date("Y-m-d H:i:s",$vo["uptime"])); ?></td>
            <td class="spgl_t_b"><?php echo (date("Y-m-d H:i:s",$vo["startDate"])); ?></td>
            <td class="spgl_t_b"><?php echo (date("Y-m-d H:i:s",$vo["endDate"])); ?></td>
            <td class="spgl_t_b"><?php if($vo["isover"] < 1): ?>无<?php elseif($vo["isover"] == 1): ?>有<?php else: ?>已处理<?php endif; ?></td>
            <td class="spgl_t_b"><a href="<?php echo U('Store/record_detail',array('id'=>$vo['id']));?>">点击查看</a></td>
            <td class="spgl_t_b"><a href="#" id="<?php echo ($vo["id"]); ?>" onclick="chartline(this.id)">查看图表</a></td>
        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
    </table>
    
<div class="test1" id="main" style="width:auto;height:240px;margin-top:50px;display:none"></div>
<div class="test1" id="timemain" style="width:auto;height:240px;margin-top:50px;display:none"></div>
</div>

<script type="text/javascript">
    //运单配置信息按钮
    $("#conf_info").click(function(){
        var barcode_id = $("#barcode option:selected").text();
        var id = barcode_id.substr(barcode_id.lastIndexOf("-")+1);
        //alert(id);
        window.location.href="<?php echo U('Store/conf_detail');?>&id="+id;

    })
    //运单批号改变
    $("#barcode").change(function(){
        var barcode_id=$("#barcode option:selected").text();
         //alert(confid);
        var id = barcode_id.substr(barcode_id.lastIndexOf("-")+1);
       window.location.href="<?php echo U('Store/detail',array('token'=>$token,'labelid'=>$labelid));?>&id="+id;
    })
</script>

<script type="text/javascript">
    // Step:3 conifg ECharts's path, link to echarts.js from current page.
    // Step:3 为模块加载器配置echarts的路径，从当前页面链接到echarts.js，定义所需图表路径
$(document).ready(function(){ 
    
        var echartx=<?php echo ($echart); ?>;    
        var markline=<?php echo ($markline); ?>;       
    //console.log(markline['humLowLimit']);
    var time=[];
    var temps=[];
    var hums=[];
    $.each(echartx,function(index,item){
        //console.log(timeFormat(parseInt(item.time)*1000));        
        time.push(timeFormat(parseInt(item.time)*1000));
        temps.push(item.temps);
        hums.push(item.hums);
    })
    
    var mltdata=[];
    var mlhdata=[];
    mltdata.push([{name:'温度下限:'+markline['temLowLimit'],yAxis:markline['temLowLimit'],xAxis:time[0]},{yAxis:markline['temLowLimit'],xAxis:time[time.length-1]}],[{name:'温度上限:'+markline['temUpLimit'],yAxis:markline['temUpLimit'],xAxis:time[0]},{yAxis:markline['temUpLimit'],xAxis:time[time.length-1]}]);
    mlhdata.push([{name:'湿度下限:'+markline['humLowLimit'],yAxis:markline['humLowLimit'],xAxis:time[0]},{yAxis:markline['humLowLimit'],xAxis:time[time.length-1]}],[{name:'湿度上限:'+markline['humUpLimit'],yAxis:markline['humUpLimit'],xAxis:time[0]},{yAxis:markline['humUpLimit'],xAxis:time[time.length-1]}]);
    //console.log(mlhdata[0]);
    require.config({
        paths: {
            echarts: '/tpl/static/echart/dist'
        }
    });
    
    // Step:4 require echarts and use it in the callback.
    // Step:4 动态加载echarts然后在回调函数中开始使用，注意保持按需加载结构定义图表路径
    require(
        [
            'echarts', 
            'echarts/chart/bar',
            'echarts/chart/line'
        ],
        function (ec) {
            var myChart = ec.init(document.getElementById('dismain'));
            var ecConfig = require('echarts/config');
            
            var option = {
                
                title : {
                        text: '标签数据统计',
                        subtext: '<?php echo ($labelid); ?>'
                    },
                tooltip : {
                    trigger: 'axis'
                },
                legend: {
                    data:['温度','湿度']
                },
                toolbox: {
                    show : true,
                    feature : {                        
                        saveAsImage : {show: true}
                    }
                },
                xAxis: [{
                        type : 'category',                        
                        data :time              
                    }],
                yAxis: [
                {
                        type : 'value',
                        splitArea : {show : true}
                    }],
                series: [
                    {
                        name:'温度',
                        type:'line',                        
                        data:temps,
                        markLine:{
                            silent:false,                             
                            data:mltdata        
                        }
                        
                    },
                    {
                        name:'湿度',
                        type:'line',                        
                        data:hums,
                        markLine:{
                            silent:false,                    
                            data:mlhdata                   
                        }                                       
                    },                    
                    ],                
            };
            myChart.setOption(option,true);
            //var picinfo=myChart.getDataURL();
            //console.log(picinfo);
            //if(picinfo){
            //  $.ajax({
            //    type:"post",
            //    data:{'baseimg':picinfo},
            //    url:"<?php echo U('Store/pdf_file');?>",
            //    success:function(data){
            //        console.log(data);
            //    },
            //    error:function(err){
            //        console.log('图片保存失败');
            //    }
            //  })
            //}else{
            //    alert('图片获取失败');
            //}
        }
        ); 
})   
    function add0(m){return m<10?'0'+m:m }
    function timeFormat(timestamp){
            var time = new Date(timestamp);
            var year = time.getFullYear();
            var month = time.getMonth()+1;
            var date = time.getDate();
            var hours = time.getHours();
            var minutes = time.getMinutes();
            var seconds = time.getSeconds();
            var str=year+""+add0(month)+""+add0(date)+"/"+add0(hours)+":"+add0(minutes)+":"+add0(seconds);
            return str;
        }
    </script>
    <script type="text/javascript">
            function chartline(id){
            //$("#dismain").hide();
            $("#main").show();
            var names = [];//类别数组（实际用来盛放X轴坐标值）
            var series1 = [];
            var series2 = [];
            //请求数据
            var barcode_id = $("#barcode option:selected").text();
            var cid = barcode_id.substr(barcode_id.lastIndexOf("-")+1);
            
            $.ajax({
                type:'post',
                url:"<?php echo U('Store/chartline');?>",
                data:{'id':id, 'cid':cid}, //id是recordset表id,cid是confset表的id           
                success:function(result){
                    //console.log(result);
                    if(!result){
                        $("#main").html("无返回数据");
                        return false;
                    }
                    $.each(JSON.parse(result), function(index,item){
                        
                        names.push(timeFormat(parseInt(item.time)*1000));
                        series1.push(item.temps);
                        series2.push(item.hums);
                    })
                    //myChart.hideLoading();
                    //绘制图表
            require.config({
                paths: {
                    echarts: '/tpl/static/echart/dist'
                }
            });
            require(
            [
                'echarts', 
                'echarts/chart/bar',
                'echarts/chart/line'
            ],
            function (ec) {
            var myChart = ec.init(document.getElementById('main'));
            
            var option={
             title: {
                 text: '温湿度数据'
             },
             tooltip: {trigger:'axis'},
             legend: {
                 data:['温度', '湿度']
             },
             toolbox: {
                 show: true,
                 feature: {                    
                    saveAsImage:{show:true}
                 }
             },
             calculable:true,
             xAxis: {
                 type:'category',
                 axisLabel:{interval:0},
                 data: []
             },
             yAxis: {
                 type:'value',
                 splitLine:{show:false},
                 name:''
             },
             series: [{
                 name: '温度',
                 type: 'line',
                 symbol:'circle',//设置折线图中表示每个坐标点的符号 emptycircle：空心圆；emptyrect：空心矩形；circle：实心圆；emptydiamond：菱形
                 data: []
             },
             {  
                name: '湿度',
                 type: 'line',
                 symbol:'diamond',//设置折线图中表示每个坐标点的符号 emptycircle：空心圆；emptyrect：空心矩形；circle：实心圆；emptydiamond：菱形
                 data: []
             }]
            };
             myChart.setOption({
                xAxis: {data: names},
                series:[{data: series1},{data: series2}]
            });
            myChart.setOption(option);
        })
                   
                },
                error:function(errorMsg){
                    alert(errorMsg);
                }
            })
        }
        //按时间查询本订单本批次的数据
        $("#tse").click(function(){
            $("#timemain").show();
            var start=$("#s").val();
            var sdate=new Date(start+" 00:00:00");
            var starttime=sdate.getTime()/1000;            
            var end=$('#e').val();
            var edate=new Date(end+" 23:59:59");
            var endtime=edate.getTime()/1000;
            if(starttime>endtime){
                alert('起始时间应大于截止时间');
                return false;
            }
            //alert(endtime);
            var barcode_id = $("#barcode option:selected").text();
            var cid = barcode_id.substr(barcode_id.lastIndexOf("-")+1);
            
            $.ajax({
                type:"post",
                url:"<?php echo U('Store/timechart');?>",
                data:{'cid':cid,'starttime':starttime,'endtime':endtime},                
                success:function(response){
                    //console.log(response);                                   
                    if(!response){
                        $("#timemain").html("无返回数据");
                        return false;
                    }
                    if(JSON.parse(response).code==0){
                        alert(JSON.parse(response).info);
                        return false;
                    }
                    var names = [];
                    var series1 = [];
                    var series2 = [];
                    $.each(JSON.parse(response), function(index,item){                        
                        names.push(timeFormat(parseInt(item.time)*1000));
                        series1.push(item.temps);
                        series2.push(item.hums);
                    })                    
            require.config({
                paths: {
                    echarts: '/tpl/static/echart/dist'
                }
            });
            require(
            [
                'echarts', 
                'echarts/chart/bar',
                'echarts/chart/line'
            ],
            function (ec) {
            var myChart = ec.init(document.getElementById('timemain'));
            
            var option={
             title: {
                 text: start+'至'+end+'温湿度数据'
             },
             tooltip: {trigger:'axis'},
             legend: {
                 data:['温度', '湿度']
             },
             toolbox: {
                 show: true,
                 feature: {                    
                    saveAsImage:{show:true}
                 }
             },
             calculable:true,
             xAxis: {
                 type:'category',
                 axisLabel:{interval:0},
                 data: []
             },
             yAxis: {
                 type:'value',
                 splitLine:{show:false},
                 name:''
             },
             series: [{
                 name: '温度',
                 type: 'line',                 
                 data: []
             },
             {  
                name: '湿度',
                 type: 'line',                 
                 data: []
             }]
            };
             myChart.setOption({
                xAxis: {data: names},
                series:[{data: series1},{data: series2}]
            });
            myChart.setOption(option);
        })
                },
                error:function(error){
                alert(error);
                }
            })
        })        
    </script>
<!--公共底-->

<hr>
<div class="d_public">
  <!-- <div class="d_public_one"><a href="http://www.cloud315.org/">关于溯云</a></div> -->
    <!-- <div class="d_public_two"><a href="<?php echo U('Index/helpcen');?>">帮助中心</a></div> -->
    <div class="d_public_three"><a href="http://www.megain.com/">联系我们</a></div>
    <div class="d_public_four"><a href="#">常见问题</a></div>
</div>
<div class="d_public_e">Copyright © 2018 www.megian.com &nbsp;All Rights Reserved</div>
<!-- <div class="d_public_n">copyright@cloud315.org</div> -->

</body>
</html>