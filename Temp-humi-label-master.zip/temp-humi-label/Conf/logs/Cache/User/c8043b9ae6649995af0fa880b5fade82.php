<?php if (!defined('THINK_PATH')) exit();?><!doctype html>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/aa.css"/>
<link rel="stylesheet" type="text/css" href="css/bb.css"/>
<script type="text/javascript" src="<?php echo RES;?>/js/jquery.min.js"></script>

<script src="/tpl/static/upyun.js?2013"></script>
<script type="text/javascript" src="<?php echo RES;?>/js/qrcode.js"></script>
<script type="text/javascript"  src="<?php echo RES;?>/js/jquery.qrcode.js"></script>

<title>分配送水工</title>
<style>
    
.lx_xl {
width: 190px;
height: 30px;
border: 1px solid #CCCCCC;
vertical-align: middle;
margin-right: 30px;
}

.g_b {
    cursor: pointer;
    height: 30px;
    background: #4B0 none repeat scroll 0% 0%;
    border: medium none;
    border-radius: 1px;
    color: #FFF;
}
</style>
</head>


</style>

<body class="tcym_zong" style="">
<form method="post" action="<?php echo U('Worder/sendworkdo2',array('token'=>$token));?>">
<input type="hidden" name="orderid" value="<?php echo ($orderid); ?>">
<div class="tcym" style="margin:20px auto">  
    <!--弹框-->
    支付方式:
    <select class="lx_xl" id="dis" name="pay">
        
           
           
            <option value="0" <?php if($res["Ftype"] == '0'): ?>selected="selected"<?php endif; ?> >未支付</option>
             <option value="1" <?php if($res["Ftype"] == '1' and $res["Fpaytype"] == '0'): ?>selected="selected"<?php endif; ?>>水票</option>
              <option value="2" <?php if($res["Ftype"] == '1' and $res["Fpaytype"] == '1'): ?>selected="selected"<?php endif; ?>>现金</option>
           
    </select>

</div>
<div>
    <input class="find_anniu g_b" style="" value="设置" type="submit">
</div>
</form>

</body>


</html>