<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/css_home_pc.css"/>
<title>智能物联管理系统企业中心</title>
<script type="text/javascript" src="<?php echo RES;?>/js/jquery.min.js"></script>
<script src="<?php echo RES;?>/js/layer.js"></script>
<style>
.wel{cursor: pointer;position: relative;}
.wel:hover .move_b{opacity: 1;top:18px;}
.move_b {width: 80px;height:58px;background:#435867;position: absolute;opacity: 0;top:-5px;left:35px;transition:0.5s;-webkit-transition:.5s;-moz-transition:.5s;}
.move_b a{text-align: center;line-height: 26px;font-size: 14px;color: #fff;display: block;} 
.active{background:#fff; color:#435867;border-top:1px solid #435867;}
</style>
</head>
<body>
<!--header-->
<!--
<div class="mengceng_bq"></div>
-->
<div class="cj_header">
  <img class="logo_size" src="img/logo1.png" alt="logo"/><span class="logo_font">智能物联网管理系统</span>
    <div class="cj_h_r">
        <div class="wel">欢迎，<?php echo (session('uname')); ?>
        <div class="move_b">
        <a href="<?php echo U('Index/edit', array('token' => $token));?>">修改</a>
        <a href="/index.php?g=Home&m=Index&a=logout">退出</a>
        </div>
    </div>
        <div class="fw_time">服务到期时间:<?php echo (date("Y-m-d",$thisUser["viptime"])); ?></div>
    </div>
</div>
<div class="cj_nav">
  <div class="f1_line"></div>
    <div class="nav_k">
        <a class="nav_font" href="<?php echo U('Wlist/index', array('token' => $token));?>" id="Wlist">统计报表</a>
        <a class="nav_font" href="<?php echo U('Store/product', array('token' => $token));?>" id="Store">标签管理</a>
        <a class="nav_font" href="<?php echo U('Work/index', array('token' => $token));?>" id="Work">用户管理</a>
        <!-- <a class="nav_font nav_c " href="<?php echo U('Wlist/index', array('token' => $token));?>">统计信息</a> 企业中心Index/frame          -->
        
    </div>
  </div>       

</div>
<script>
$(document).ready(function(){
var url=window.location.href;
var reg=/m=[a-z]*/i;
var arr=url.match(reg);
var str=arr[0].substr(2);
$("#"+str).addClass("active");
})
function drop_confirm(msg, url){
    if(confirm(msg)){
        window.location = url;
    }
}
</script>

 <style>
  .old_2{background:#fff; color:#435867;}  
  .tjb3 input, select{margin-right: 28px}
  .arr{width:15px;display: inline-block;}
  .uparr{width:13px;
    transform:rotate(180deg);
    -ms-transform:rotate(180deg); /* Internet Explorer */
    -moz-transform:rotate(180deg); /* Firefox */
    -webkit-transform:rotate(180deg); /* Safari 和 Chrome */
    -o-transform:rotate(180deg); /* Opera */
  }
  .dowarr{width:13px;margin:3px -1px 0 0;}
</style>
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/shangpin_guan_li.css"/>
<script src="<?php echo STATICS;?>/jquery-1.4.2.min.js" type="text/javascript"></script>

<!--内容-->
<div class="scgl_nr" style="height:580px">
	
    <div class="tjb2">标签管理
    <!-- <a href="<?php echo U('Store/index',array('token'=>$token,'catid'=>$catid));?>"><input class="logo_sc_sc b_b" type="button" value="返回上一级"/></a> -->
    </div>
    <div class="tjb3">
       <form method="post" action="">
        <input type="text" name="labelid" placeholder="请输入标签号查询">
        <select  name="labeltype">
            <option value="-1">所有类型</option>
            <?php if(is_array($labeltype)): $i = 0; $__LIST__ = $labeltype;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$lbt): $mod = ($i % 2 );++$i;?><option value="<?php echo ($lbt["tagtype"]); ?>"><?php echo ($lbt["tagtype"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
        </select>
        <input type="text" name="barcode" placeholder="运单批次查询">
        <select  name="warn">
            <option value="-1">报警情况</option>            
            <option value="1" <?php if($over == '1'): ?>selected<?php endif; ?>>有</option>
            <option value="0">无</option>  
            <option value="2">已处理</option>
        </select>
        <input type="submit" name="" value="查询" style="width:70px;text-align: center;">
        <!-- <a href="<?php echo U('Store/excellabel',array('token'=>$token));?>" class="exbtn">下载表格</a> -->
    </div>
    </form>
	<table class="spgl_table">
    	<tr class="">
        	<td class="spgl_t_b xlh" style=""><span style="float: left;margin:4px 6px">标签号</span><span class="arr"><a href="<?php echo U('Store/product',array('token'=>$token,'sort'=>'asc'));?>"><img src="img/a/downarr.png" class="uparr"></a><a href="<?php echo U('Store/product',array('token'=>$token,'sort'=>'desc'));?>"><img src="img/a/downarr.png" class="dowarr"></a></span></td>
            <td class="spgl_t_b spwg" style="">标签类型</td>           
            <td class="spgl_t_b gg" style="">固件版本</td>
            <td class="spgl_t_b cjsj" style="">最新批次(运单号)</td>
            <td class="spgl_t_b spwg" style="">本批次最新上传报警</td>            
            <td class="spgl_t_b cz" style="">操作</td>
        </tr>
        <?php if(is_array($records)): $i = 0; $__LIST__ = $records;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?><tr class="h_bg">
        	<td class="spgl_t_b xlh" style=""><?php echo ($list["labelId"]); ?></td>
            <td class="spgl_t_b spwg" style=""><?php echo ($list["labelType"]); ?></td>
            <td class="spgl_t_b gg" style=""><?php echo ($list["remoteFirmware"]); ?></td>           
            <td class="spgl_t_b cjsj" style=""><?php echo ($list["barCode"]); ?></td>
            <td class="spgl_t_b spwg" style="">
                <?php if($list["isover"] == '1'): ?>有
                <?php elseif($list["isover"] == '0'): ?>无
                <?php else: ?>已处理<?php endif; ?></td>            
            <td class="spgl_t_b cz" >
            <a href="<?php echo U('Store/detail',array('labelid' => $list['labelId'], 'token' => $token));?>" class="a_color">查看详情</a>    
            <?php if($list["isover"] == '1'): ?><a href="javascript:drop_confirm('您确定要处理报警吗?', '<?php echo U('Store/deal',array('id'=>$list['id']));?>');" class="a_color">&nbsp;&nbsp;处理报警</a><?php endif; ?>
            </td>
        </tr><?php endforeach; endif; else: echo "" ;endif; ?>        
    </table>
    
    <!--页面显示-->
    <p class="neirong_yema" style="text-align: center;width:auto;margin:15px 0">  <?php echo ($page); ?>
    </p>
   
</div>

<hr>
<div class="d_public">
  <!-- <div class="d_public_one"><a href="http://www.cloud315.org/">关于溯云</a></div> -->
    <!-- <div class="d_public_two"><a href="<?php echo U('Index/helpcen');?>">帮助中心</a></div> -->
    <div class="d_public_three"><a href="http://www.megain.com/">联系我们</a></div>
    <div class="d_public_four"><a href="#">常见问题</a></div>
</div>
<div class="d_public_e">Copyright © 2018 www.megian.com &nbsp;All Rights Reserved</div>
<!-- <div class="d_public_n">copyright@cloud315.org</div> -->

</body>
</html>

</body>
<script>

function drop_confirm(msg, url){
    if(confirm(msg)){
        window.location = url;
    }
}
// </script>

</html>