<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/css_home_pc.css"/>
<title>智能物联管理系统企业中心</title>
<script type="text/javascript" src="<?php echo RES;?>/js/jquery.min.js"></script>
<script src="<?php echo RES;?>/js/layer.js"></script>
<style>
.wel{cursor: pointer;position: relative;}
.wel:hover .move_b{opacity: 1;top:18px;}
.move_b {width: 80px;height:58px;background:#435867;position: absolute;opacity: 0;top:-5px;left:35px;transition:0.5s;-webkit-transition:.5s;-moz-transition:.5s;}
.move_b a{text-align: center;line-height: 26px;font-size: 14px;color: #fff;display: block;} 
.active{background:#fff; color:#435867;border-top:1px solid #435867;}
</style>
</head>
<body>
<!--header-->
<!--
<div class="mengceng_bq"></div>
-->
<div class="cj_header">
  <img class="logo_size" src="img/logo1.png" alt="logo"/><span class="logo_font">智能物联网管理系统</span>
    <div class="cj_h_r">
        <div class="wel">欢迎，<?php echo (session('uname')); ?>
        <div class="move_b">
        <a href="<?php echo U('Index/edit', array('token' => $token));?>">修改</a>
        <a href="/index.php?g=Home&m=Index&a=logout">退出</a>
        </div>
    </div>
        <div class="fw_time">服务到期时间:<?php echo (date("Y-m-d",$thisUser["viptime"])); ?></div>
    </div>
</div>
<div class="cj_nav">
  <div class="f1_line"></div>
    <div class="nav_k">
        <a class="nav_font" href="<?php echo U('Wlist/index', array('token' => $token));?>" id="Wlist">统计报表</a>
        <a class="nav_font" href="<?php echo U('Store/product', array('token' => $token));?>" id="Store">标签管理</a>
        <a class="nav_font" href="<?php echo U('Work/index', array('token' => $token));?>" id="Work">用户管理</a>
        <!-- <a class="nav_font nav_c " href="<?php echo U('Wlist/index', array('token' => $token));?>">统计信息</a> 企业中心Index/frame          -->
        
    </div>
  </div>       

</div>
<script>
$(document).ready(function(){
var url=window.location.href;
var reg=/m=[a-z]*/i;
var arr=url.match(reg);
var str=arr[0].substr(2);
$("#"+str).addClass("active");
})
function drop_confirm(msg, url){
    if(confirm(msg)){
        window.location = url;
    }
}
</script>

<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/shou_ye.css"/>


<script type="text/javascript" src="./tpl/static/laydate/laydate.js"></script>
<!--内容-->
<div class="sy_nr">
  <div class="sy_user">
       
    <div class="sy_info">
        <div>企业名称: <?php echo ($wxName); ?></div>
        <div>企业地址: <?php echo ($wxinfo["waddress"]); ?></div>
        <div>企业编号: <?php echo ($token); ?></div>
    </div>
    <div class="sy_info">
        <div>负责人: <?php echo ($wxinfo["smsuser"]); ?></div>
        <div>联系电话: <?php echo ($wxinfo["phone"]); ?></div>
        <a class="g_b sy_editbtn" href="<?php echo U('Index/edit',array('token' => $token));?>">信息修改</a>
    </div>

   </div>
   <div class="tjb">数据统计</div>

<script>
   function a(stmps,stmpe){
    $('#s').val(stmps);
    $('#e').val(stmpe);
    url="&st="+stmps+"&e="+stmpe;
    url="<?php echo U('Index/frame', array('token' => $token));?>"+url;
    window.location.href=url;
  }
  function aa(){
    //stmpgoods=document.getElementById("goods");
    stmps=document.getElementById("s");
    stmpe=document.getElementById("e");
    if(stmps.value>0 && stmps.value>0 && stmps.value>stmpe.value){
      alert("请输入正确的日期范围");
      return;
    }
    
    url="&st="+stmps.value+"&e="+stmpe.value;
    url="<?php echo U('Index/frame', array('token' => $token));?>"+url
    window.location.href=url;
  }
</script>
   <div class="sx">
      <span class="sx_time">筛选日期：</span>
        
        <input class="logo_sr" style="margin-left:22px;" type="text" value="" id="s" onclick="laydate()"/>
    <span style="vertical-align:middle; padding:0 5px;">至</span>
    <input class="logo_sr" type="text" value="" id="e" onclick="laydate()"/>
    <input class="find_anniu g_b" type="button" style="margin-left: 20px" value="查询报表" onclick="aa()"/>
   </div>
<div class="sx_product">
    
    <div style="width:33%;float:left;text-align: center;">
        <input type="button" value="总标签数量:<?php echo (($total)?($total):"0"); ?>" style="border:1px solid #435867; width:200px; line-height:60px;margin-top: 28px">
    </div>
    <div style="width:33%;float:left;text-align: center;">
        <input type="button" value="总上传次数：<?php echo (($num1)?($num1):"0"); ?>" style="border:1px solid #435867; width:200px; line-height:60px;margin-top: 28px">
    </div>
    <div style="width:33%;float:left;text-align: center;">
         <input type="button" value="报警次数：<?php echo (($num2)?($num2):"0"); ?>" style="border:1px solid #435867; width:200px; line-height:60px;margin-top: 28px">
    </div>
     
</div>
<!--公共底-->

<hr>
<div class="d_public">
  <!-- <div class="d_public_one"><a href="http://www.cloud315.org/">关于溯云</a></div> -->
    <!-- <div class="d_public_two"><a href="<?php echo U('Index/helpcen');?>">帮助中心</a></div> -->
    <div class="d_public_three"><a href="http://www.megain.com/">联系我们</a></div>
    <div class="d_public_four"><a href="#">常见问题</a></div>
</div>
<div class="d_public_e">Copyright © 2018 www.megian.com &nbsp;All Rights Reserved</div>
<!-- <div class="d_public_n">copyright@cloud315.org</div> -->

</body>
</html>