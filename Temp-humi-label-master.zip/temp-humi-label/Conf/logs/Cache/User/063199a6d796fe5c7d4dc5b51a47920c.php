<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/css_home_pc.css"/>
<title> 码上订水</title>
<script type="text/javascript" src="<?php echo RES;?>/js/jquery.min.js"></script>





<script src="<?php echo RES;?>/js/layer.js"></script>
<style>

</style>
</head>
<body>
<!--header-->
<!--
<div class="mengceng_bq"></div>
-->


<div class="cj_header">
  <img class="logo_size" src="./tpl/User/default/img/cloudlogo.png" alt="logo"/>
    <div class="cj_h_r">
        <div class="wel">欢迎，<?php echo (session('uname')); ?></div>
        <div class="fw_time">服务到期时间:<?php echo (date("Y-m-d",$thisUser["viptime"])); ?></div>
    </div>
</div>
<div class="cj_nav">
  <div class="f1_line"></div>
    <div class="nav_k">
        <a class="nav_font nav_c " href="<?php echo U('Index/frame', array('token' => $token));?>">首页</a>
        <a class="nav_font nav_c " href="<?php echo U('Store/product', array('token' => $token));?>">产品管理</a>
        <a class="nav_font nav_c " href="<?php echo U('Work/index', array('token' => $token));?>">送水工管理</a>


        <div class="nav_font nav_c ex_nav " style="">订单管理
               <div class="nav_xlcd_k" style="">
                <div class="nav_xl_font " style="">
                    <a class="nav_font nav_c " href="<?php echo U('Worder/index', array('token' => $token));?>">订单管理</a>
                </div>

                <div class="nav_xl_font " style="">
                    <a class="nav_font nav_c " href="<?php echo U('Wmember/countmember', array('token' => $token));?>">下单会员</a>
                </div>
            </div>   
        </div>

<?php if ($Ftype == '1'){ ?>
        <div class="nav_font nav_c ex_nav " style="">本地生活
               <div class="nav_xlcd_k" style="">
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Near/index', array('token' => $token));?>">基本管理</a>
                </div>

                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Near/orderlist', array('token' => $token));?>">订单</a>
                </div>
            </div>   
        </div>
<?php }?>   

         <!-- <a class="nav_font nav_c " href="<?php echo U('Wmember/countmember', array('token' => $token));?>">下单会员</a> -->

         <a class="nav_font nav_c " href="<?php echo U('Wmember/index', array('token' => $token));?>">会员列表</a>
        

        

        <!-- <a class="nav_font nav_c " href="<?php echo U('Worder/index', array('token' => $token));?>">订单管理</a> -->

        <a class="nav_font nav_c " href="<?php echo U('Wlist/index', array('token' => $token));?>">统计信息</a>

        <!-- <a class="nav_font nav_c " href="<?php echo U('Recmlog/index', array('token' => $token));?>">学生推荐</a> -->

          <div class="nav_font nav_c ex_nav " style="">其它管理
               <div class="nav_xlcd_k" style="">
                <div class="nav_xl_font " style="">

                    <a href="<?php echo U('Storeflash/index', array('token' => $token));?>">广告管理</a>
                </div>
             
                <!--  <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Wothers/index', array('token' => $token));?>">其它管理</a>
                </div> -->
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Worder/rewardlist', array('token' => $token));?>">奖励日志</a>
                </div>

                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Index/intro', array('token' => $token));?>">商城介绍</a>
                </div>
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('ticket/set', array('token' => $token));?>">水票设置</a>
                </div>
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Notice/index', array('token' => $token));?>">公告管理</a>
                </div>
                 <div class="nav_xl_font " style="">
                    <a href="javascript:void(0)" id="ordertimes">下单次数</a>
                </div>
              
            </div>   
        </div>
    </div>

        

        <div class="public_anniu_k">
              <input class="public_anniu b_b scyl" type="button" value="扫码派单" id="about"/>
              <input class="public_anniu b_b scyl" type="button" value="预约时间" id="ordertime" style="margin-top:10px;"/>
 <!--              <input class="public_anniu b_b scyl" type="button" value="下单次数" id="ordertimes" style="margin-top:10px;"/> -->
           <!--  <a href="<?php echo U('Index/helpcen');?>" target="_blank"><input class="public_anniu b_b" style="margin-top:10px;" type="button" value="帮助中心"/></a>
           <a href="#"> <input class="public_anniu b_b" style="margin-top:10px;" type="button" value="常见问题"/></a> -->
            <a href="/index.php?g=Home&m=Index&a=logout"> <input class="public_anniu b_b" style="margin-top:10px;" type="button" value="退出"/></a>
        </div>
</div>
<script>

function drop_confirm(msg, url){
    if(confirm(msg)){
        window.location = url;
    }
</script>



<script>
//弹出layer
$('#about').on('click', function(){
//alert("ok");
    layer.open({
        type: 2,
        title: '预览页',
        shadeClose: true,   
        shade: 0.8,
        area: ['1000px', '700px'],
        content: 'index.php?g=User&m=Index&a=showview'   //打开的页面<?php echo ($f_siteUrl); ?>/
    }); 
});

$('#ordertime').click(function(){
         layer.open({
        type: 2,
        title: '预览页',
        shadeClose: true,   
        shade: 0.8,
        area: ['400px', '200px'],
        content: 'index.php?g=User&m=Index&a=ordertime'   //打开的页面<?php echo ($f_siteUrl); ?>/
    }); 
})

$('#ordertimes').click(function(){
         layer.open({
        type: 2,
        title: '预览页',
        shadeClose: true,   
        shade: 0.8,
        area: ['400px', '200px'],
        content: 'index.php?g=User&m=Worder&a=ordertimes'   //打开的页面<?php echo ($f_siteUrl); ?>/
    }); 
})
</script>

 <style>
  .old_2{background:#fff; color:#435867;}  
</style>
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/shangpin_guan_li.css"/>
<script src="<?php echo STATICS;?>/jquery-1.4.2.min.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo RES;?>/js/qrcode.js"></script>
<script type="text/javascript"  src="<?php echo RES;?>/js/jquery.qrcode.js"></script>
<link rel="stylesheet" type="text/css" href="./tpl/static/date/hDate.css"/>
<script type="text/javascript" src="./tpl/static/date/hDate.js"></script>
<script type="text/javascript" src="/public/websocket.js"></script>
<!--内容-->
<div class="scgl_nr" style="height:auto">
	<div class="tjb1"><div class="yd"></div>订单管理</div>
 <form method="post" action="<?php echo U('Worder/indexsr',array('token'=>$token));?>">
  <div class="tjb4" style="background:#ECECFB none repeat scroll 0% 0%">
        
        &nbsp;&nbsp;订&nbsp;&nbsp;单&nbsp;&nbsp;号:
        <input name="Forderid"   type="text" style="height:28px;"placeholder="订单号" value="<?php echo ($Forderid); ?>">
        客&nbsp;&nbsp;户&nbsp;&nbsp;名:
        <input name="Fusers"   type="text" style="height:28px;"placeholder="用户手机" value="<?php echo ($Fusers); ?>">
        订单状态:
        <select  name="Fstatus"  style="height:28px;">
                    <option value="-1">请选择</option>
                     <option value="1" <?php if($Fstatus == 1): ?>selected<?php endif; ?>>未派单</option>
                     <option value="2" <?php if($Fstatus == 2): ?>selected<?php endif; ?>>已派单</option>
                     <option value="3" <?php if($Fstatus == 3): ?>selected<?php endif; ?>>已完成</option>
        </select>
        
      
    </div>
    <div class="tjb4" style="background:#ECECFB none repeat scroll 0% 0%">
     &nbsp;&nbsp;下单时间:
        <input name="starttime" id="date1" type="text"  style="height:28px;" onClick="calendar.show({ id: this })" value="<?php echo ($starttime); ?>" />
        &nbsp;&nbsp;&nbsp;&nbsp;——&nbsp;&nbsp;&nbsp;&nbsp;
        <input name="endtime" id="date2" type="text"  style="height:28px;" onClick="calendar.show({ id: this })" value="<?php echo ($endtime); ?>" />

        <input class="logo_sc b_b" value="确认选择" type="submit">
        <input class="logo_sc b_b" type="button" id="allclick" value="批量分配" />
    </div>
    <input type="hidden" name='token' value="<?php echo ($_GET['token']); ?>">
     </form>
	<table class="spgl_table" style="height:780px">
    	<tr class="">
            <td style="width: 50px;">选择</td>
        	<td class="spgl_t_b cz" style="">订单编号</td>
            <td class="spgl_t_b flmc" style="">客户名</td>
            <td class="spgl_t_b gg" style="">送水地址</td>
         
           <!--  <td class="spgl_t_b cjsj" style="">送水工</td> -->
            <td class="spgl_t_b cjsj" style="">总金额</td>
            <td class="spgl_t_b cz" style="">下单时间</td>
            <td class="spgl_t_b cjsj" style="">状态</td>
            <td class="spgl_t_b cjsj" style="">送水工</td>
            <td class="spgl_t_b cz" style="">更改状态</td>
            <td class="spgl_t_b cz" style="">操作</td>
        </tr>
        <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><tr class="h_bg">
            <td><input type="checkbox" value="<?php echo ($item["Fid"]); ?>" name="ixz"></td>
        	<td class="spgl_t_b cz" style=""><?php if($item[Fticket] == "1"): ?>(水票)<?php endif; ?> <?php echo ($item["Forderid"]); ?></td>
            <td class="spgl_t_b flmc" style=""><?php echo ($item["Fusers"]); ?></td>
            <td class="spgl_t_b gg" style=""><?php echo ($item["Faddress"]); ?></td>
            <!-- <td class="spgl_t_b gg" style=""><?php echo ($item["Fname"]); ?></td> -->
            <td class="spgl_t_b cjsj" style=""><?php echo ($item["Ftotal"]); ?></td>
            <td class="spgl_t_b cjsj" style=""><?php echo (date("Y-m-d H:i:s",$item["Fordertime"])); ?></td>
           <td class="spgl_t_b cjsj" style="">
                
           <?php if($item["Fstatus"] == '0' ): ?><span style="color:red">已取消</span>
           <?php elseif($item["Fstatus"] == '1'): ?> 
           <span style="color:blue">未派单</span>
           <?php elseif($item["Fstatus"] == '2'): ?>
           <span style="color:green">已派单</span>
       
           
            <?php else: ?>
            <span style="color:green">已完成</span><?php endif; ?>

           </td>
           <td class="spgl_t_b cjsj" style="">
            <?php if($item["Fstatus"] == '1' ): ?><a href="javascript:void(0)" style="color: #007FFF;" onclick="sendwork(<?php echo ($item["Fid"]); ?>,'<?php echo ($token); ?>')">分配</a>
           <?php else: ?>
           --<?php endif; ?>
           </td>
           <?php if($item["Fstatus"] == '1' ): ?><td class="spgl_t_b cz" >
            <a href="<?php echo U('Worder/status',array('token'=>$token,'Fid' => $item['Fid'],'status'=>0));?>" style="color: #007FFF;">取消</a>
            </td>
            <?php elseif($item["Fstatus"] == '2' ): ?>
            <td class="spgl_t_b cz" >

            <a href="<?php echo U('Worder/status',array('token'=>$token,'Fid' => $item['Fid'],'status'=>1));?>" style="color: #007FFF;">未派单</a>-
            <a href="javascript:void(0)" style="color: #007FFF;" onclick="sendwork2(<?php echo ($item["Fid"]); ?>,'<?php echo ($token); ?>')">已完成</a>-
            <a href="<?php echo U('Worder/status',array('token'=>$token,'Fid' => $item['Fid'],'status'=>0));?>" style="color: #007FFF;">取消</a>
           </td>
            <?php elseif($item["Fstatus"] == '3' ): ?>
             <td class="spgl_t_b cz" >
             <a href="<?php echo U('Worder/status',array('token'=>$token,'Fid' => $item['Fid'],'status'=>0));?>" style="color: #007FFF;">取消</a>
             </td>
            <?php else: ?>
           <td class="spgl_t_b cz" >

            --
           </td><?php endif; ?>
            <td class="spgl_t_b cz" style="">
            
            <a href="<?php echo U('Worder/orderfino',array('Fid' => $item['Fid'], 'token' => $token));?>" class="a_color" style="">详情</a>
            </td>
            
 
       </tr><?php endforeach; endif; else: echo "" ;endif; ?>
       
    
          <tr></tr>    
    </table>
    
    <!--页面显示-->
    <p class="neirong_yema">  
        <?php echo ($page); ?>
    </p>
   
    
    
</div>

  
<!--公共底-->
<hr>
<div class="d_public">
	<div class="d_public_one">关于溯云</div>
    <div class="d_public_two">帮助中心</div>
    <div class="d_public_three">联系我们</div>
    <div class="d_public_four">常见问题</div>
</div>
<div class="d_public_e">Copyright © 2015 cloud315.com All Rights Reserved</div>
<div class="d_public_n">copyright@cloud315.com</div>
    
</div>

</body>
<script>
//弹出layer
  function sendwork(Forderid,token){
     
        layer.open({
        type: 2,
        title: '关闭弹窗后及时刷新',
        shadeClose: true,   
        shade: 0.8,
        area: ['300px', '200px'],
        content: '/index.php?g=User&m=Worder&a=send_work&Forderid='+Forderid+'&token='+token   //打开的页面
    }); 
  }

    function sendwork2(Forderid,token){
     
        layer.open({
        type: 2,
        title: '关闭弹窗后及时刷新',
        shadeClose: true,   
        shade: 0.8,
        area: ['300px', '200px'],
        content: '/index.php?g=User&m=Worder&a=send_work2&Forderid='+Forderid+'&token='+token   //打开的页面
    }); 
  }


$('#allclick').click(function(){
    var ixz = document.getElementsByName("ixz");
    var stmp = [];
    for(var i=0;i<ixz.length;i++){
        if(ixz[i].checked){
            stmp.push(ixz[i].value);
        }
    }
    sendwork(stmp.toString(),'<?php echo ($token); ?>')
});

            // $('body').append('<object height="0" width="0" data="/music/2456.mp3"></object>');
    var url = "ws://114.215.100.254:3000/water/norder?token=<?php echo ($_GET['token']); ?>&num=<?php echo ($count); ?>";
    stmp = 1;
    websocket.onmessage = function(e){
            notify('提示', '您有新增订单', 'img/123.png');
        if(stmp == 1 && e.data != "0"){
            $('body').append('<object height="0" width="0" data="/music/2456.mp3" onload="if(confirm(\'您有新增订单，是否刷新？\')){window.location.reload();}"></object>');
            stmp = 0;
        }
    }
    websocket.open(url);
</script>

</html>