<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/css_home_pc.css"/>
<title> 码上订水</title>
<script type="text/javascript" src="<?php echo RES;?>/js/jquery.min.js"></script>





<script src="<?php echo RES;?>/js/layer.js"></script>
<style>

</style>
</head>
<body>
<!--header-->
<!--
<div class="mengceng_bq"></div>
-->


<div class="cj_header">
  <img class="logo_size" src="./tpl/User/default/img/cloudlogo.png" alt="logo"/>
    <div class="cj_h_r">
        <div class="wel">欢迎，<?php echo (session('uname')); ?></div>
        <div class="fw_time">服务到期时间:<?php echo (date("Y-m-d",$thisUser["viptime"])); ?></div>
    </div>
</div>
<div class="cj_nav">
  <div class="f1_line"></div>
    <div class="nav_k">
        <a class="nav_font nav_c " href="<?php echo U('Index/frame', array('token' => $token));?>">首页</a>
        <a class="nav_font nav_c " href="<?php echo U('Store/product', array('token' => $token));?>">产品管理</a>
        <a class="nav_font nav_c " href="<?php echo U('Work/index', array('token' => $token));?>">送水工管理</a>


        <div class="nav_font nav_c ex_nav " style="">订单管理
               <div class="nav_xlcd_k" style="">
                <div class="nav_xl_font " style="">
                    <a class="nav_font nav_c " href="<?php echo U('Worder/index', array('token' => $token));?>">订单管理</a>
                </div>

                <div class="nav_xl_font " style="">
                    <a class="nav_font nav_c " href="<?php echo U('Wmember/countmember', array('token' => $token));?>">下单会员</a>
                </div>
            </div>   
        </div>

<?php if ($Ftype == '1'){ ?>
        <div class="nav_font nav_c ex_nav " style="">本地生活
               <div class="nav_xlcd_k" style="">
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Near/index', array('token' => $token));?>">基本管理</a>
                </div>

                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Near/orderlist', array('token' => $token));?>">订单</a>
                </div>
            </div>   
        </div>
<?php }?>   

         <!-- <a class="nav_font nav_c " href="<?php echo U('Wmember/countmember', array('token' => $token));?>">下单会员</a> -->

         <a class="nav_font nav_c " href="<?php echo U('Wmember/index', array('token' => $token));?>">会员列表</a>
        

        

        <!-- <a class="nav_font nav_c " href="<?php echo U('Worder/index', array('token' => $token));?>">订单管理</a> -->

        <a class="nav_font nav_c " href="<?php echo U('Wlist/index', array('token' => $token));?>">统计信息</a>

        <!-- <a class="nav_font nav_c " href="<?php echo U('Recmlog/index', array('token' => $token));?>">学生推荐</a> -->

          <div class="nav_font nav_c ex_nav " style="">其它管理
               <div class="nav_xlcd_k" style="">
                <div class="nav_xl_font " style="">

                    <a href="<?php echo U('Storeflash/index', array('token' => $token));?>">广告管理</a>
                </div>
             
                <!--  <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Wothers/index', array('token' => $token));?>">其它管理</a>
                </div> -->
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Worder/rewardlist', array('token' => $token));?>">奖励日志</a>
                </div>

                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Index/intro', array('token' => $token));?>">商城介绍</a>
                </div>
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('ticket/set', array('token' => $token));?>">水票设置</a>
                </div>
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Notice/index', array('token' => $token));?>">公告管理</a>
                </div>
                 <div class="nav_xl_font " style="">
                    <a href="javascript:void(0)" id="ordertimes">下单次数</a>
                </div>
              
            </div>   
        </div>
    </div>

        

        <div class="public_anniu_k">
              <input class="public_anniu b_b scyl" type="button" value="扫码派单" id="about"/>
              <input class="public_anniu b_b scyl" type="button" value="预约时间" id="ordertime" style="margin-top:10px;"/>
 <!--              <input class="public_anniu b_b scyl" type="button" value="下单次数" id="ordertimes" style="margin-top:10px;"/> -->
           <!--  <a href="<?php echo U('Index/helpcen');?>" target="_blank"><input class="public_anniu b_b" style="margin-top:10px;" type="button" value="帮助中心"/></a>
           <a href="#"> <input class="public_anniu b_b" style="margin-top:10px;" type="button" value="常见问题"/></a> -->
            <a href="/index.php?g=Home&m=Index&a=logout"> <input class="public_anniu b_b" style="margin-top:10px;" type="button" value="退出"/></a>
        </div>
</div>
<script>

function drop_confirm(msg, url){
    if(confirm(msg)){
        window.location = url;
    }
</script>



<script>
//弹出layer
$('#about').on('click', function(){
//alert("ok");
    layer.open({
        type: 2,
        title: '预览页',
        shadeClose: true,   
        shade: 0.8,
        area: ['1000px', '700px'],
        content: 'index.php?g=User&m=Index&a=showview'   //打开的页面<?php echo ($f_siteUrl); ?>/
    }); 
});

$('#ordertime').click(function(){
         layer.open({
        type: 2,
        title: '预览页',
        shadeClose: true,   
        shade: 0.8,
        area: ['400px', '200px'],
        content: 'index.php?g=User&m=Index&a=ordertime'   //打开的页面<?php echo ($f_siteUrl); ?>/
    }); 
})

$('#ordertimes').click(function(){
         layer.open({
        type: 2,
        title: '预览页',
        shadeClose: true,   
        shade: 0.8,
        area: ['400px', '200px'],
        content: 'index.php?g=User&m=Worder&a=ordertimes'   //打开的页面<?php echo ($f_siteUrl); ?>/
    }); 
})
</script>

 <style>
  .old_2{background:#fff; color:#435867;}  
</style>
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/shangpin_guan_li.css"/>
<script src="<?php echo STATICS;?>/jquery-1.4.2.min.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo RES;?>/js/qrcode.js"></script>
<script type="text/javascript"  src="<?php echo RES;?>/js/jquery.qrcode.js"></script>

<!--内容-->
<div class="scgl_nr" style="height:auto">
	<div class="tjb1"><div class="yd"></div>用户管理</div>
 
  <div class="tjb4" style="margin-left:20px">
        <form method="post" action="">
        <span class="sxcp_font">客户手机&nbsp;&nbsp;:&nbsp;&nbsp;</span>
        <input name="Fusername"   type="text" style="height:28px;">
        <span class="sxcp_font">客户地址&nbsp;&nbsp;:&nbsp;&nbsp;</span>
        <input name="Faddress"   type="text" style="height:28px;">
       <!--  <span class="sxcp_font">客户性质&nbsp;&nbsp;:&nbsp;&nbsp;</span>
        <select  name="goodname"  style="height:28px;">
                    <option></option>

                     <option value="138">对饮小酌</option>
                     <option value="139">天然果品</option>
                     <option value="140">温馨母婴</option>
        </select> -->
        <input class="logo_sc b_b" value="确认选择" type="submit">
       </form>
    </div>
	<table class="spgl_table" style="height:780px">
    	<tr class="">
        	<td class="spgl_t_b xlh" style="">序号</td>
            <td class="spgl_t_b flmc" style="">客户</td>
            <td class="spgl_t_b gg" style="">送水地址</td>
         
           <td class="spgl_t_b cjsj" style="">注册时间</td>
            <td class="spgl_t_b cjsj" style="">欠款</td>
            <!-- <td class="spgl_t_b cjsj" style="">推荐奖励</td> -->

            <td class="spgl_t_b cjsj" style="width: 170px;">水票</td>
            <td class="spgl_t_b cz" style="width: 50px;">推荐人工号</td>
            <td class="spgl_t_b cz" style="width: 50px;">查看</td>
          
        </tr>
        <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><tr class="h_bg">
        	<td class="spgl_t_b xlh" style=""><?php echo ($i); ?></td>
            <td class="spgl_t_b flmc" style=""><?php echo ($item["Fusername"]); ?></td>
            <td class="spgl_t_b gg" style=""><?php echo ($item["Faddress"]); ?></td>
    
            <td class="spgl_t_b cjsj" style=""><?php echo (date("Y-m-d H:i:s",$item["Fcreatetime"])); ?></td>
            <td class="spgl_t_b cjsj" style=""><?php echo ($item["total"]); ?></td>
            <!-- <td class="spgl_t_b cjsj" style=""><a href="<?php echo U('Wmember/userinfo',array('Fid' => $item['Fid'], 'token' => $token));?>" class="a_color" style="">查看</a></td> -->
            <td class="spgl_t_b cjsj" style=""><a href="javascript:" onclick="getticket(this, '<?php echo ($item["Fusername"]); ?>')">查看</a></td>
            
            <td class="spgl_t_b cz" style="width: 50px;"><?php echo ($item["Frecom"]); ?></td>
            <td class="spgl_t_b cz" style="">
            <a href="<?php echo U('Wmember/userinfo',array('Fid' => $item['Fid'], 'token' => $token));?>" class="a_color" style="">详情</a>  
   
    
            </td>
            

        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
       
    
          <tr></tr>    
    </table>
    
    <!--页面显示-->
    <p class="neirong_yema">  
        <?php echo ($page); ?>
    </p>

   
    
    
</div>

  
<!--公共底-->
<hr>
<div class="d_public">
	<div class="d_public_one">关于溯云</div>
    <div class="d_public_two">帮助中心</div>
    <div class="d_public_three">联系我们</div>
    <div class="d_public_four">常见问题</div>
</div>
<div class="d_public_e">Copyright © 2015 cloud315.com All Rights Reserved</div>
<div class="d_public_n">copyright@cloud315.com</div>
    
</div>
</body>
<script type="text/javascript">
    function getticket(t, id){
        htmlobj=$.ajax({url:"<?php echo U('ticket/getticket', $_GET);?>&id="+id,async:false});
        $(t).html(htmlobj.responseText);
    }
</script>

</html>