<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/css_home_pc.css"/>
<title>智能物联管理系统企业中心</title>
<script type="text/javascript" src="<?php echo RES;?>/js/jquery.min.js"></script>
<script src="<?php echo RES;?>/js/layer.js"></script>
<style>
.wel{cursor: pointer;position: relative;}
.wel:hover .move_b{opacity: 1;top:18px;}
.move_b {width: 80px;height:58px;background:#435867;position: absolute;opacity: 0;top:-5px;left:35px;transition:0.5s;-webkit-transition:.5s;-moz-transition:.5s;}
.move_b a{text-align: center;line-height: 26px;font-size: 14px;color: #fff;display: block;} 
.active{background:#fff; color:#435867;border-top:1px solid #435867;}
</style>
</head>
<body>
<!--header-->
<!--
<div class="mengceng_bq"></div>
-->
<div class="cj_header">
  <img class="logo_size" src="img/logo1.png" alt="logo"/><span class="logo_font">智能物联网管理系统</span>
    <div class="cj_h_r">
        <div class="wel">欢迎，<?php echo (session('uname')); ?>
        <div class="move_b">
        <a href="<?php echo U('Index/edit', array('token' => $token));?>">修改</a>
        <a href="/index.php?g=Home&m=Index&a=logout">退出</a>
        </div>
    </div>
        <div class="fw_time">服务到期时间:<?php echo (date("Y-m-d",$thisUser["viptime"])); ?></div>
    </div>
</div>
<div class="cj_nav">
  <div class="f1_line"></div>
    <div class="nav_k">
        <a class="nav_font" href="<?php echo U('Wlist/index', array('token' => $token));?>" id="Wlist">统计报表</a>
        <a class="nav_font" href="<?php echo U('Store/product', array('token' => $token));?>" id="Store">标签管理</a>
        <a class="nav_font" href="<?php echo U('Work/index', array('token' => $token));?>" id="Work">用户管理</a>
        <!-- <a class="nav_font nav_c " href="<?php echo U('Wlist/index', array('token' => $token));?>">统计信息</a> 企业中心Index/frame          -->
        
    </div>
  </div>       

</div>
<script>
$(document).ready(function(){
var url=window.location.href;
var reg=/m=[a-z]*/i;
var arr=url.match(reg);
var str=arr[0].substr(2);
$("#"+str).addClass("active");
})
function drop_confirm(msg, url){
    if(confirm(msg)){
        window.location = url;
    }
}
</script>


<link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/themes/default/default.css" />
<script src="<?php echo STATICS;?>/kindeditor/lang/zh_CN.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/shop_guan_li_info_sz.css"/>
<div class="jscgl_nr" style="height:500px">
  <div class="jtjb2">配置信息  
    <input class="jlogo_sc_sc b_b" type="button" value="返回上一级" onClick="javascript:history.back()"/>
    <a href="<?php echo U('Store/exportcsv',array('cid'=>$list['id']));?>"><span class="btn">导出数据csv</span></a>  
  </div>
  <div style="width:50%;float: left">
    <div class="jscmc">标签编号：<span><?php echo ($list["labelId"]); ?></span></div>
    <div class="jscmc">上传账号：<span><?php echo ($list["username"]); ?></span></div> 
    <div class="jscmc">货物名称：<span><?php echo ($list["article"]); ?></span></div>
    <div class="jscmc">货物单号：<span><?php echo ($list["barCode"]); ?></span></div>
    <div class="jscmc">公司名称：<span><?php echo ($list["company"]); ?></span></div>
    <div class="jscmc">配 置 人：<span><?php echo ($list["configBy"]); ?></span></div>
    <div class="jscmc">订单时间：<span><?php echo (date("Y-m-d H:i:s",$list["deliveryTime"])); ?></span></div>
    <div class="jscmc">发货地址：<span><?php echo ($list["shippingAddr"]); ?></span></div>
    <div class="jscmc">收货地址：<span><?php echo ($list["shipTo"]); ?></span></div>
  </div>
  <div> 
    <div class="jscmc">采样间隔：<span><?php echo ($list["frequency"]); ?>分钟</span></div>
    <div class="jscmc">采集湿度：<span><?php if($list["humNeed"] > 0): ?>是<?php else: ?>否<?php endif; ?></span></div>    
    <div class="jscmc">延迟启动：<span><?php echo ($list["startDelay"]); ?>分钟</span></div>
    <div class="jscmc">湿度上限：<span><?php echo ($list["humUpLimit"]); ?> %</span></div>
    <div class="jscmc">湿度下限：<span><?php echo ($list["humLowLimit"]); ?> %</span></div>
    <div class="jscmc">温度上限：<span><?php echo ($list["temUpLimit"]); ?> ℃</span></div>
    <div class="jscmc">温度下限：<span><?php echo ($list["temLowLimit"]); ?> ℃</span></div>
    <div class="jscmc">备注信息：<span><?php echo ($list["remark"]); ?></span></div>
  </div>
</div>

<hr>
<div class="d_public">
  <!-- <div class="d_public_one"><a href="http://www.cloud315.org/">关于溯云</a></div> -->
    <!-- <div class="d_public_two"><a href="<?php echo U('Index/helpcen');?>">帮助中心</a></div> -->
    <div class="d_public_three"><a href="http://www.megain.com/">联系我们</a></div>
    <div class="d_public_four"><a href="#">常见问题</a></div>
</div>
<div class="d_public_e">Copyright © 2018 www.megian.com &nbsp;All Rights Reserved</div>
<!-- <div class="d_public_n">copyright@cloud315.org</div> -->

</body>
</html>