<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/aa.css"/>
<link rel="stylesheet" type="text/css" href="css/bb.css"/>
<script type="text/javascript" src="<?php echo RES;?>/js/jquery.min.js"></script>

<script src="/tpl/static/upyun.js?2013"></script>
<script type="text/javascript" src="<?php echo RES;?>/js/qrcode.js"></script>
<script type="text/javascript"  src="<?php echo RES;?>/js/jquery.qrcode.js"></script>




<title>商城预览</title>
</head>
<style>
 .tcym{height:1px;width:100%; position:relative;}

/*弹出*/ 
.mengceng_bq{width:100%; height:100%; background:rgba(0,0,0,0.5);position:absolute;z-index:2; display:block;}

.scyl_tan_k{position:absolute; top:10px;right:0px; height:740px;width:510px; background:#fff; z-index:3; display:block; border:0px solid #435866;}
.scyl_title{position:absolute; top:0px;left:150px; font-size:20px; font-weight:400; color:#435866;}
.scyl_close{height:40px; background:#D6DEE3; line-height:40px; font-size:16px; text-indent:910px; cursor:pointer; font-weight:400; color:#F00;}

/*.scyl_phone{ width:402px; height:650px; margin-top:15px; margin-left:15px; float:left;}*/
.phone_dis{ position:absolute; left:28px; top:122px; background:#fff; width:350px; height:400px;}
.scyl_erweima1{ width:400px; height:630px; margin-top:25px; margin-right:15px; text-align:center;float: left;}
.scyl_erweima{ width:400px; height:630px; margin-top:25px; margin-right:15px; text-align:center;float: right;}

.sjyl_bdwx{height:50px;width:400px; background:#435866;font-size:20px; text-align:center; font-weight:bold; line-height:50px; color:#fff;}
.sjyl_bdwx1{height:80px;width:400px;font-size:18px;  font-weight:400; line-height:80px; color:#435866;}
.sjyl_bdwx2{height:60px;width:400px;font-size:14px; line-height:20px; color:#435866;}
.sjyl_bdwx3{height:50px;width:100px;font-size:18px;  font-weight:400; line-height:50px; color:#435866; display:inline-block;}
.sjyl_bdwx4{height:300px;width:300px; background:#999; display:inline-block; vertical-align:text-top; margin-left:20px;}
.sjyl_tu_ts{font-size:16px; color:#FF7F00; line-height:35px; text-indent:150px;}
.sjyl_sp_anniu{width:130px; margin:50px 0 0 180px; height: 34px; background: #4B0; color: #fff; border: none;}

</style>

<body class="tcym_zong" style="">

<div class="tcym">  
    <!--弹框-->
    <!-- <div class="scyl_tan_k">  -->
        <!-- <div class="scyl_phone" style="background: url(./tpl/User/default/img/i6.png) center center no-repeat; position:relative;">
            <div class="phone_dis">
                <iframe id="preshow" name="preshow"  src="<?php echo ($f_siteUrl); ?>/index.php?g=Wap&m=Store&token=<?php echo ($info["token"]); ?>&show=1"  frameborder="0" style=" width:350px; height:488px; overflow-x:hidden;"></iframe>
            </div>
        </div> -->

       <div class="scyl_erweima1">
            <div class="sjyl_bdwx">水站公共二维码</div>
            <div class="sjyl_bdwx1">水站公共二维码:</div>
            <div class="sjyl_bdwx2"><?php echo ($f_siteUrl); ?>/index.php?g=Wap&m=Reg&a=station&token=<?php echo ($info["token"]); ?></div>
            <div class="sjyl_bdwx3">二维码:</div>
                  <div id='code1' style="display:inline-block; vertical-align: text-top;"> </div>
            <!-- <img class="sjyl_bdwx4" src="" alt="二维码"/> -->
           <!--  <div class="sjyl_tu_ts">更换模板时请刷新后预览</div>
            <input class="sjyl_sp_anniu g_b" type="button" value="刷&nbsp;&nbsp;新" onclick="setnew();"/> -->
        </div>


        <div class="scyl_erweima">
            <div class="sjyl_bdwx">手机派单二维码</div>
            <div class="sjyl_bdwx1">手机派单入口:</div>
            <div class="sjyl_bdwx2"><?php echo ($f_siteUrl); ?>/index.php?g=Wap&m=Water_manage&a=userlogin</div>
            <div class="sjyl_bdwx3">二维码:</div>
                  <div id='code' style="display:inline-block; vertical-align: text-top;"> </div>
            <!-- <img class="sjyl_bdwx4" src="" alt="二维码"/> -->
           <!--  <div class="sjyl_tu_ts">更换模板时请刷新后预览</div>
            <input class="sjyl_sp_anniu g_b" type="button" value="刷&nbsp;&nbsp;新" onclick="setnew();"/> -->
        </div>
    <!-- </div>   -->
</div>
</body>
<script>
function setnew(){
     window.location.reload();
}
</script>

<script type="text/javascript">
var img = $('#code').qrcode({text: "<?php echo ($f_siteUrl); ?>/index.php?g=Wap&m=Water_manage&a=userlogin"}); 
var img1 = $('#code1').qrcode({text: "<?php echo ($f_siteUrl); ?>/index.php?g=Wap&m=Reg&a=station&token=<?php echo ($info["token"]); ?>"}); 
</script>
</html>