<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/css_home_pc.css"/>
<title> 码上订水</title>
<script type="text/javascript" src="<?php echo RES;?>/js/jquery.min.js"></script>





<script src="<?php echo RES;?>/js/layer.js"></script>
<style>

</style>
</head>
<body>
<!--header-->
<!--
<div class="mengceng_bq"></div>
-->


<div class="cj_header">
  <img class="logo_size" src="./tpl/User/default/img/cloudlogo.png" alt="logo"/>
    <div class="cj_h_r">
        <div class="wel">欢迎，<?php echo (session('uname')); ?></div>
        <div class="fw_time">服务到期时间:<?php echo (date("Y-m-d",$thisUser["viptime"])); ?></div>
    </div>
</div>
<div class="cj_nav">
  <div class="f1_line"></div>
    <div class="nav_k">
        <a class="nav_font nav_c " href="<?php echo U('Index/frame', array('token' => $token));?>">首页</a>
        <a class="nav_font nav_c " href="<?php echo U('Store/product', array('token' => $token));?>">产品管理</a>
        <a class="nav_font nav_c " href="<?php echo U('Work/index', array('token' => $token));?>">送水工管理</a>


        <div class="nav_font nav_c ex_nav " style="">订单管理
               <div class="nav_xlcd_k" style="">
                <div class="nav_xl_font " style="">
                    <a class="nav_font nav_c " href="<?php echo U('Worder/index', array('token' => $token));?>">订单管理</a>
                </div>

                <div class="nav_xl_font " style="">
                    <a class="nav_font nav_c " href="<?php echo U('Wmember/countmember', array('token' => $token));?>">下单会员</a>
                </div>
            </div>   
        </div>

<?php if ($Ftype == '1'){ ?>
        <div class="nav_font nav_c ex_nav " style="">本地生活
               <div class="nav_xlcd_k" style="">
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Near/index', array('token' => $token));?>">基本管理</a>
                </div>

                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Near/orderlist', array('token' => $token));?>">订单</a>
                </div>
            </div>   
        </div>
<?php }?>   

         <!-- <a class="nav_font nav_c " href="<?php echo U('Wmember/countmember', array('token' => $token));?>">下单会员</a> -->

         <a class="nav_font nav_c " href="<?php echo U('Wmember/index', array('token' => $token));?>">会员列表</a>
        

        

        <!-- <a class="nav_font nav_c " href="<?php echo U('Worder/index', array('token' => $token));?>">订单管理</a> -->

        <a class="nav_font nav_c " href="<?php echo U('Wlist/index', array('token' => $token));?>">统计信息</a>

        <!-- <a class="nav_font nav_c " href="<?php echo U('Recmlog/index', array('token' => $token));?>">学生推荐</a> -->

          <div class="nav_font nav_c ex_nav " style="">其它管理
               <div class="nav_xlcd_k" style="">
                <div class="nav_xl_font " style="">

                    <a href="<?php echo U('Storeflash/index', array('token' => $token));?>">广告管理</a>
                </div>
             
                <!--  <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Wothers/index', array('token' => $token));?>">其它管理</a>
                </div> -->
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Worder/rewardlist', array('token' => $token));?>">奖励日志</a>
                </div>

                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Index/intro', array('token' => $token));?>">商城介绍</a>
                </div>
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('ticket/set', array('token' => $token));?>">水票设置</a>
                </div>
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Notice/index', array('token' => $token));?>">公告管理</a>
                </div>
                 <div class="nav_xl_font " style="">
                    <a href="javascript:void(0)" id="ordertimes">下单次数</a>
                </div>
              
            </div>   
        </div>
    </div>

        

        <div class="public_anniu_k">
              <input class="public_anniu b_b scyl" type="button" value="扫码派单" id="about"/>
              <input class="public_anniu b_b scyl" type="button" value="预约时间" id="ordertime" style="margin-top:10px;"/>
 <!--              <input class="public_anniu b_b scyl" type="button" value="下单次数" id="ordertimes" style="margin-top:10px;"/> -->
           <!--  <a href="<?php echo U('Index/helpcen');?>" target="_blank"><input class="public_anniu b_b" style="margin-top:10px;" type="button" value="帮助中心"/></a>
           <a href="#"> <input class="public_anniu b_b" style="margin-top:10px;" type="button" value="常见问题"/></a> -->
            <a href="/index.php?g=Home&m=Index&a=logout"> <input class="public_anniu b_b" style="margin-top:10px;" type="button" value="退出"/></a>
        </div>
</div>
<script>

function drop_confirm(msg, url){
    if(confirm(msg)){
        window.location = url;
    }
</script>



<script>
//弹出layer
$('#about').on('click', function(){
//alert("ok");
    layer.open({
        type: 2,
        title: '预览页',
        shadeClose: true,   
        shade: 0.8,
        area: ['1000px', '700px'],
        content: 'index.php?g=User&m=Index&a=showview'   //打开的页面<?php echo ($f_siteUrl); ?>/
    }); 
});

$('#ordertime').click(function(){
         layer.open({
        type: 2,
        title: '预览页',
        shadeClose: true,   
        shade: 0.8,
        area: ['400px', '200px'],
        content: 'index.php?g=User&m=Index&a=ordertime'   //打开的页面<?php echo ($f_siteUrl); ?>/
    }); 
})

$('#ordertimes').click(function(){
         layer.open({
        type: 2,
        title: '预览页',
        shadeClose: true,   
        shade: 0.8,
        area: ['400px', '200px'],
        content: 'index.php?g=User&m=Worder&a=ordertimes'   //打开的页面<?php echo ($f_siteUrl); ?>/
    }); 
})
</script>

 <style>
  .old_2{background:#fff; color:#435867;}  
</style>
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/shangpin_guan_li_hdp.css"/>
<script src="/tpl/static/artDialog/jquery.artDialog.js?skin=default"></script>

<script src="/tpl/static/artDialog/plugins/iframeTools.js"></script>
<!--内容-->
<div class="scgl_nr">
  <div class="tjb1"><div class="yd"></div>商城管理</div>
    <div class="tjb2"><div class="yd"></div>商品管理
  <!--   <a href="<?php echo U('Shoptmpls/index', array('token' => $token));?>">
        <input class="logo_sc_sc b_b" type="button" value="返回上一级"/>
      </a> -->
      </div>
    <div class="tjb3">
      <a href="<?php echo U('Storeflash/add');?>" class="btn btn-primary btn_submit  J_ajax_submit_btn" >

      <input class="logo_sc b_b" type="button" value="新增广告"/>
     
      </a>
    </div>
  <table class="spgl_table">
      <tr class="">
            <td class="spgl_t_b flmc" style="">广告描述</td>
            <td class="spgl_t_b gg" style="">图片预览</td>
            
            <td class="spgl_t_b spwg" style="">幻灯片外链地址</td>
              <td class="spgl_t_b spwg" style="width:60px">是否展示</td>
           
            <td class="spgl_t_b cz" style="">操作</td>
        </tr>
        <?php if(is_array($info)): $i = 0; $__LIST__ = $info;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr class="h_bg">
              <td class="spgl_t_b flmc" style=""><?php echo ($vo["info"]); ?></td>
              <td class="spgl_t_b gg" style=""><img src="<?php echo ($vo["img"]); ?>" style="width:110px;height:110px"></td>
              
              <td class="spgl_t_b spwg" style=" height:130px;"><?php echo (htmlspecialchars_decode($vo["url"])); ?></td>
         

              <td class="spgl_t_b spwg" style="width:60px"><?php if($vo["attr"] == '1' ): ?>是<?php else: ?>否<?php endif; ?></td>
              <td class="spgl_t_b cz" style="">
              <!--
              <a href="<?php echo U('Wap/Store/index',array('token'=>$_SESSION['token']));?>" class="a_color" style="">查看</a>
              -->
              <input class="logo_sr" type="hidden" id="img_<?php echo ($vo["id"]); ?>" value="<?php echo ($vo["img"]); ?>" name="img">
              <script src="/tpl/static/upyun.js?2013"></script>
              <a href="javascript:void(0)" onclick="viewImg('img_<?php echo ($vo["id"]); ?>')" class="a_color" style="">查看</a>
              &nbsp;&nbsp;  -  &nbsp;&nbsp;<a href="<?php echo U('Storeflash/edit',array('id'=>$vo['id'],'tip'=>$tip));?>" class="a_color" style="">编辑</a>&nbsp;&nbsp;  -  &nbsp;&nbsp;<a href="javascript:alert2('您确定要删除吗?', '<?php echo U('Storeflash/del',array('id'=>$vo['id'],'tip'=>$tip));?>');" class="a_color" style="">删除</a>
              </td>
          </tr><?php endforeach; endif; else: echo "" ;endif; ?>

        
          
    </table>
    
    <!-------------页面显示------------------>
    <p class="neirong_yema">  
       <!--  <span class="yeshu_font yema_hover diyiye"><<首页</span>
        <span class="yeshu_font yema_hover">上一页</span>
        <span class="yeshuianshi">
            <span class="yeshu_font yema_hover yema_click yema_first">1</span>
            <span class="yeshu_font yema_hover yema_click">2</span>
            <span class="yeshu_font yema_hover yema_click">3</span>
            <span class="yeshu_font yema_hover yema_click  yema_last">4</span>
        </span>
        <span class="yeshu_font yema_hover">下一页</span>
        <span class="yeshu_font yema_hover weiye">尾页>></span>
        <span class="yeshu_font" style="border:none;">共4条</span>
        <span class="yeshu_font" style="border:none;">每页5条信息</span> -->
        <?php echo ($page); ?>
    </p>
    
    
</div>
<script type="text/javascript">
function alert2(msg,url){
   if(confirm(msg)){
        window.location = url;
    }
}


</script>
<hr>
<div class="d_public">
  <div class="d_public_one"><a href="http://www.cloud315.org/">关于溯云</a></div>
    <div class="d_public_two"><a href="<?php echo U('Index/helpcen');?>">帮助中心</a></div>
    <div class="d_public_three"><a href="http://www.cloud315.org/">联系我们</a></div>
    <div class="d_public_four"><a href="#">常见问题</a></div>
</div>
<div class="d_public_e">Copyright © 2015 cloud315.org All Rights Reserved</div>
<div class="d_public_n">copyright@cloud315.org</div>

</body>
</html>