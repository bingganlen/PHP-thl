<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/css_home_pc.css"/>
<title> 码上订水</title>
<script type="text/javascript" src="<?php echo RES;?>/js/jquery.min.js"></script>





<script src="<?php echo RES;?>/js/layer.js"></script>
<style>

</style>
</head>
<body>
<!--header-->
<!--
<div class="mengceng_bq"></div>
-->


<div class="cj_header">
  <img class="logo_size" src="./tpl/User/default/img/cloudlogo.png" alt="logo"/>
    <div class="cj_h_r">
        <div class="wel">欢迎，<?php echo (session('uname')); ?></div>
        <div class="fw_time">服务到期时间:<?php echo (date("Y-m-d",$thisUser["viptime"])); ?></div>
    </div>
</div>
<div class="cj_nav">
  <div class="f1_line"></div>
    <div class="nav_k">
        <a class="nav_font nav_c " href="<?php echo U('Index/frame', array('token' => $token));?>">首页</a>
        <a class="nav_font nav_c " href="<?php echo U('Store/product', array('token' => $token));?>">产品管理</a>
        <a class="nav_font nav_c " href="<?php echo U('Work/index', array('token' => $token));?>">送水工管理</a>


        <div class="nav_font nav_c ex_nav " style="">订单管理
               <div class="nav_xlcd_k" style="">
                <div class="nav_xl_font " style="">
                    <a class="nav_font nav_c " href="<?php echo U('Worder/index', array('token' => $token));?>">订单管理</a>
                </div>

                <div class="nav_xl_font " style="">
                    <a class="nav_font nav_c " href="<?php echo U('Wmember/countmember', array('token' => $token));?>">下单会员</a>
                </div>
            </div>   
        </div>

<?php if ($Ftype == '1'){ ?>
        <div class="nav_font nav_c ex_nav " style="">本地生活
               <div class="nav_xlcd_k" style="">
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Near/index', array('token' => $token));?>">基本管理</a>
                </div>

                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Near/orderlist', array('token' => $token));?>">订单</a>
                </div>
            </div>   
        </div>
<?php }?>   

         <!-- <a class="nav_font nav_c " href="<?php echo U('Wmember/countmember', array('token' => $token));?>">下单会员</a> -->

         <a class="nav_font nav_c " href="<?php echo U('Wmember/index', array('token' => $token));?>">会员列表</a>
        

        

        <!-- <a class="nav_font nav_c " href="<?php echo U('Worder/index', array('token' => $token));?>">订单管理</a> -->

        <a class="nav_font nav_c " href="<?php echo U('Wlist/index', array('token' => $token));?>">统计信息</a>

        <!-- <a class="nav_font nav_c " href="<?php echo U('Recmlog/index', array('token' => $token));?>">学生推荐</a> -->

          <div class="nav_font nav_c ex_nav " style="">其它管理
               <div class="nav_xlcd_k" style="">
                <div class="nav_xl_font " style="">

                    <a href="<?php echo U('Storeflash/index', array('token' => $token));?>">广告管理</a>
                </div>
             
                <!--  <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Wothers/index', array('token' => $token));?>">其它管理</a>
                </div> -->
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Worder/rewardlist', array('token' => $token));?>">奖励日志</a>
                </div>

                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Index/intro', array('token' => $token));?>">商城介绍</a>
                </div>
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('ticket/set', array('token' => $token));?>">水票设置</a>
                </div>
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Notice/index', array('token' => $token));?>">公告管理</a>
                </div>
                 <div class="nav_xl_font " style="">
                    <a href="javascript:void(0)" id="ordertimes">下单次数</a>
                </div>
              
            </div>   
        </div>
    </div>

        

        <div class="public_anniu_k">
              <input class="public_anniu b_b scyl" type="button" value="扫码派单" id="about"/>
              <input class="public_anniu b_b scyl" type="button" value="预约时间" id="ordertime" style="margin-top:10px;"/>
 <!--              <input class="public_anniu b_b scyl" type="button" value="下单次数" id="ordertimes" style="margin-top:10px;"/> -->
           <!--  <a href="<?php echo U('Index/helpcen');?>" target="_blank"><input class="public_anniu b_b" style="margin-top:10px;" type="button" value="帮助中心"/></a>
           <a href="#"> <input class="public_anniu b_b" style="margin-top:10px;" type="button" value="常见问题"/></a> -->
            <a href="/index.php?g=Home&m=Index&a=logout"> <input class="public_anniu b_b" style="margin-top:10px;" type="button" value="退出"/></a>
        </div>
</div>
<script>

function drop_confirm(msg, url){
    if(confirm(msg)){
        window.location = url;
    }
</script>



<script>
//弹出layer
$('#about').on('click', function(){
//alert("ok");
    layer.open({
        type: 2,
        title: '预览页',
        shadeClose: true,   
        shade: 0.8,
        area: ['1000px', '700px'],
        content: 'index.php?g=User&m=Index&a=showview'   //打开的页面<?php echo ($f_siteUrl); ?>/
    }); 
});

$('#ordertime').click(function(){
         layer.open({
        type: 2,
        title: '预览页',
        shadeClose: true,   
        shade: 0.8,
        area: ['400px', '200px'],
        content: 'index.php?g=User&m=Index&a=ordertime'   //打开的页面<?php echo ($f_siteUrl); ?>/
    }); 
})

$('#ordertimes').click(function(){
         layer.open({
        type: 2,
        title: '预览页',
        shadeClose: true,   
        shade: 0.8,
        area: ['400px', '200px'],
        content: 'index.php?g=User&m=Worder&a=ordertimes'   //打开的页面<?php echo ($f_siteUrl); ?>/
    }); 
})
</script>

 <style>
  .old_2{background:#fff; color:#435867;}  
</style>

<link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/plugins/code/prettify.css" />
<script src="<?php echo STATICS;?>/kindeditor/kindeditor.js" type="text/javascript"></script>
<script src="<?php echo STATICS;?>/kindeditor/lang/zh_CN.js" type="text/javascript"></script>
<script src="<?php echo STATICS;?>/kindeditor/plugins/code/prettify.js" type="text/javascript">
</script>


<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/shop_guan_li -fl.css"/>
<script src="/tpl/static/artDialog/jquery.artDialog.js?skin=default"></script>
<script src="/tpl/static/artDialog/plugins/iframeTools.js"></script>
<script type="text/javascript" src="./tpl/static/laydate/laydate.js"></script>
<!--内容-->
<form class="form" method="post" action="<?php echo U('Notice/setdo',array('token'=>$token));?>" enctype="multipart/form-data"> 


<div class="scgl_nr">
  <div class="tjb1"><div class="yd"></div>水站管理</div>
    <div class="tjb2"><div class="yd"></div>公告管理
   
</div>
    <div class="tjb3"></div>

    <div class="scmc">
      <span style="color:#FF0000;">*</span>内容：
      <div style="margin-top:20px;margin-left:50px">
     <textarea class="spmc_sr" name='body' style="height:120px"><?php echo ($list["Fbody"]); ?></textarea>
     </div>
      
      <span style="color:#FF0000;">*</span>展示：
      <div style="margin-top:20px;margin-left:50px">
     <input type="checkbox" name="show" id="show" style="margin-left:0" <?php if($list["Fshow"] == '1'): ?>checked="checked"<?php endif; ?>value="1">
     </div>
     </div>
    

    <input class="cj_sp_anniu g_b" type="submit" value="保&nbsp;&nbsp;存"/>
   
</div>
</form>
<!--公共底-->
<script type="text/javascript">

</script>
<hr>
<div class="d_public">
  <div class="d_public_one"><a href="http://www.cloud315.org/">关于溯云</a></div>
    <div class="d_public_two"><a href="<?php echo U('Index/helpcen');?>">帮助中心</a></div>
    <div class="d_public_three"><a href="http://www.cloud315.org/">联系我们</a></div>
    <div class="d_public_four"><a href="#">常见问题</a></div>
</div>
<div class="d_public_e">Copyright © 2015 cloud315.org All Rights Reserved</div>
<div class="d_public_n">copyright@cloud315.org</div>

</body>
</html>