<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/css_home_pc.css"/>
<title>智能物联管理系统企业中心</title>
<script type="text/javascript" src="<?php echo RES;?>/js/jquery.min.js"></script>





<script src="<?php echo RES;?>/js/layer.js"></script>
<style>

</style>
</head>
<body>
<!--header-->
<!--
<div class="mengceng_bq"></div>
-->


<div class="cj_header">
  <img class="logo_size" src="img/logo1.png" alt="logo"/><span class="logo_font">智能物联网管理系统</span>
    <div class="cj_h_r">
        <div class="wel">欢迎，<?php echo (session('uname')); ?></div>
        <div class="fw_time">服务到期时间:<?php echo (date("Y-m-d",$thisUser["viptime"])); ?></div>
    </div>
</div>
<div class="cj_nav">
  <div class="f1_line"></div>
    <div class="nav_k">
        <a class="nav_font nav_c " href="<?php echo U('Index/frame', array('token' => $token));?>">企业中心</a>
        <a class="nav_font nav_c " href="<?php echo U('Store/product', array('token' => $token));?>">标签管理</a>
        <a class="nav_font nav_c " href="<?php echo U('Work/index', array('token' => $token));?>">用户管理</a>
        <a class="nav_font nav_c " href="<?php echo U('Wlist/index', array('token' => $token));?>">统计信息</a>          
    </div>
  </div>       

        <div class="public_anniu_k">              
            <a href="/index.php?g=Home&m=Index&a=logout"> <input class="public_anniu b_b" style="margin-top:10px;" type="button" value="退出"/></a>
        </div>
</div>
<script>

function drop_confirm(msg, url){
    if(confirm(msg)){
        window.location = url;
    }
</script>

<style>
  .old_2{background:#fff; color:#435867;}  
</style>
<link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/plugins/code/prettify.css" />
<script src="<?php echo STATICS;?>/kindeditor/kindeditor.js" type="text/javascript"></script>
<script src="<?php echo STATICS;?>/kindeditor/lang/zh_CN.js" type="text/javascript"></script>
<script src="<?php echo STATICS;?>/kindeditor/plugins/code/prettify.js" type="text/javascript">
</script>
<script src="/tpl/static/artDialog/jquery.artDialog.js?skin=default"></script>
<script src="/tpl/static/artDialog/plugins/iframeTools.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/shop_guan_li_info_sz.css"/>

<?php if($isUpdate == 1): ?><input type="hidden" name="id" value="<?php echo ($set["id"]); ?>" /><?php endif; ?>
<!--内容-------------------------------------------------------->
<form method="post" action="" id="formID">
<input type="hidden" name="discount" id="discount" value="<?php echo ($set["discount"]); ?>" />
<div class="jscgl_nr">
  <div class="jtjb1"><div class="jyd"></div>商城管理</div>
    <div class="jtjb2"><div class="jyd"></div>商品设置

 <a href="<?php echo U('Store/product',array('token'=>$token,'catid'=>$catid));?>" >
    <input class="jlogo_sc_sc b_b" type="button" value="返回上一级"/>
</a>
    </div>

    <div class="jtjb3">
      <input class="jlogo_sc b_b janniu_qieuan jjjj" style="margin:15px 15px 0 50px;background:#fff; color:#435867;" type="button" value="基本信息"/>
    </div>
  <div class="jscmc"><span style="color:#FF0000;">*</span>&nbsp;&nbsp;名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;称&nbsp;：
        <input type="hidden" name="pid" id="pid" value="<?php echo ($set["id"]); ?>"/>
        <input class="jspmc_sr" type="text" id="name" name="name" value="<?php echo ($set["name"]); ?>"/>

    </div>

     <div class="jscmc" style="margin-top:15px;"><span style="color:#FF0000;">*</span>&nbsp;&nbsp;&nbsp;简&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;称：
        <input class="jspmc_sr" style="width:480px;" type="text" id="shortname" name="shortname" value="<?php echo ($set["shortname"]); ?>"/>
    </div>

    
    <div class="jscmc"><span style="color:#FF0000;">*</span>&nbsp;&nbsp;价&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;格&nbsp;：
        <input class="jspmc_sr" type="text" id="price" name="price" value="<?php echo ($set["price"]); ?>"/>

    </div>
    <div class="jscmc"><span style="color:#FF0000;">*</span>&nbsp;&nbsp;规&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;格&nbsp;：
        <input class="jspmc_sr" type="text" id="spec" name="spec" value="<?php echo ($set["spec"]); ?>"/>
    </div>
    
    <div class="jscmc">&nbsp;&nbsp;&nbsp;库&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;存&nbsp;：
        <input class="jspmc_sr" type="text" id="num" name="num" value="<?php echo ($set["num"]); ?>"/>
    </div>
    
    
    
    <div class="jlogo_tu_up">&nbsp;&nbsp;&nbsp;产&nbsp;品&nbsp;图&nbsp;片&nbsp;：
        <input class="jlogo_sr" type="text" name="logourl" id="pic" value="<?php echo ($set["logourl"]); ?>"/>
        
        <script src="/tpl/static/upyun.js"></script>
        <a href="###" onclick="upyunPicUpload('pic',700,700,'<?php echo ($token); ?>')" class="a_upload">
          <input class="jlogo_sc b_b" type="button" value="图片上传"/></a>
        <a href="###" onclick="viewImg('pic')">
          <input class="jlogo_yl b_b" type="button" value="图片预览"/></a>
    </div>

    <div class="jscmc" style="margin-top:15px;">&nbsp;&nbsp;&nbsp;排&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;序：
        <input class="jspmc_sr" style="width:480px;" type="text" id="sort" name="sort" value="<?php echo ($set["sort"]); ?>"/><div class="jtu_ts" style="display:inline-block; text-indent:10px;">数字越小排再越前（大于等于0的整数）</div>
    </div>

    
  
</div>

</div>


<div style="position:relative; width:500px; height:60px; margin:auto;">
       
      <input class="dw_anniu1 g_b" style="top:-20px;" type="button" value="保&nbsp;&nbsp;存" id="save"/>
      
    </div>

</form>
<script type="text/javascript">
$(".tt").hide();
add03count=-1;

 
$("#save").click(function(){ 


    var name = $("#name").val();
    if (name.length < 1) {
     
      art.dialog({title:'消息提示', ok:true, width:300, height:200, content:'名称不能为空'});
      return false;
         }

     

    var num = $("#num").val();
    if (isNaN(num)) {
      art.dialog({title:'消息提示', ok:true, width:300, height:200, content:'库存应该是为正整数'});
      return false;
    }

    var check=/^\d+(\.\d+)?$/;
    var price = $("#price").val();
    if (check.test(price)==false) {
      art.dialog({title:'消息提示', ok:true, width:300, height:200, content:'请输入正确的价格'});
      return false;
    }

     var shortname = $("#shortname").val();
    if (shortname.length < 1) {
     
      art.dialog({title:'消息提示', ok:true, width:300, height:200, content:'简称不能为空'});
      return false;
         }



    var spec=$("#spec").val(); 

    var pic = $("#pic").val();

      var data = {
          pid:$("#pid").val(),
          name:name,
          num:num,
          price:price,
          spec:spec,
          pic:pic,
          
          token:'<?php echo ($token); ?>',
        
          sort:$("#sort").val(),
          shortname:$("#shortname").val()
          };
    
    $.post('index.php?g=User&m=Store&a=productSave', data, function(response){
      if (response.error_code == false) {
        art.dialog({
          title:'消息提示', 
            content: response.msg, 
            width:300, 
            height:200,
            lock: true,
            ok: function () {
              this.time(3);
    
            location.href='index.php?g=User&m=Store&a=addNew&token=<?php echo ($token); ?>&id='+response.pid;
                return false;

            },
            cancelVal: '关闭'
        });
      } else {
        art.dialog({title:'消息提示', time:2, width:300, height:200, content:response.msg});

      }
      
    }, 'json');
  });



</script>

<hr>
<div class="d_public">
  <!-- <div class="d_public_one"><a href="http://www.cloud315.org/">关于溯云</a></div> -->
    <!-- <div class="d_public_two"><a href="<?php echo U('Index/helpcen');?>">帮助中心</a></div> -->
    <div class="d_public_three"><a href="http://www.megain.net/">联系我们</a></div>
    <div class="d_public_four"><a href="#">常见问题</a></div>
</div>
<div class="d_public_e">Copyright © 2018 www.megian.net All Rights Reserved</div>
<!-- <div class="d_public_n">copyright@cloud315.org</div> -->

</body>
</html>