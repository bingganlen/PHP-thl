<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/css_home_pc.css"/>
<title>智能物联管理系统企业中心</title>
<script type="text/javascript" src="<?php echo RES;?>/js/jquery.min.js"></script>
<script src="<?php echo RES;?>/js/layer.js"></script>
<style>
.wel{cursor: pointer;position: relative;}
.wel:hover .move_b{opacity: 1;top:18px;}
.move_b {width: 80px;height:58px;background:#435867;position: absolute;opacity: 0;top:-5px;left:35px;transition:0.5s;-webkit-transition:.5s;-moz-transition:.5s;}
.move_b a{text-align: center;line-height: 26px;font-size: 14px;color: #fff;display: block;} 
.active{background:#fff; color:#435867;border-top:1px solid #435867;}
</style>
</head>
<body>
<!--header-->
<!--
<div class="mengceng_bq"></div>
-->
<div class="cj_header">
  <img class="logo_size" src="img/logo1.png" alt="logo"/><span class="logo_font">智能物联网管理系统</span>
    <div class="cj_h_r">
        <div class="wel">欢迎，<?php echo (session('uname')); ?>
        <div class="move_b">
        <a href="<?php echo U('Index/edit', array('token' => $token));?>">修改</a>
        <a href="/index.php?g=Home&m=Index&a=logout">退出</a>
        </div>
    </div>
        <div class="fw_time">服务到期时间:<?php echo (date("Y-m-d",$thisUser["viptime"])); ?></div>
    </div>
</div>
<div class="cj_nav">
  <div class="f1_line"></div>
    <div class="nav_k">
        <a class="nav_font" href="<?php echo U('Wlist/index', array('token' => $token));?>" id="Wlist">统计报表</a>
        <a class="nav_font" href="<?php echo U('Store/product', array('token' => $token));?>" id="Store">标签管理</a>
        <a class="nav_font" href="<?php echo U('Work/index', array('token' => $token));?>" id="Work">用户管理</a>
        <!-- <a class="nav_font nav_c " href="<?php echo U('Wlist/index', array('token' => $token));?>">统计信息</a> 企业中心Index/frame          -->
        
    </div>
  </div>       

</div>
<script>
$(document).ready(function(){
var url=window.location.href;
var reg=/m=[a-z]*/i;
var arr=url.match(reg);
var str=arr[0].substr(2);
$("#"+str).addClass("active");
})
function drop_confirm(msg, url){
    if(confirm(msg)){
        window.location = url;
    }
}
</script>


<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/chuang_jian_shop.css"/>
<script src="<?php echo STATICS;?>/jquery-1.4.2.min.js" type="text/javascript"></script>
<script src="<?php echo STATICS;?>/artDialog/jquery.artDialog.js?skin=default"></script>
<script src="<?php echo STATICS;?>/artDialog/plugins/iframeTools.js"></script>
<script src="<?php echo RES;?>/js/date/WdatePicker.js"></script>


<!--内容-->
<div class="cj_nr m_nr_top  nr_border" style="height:500px;">
  <div class="cj_nr_bg">
      <span class="cjsc_font">企业信息编辑</span>
        <div class="cj_nr_k">
            <div class="cj_nr_l">
              <form method="post" action="<?php echo U('User/Index/upsave');?>" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo ($info["id"]); ?>">
             <!--  <div class="scmc"><span style="color:#FF0000;">*</span>&nbsp;&nbsp;商&nbsp;城&nbsp;名&nbsp;称:&nbsp;&nbsp;&nbsp;
                  <input class="spmc_sr" type="text" required class="px" name="wxname" value="<?php echo ($info["wxname"]); ?>"/>
                </div>
                <div class="logo_tu_up"><span style="color:#FF0000;">*</span>&nbsp;&nbsp;LOGO图片:&nbsp;&nbsp;&nbsp;
                  <input type="text" class="logo_sr" name="headerpic" id="headerpic" value="<?php echo ($info["headerpic"]); ?>">
                    <script src="/tpl/static/upyun.js"></script>
                    <a href="###" onclick="upyunPicUpload('headerpic',1000,500,'<?php echo ($token); ?>')">
                    <input class="logo_sc b_b" type="button" value="上传"/>
                    </a>

                    <a href="###" onclick="viewImg('headerpic')" class="btn btn-primary btn_submit  J_ajax_submit_btns">
                    <input class="logo_yl b_b" type="button" value="预览"/>
                    </a>
                </div>
                <div class="tu_ts">请填写图片外链地址 上传 预览 头像图片</div>
                <div class="sclx"><span style="color:#FF0000;">*</span>&nbsp;&nbsp;商&nbsp;城&nbsp;类&nbsp;型:&nbsp;&nbsp;&nbsp;
                  <?php if($info[lx] == 0): ?>生产型企业<?php else: ?>销售型企业<?php endif; ?> -->
                  <!-- <select name="lx">
                    <?php if($info[lx] == 0): ?><option value ="0">生产型企业</option>
                          <option value ="1">销售型企业</option>
                    <?php else: ?>
                          <option value ="1">销售型企业</option>
                          <option value ="0">生产型企业</option><?php endif; ?>
                 </select> -->
                <!-- </div>
                <div class="tu_ts">生产型企业可以添加分销商，销售型企业不能添加分销商</div> -->
                <div class="scmc"><!-- <span style="color:#FF0000;">*</span> -->&nbsp;&nbsp;&nbsp;企业名称：&nbsp;&nbsp;
                  <!-- <input class="spmc_sr" type="text" required class="px" name="wxname" id="wxname" value="<?php echo ($info["wxname"]); ?>"/> --><span><?php echo ($info["wxname"]); ?></span>
                  <input type="hidden" name="wxname" value="<?php echo ($info["wxname"]); ?>">
                </div>
                <!-- <div class="tu_ts">（必填，提交后将不能修改）</div> -->
                 <div class="scmc"><span style="color:#FF0000;">*</span>&nbsp;企业地址：&nbsp;&nbsp;
                 <input class="spmc_sr" type="text" required class="px" name="waddress" id="waddress" value="<?php echo ($info["waddress"]); ?>"/>
                </div>

                <!-- <div class="scmc"><span style="color:#FF0000;">*</span>&nbsp;&nbsp;经销商编码:&nbsp;&nbsp;
                  <input class="spmc_sr" type="text"  class="px" name="qrcode" id="qrcode" value="<?php echo ($info["Fcode"]); ?>" <?php if($info["Fcode"] != ''): ?>readonly="readonly"<?php endif; ?> />
                </div> -->
                <div class="scmc"><span style="color:#FF0000;">*</span>&nbsp;联系电话：&nbsp;&nbsp;
                  <input class="spmc_sr" type="text" required class="px" name="phone" id="phone" value="<?php echo ($info["phone"]); ?>"/>
                </div>
                <!--  <div class="tu_ts">（必填）</div> -->


                <div class="scmc"><span style="color:#FF0000;">*</span>&nbsp;负&nbsp;责&nbsp;人：&nbsp;&nbsp;&nbsp;
                  <input class="spmc_sr" type="text" required class="px" name="smsuser" id="smsuser" value="<?php echo ($info["smsuser"]); ?>"/>
                </div>
                 <!-- <div class="tu_ts">（必填）</div> -->

                <!-- <div class="logo_tu_up"><span style="color:#FF0000;">*</span>&nbsp;&nbsp;LOGO图片:&nbsp;&nbsp;&nbsp;
                  <input type="text" class="logo_sr" name="headerpic" id="headerpic" value="<?php echo ($info["headerpic"]); ?>">
                    <script src="/tpl/static/upyun.js"></script>
                    <a href="###" onclick="upyunPicUpload('headerpic',1000,500,'<?php echo ($token); ?>')">
                    <input class="logo_sc b_b" type="button" value="上传"/>
                    </a>
                    <a href="###" onclick="viewImg('headerpic')" class="btn btn-primary btn_submit  J_ajax_submit_btns">
                    <input class="logo_yl b_b" type="button" value="预览"/>
                    </a>
                </div>
                <div class="tu_ts">（请填写图片外链地址 上传 预览 头像图片）</div> -->

                 <input type="hidden" name="token" value="<?php echo ($info["token"]); ?>" class="px" tabindex="1" size="40">
                <input class="cj_sp_anniu g_b" type="submit" value="确认修改"/>
                </form>
            </div>
            <!-- <div class="cj_nr_r">
              <img src="./tpl/User/default/img/eweima.png"/> 
            </div> -->
         </div>
    </div>
</div>
<!--公共底-->
<script>
$('#submit').click(function(){
  var status=true;
  var Fname = $("#wxname").val()
    if ($.trim(Fname) == "") {
      alert("请填写水站名称")
      status=false;
      return status;
    }

     var address = $("#address").val()
    if ($.trim(address) == "") {
      alert("请填写水站地址")
      status=false;
      return status;
    }
    
    var Fphone = $("#phone").val()
    var patrn = /(^[0-9]{3,4}\-[0-9]{7,8}$)|(^[0-9]{7,8}$)|(^\([0-9]{3,4}\)[0-9]{3,8}$)|(^0{0,1}13[0-9]{9}$)|(13\d{9}$)|(15[0135-9]\d{8}$)|(18[267]\d{8}$)/;
    if (!patrn.exec($.trim(Fphone))) {
        alert("请填写正确的手机号")
        status=false;
        return status;
    }

    var smsuser = $("#smsuser").val()
    if ($.trim(smsuser) == "") {
      alert("请填写水站负责人信息")
      status=false;
      return status;
    }

 if(status==true){
    $('form').submit();
 }
})
</script>

<hr>
<div class="d_public">
  <!-- <div class="d_public_one"><a href="http://www.cloud315.org/">关于溯云</a></div> -->
    <!-- <div class="d_public_two"><a href="<?php echo U('Index/helpcen');?>">帮助中心</a></div> -->
    <div class="d_public_three"><a href="http://www.megain.com/">联系我们</a></div>
    <div class="d_public_four"><a href="#">常见问题</a></div>
</div>
<div class="d_public_e">Copyright © 2018 www.megian.com &nbsp;All Rights Reserved</div>
<!-- <div class="d_public_n">copyright@cloud315.org</div> -->

</body>
</html>