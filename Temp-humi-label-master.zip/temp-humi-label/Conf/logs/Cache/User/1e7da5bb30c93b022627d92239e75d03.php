<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <?php if ($list): ?>
    <table style="width: 100%;margin-top: 10px;margin-bottom: 10px;">
        <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr style="height: 25px;">
                <td style="text-align: left;"><?php echo ($vo["gname"]); ?>水票</td>
                <td style="text-align: right;"><?php echo ($vo["Fnum"]); ?>张</td>
            </tr><?php endforeach; endif; else: echo "" ;endif; ?>
    </table>
    <?php else: ?>
        无
    <?php endif ?>
</body>
</html>