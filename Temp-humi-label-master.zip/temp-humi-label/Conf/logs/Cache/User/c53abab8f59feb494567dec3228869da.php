<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/css_home_pc.css"/>
<title>智能物联管理系统企业中心</title>
<script type="text/javascript" src="<?php echo RES;?>/js/jquery.min.js"></script>
<script src="<?php echo RES;?>/js/layer.js"></script>
<style>
.wel{cursor: pointer;position: relative;}
.wel:hover .move_b{opacity: 1;top:18px;}
.move_b {width: 80px;height:58px;background:#435867;position: absolute;opacity: 0;top:-5px;left:35px;transition:0.5s;-webkit-transition:.5s;-moz-transition:.5s;}
.move_b a{text-align: center;line-height: 26px;font-size: 14px;color: #fff;display: block;} 
.active{background:#fff; color:#435867;border-top:1px solid #435867;}
</style>
</head>
<body>
<!--header-->
<!--
<div class="mengceng_bq"></div>
-->
<div class="cj_header">
  <img class="logo_size" src="img/logo1.png" alt="logo"/><span class="logo_font">智能物联网管理系统</span>
    <div class="cj_h_r">
        <div class="wel">欢迎，<?php echo (session('uname')); ?>
        <div class="move_b">
        <a href="<?php echo U('Index/edit', array('token' => $token));?>">修改</a>
        <a href="/index.php?g=Home&m=Index&a=logout">退出</a>
        </div>
    </div>
        <div class="fw_time">服务到期时间:<?php echo (date("Y-m-d",$thisUser["viptime"])); ?></div>
    </div>
</div>
<div class="cj_nav">
  <div class="f1_line"></div>
    <div class="nav_k">
        <a class="nav_font" href="<?php echo U('Wlist/index', array('token' => $token));?>" id="Wlist">统计报表</a>
        <a class="nav_font" href="<?php echo U('Store/product', array('token' => $token));?>" id="Store">标签管理</a>
        <a class="nav_font" href="<?php echo U('Work/index', array('token' => $token));?>" id="Work">用户管理</a>
        <!-- <a class="nav_font nav_c " href="<?php echo U('Wlist/index', array('token' => $token));?>">统计信息</a> 企业中心Index/frame          -->
        
    </div>
  </div>       

</div>
<script>
$(document).ready(function(){
var url=window.location.href;
var reg=/m=[a-z]*/i;
var arr=url.match(reg);
var str=arr[0].substr(2);
$("#"+str).addClass("active");
})
function drop_confirm(msg, url){
    if(confirm(msg)){
        window.location = url;
    }
}
</script>


 <style>
  .old_2{background:#fff; color:#435867;}  
</style>
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/shop_guan_li.css"/>
<!--内容-->
<div class="scgl_nr">
  <!-- <div class="tjb1"><div class="yd"></div>送水工管理</div> -->
    <div class="tjb2">上传记录列表
    <div style="float:right;margin: 16px 150px 0 0;">
        <a href="<?php echo U('Work/index',array('token'=>$token));?>" >
            <input class="b_b" type="button" style="padding:5px 8px" value="返回上一级"/>
        </a>
    </div>
</div>
<div class="tjb3" style="font-size: 18px">
    <form method="post" action="">
        <input type="hidden" name="Fid" value="<?php echo ($_GET['Fid']); ?>">
        <span style="color: #fff;">标签编号：</span><input type="text" name="labelid">
        <span style="color: #fff;">起始时间：</span><input name="start" type="date" value="" >
        <span style="color: #fff;">截止时间：</span><input name="end" type="date" value="" >
        <input type="submit" value="查询" class="logo_sc b_b">
    </form>
</div>
    <table class="spgl_table">
        <tr class="">
            <td class="spgl_t_b xlh" style="">标签编号</td>
            <td class="spgl_t_b flmc" style="">采样起始时间</td>
            <td class="spgl_t_b gg" style="">采样截至时间</td>
            <td class="spgl_t_b spwg" style="">上传地址</td>
            <td class="spgl_t_b cz" style="">配置信息</td>
            <td class="spgl_t_b cz" style="">记录概况</td>
        </tr>
        <?php if(is_array($user_record)): $i = 0; $__LIST__ = $user_record;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$hostlist): $mod = ($i % 2 );++$i;?><tr class="h_bg">
                <td class="spgl_t_b xlh" style=""><?php echo ($hostlist["labelId"]); ?></td>
                <!-- <td class="spgl_t_b flmc" style="">
                    <?php if($hostlist['Fstatus'] == 2): ?><label>配送中<label><?php endif; ?>
                    <?php if($hostlist['Fstatus'] == 3): ?><label>已完成</label><?php endif; ?>
                </td> -->
                <td class="spgl_t_b flmc" style=""><?php echo (date("Y-m-d H:i:s",$hostlist["startDate"])); ?></td>
                <td class="spgl_t_b flmc" style=""><?php echo (date("Y-m-d H:i:s",$hostlist["endDate"])); ?></td>
                <td class="spgl_t_b gg" style=""><?php echo ($hostlist["uploadAddr"]); ?></td>
                <td class="spgl_t_b cz" style="">
                <a href="<?php echo U('Store/conf_detail',array('id'=>$hostlist['cid']));?>">点击查看</a>
                </td>
                <td class="spgl_t_b cz" style="">
                <a href="<?php echo U('Store/record_detail',array('id'=>$hostlist['id']));?>">点击查看</a>
                </td>
            </tr><?php endforeach; endif; else: echo "" ;endif; ?>
    </table>
    
    <!---->
    <p class="neirong_yema">  
       <?php echo ($page); ?>
    </p>
    
    
</div>



<script>
$(document).ready(function(){
<!-------------分页------------------->       
    $(".yema_click").click(function(){
        $(".yema_click").css({background:"none",color:"#333"})
        $(this).css({background:"#435867",color:"#fff"})
        })
        
    $(".diyiye").click(function(){
        $(".yema_click").css({background:"none",color:"#333"})
        $(".yema_first").css({background:"#435867",color:"#fff"})
        })
    $(".weiye").click(function(){
        $(".yema_click").css({background:"none",color:"#333"})
        $(".yema_last").css({background:"#435867",color:"#fff"})
        })  
})

function alert2(msg,url){
   if(confirm(msg)){
        window.location = url;
    }
}


</script>

<!--公共底-->
<hr>
<div class="d_public">
  <!-- <div class="d_public_one"><a href="http://www.cloud315.org/">关于溯云</a></div> -->
    <!-- <div class="d_public_two"><a href="<?php echo U('Index/helpcen');?>">帮助中心</a></div> -->
    <div class="d_public_three"><a href="http://www.megain.com/">联系我们</a></div>
    <div class="d_public_four"><a href="#">常见问题</a></div>
</div>
<div class="d_public_e">Copyright © 2018 www.megian.com &nbsp;All Rights Reserved</div>
<!-- <div class="d_public_n">copyright@cloud315.org</div> -->

</body>
</html>