<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/css_home_pc.css"/>
<title>智能物联管理系统企业中心</title>
<script type="text/javascript" src="<?php echo RES;?>/js/jquery.min.js"></script>
<script src="<?php echo RES;?>/js/layer.js"></script>
<style>
.wel{cursor: pointer;position: relative;}
.wel:hover .move_b{opacity: 1;top:18px;}
.move_b {width: 80px;height:58px;background:#435867;position: absolute;opacity: 0;top:-5px;left:35px;transition:0.5s;-webkit-transition:.5s;-moz-transition:.5s;}
.move_b a{text-align: center;line-height: 26px;font-size: 14px;color: #fff;display: block;} 
.active{background:#fff; color:#435867;border-top:1px solid #435867;}
</style>
</head>
<body>
<!--header-->
<!--
<div class="mengceng_bq"></div>
-->
<div class="cj_header">
  <img class="logo_size" src="img/logo1.png" alt="logo"/><span class="logo_font">智能物联网管理系统</span>
    <div class="cj_h_r">
        <div class="wel">欢迎，<?php echo (session('uname')); ?>
        <div class="move_b">
        <a href="<?php echo U('Index/edit', array('token' => $token));?>">修改</a>
        <a href="/index.php?g=Home&m=Index&a=logout">退出</a>
        </div>
    </div>
        <div class="fw_time">服务到期时间:<?php echo (date("Y-m-d",$thisUser["viptime"])); ?></div>
    </div>
</div>
<div class="cj_nav">
  <div class="f1_line"></div>
    <div class="nav_k">
        <a class="nav_font" href="<?php echo U('Wlist/index', array('token' => $token));?>" id="Wlist">统计报表</a>
        <a class="nav_font" href="<?php echo U('Store/product', array('token' => $token));?>" id="Store">标签管理</a>
        <a class="nav_font" href="<?php echo U('Work/index', array('token' => $token));?>" id="Work">用户管理</a>
        <!-- <a class="nav_font nav_c " href="<?php echo U('Wlist/index', array('token' => $token));?>">统计信息</a> 企业中心Index/frame          -->
        
    </div>
  </div>       

</div>
<script>
$(document).ready(function(){
var url=window.location.href;
var reg=/m=[a-z]*/i;
var arr=url.match(reg);
var str=arr[0].substr(2);
$("#"+str).addClass("active");
})
function drop_confirm(msg, url){
    if(confirm(msg)){
        window.location = url;
    }
}
</script>

<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/shou_ye.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/shop_guan_li.css"/>
<script type="text/javascript" src="./tpl/static/laydate/laydate.js"></script>
<!--内容-->
<div class="sy_nr">
    <div class="tjb">统计信息</div>    
<script>
  function aa(){
    stmps=document.getElementById("s");
    stmpe=document.getElementById("e");
    if(stmps.value>stmpe.value){
      alert("请输入正确的日期范围")
      return;
    }
    url="&st="+stmps.value+"&e="+stmpe.value;
    url="<?php echo U('Wlist/index', array('token' => $token));?>"+url
    window.location.href=url;
  }
  function a(stmps,stmpe){
    $('#s').val(stmps);
    $('#e').val(stmpe);
    url="&st="+stmps+"&e="+stmpe;
    url="<?php echo U('Wlist/index', array('token' => $token));?>"+url;
    window.location.href=url;
  }
</script>
<div class="sx">
    <span class="sx_time">高级查询：</span>
    <input class="logo_sr" style="margin-left:22px;" type="text" value="<?php echo (date("Y-m-d",$start)); ?>" id="s" onclick="laydate()"/>
    <span style="vertical-align:middle; padding:0 10px;">至</span>
    <input class="logo_sr" type="text" value="<?php echo (date("Y-m-d",$last)); ?>" id="e" onclick="laydate()"/>
    <input class="find_anniu g_b ml16" type="button" value="查询" onclick="aa()"/>
    <input class="find_anniu g_b ml16" type="button" value="本周" onclick="a('<?php echo ($bw); ?>','<?php echo ($now); ?>')"/>
    <input class="find_anniu g_b ml16" type="button" value="本月" onclick="a('<?php echo ($bm); ?>','<?php echo ($now); ?>')"/>
     <input class="find_anniu g_b ml16" type="button" value="本季" onclick="a('<?php echo ($bq); ?>','<?php echo ($now); ?>')"/>
</div>

<div class="tjb2">报警次数统计</div>
<!-- 新增当日查看 -->
  <div class="itembar">
    <a href="<?php echo U('Store/product',array('token' => $token,'over'=>1));?>" style="color:#eb6100">总报警次数：<?php echo (($ovnum)?($ovnum):'0'); ?></a>
    <!-- &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;标签类型和数量：<?php if($reslb['WIFI'] > 0): ?>WIFI:<?php echo ($reslb["WIFI"]); endif; ?>&nbsp;&nbsp;<?php if($reslb['NFC'] > 0): ?>NFC:<?php echo ($reslb["NFC"]); endif; ?>&nbsp;&nbsp;<?php if($reslb['BLE'] > 0): ?>BLE:<?php echo ($reslb["BLE"]); endif; ?><br/> -->
    <!-- <a href="" style="margin-left: 80px">总上传次数：<?php echo (($upnum)?($upnum):'0'); ?></a> -->
  </div>
  <div class="tjb2">标签统计：</div>
    <div class="itembar">
        <a href="<?php echo U('Store/product',array('token' => $token));?>">总标签数：<?php echo (($total)?($total):'0'); ?></a>
    </div>
    <div class="tjb2">数据上传统计</div>
    <div class="itembar">
        总上传次数：<?php echo (($upnum)?($upnum):'0'); ?>
    </div>
    <!-- <?php if(isset($res)): ?><table class="spgl_table">
        <tr class="">
            <td class="spgl_t_b flmc" style="">标签名称</td>
            <td class="spgl_t_b flmc" style="">标签类型</td>            
            <td class="spgl_t_b flmc" style="">上传人</td>
            <td class="spgl_t_b flmc" style="">上传时间</td>

        </tr>
        <?php if(is_array($res)): $i = 0; $__LIST__ = $res;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$res): $mod = ($i % 2 );++$i;?><tr class="h_bg">
                <td class="spgl_t_b flmc" style=""><?php echo ($res["labelId"]); ?></td>
                <td class="spgl_t_b flmc" style=""><?php echo ($res["labelType"]); ?></td>
                <td class="spgl_t_b flmc" style=""><?php echo ($res["Fname"]); ?></td>
                <td class="spgl_t_b gg" style=""><?php echo (date("Y-m-d H:m:s",$res["uptime"])); ?></td>                
            </tr><?php endforeach; endif; else: echo "" ;endif; ?>
    </table><?php endif; ?> -->
<div class="ctbtn">
<p><input type="radio" name="ctype" value="labelnum"><span>标签个数</span></p>
<p><input type="radio" name="ctype" value="upload"><span>上传次数</span></p>
<p><input type="radio" name="ctype" value="warning" checked="checked">
<span class="ctact">报警次数</span></p>
</div>
<div id="chartarea" style="width:960px;height:400px"></div>
  </div>
<script src="/tpl/static/echart/dist/echarts.js"></script>
<script type="text/javascript">
    //底部图 theme表主题，warning报警表;upload上传次数表;labelnum标签总数表
    

//var myChart = echarts.init(document.getElementById('chartarea'),'warning');
function _ajax(theme,sta,end){
    $.ajax({
        type:'post',
        url:"<?php echo U('Wlist/chartdata',array('token'=>$token));?>",
        data:{theme:theme,start:sta,end:end},
        success:function(res){            
            var result=JSON.parse(res);
            var themer="";
            switch (theme){
                case 'warning':themer='报警次数';break;
                case 'upload':themer='上传次数';break;
                case 'labelnum':themer='标签数量';break;
            }           
            require.config({
              paths: {
              echarts: '/tpl/static/echart/dist'
              }
            });
            require(
            [
                'echarts',                
                'echarts/chart/line'
            ],
            function (ec) {
            var myChart = ec.init(document.getElementById('chartarea'));           
            var option = {
                title:{text:sta+'至'+end+themer},
                tooltip: {trigger:'axis'},
                xAxis:{data:result.xarr},
                yAxis:{},
                series:[{
                    name:themer,
                    type:'line',
                    data:result.yarr
                }]
            };
            myChart.setOption(option);
        })
        },
        error:function(msg){
            alert(msg);
        }
    });
}
$(function(){
    var st=$("#s").val();
    var end=$("#e").val();
    _ajax('warning',st,end);
    $("input[name='ctype']").change(function(){
      var radio=$(this).val();      
      $("input[name='ctype']").next('span').removeClass('ctact');
      $(this).next('span').addClass('ctact');
      switch(radio){
        case 'warning':_ajax('warning',st,end);break;
        case 'upload':_ajax('upload',st,end);break;
        default:_ajax('labelnum',st,end);
      }
    });
});

</script>
<!--公共底-->
<hr>
<div class="d_public">
  <!-- <div class="d_public_one"><a href="http://www.cloud315.org/">关于溯云</a></div> -->
    <!-- <div class="d_public_two"><a href="<?php echo U('Index/helpcen');?>">帮助中心</a></div> -->
    <div class="d_public_three"><a href="http://www.megain.com/">联系我们</a></div>
    <div class="d_public_four"><a href="#">常见问题</a></div>
</div>
<div class="d_public_e">Copyright © 2018 www.megian.com &nbsp;All Rights Reserved</div>
<!-- <div class="d_public_n">copyright@cloud315.org</div> -->

</body>
</html>