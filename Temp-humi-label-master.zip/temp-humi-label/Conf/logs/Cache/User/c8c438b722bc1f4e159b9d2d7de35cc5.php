<?php if (!defined('THINK_PATH')) exit();?>
 <style>
  .old_2{background:#fff; color:#435867;}  


  .tipbox:before,.tipbox:after{content: "";
position: absolute;
border-style:dashed dashed  solid   dashed;
line-height: 1;
display: inline-block;}
.tipbox:after{
left: 75px;
border-color: transparent transparent #666;
border-width: 11px;

top: -22px; z-index:1080}
.tipbox:before{left: 76px;
border-color: transparent transparent #666;
border-width: 10px; top:-19px; z-index:1081
 
}
.tipbox{
position:absolute;
top: 160px;
left: 455px;
width: 150px;
display: none;
color: #fff;
line-height: 40px;
text-align: center;
background-color:#666;
border: 1px solid #666;

padding: 5px;
text-align: center;
border-radius: 2px;
word-wrap: break-word;
break-word:break-all;

}
#bid1:hover{
  transform:rotate(180deg);
-ms-transform:rotate(180deg);   /* IE 9 */
-moz-transform:rotate(180deg);  /* Firefox */
-webkit-transform:rotate(180deg); /* Safari 和 Chrome */
-o-transform:rotate(180deg); /* Opera */
}
#bid2:hover{
  transform:rotate(180deg);
-ms-transform:rotate(180deg);   /* IE 9 */
-moz-transform:rotate(180deg);  /* Firefox */
-webkit-transform:rotate(180deg); /* Safari 和 Chrome */
-o-transform:rotate(180deg); /* Opera */
}
</style>
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/shangpin_guan_li.css"/>
<script src="<?php echo STATICS;?>/jquery-1.4.2.min.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo RES;?>/js/qrcode.js"></script>
<script type="text/javascript"  src="<?php echo RES;?>/js/jquery.qrcode.js"></script>
<link rel="stylesheet" type="text/css" href="./tpl/static/date/hDate.css"/>
<script type="text/javascript" src="./tpl/static/date/hDate.js"></script>
<script type="text/javascript" src="/public/websocket.js"></script>
<!--内容-->
<div class="scgl_nr" style="height:auto">
<div  class="tipbox">
  <p>统计用户<br>已完成订单总数</p>

</div>
	<div class="tjb1"><div class="yd"></div>新用户统计</div>
 
	<table class="spgl_table" style="height:780px">
    <thead>
  <tr style="height:40px">
           <!--  <td style="width: 50px;">选择</td> -->
        	<th class="spgl_t_b xlh" style="">序号</th>
            <th class="spgl_t_b flmc" style="">订单编号</th>
            <th class="spgl_t_b gg" style="">送水地址</th>
            <th class="spgl_t_b gg" style="">下单时间</th>
            <th class="spgl_t_b gg" style="">总金额</th>
 
        </tr>
     </thead>
       <tbody class="contet">
        <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><tr class="h_bg">
            <!-- <td><input type="checkbox" value="<?php echo ($item["Fid"]); ?>" name="ixz"></td> -->
        	<td class="spgl_t_b xlh" style=""><?php echo ($item["Fid"]); ?></td>
          <th class="spgl_t_b flmc" style=""><?php echo ($item["Forderid"]); ?></td>
           <td class="spgl_t_b gg" style=""><?php echo ($item["Faddress"]); ?></td>
            <th class="spgl_t_b gg" style=""><?php echo (date("Y-m-d H:i:s",$item["Fordertime"])); ?></th>
             <th class="spgl_t_b gg" style=""><?php echo ($item["Ftotal"]); ?></td>
           
        
        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
        
    
          <tr>
            
              <!--页面显示-->
    <p class="neirong_yema">  
        <?php echo ($page); ?>
    </p>
          </tr> 
        </tbody>
        <input type="hidden" value="desc" id="sort22">
         <input type="hidden" value="desc" id="sort33">
    </table>
    
  
 
   
    
    
</div>


    
</div>
</body>


</html>