<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/css_home_pc.css"/>
<title> 码上订水</title>
<script type="text/javascript" src="<?php echo RES;?>/js/jquery.min.js"></script>





<script src="<?php echo RES;?>/js/layer.js"></script>
<style>

</style>
</head>
<body>
<!--header-->
<!--
<div class="mengceng_bq"></div>
-->


<div class="cj_header">
  <img class="logo_size" src="./tpl/User/default/img/cloudlogo.png" alt="logo"/>
    <div class="cj_h_r">
        <div class="wel">欢迎，<?php echo (session('uname')); ?></div>
        <div class="fw_time">服务到期时间:<?php echo (date("Y-m-d",$thisUser["viptime"])); ?></div>
    </div>
</div>
<div class="cj_nav">
  <div class="f1_line"></div>
    <div class="nav_k">
        <a class="nav_font nav_c " href="<?php echo U('Index/frame', array('token' => $token));?>">首页</a>
        <a class="nav_font nav_c " href="<?php echo U('Store/product', array('token' => $token));?>">产品管理</a>
        <a class="nav_font nav_c " href="<?php echo U('Work/index', array('token' => $token));?>">送水工管理</a>


        <div class="nav_font nav_c ex_nav " style="">订单管理
               <div class="nav_xlcd_k" style="">
                <div class="nav_xl_font " style="">
                    <a class="nav_font nav_c " href="<?php echo U('Worder/index', array('token' => $token));?>">订单管理</a>
                </div>

                <div class="nav_xl_font " style="">
                    <a class="nav_font nav_c " href="<?php echo U('Wmember/countmember', array('token' => $token));?>">下单会员</a>
                </div>
            </div>   
        </div>

<?php if ($Ftype == '1'){ ?>
        <div class="nav_font nav_c ex_nav " style="">本地生活
               <div class="nav_xlcd_k" style="">
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Near/index', array('token' => $token));?>">基本管理</a>
                </div>

                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Near/orderlist', array('token' => $token));?>">订单</a>
                </div>
            </div>   
        </div>
<?php }?>   

         <!-- <a class="nav_font nav_c " href="<?php echo U('Wmember/countmember', array('token' => $token));?>">下单会员</a> -->

         <a class="nav_font nav_c " href="<?php echo U('Wmember/index', array('token' => $token));?>">会员列表</a>
        

        

        <!-- <a class="nav_font nav_c " href="<?php echo U('Worder/index', array('token' => $token));?>">订单管理</a> -->

        <a class="nav_font nav_c " href="<?php echo U('Wlist/index', array('token' => $token));?>">统计信息</a>

        <!-- <a class="nav_font nav_c " href="<?php echo U('Recmlog/index', array('token' => $token));?>">学生推荐</a> -->

          <div class="nav_font nav_c ex_nav " style="">其它管理
               <div class="nav_xlcd_k" style="">
                <div class="nav_xl_font " style="">

                    <a href="<?php echo U('Storeflash/index', array('token' => $token));?>">广告管理</a>
                </div>
             
                <!--  <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Wothers/index', array('token' => $token));?>">其它管理</a>
                </div> -->
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Worder/rewardlist', array('token' => $token));?>">奖励日志</a>
                </div>

                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Index/intro', array('token' => $token));?>">商城介绍</a>
                </div>
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('ticket/set', array('token' => $token));?>">水票设置</a>
                </div>
                <div class="nav_xl_font " style="">
                    <a href="<?php echo U('Notice/index', array('token' => $token));?>">公告管理</a>
                </div>
                 <div class="nav_xl_font " style="">
                    <a href="javascript:void(0)" id="ordertimes">下单次数</a>
                </div>
              
            </div>   
        </div>
    </div>

        

        <div class="public_anniu_k">
              <input class="public_anniu b_b scyl" type="button" value="扫码派单" id="about"/>
              <input class="public_anniu b_b scyl" type="button" value="预约时间" id="ordertime" style="margin-top:10px;"/>
 <!--              <input class="public_anniu b_b scyl" type="button" value="下单次数" id="ordertimes" style="margin-top:10px;"/> -->
           <!--  <a href="<?php echo U('Index/helpcen');?>" target="_blank"><input class="public_anniu b_b" style="margin-top:10px;" type="button" value="帮助中心"/></a>
           <a href="#"> <input class="public_anniu b_b" style="margin-top:10px;" type="button" value="常见问题"/></a> -->
            <a href="/index.php?g=Home&m=Index&a=logout"> <input class="public_anniu b_b" style="margin-top:10px;" type="button" value="退出"/></a>
        </div>
</div>
<script>

function drop_confirm(msg, url){
    if(confirm(msg)){
        window.location = url;
    }
</script>



<script>
//弹出layer
$('#about').on('click', function(){
//alert("ok");
    layer.open({
        type: 2,
        title: '预览页',
        shadeClose: true,   
        shade: 0.8,
        area: ['1000px', '700px'],
        content: 'index.php?g=User&m=Index&a=showview'   //打开的页面<?php echo ($f_siteUrl); ?>/
    }); 
});

$('#ordertime').click(function(){
         layer.open({
        type: 2,
        title: '预览页',
        shadeClose: true,   
        shade: 0.8,
        area: ['400px', '200px'],
        content: 'index.php?g=User&m=Index&a=ordertime'   //打开的页面<?php echo ($f_siteUrl); ?>/
    }); 
})

$('#ordertimes').click(function(){
         layer.open({
        type: 2,
        title: '预览页',
        shadeClose: true,   
        shade: 0.8,
        area: ['400px', '200px'],
        content: 'index.php?g=User&m=Worder&a=ordertimes'   //打开的页面<?php echo ($f_siteUrl); ?>/
    }); 
})
</script>

 <style>
  .old_2{background:#fff; color:#435867;}  
  .tipbox:before,.tipbox:after{content: "";
position: absolute;
border-style:dashed dashed  solid   dashed;
line-height: 1;
display: inline-block;}
.tipbox:after{
left: 75px;
border-color: transparent transparent #666;
border-width: 11px;

top: -22px; z-index:1080}
.tipbox:before{left: 76px;
border-color: transparent transparent #666;
border-width: 10px; top:-19px; z-index:1081
 
}
.tipbox{
position:absolute;
top: 160px;
left: 455px;
width: 150px;
display: none;
color: #fff;
line-height: 40px;
text-align: center;
background-color:#666;
border: 1px solid #666;

padding: 5px;
text-align: center;
border-radius: 2px;
word-wrap: break-word;
break-word:break-all;

}
#bid1:hover{
  transform:rotate(180deg);
-ms-transform:rotate(180deg);   /* IE 9 */
-moz-transform:rotate(180deg);  /* Firefox */
-webkit-transform:rotate(180deg); /* Safari 和 Chrome */
-o-transform:rotate(180deg); /* Opera */
}
#bid2:hover{
  transform:rotate(180deg);
-ms-transform:rotate(180deg);   /* IE 9 */
-moz-transform:rotate(180deg);  /* Firefox */
-webkit-transform:rotate(180deg); /* Safari 和 Chrome */
-o-transform:rotate(180deg); /* Opera */
}
</style>
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/shangpin_guan_li.css"/>
<script src="<?php echo STATICS;?>/jquery-1.4.2.min.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo RES;?>/js/qrcode.js"></script>
<script type="text/javascript"  src="<?php echo RES;?>/js/jquery.qrcode.js"></script>
<link rel="stylesheet" type="text/css" href="./tpl/static/date/hDate.css"/>
<script type="text/javascript" src="./tpl/static/date/hDate.js"></script>
<script type="text/javascript" src="/public/websocket.js"></script>
<!--内容-->
<div class="scgl_nr" style="height:auto">
<div  class="tipbox">
  <p>统计用户<br>已完成订单总数</p>
</div>
    <div class="tjb1"><div class="yd"></div>生活服务订单</div>
 <form method="post" action="<?php echo U('Near/orderlist',array('token'=>$token));?>">
    <div class="tjb4" style="background:#ECECFB none repeat scroll 0% 0%">
     &nbsp;&nbsp;下单时间:
        <input name="starttime" id="date1" type="text"  style="height:28px;" onClick="calendar.show({ id: this })" value="<?php echo ($starttime); ?>" />
        &nbsp;&nbsp;——&nbsp;&nbsp;
        <input name="endtime" id="date2" type="text"  style="height:28px;" onClick="calendar.show({ id: this })" value="<?php echo ($endtime); ?>" />
        服务类别:
        <select  name="type"  style="height:28px;">
                    <option value="-1">请选择</option>
                     <option value="1" <?php if($type == 1): ?>selected<?php endif; ?>>回收</option>
                     <option value="2" <?php if($type == 2): ?>selected<?php endif; ?>>清洁</option>
                     <option value="3" <?php if($type == 3): ?>selected<?php endif; ?>>干洗</option>
                     <option value="3" <?php if($type == 3): ?>selected<?php endif; ?>>其他</option>
        </select>
         状态:
        <select  name="status"  style="height:28px;">
                    <option value="-1">请选择</option>
                     <option value="1" <?php if($status == 1): ?>selected<?php endif; ?>>未处理</option>
                     <option value="2" <?php if($status == 2): ?>selected<?php endif; ?>>已处理</option>
        </select>
        <input class="logo_sc b_b" type="submit" id="allclick" value="查看" />
    </div>
    <input type="hidden" name='token' value="<?php echo ($_GET['token']); ?>">
</form>








  
    <table class="spgl_table" style="height:780px">
    <thead>
  <tr style="height:40px">
           <!--  <td style="width: 50px;">选择</td> -->
            <th class="spgl_t_b xlh" style="">序号</th>
            <th class="spgl_t_b flmc" style="">订单号</th>
            <!-- <th class="spgl_t_b gg" style="">送水地址</th> -->
              <!-- <td class="spgl_t_b gg" style="">注册时间</td> -->
             <!-- <th class="spgl_t_b xlh" style="" id="fordernum"><a href="#">下单数 <img src="img/up.jpg" style="width:15px;margin-left:5px;" id="bid2"></a><img src="img/show.jpg"  style="width:15px;margin-left:5px;" id="show"></th> -->
             <th class="spgl_t_b xlh" style="">订单状态</th>
              <th class="spgl_t_b xlh" style="">服务类别</th>
              <th class="spgl_t_b xlh" style="">下单手机号</th>
              <th class="spgl_t_b flmc" style="" >下单时间</th>
 
        </tr>
     </thead>
       <tbody class="contet">
        <?php if(is_array($orderinfos)): $i = 0; $__LIST__ = $orderinfos;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><tr class="h_bg">
            <!-- <td><input type="checkbox" value="<?php echo ($item["Fid"]); ?>" name="ixz"></td> -->
            <td class="spgl_t_b xlh" style=""><?php echo ($i); ?></td>
            <td class="spgl_t_b flmc" style=""><?php echo ($item["ordernum"]); ?></td>
            <!-- <td class="spgl_t_b gg" style=""><?php echo ($item["Faddress"]); ?></td> -->
            <!--  <td class="spgl_t_b gg" style=""><?php echo (date("Y-m-d H:i:s",$item["Fcreatetime"])); ?></td> -->
               <!-- <td class="spgl_t_b xlh" style=""><?php echo (($item["Fordernum"])?($item["Fordernum"]):'0'); ?></td> -->
               <td class="spgl_t_b xlh" style="">
                   <?php if($item["status"] == '0' ): ?><span style="color:red">未处理</span>
                   <?php elseif($item["status"] == '1'): ?> 
                        <span style="color:blue">已完成</span>
                   <?php elseif($item["status"] == '2'): ?>
                        <span style="color:green">已取消</span>
                    <?php else: ?>
                        <span style="color:green">催单</span><?php endif; ?>
               </td>
               <td class="spgl_t_b xlh" style="">
                    <?php if($item["type"] == '0' ): ?><span style="color:red">回收</span>
                   <?php elseif($item["type"] == '1'): ?> 
                        <span style="color:blue">清洁</span>
                   <?php elseif($item["type"] == '2'): ?>
                        <span style="color:green">干洗</span>
                    <?php else: ?>
                        <span style="color:green">常用</span><?php endif; ?>
               </td>
               <td class="spgl_t_b xlh" style=""><?php echo ($item["userphone"]); ?></td>
               <td class="spgl_t_b flmc" style=""><?php echo (date("Y-m-d H:i:s",$item["createtime"])); ?></td>
        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
        
    
          <tr>
            
              <!--页面显示-->
    <p class="neirong_yema">  
        <?php echo ($page); ?>
    </p>
          </tr> 
        </tbody>
        <input type="hidden" value="desc" id="sort22">
         <input type="hidden" value="desc" id="sort33">
    </table>
    
  
 
   
    
    
</div>

  
<!--公共底-->
<hr>
<div class="d_public">
    <div class="d_public_one">关于溯云</div>
    <div class="d_public_two">帮助中心</div>
    <div class="d_public_three">联系我们</div>
    <div class="d_public_four">常见问题</div>
</div>
<div class="d_public_e">Copyright © 2015 cloud315.com All Rights Reserved</div>
<div class="d_public_n">copyright@cloud315.com</div>
    
</div>
</body>
<script type="text/javascript">

    //上下箭头
    <?php if($_GET['sort']=='desc'){ ?>
         $('#bid2').attr('src','img/down.jpg');
          $('#bid1').attr('src','img/down.jpg');
    <?php }?>
     <?php if($_GET['sort']=='asc'){ ?>
         $('#bid1').attr('src','img/up.jpg');
         $('#bid2').attr('src','img/up.jpg');
    <?php }?>
    $('#allclick').click(function(){
    // var ixz = document.getElementsByName("ixz");
    // var stmp = [];
    // for(var i=0;i<ixz.length;i++){
    //     if(ixz[i].checked){
    //         stmp.push(ixz[i].value);
    //     }
    // }
    // var ids=stmp.toString();
    //alert(ids);
    var date1=$('#date1').val();
    var date2=$('#date2').val();
    var floor=$('#floor').val();
    window.location.href="<?php echo U('Wmember/excel',array('token'=>$_GET['token'],'excel'=>'excel'));?>&date1="+date1+"&date2="+date2+"&floor="+floor;
  });

    //智能排序
    $('#show').mouseover(function(){

       $('.tipbox').css('display','block');

    })
     $('#show').mouseout(function(){

       $('.tipbox').css('display','none');

    })

      

   $('#fordernum').click(function(){
        var date1=$('#date1').val();
        var date2=$('#date2').val();
        var floor=$('#floor').val();
        var sort='';
         var sort22=$('#sort22').val();
         if(sort22=='desc'){
            sort='desc';
         }else{
            sort='asc';
         }
      
        var url='index.php?g=User&m=Wmember&a=sort_desc&date1='+date1+'&date2='+date2+'&floor='+floor;
       //$.get(url,{fordernum:'fordernum',token:'<?php echo ($_GET['token']); ?>','sort':sort},function(result){
                
                 <?php if(empty($_GET['sort'])){ ?>

                   $('#sort22').val('asc');
                       $('#bid2').attr('src','img/down.jpg');
                       sort='asc';
                       window.location.href=url+"&fordernum=fordernum&token="+"<?php echo ($_GET['token']); ?>"+"&sort="+sort;
                 <?php } ?>


                 <?php if($_GET['sort']=='desc'){ ?>

                   $('#sort22').val('asc');
                       $('#bid2').attr('src','img/down.jpg');
                       sort='asc';
                       window.location.href=url+"&fordernum=fordernum&token="+"<?php echo ($_GET['token']); ?>"+"&sort="+sort;
                 <?php } ?>
                 <?php if($_GET['sort']=='asc'){ ?>
                   $('#sort22').val('desc');
                       $('#bid2').attr('src','img/up.jpg');
                       sort='desc';
                        window.location.href=url+"&fordernum=fordernum&token="+"<?php echo ($_GET['token']); ?>"+"&sort="+sort;
                 <?php } ?>
                 // if(sort=='desc'){
                    
                 // }else{
                      $('#sort22').val('desc');
                      $('#bid2').attr('src','img/up.jpg');
                 // }
                // $('.contet').html(result);
                 //alert(result);

                
           // });


    })

   $('#lasttime').click(function(){
 
        var date1=$('#date1').val();
        var date2=$('#date2').val();
        var floor=$('#floor').val();

        var sort='';
        var sort33=$('#sort33').val();
         if(sort33=='desc'){
            sort='desc';
         }else{
            sort='asc';
         }
        
        var url='index.php?g=User&m=Wmember&a=sort_desc&date1='+date1+'&date2='+date2+'&floor='+floor;
       //$.get(url,{lasttime:'lasttime',token:'<?php echo ($_GET['token']); ?>','sort':sort},function(result){
            
             // if(sort=='desc'){
             //        $('#sort33').val('asc');
             //        $('#bid1').attr('src','img/down.jpg');
             //     }else{
             //          $('#sort33').val('desc');
             //           $('#bid1').attr('src','img/up.jpg');
             //     }
                 
                //$('.contet').html(result);
            // });
           
                 <?php if(empty($_GET['sort'])){ ?>

                   $('#sort33').val('asc');
                       $('#bid1').attr('src','img/down.jpg');
                       sort='asc';
                       window.location.href=url+"&lasttime=lasttime&token="+"<?php echo ($_GET['token']); ?>"+"&sort="+sort;
                 <?php } ?>

           <?php if($_GET['sort']=='desc'){ ?>
                   $('#sort33').val('asc');
                       $('#bid1').attr('src','img/down.jpg');
                       sort='asc';
                       window.location.href=url+"&lasttime=lasttime&token="+"<?php echo ($_GET['token']); ?>"+"&sort="+sort;
                 <?php } ?>
                 <?php if($_GET['sort']=='asc'){ ?>
                   $('#sort33').val('desc');
                       $('#bid1').attr('src','img/up.jpg');
                        sort='desc';
                       window.location.href=url+"&lasttime=lasttime&token="+"<?php echo ($_GET['token']); ?>"+"&sort="+sort;
                 <?php } ?>
    })



//详情弹框 

    function orderifno(userid,token,suername){
     
        layer.open({
        type: 2,
        title:'客户'+suername+'已完成订单详情' ,
        shadeClose: true,   
        shade: 0.8,
        area: ['950px', '600px'],
        content: '/index.php?g=User&m=Wmember&a=orderinfo&userid='+userid+'&token='+token+'&suername='+suername   //打开的页面
    }); 
  }


</script>

</html>