<?php if (!defined('THINK_PATH')) exit();?><style type="text/css">
  
  .g_b {
  cursor: pointer;
  height: 30px;
  background: #44BB00;
  border: none;
  border-radius: 1px;
  color: #fff;
}
</style>
<form action="<?php echo U('Index/ordertimedo');?>" method="post">
设置开始时间:
  <select class="sele_type font5b"  name="Fstart_time" id="Fstart_time" style="width:150px;height:40px">
       
        <option value="6" <?php if($res["Fstart_time"] == 6): ?>selected="selected"<?php endif; ?>>6:00</option>
        <option value="6.5" <?php if($res["Fstart_time"] == 6.5): ?>selected="selected"<?php endif; ?>>6:30</option>
        <option value="7" <?php if($res["Fstart_time"] == 7): ?>selected="selected"<?php endif; ?>>7:00</option>
        <option value="7.5" <?php if($res["Fstart_time"] == 7.5): ?>selected="selected"<?php endif; ?>>7:30</option>
        <option value="8" <?php if($res["Fstart_time"] == 8): ?>selected="selected"<?php endif; ?>>8:00</option>
         <option value="8.5" <?php if($res["Fstart_time"] == 8.5): ?>selected="selected"<?php endif; ?>>8:30</option>
        <option value="9" <?php if($res["Fstart_time"] == 9): ?>selected="selected"<?php endif; ?>>9:00</option>
        <option value="9.5" <?php if($res["Fstart_time"] == 9.5): ?>selected="selected"<?php endif; ?>>9:30</option>
        <option value="10" <?php if($res["Fstart_time"] == 10): ?>selected="selected"<?php endif; ?>>10:00</option>
        <option value="10.5" <?php if($res["Fstart_time"] == 10.5): ?>selected="selected"<?php endif; ?>>10:30</option>
        <option value="11" <?php if($res["Fstart_time"] == 11): ?>selected="selected"<?php endif; ?>>11:00</option>
        <option value="11.5" <?php if($res["Fstart_time"] == 11.5): ?>selected="selected"<?php endif; ?>>11:30</option>
        <option value="12" <?php if($res["Fstart_time"] == 12): ?>selected="selected"<?php endif; ?>>12:00</option>
        <option value="12.5" <?php if($res["Fstart_time"] == 12.5): ?>selected="selected"<?php endif; ?>>12:30</option>
        <option value="13" <?php if($res["Fstart_time"] == 13): ?>selected="selected"<?php endif; ?>>13:00</option>
        <option value="13.5" <?php if($res["Fstart_time"] == 13.5): ?>selected="selected"<?php endif; ?>>13:30</option>
        <option value="14" <?php if($res["Fstart_time"] == 14): ?>selected="selected"<?php endif; ?>>14:00</option>
        <option value="14.5" <?php if($res["Fstart_time"] == 14.5): ?>selected="selected"<?php endif; ?>>14:30</option>
        <option value="15" <?php if($res["Fstart_time"] == 15): ?>selected="selected"<?php endif; ?>>15:00</option>
        <option value="15.5" <?php if($res["Fstart_time"] == 15.5): ?>selected="selected"<?php endif; ?>>15:30</option>
        <option value="16" <?php if($res["Fstart_time"] == 16): ?>selected="selected"<?php endif; ?>>16:00</option>
        <option value="16.5" <?php if($res["Fstart_time"] == 16.5): ?>selected="selected"<?php endif; ?>>16:30</option>
        <option value="17" <?php if($res["Fstart_time"] == 17): ?>selected="selected"<?php endif; ?>>17:00</option>
        <option value="17.5" <?php if($res["Fstart_time"] == 17.5): ?>selected="selected"<?php endif; ?>>17:30</option>
        <option value="18" <?php if($res["Fstart_time"] == 18): ?>selected="selected"<?php endif; ?>>18:00</option>
        <option value="18.5" <?php if($res["Fstart_time"] == 18.5): ?>selected="selected"<?php endif; ?>>18:30</option>
        <option value="19" <?php if($res["Fstart_time"] == 19): ?>selected="selected"<?php endif; ?>>19:00</option>
        <option value="19.5" <?php if($res["Fstart_time"] == 19.5): ?>selected="selected"<?php endif; ?>>19:30</option>
        <option value="20" <?php if($res["Fstart_time"] == 20): ?>selected="selected"<?php endif; ?>>20:00</option>
        <option value="20.5" <?php if($res["Fstart_time"] == 20.5): ?>selected="selected"<?php endif; ?>>20:30</option>
        <option value="21" <?php if($res["Fstart_time"] == 21): ?>selected="selected"<?php endif; ?>>21:00</option>
        <option value="21.5" <?php if($res["Fstart_time"] == 21.5): ?>selected="selected"<?php endif; ?>>21:30</option>
        <option value="22" <?php if($res["Fstart_time"] == 22): ?>selected="selected"<?php endif; ?>>22:00</option>
        <option value="22.5" <?php if($res["Fstart_time"] == 22.5): ?>selected="selected"<?php endif; ?>>22:30</option>
        <option value="23" <?php if($res["Fstart_time"] == 23): ?>selected="selected"<?php endif; ?>>23:00</option>
        <option value="23.5" <?php if($res["Fstart_time"] == 23.5): ?>selected="selected"<?php endif; ?>>23:30</option>
  </select>
  <br>
  <br>
  设置结束时间:
  <select class="sele_type font5b"  name="Fend_time" id="Fend_time" style="width:150px;height:40px">
       
           
        <option value="9" <?php if($res["Fend_time"] == 9): ?>selected="selected"<?php endif; ?>>9:00</option>
        <option value="9.5" <?php if($res["Fend_time"] == 9.5): ?>selected="selected"<?php endif; ?>>9:30</option>
        <option value="10" <?php if($res["Fend_time"] == 10): ?>selected="selected"<?php endif; ?>>10:00</option>
        <option value="10.5" <?php if($res["Fend_time"] == 10.5): ?>selected="selected"<?php endif; ?>>10:30</option>
        <option value="11" <?php if($res["Fend_time"] == 11): ?>selected="selected"<?php endif; ?>>11:00</option>
        <option value="11.5" <?php if($res["Fend_time"] == 11.5): ?>selected="selected"<?php endif; ?>>11:30</option>
        <option value="12" <?php if($res["Fend_time"] == 12): ?>selected="selected"<?php endif; ?>>12:00</option>
        <option value="12.5" <?php if($res["Fend_time"] == 12.5): ?>selected="selected"<?php endif; ?>>12:30</option>
        <option value="13" <?php if($res["Fend_time"] == 13): ?>selected="selected"<?php endif; ?>>13:00</option>
        <option value="13.5" <?php if($res["Fend_time"] == 13.5): ?>selected="selected"<?php endif; ?>>13:30</option>
        <option value="14" <?php if($res["Fend_time"] == 14): ?>selected="selected"<?php endif; ?>>14:00</option>
        <option value="14.5" <?php if($res["Fend_time"] == 14.5): ?>selected="selected"<?php endif; ?>>14:30</option>
        <option value="15" <?php if($res["Fend_time"] == 15): ?>selected="selected"<?php endif; ?>>15:00</option>
        <option value="15.5" <?php if($res["Fend_time"] == 15.5): ?>selected="selected"<?php endif; ?>>15:30</option>
        <option value="16" <?php if($res["Fend_time"] == 16): ?>selected="selected"<?php endif; ?>>16:00</option>
        <option value="16.5" <?php if($res["Fend_time"] == 16.5): ?>selected="selected"<?php endif; ?>>16:30</option>
        <option value="17" <?php if($res["Fend_time"] == 17): ?>selected="selected"<?php endif; ?>>17:00</option>
        <option value="17.5" <?php if($res["Fend_time"] == 17.5): ?>selected="selected"<?php endif; ?>>17:30</option>
        <option value="18" <?php if($res["Fend_time"] == 18): ?>selected="selected"<?php endif; ?>>18:00</option>
        <option value="18.5" <?php if($res["Fend_time"] == 18.5): ?>selected="selected"<?php endif; ?>>18:30</option>
        <option value="19" <?php if($res["Fend_time"] == 19): ?>selected="selected"<?php endif; ?>>19:00</option>
        <option value="19.5" <?php if($res["Fend_time"] == 19.5): ?>selected="selected"<?php endif; ?>>19:30</option>
        <option value="20" <?php if($res["Fend_time"] == 20): ?>selected="selected"<?php endif; ?>>20:00</option>
        <option value="20.5" <?php if($res["Fend_time"] == 20.5): ?>selected="selected"<?php endif; ?>>20:30</option>
        <option value="21" <?php if($res["Fend_time"] == 21): ?>selected="selected"<?php endif; ?>>21:00</option>
        <option value="21.5" <?php if($res["Fend_time"] == 21.5): ?>selected="selected"<?php endif; ?>>21:30</option>
        <option value="22" <?php if($res["Fend_time"] == 22): ?>selected="selected"<?php endif; ?>>22:00</option>
        <option value="22.5" <?php if($res["Fend_time"] == 22.5): ?>selected="selected"<?php endif; ?>>22:30</option>
        <option value="23" <?php if($res["Fend_time"] == 23): ?>selected="selected"<?php endif; ?>>23:00</option>
        <option value="23.5" <?php if($res["Fend_time"] == 23.5): ?>selected="selected"<?php endif; ?>>23:30</option>
        <option value="24" <?php if($res["Fend_time"] == 24): ?>selected="selected"<?php endif; ?>>24:00</option>
        
  </select>

  <input type="submit" value="提交" class="g_b"/>
  </form>