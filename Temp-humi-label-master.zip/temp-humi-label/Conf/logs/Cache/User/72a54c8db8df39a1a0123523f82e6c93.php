<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/css_home_pc.css"/>
<title>智能物联管理系统企业中心</title>
<script type="text/javascript" src="<?php echo RES;?>/js/jquery.min.js"></script>
<script src="<?php echo RES;?>/js/layer.js"></script>
<style>
.wel{cursor: pointer;position: relative;}
.wel:hover .move_b{opacity: 1;top:18px;}
.move_b {width: 80px;height:58px;background:#435867;position: absolute;opacity: 0;top:-5px;left:35px;transition:0.5s;-webkit-transition:.5s;-moz-transition:.5s;}
.move_b a{text-align: center;line-height: 26px;font-size: 14px;color: #fff;display: block;} 
.active{background:#fff; color:#435867;border-top:1px solid #435867;}
</style>
</head>
<body>
<!--header-->
<!--
<div class="mengceng_bq"></div>
-->
<div class="cj_header">
  <img class="logo_size" src="img/logo1.png" alt="logo"/><span class="logo_font">智能物联网管理系统</span>
    <div class="cj_h_r">
        <div class="wel">欢迎，<?php echo (session('uname')); ?>
        <div class="move_b">
        <a href="<?php echo U('Index/edit', array('token' => $token));?>">修改</a>
        <a href="/index.php?g=Home&m=Index&a=logout">退出</a>
        </div>
    </div>
        <div class="fw_time">服务到期时间:<?php echo (date("Y-m-d",$thisUser["viptime"])); ?></div>
    </div>
</div>
<div class="cj_nav">
  <div class="f1_line"></div>
    <div class="nav_k">
        <a class="nav_font" href="<?php echo U('Wlist/index', array('token' => $token));?>" id="Wlist">统计报表</a>
        <a class="nav_font" href="<?php echo U('Store/product', array('token' => $token));?>" id="Store">标签管理</a>
        <a class="nav_font" href="<?php echo U('Work/index', array('token' => $token));?>" id="Work">用户管理</a>
        <!-- <a class="nav_font nav_c " href="<?php echo U('Wlist/index', array('token' => $token));?>">统计信息</a> 企业中心Index/frame          -->
        
    </div>
  </div>       

</div>
<script>
$(document).ready(function(){
var url=window.location.href;
var reg=/m=[a-z]*/i;
var arr=url.match(reg);
var str=arr[0].substr(2);
$("#"+str).addClass("active");
})
function drop_confirm(msg, url){
    if(confirm(msg)){
        window.location = url;
    }
}
</script>

 <style>
  .old_2{background:#fff; color:#435867;}  
</style>
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/shop_guan_li -fl.css"/>
<script src="/tpl/static/artDialog/jquery.artDialog.js?skin=default"></script>
<script src="/tpl/static/artDialog/plugins/iframeTools.js"></script>
<!--内容-->
<form class="form" method="post" action="<?php echo U('Work/adddo',array('token'=>$token));?>" enctype="multipart/form-data" id ="form"> 
<div class="scgl_nr">
  
    <div class="tjb2">员工添加
    <a href="<?php echo U('Work/index',array('token'=>$token));?>">
        <input class="logo_sc_sc b_b" type="button" value="返回上一级"/>
    </a>
</div>
<input type="hidden" name="token" value="<?php echo ($token); ?>">

<div class="tjb3"></div>
  <div class="scmc"><span style="color:#FF0000;">*</span>&nbsp;&nbsp;名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;称&nbsp;：
        <input class="spmc_sr" type="text" name="Fname" value="" id="Fname"/>
    </div>
   
    <div class="scmc"><span style="color:#FF0000;">*</span>&nbsp;&nbsp;电&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;话&nbsp;：
        <input class="spmc_sr" name="Fphone" value="" id="Fphone"/>
    </div>
    <div class="scmc"><span style="color:#FF0000;">*</span>&nbsp;&nbsp;密&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;码&nbsp;：
        <input class="spmc_sr" name="Fpwd" value="" id="Fpwd" type="text"/>
    </div>
   <!--  <div class="scmc"><span style="color:#FF0000;">*</span>&nbsp;&nbsp;身&nbsp;份&nbsp;证&nbsp;号&nbsp;：
        <input class="spmc_sr" name="shenfen" value="" id="shenfen"/>
    </div> -->

     <!-- <div class="scmc"><span style="color:#FF0000;">*</span>&nbsp;&nbsp;编&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;号&nbsp;：
        <input class="spmc_sr" name="Fworkernum" value="" id="Fworkernum"/>
    </div> -->

    
    <input class="cj_sp_anniu g_b" type="submit" value="保&nbsp;&nbsp;存" id="submit"/>
    <a href="<?php echo U('Work/index',array('token'=>$token));?>" class="btn">
        <input class="cj_sp_anniu2 g_b" type="button" value="取&nbsp;&nbsp;消"/>
    </a>
</div>
</form>
<!--公共底-->

<script>
$(document).ready(function(){
<!-------------分页------------------->     
  $(".yema_click").click(function(){
    $(".yema_click").css({background:"none",color:"#333"})
    $(this).css({background:"#435867",color:"#fff"})
    })
    
  $(".diyiye").click(function(){
    $(".yema_click").css({background:"none",color:"#333"})
    $(".yema_first").css({background:"#435867",color:"#fff"})
    })
  $(".weiye").click(function(){
    $(".yema_click").css({background:"none",color:"#333"})
    $(".yema_last").css({background:"#435867",color:"#fff"})
    })  
})

$('#submit').click(function(){
  var status=true;
  var Fname = $("#Fname").val()
    if ($.trim(Fname) == "") {
      alert("请填写用户名")
      status=false;
      return status;
    }
    var Fphone = $("#Fphone").val()
    var patrn = /^(1(([0-9][0-9])|(47)|(85)|[8][01256789]))\d{8}$/;
    if (!patrn.exec($.trim(Fphone))) {
        alert("请填写正确的手机号")
        status=false;
        return status;
    }


    var Fpwd = $("#Fpwd").val()
    if ($.trim(Fpwd) == "") {
      alert("请输入密码")
      status=false;
      return status;
    }

    // var shenfen = $("#shenfen").val()
    // var patrn = /^\d{6}(18|19|20)?\d{2}(0[1-9]|1[12])(0[1-9]|[12]\d|3[01])\d{3}(\d|X)$/;
    // if (!patrn.exec($.trim(shenfen))) {
    //     alert("请填写正确的身份证号")
    //     status=false;
    //     return status;
    // }
    // var Fworkernum = $("#Fworkernum").val()
    // if ($.trim(Fworkernum) == "") {
    //   alert("请填写员工编号")
    //   status=false;
    //   return status;
    // }

 if(status==true){
    $('form').submit();
 }
})


</script>
<hr>
<div class="d_public">
  <!-- <div class="d_public_one"><a href="http://www.cloud315.org/">关于溯云</a></div> -->
    <!-- <div class="d_public_two"><a href="<?php echo U('Index/helpcen');?>">帮助中心</a></div> -->
    <div class="d_public_three"><a href="http://www.megain.com/">联系我们</a></div>
    <div class="d_public_four"><a href="#">常见问题</a></div>
</div>
<div class="d_public_e">Copyright © 2018 www.megian.com &nbsp;All Rights Reserved</div>
<!-- <div class="d_public_n">copyright@cloud315.org</div> -->

</body>
</html>