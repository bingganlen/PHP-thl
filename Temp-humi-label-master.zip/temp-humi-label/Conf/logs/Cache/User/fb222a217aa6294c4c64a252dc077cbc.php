<?php if (!defined('THINK_PATH')) exit(); if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><tr class="h_bg">
            <!-- <td><input type="checkbox" value="<?php echo ($item["Fid"]); ?>" name="ixz"></td> -->
          <td class="spgl_t_b xlh" style=""><?php echo ($i); ?></td>
            <td class="spgl_t_b flmc" style=""><?php echo ($item["Fusername"]); ?></td>
            <td class="spgl_t_b gg" style=""><?php echo ($item["Faddress"]); ?></td>
            <!--  <td class="spgl_t_b gg" style=""><?php echo (date("Y-m-d H:i:s",$item["Fcreatetime"])); ?></td> -->
               <td class="spgl_t_b xlh" style=""><?php echo ($item["Fordernum"]); ?></td>
               <td class="spgl_t_b xlh" style=""><?php echo ($item["Fwnum"]); ?></td>
               <td class="spgl_t_b xlh" style=""><?php echo ($item["Fallmoney"]); ?></td>
               <td class="spgl_t_b flmc" style=""><?php echo (date("Y-m-d H:i:s",$item["Flasttime"])); ?></td>
        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
       
    
          <tr>
            
              <!--页面显示-->
    <p class="neirong_yema">  
        <?php echo ($page); ?>
    </p>
          </tr>