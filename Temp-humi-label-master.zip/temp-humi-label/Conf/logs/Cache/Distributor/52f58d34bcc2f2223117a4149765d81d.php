<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>码上订水供应商后台管理系统</title>
    <meta name="keywords" content="<?php echo ($f_siteName); ?>-Saivi后台管理系统" />
    <meta name="description" content="<?php echo ($f_siteName); ?>-Saivi后台管理系统" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />    
    
    <link href="<?php echo RES;?>/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo RES;?>/css/bootstrap-responsive.min.css" rel="stylesheet" />
    
    <link href="<?php echo RES;?>/css/font-awesome.css" rel="stylesheet" />
    
    <link href="<?php echo RES;?>/css/adminia.css" rel="stylesheet" /> 
    <link href="<?php echo RES;?>/css/adminia-responsive.css" rel="stylesheet" /> 
    
    <link href="<?php echo RES;?>/css/pages/dashboard.css" rel="stylesheet" /> 
    <link href="<?php echo RES;?>/css/pages/faq.css" rel="stylesheet" />

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="<?php echo RES;?>/js/html5.js"></script>
    <![endif]-->
	<script src="<?php echo RES;?>/js/jquery-1.7.2.min.js"></script>
	
    <!--日期-->
    <link rel="stylesheet" type="text/css" href="./tpl/static/date/hDate.css"/>
    <script type="text/javascript" src="./tpl/static/date/hDate.js"></script>

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript">
	$(function(){

		var str = $(".widget-header h3").html();
		// alert(str.indexOf("&gt;"));
		var hstr = $.trim(str.substr(0, str.indexOf("&gt;")));
		var num = '';
		if(hstr == "站点设置")
			num = '1';
		else if(hstr == '用户管理')
			num = '2';
		else if(hstr == '内容管理')
			num = '3';
		else if(hstr == '公众号管理')
			num = '4';
		else if(hstr == '功能管理')
			num = '5'
		else if(hstr == '扩展管理')
			num = '6';

		var current = '#collapse' + num;
		$(current).css('height','auto').removeClass('collapse').addClass('in');

	})
</script>
</head>

<body>
	
<div class="navbar navbar-fixed-top">
	
	<div class="navbar-inner">
		
		<div class="container">
			
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> 
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span> 				
			</a>
			
			<a class="brand" href="<?php echo U('Distributor/System/index');?>">码上订水</a>
			
			<div class="nav-collapse">
			
				<ul class="nav pull-right">

					
					<li class="divider-vertical"></li>
					
					<li class="dropdown">
						
						<a data-toggle="dropdown" class="dropdown-toggle " href="#">
							管理 <b class="caret"></b>							
						</a>
						
						<ul class="dropdown-menu">
<!-- 							
							<li>
								<a href="./change_password.html"><i class="icon-lock"></i> 密码修改</a>
							</li> -->
							
							<li class="divider"></li>
							<li>
								<a href="<?php echo U('Distributor/Adminsaivi/logout');?>">&nbsp;退出系统</a>
							</li>
						</ul>
					</li>
				</ul>
				
			</div> <!-- /nav-collapse -->
			
		</div> <!-- /container -->
		
	</div> <!-- /navbar-inner -->
	
</div> <!-- /navbar -->


<div id="content">
  
  <div class="container">
    
    <div class="row">
      
      <div class="span3">
				
				<ul id="main-nav" class="nav nav-tabs nav-stacked">

                    	<li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse1">
		                <i class="icon-th"></i>
		                个人中心
		              </a>

		              <div id="collapse1" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('Distributor/Useradmin/index');?>'">
		                  <i class="icon-share-alt"></i>
		                  个人中心
		                </a>
		              </div>
					</li>


                    	<li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse3">
		                <i class="icon-th"></i>
		                订单列表
		              </a>

		              <div id="collapse3" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('Distributor/Order/index');?>'">
		                  <i class="icon-share-alt"></i>
		                  订单列表
		                </a>
		              </div>
					</li>

					<li class="active accordion-group">
		              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse4">
		                <i class="icon-th"></i>
		                用户列表
		              </a>

		              <div id="collapse4" class="accordion-body collapse" style="height: 0px; ">
		                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="" onclick="javascript:window.location.href = '<?php echo U('Distributor/User/index');?>'">
		                  <i class="icon-share-alt"></i>
		                  用户列表
		                </a>
		              </div>
					</li>
<li class="active accordion-group">
                              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse5">
                                <i class="icon-th"></i>
                                水站管理
                              </a>

                              <div id="collapse5" class="accordion-body collapse" style="height: 0px; ">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#" onclick="javascript:window.location.href = '<?php echo U('Distributor/Water/index');?>'">
                                  <i class="icon-share-alt"></i>
                                  水站管理
                                </a>
                              </div>
                                        </li>
<li class="active accordion-group">
                              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse6">
                                <i class="icon-th"></i>
                                商品管理
                              </a>

                              <div id="collapse6" class="accordion-body collapse" style="height: 0px; ">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#" onclick="javascript:window.location.href = '<?php echo U('Distributor/Product/index');?>'">
                                  <i class="icon-share-alt"></i>
                                  商品管理
                                </a>
                              </div>
                                        </li>
<li class="active accordion-group">
                              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse7">
                                <i class="icon-th"></i>
                                统计管理
                              </a>

                              <div id="collapse7" class="accordion-body collapse" style="height: 0px; ">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#" onclick="javascript:window.location.href = '<?php echo U('Distributor/Count/index');?>'">
                                  <i class="icon-share-alt"></i>
                                  统计管理
                                </a>
                              </div>
                                        </li>
<li class="active accordion-group">
                              <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#collapse8">
                                <i class="icon-th"></i>
                                banner管理
                              </a>

                              <div id="collapse8" class="accordion-body collapse" style="height: 0px; ">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="" href="#" onclick="javascript:window.location.href = '<?php echo U('Distributor/Banner/index');?>'">
                                  <i class="icon-share-alt"></i>
                                  banner管理
                                </a>
                              </div>
                                        </li>
				</ul>	
			
				<br />
		
			</div> <!-- /span3 -->

        
      <div class="span9">

        <div class="widget widget-table">
                    
          <div class="widget-header">
            <i class="icon-th-list"></i>
            <h3>产品管理 >> 产品管理</h3>
          </div> <!-- /widget-header -->
          
          <div class="widget-content">
<form action="" method="POST"  enctype="multipart/form-data">
<div class="jscmc"><span style="color:#FF0000;">*</span>&nbsp;&nbsp;名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;称&nbsp;：
        <input type="hidden" name="pid" id="pid" value=""/>
        <input class="jspmc_sr" type="text" id="name" name="name" value=""/>

    </div>

     <div class="jscmc" style="margin-top:15px;"><span style="color:#FF0000;">*</span>&nbsp;&nbsp;&nbsp;简&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;称：
        <input class="jspmc_sr" style="width:480px;" type="text" id="shortname" name="shortname" value=""/>
    </div>

    
    <div class="jscmc"><span style="color:#FF0000;">*</span>&nbsp;&nbsp;价&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;格&nbsp;：
        <input class="jspmc_sr" type="text" id="price" name="price" value=""/>

    </div>
    <div class="jscmc"><span style="color:#FF0000;">*</span>&nbsp;&nbsp;规&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;格&nbsp;：
        <input class="jspmc_sr" type="text" id="spec" name="spec" value=""/>
    </div>
    
    <div class="jscmc">&nbsp;&nbsp;&nbsp;库&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;存&nbsp;：
        <input class="jspmc_sr" type="text" id="num" name="num" value=""/>
    </div>
    
    
    
    <div class="jlogo_tu_up">&nbsp;&nbsp;&nbsp;产&nbsp;品&nbsp;图&nbsp;片&nbsp;：
        <input class="jlogo_sr" type="file" name="image" id="pic" value=""/>
    </div>

    <div class="jscmc" style="margin-top:15px;">&nbsp;&nbsp;&nbsp;排&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;序：
        <input class="jspmc_sr" style="width:480px;" type="text" id="sort" name="sort" value=""/><div class="jtu_ts" style="display:inline-block; text-indent:10px;">数字越小排再越前（大于等于0的整数）</div>
    </div>
<div style="position:relative; width:500px; height:60px; margin:auto;">
       
      <input class="dw_anniu1 g_b" style="top:-20px;" type="submit" value="保&nbsp;&nbsp;存" id="save"/>
      
    </div>
</form>

<table class="table table-striped table-bordered" style="margin-top:10px;" id="set_table">
	  <tr>
		<td width="70">ID</td>
		<td width="150">商品名称</td>
		<td width="150">金额</td>
		<td width="150">图片</td>
		<td width="150">操作</td>
	  </tr>
   	  <?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
                                <td align='center'><?php echo ($vo["id"]); ?></td>
                                <td ><?php echo ($vo["name"]); ?></td>
                                <td ><?php echo ($vo["price"]); ?></td>
				<td><img src="<?php echo ($vo["logourl"]); ?>" style="width:100px;height:100px;"></td>
                                <td align='center'>
					<a href="/index.php?g=Distributor&m=Product&a=set&token=<?php echo ($vo["token"]); ?>&id=<?php echo ($vo["id"]); ?>">修改</a>
                                        <a href="/index.php?g=Distributor&m=Product&a=del&token=<?php echo ($vo["token"]); ?>&id=<?php echo ($vo["id"]); ?>">删除</a>
                                </td>


                        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
</table>

</div>
</div>
</div>
</div>
</div>
</div>
<div class="navbar navbar-fixed-bottom">
	<div class="navbar-inner" style="text-align: right;color:#fff;">
		码上订水供应商平台
	</div>
</div>

<script type="text/javascript" src="https://select2.github.io/dist/js/select2.min.js"></script>
<link href="https://select2.github.io/dist/css/select2.min.css" type="text/css" rel="stylesheet" />
<style>.select2-search__field{height:30px;}</style>
<script>$("select").select2();</script>
    

<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->

<script src="<?php echo RES;?>/js/excanvas.min.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.pie.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.orderBars.js"></script>
<script src="<?php echo RES;?>/js/jquery.flot.resize.js"></script>
<script src="<?php echo STATICS;?>/artDialog/jquery.artDialog.js?skin=default"></script>
<script src="<?php echo STATICS;?>/artDialog/plugins/iframeTools.js"></script>


<script src="<?php echo RES;?>/js/bootstrap.js"></script>
<script src="<?php echo RES;?>/js/charts/bar.js"></script>
  </body>
</html>