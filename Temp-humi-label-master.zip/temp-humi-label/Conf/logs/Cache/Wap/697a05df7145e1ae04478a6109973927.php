<?php if (!defined('THINK_PATH')) exit();?>
<div class="header_k">
 <!-- <?php if($_GET['bid'] == 'bid' ): ?><img class="icon_left" src="img/back.png" onclick="window.history.back()" />
 
 <?php else: ?>
 
   <img class="icon_left" src="img/chose_user.png"/><?php endif; ?> 头部左侧头像隐藏-->
   
    <div class="sz_name"> <a href="<?php echo U('Store/intro',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>"><?php echo ($userinfo["Fwatername"]); ?></a> <!-- <span><img class="title_d" src="img/a/nav_btn.png" style=""></span>头部点隐藏 --></div>

    <!-- <?php if($bid == 'orders'): ?><a href="<?php echo U('Nativelife/orderlist',array('token'=>$FFtoken));?>">
        <img class="icon_right" src="img/a/nav_fh.png"/>
        </a>
    <?php else: ?>
        <a href="tel:<?php echo ($userinfo["Fphone"]); ?>">
        <img class="icon_right" src="img/dh.png"/>
        </a><?php endif; ?> 头部右侧图标隐藏-->
    <!-- <div style="width:34px;width:100%"><p style="float:left;font-size:28px;">您目前的积分：90</p><img src="img/jifen.gif" style="float:right;"/> </div>积分隐藏-->
    
</div>
<div class="h55"></div>


<!--切换账号-->
<div class="tc_mc"></div>
<div class="tc_chose_k">
    <div class="tip blue_color">您可以切换其他账号登陆！</div>
    <a href="index.php?g=Wap&m=Reg&a=station&token=<?php echo ($FFtoken); ?>"><div class="go_join">切换账号 > ></div></a>
    <img class="date_close" src="img/gb.png"/>
</div>
<script>
//蒙层不可滑动
        $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.tc_mc').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
         $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.tc_chose_k').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
//切换账号
     $(document).ready(function() {
        $(".icon_left").click(function(){
            $(".tc_mc").css("display","block")
            $(".tc_chose_k").css("display","block")
            })
        $(".tc_mc").click(function(){
            $(".tc_mc").css("display","none")
            $(".tc_chose_k").css("display","none")
            })
        $(".date_close").click(function(){
            $(".tc_mc").css("display","none")
            $(".tc_chose_k").css("display","none")
            })
        })
</script>
<?php if(empty($products) != true ): ?><ul class="m-cart-list">
<?php if(is_array($products)): $i = 0; $__LIST__ = $products;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$p): $mod = ($i % 2 );++$i; if(empty($p['detail']) != true): if(is_array($p['detail'])): $i = 0; $__LIST__ = $p['detail'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$row): $mod = ($i % 2 );++$i;?><li number="1">
				<span class="pic"><a href="<?php echo U('Store/product',array('token'=>$_GET['token'],'id'=>$p['id'],'wecha_id'=>$_GET['wecha_id']));?>"><img src="<?php echo ($p["logourl"]); ?>" width="75" height="75"></a></span>
				<span class="con">
					<a href="<?php echo U('Store/product',array('token'=>$_GET['token'],'id'=>$p['id'],'wecha_id'=>$_GET['wecha_id']));?>" class="t"><?php echo ($p["name"]); ?></a>
					<i class="d"><?php if(empty($p['formatTitle']) != true): echo ($p["formatTitle"]); ?>：<?php echo ($row["formatName"]); endif; ?> <?php if(empty($p['colorTitle']) != true): ?>，<?php echo ($p["colorTitle"]); ?>：<?php echo ($row["colorName"]); endif; ?></i>
					<p>
					<label>数量：</label>
					<span>
					<i style="cursor: pointer;" onclick="plus_minus(<?php echo ($p["id"]); ?>, -1, <?php echo ($row["id"]); ?>)" class="dec"></i>
					<input type="text" value="<?php echo ($row["count"]); ?>" onchange="change_minus(<?php echo ($p["id"]); ?>, <?php echo ($row["id"]); ?>)" id="num_<?php echo ($p["id"]); ?>_<?php echo ($row["id"]); ?>">
					<i style="cursor: pointer;" onclick="plus_minus(<?php echo ($p["id"]); ?>, 1, <?php echo ($row["id"]); ?>)" class="add"></i>
					</span>
					</p>
					<p>
					<label>库存：</label>
					<span id="stock"><?php echo ($row["num"]); ?></span>
					</p>
					<p>	
					<label>价格：</label><span class="price">￥<?php echo ($row["price"]); ?></span>
					<!-- <label style="cursor:pointer" onclick="location.href='<?php echo U('Store/deleteCart',array('token'=>$_GET['token'],'id'=>$p['id'],'did'=>$row['id'],'wecha_id'=>$_GET['wecha_id']));?>'" class="del">删除</label> -->
					<label style="cursor:pointer" onclick="location.href='<?php echo U('Store/deleteCart',array('token'=>$_GET['token'],'id'=>$p['id'],'did'=>$row['id'],'wecha_id'=>$_GET['wecha_id']));?>'" class="del">删除</label>
					</p>
				</span>
			</li><?php endforeach; endif; else: echo "" ;endif; ?>
	<?php else: ?>
		<li number="<?php echo ($p["count"]); ?>">
			<span class="pic"><a href="<?php echo U('Store/product',array('token'=>$_GET['token'],'id'=>$p['id'],'wecha_id'=>$_GET['wecha_id']));?>"><img src="<?php echo ($p["logourl"]); ?>" width="75" height="75"></a></span>
			<span class="con">
				<a href="<?php echo U('Store/product',array('token'=>$_GET['token'],'id'=>$p['id'],'wecha_id'=>$_GET['wecha_id']));?>" class="t"><?php echo ($p["name"]); ?></a>
				<p>
					<label>数量：</label>
					<span>
						<i style="cursor: pointer;" onclick="plus_minus(<?php echo ($p["id"]); ?>, -1, 0)" class="dec"></i>
						<input type="text" value="<?php echo ($p["count"]); ?>" onchange="change_minus(<?php echo ($p["id"]); ?>, 0)" id="num_<?php echo ($p["id"]); ?>_0">
						<i style="cursor: pointer;" onclick="plus_minus(<?php echo ($p["id"]); ?>, 1, 0)" class="add"></i>
					</span>
				</p>
				<p>
				<label>库存：</label>
				<span id="stock"><?php echo ($p["num"]); ?></span>
				</p>
				<p>	
				<label>销售价：</label><span class="price">￥<?php echo ($p["price"]); ?></span>
				<label style="cursor:pointer" onclick="location.href='<?php echo U('Store/deleteCart',array('token'=>$_GET['token'],'id'=>$p['id'],'did'=>0,'wecha_id'=>$_GET['wecha_id']));?>'" class="del">删除</label>
				</p>
			</span>
		</li><?php endif; endforeach; endif; else: echo "" ;endif; ?>
</ul>
<div class="m-cart-toal">
<!-- <p style="color:#E58B4C;text-align:left;padding:0 10px 1rem;border-bottom:1px dotted #ccc;margin:0 -10px 1rem;font-size:1.2rem;line-height:1.4rem">享受的优惠: 注册名鞋库会员，满百包邮！（货到付款除外）</p> -->
<p class="check" style="font-size:1.4rem">商品总数:<b id="total_count"><?php echo ($totalCount); ?></b>　商品总额:<b id="total_price">￥<?php echo ($totalFee); ?></b></p>
<p class="act">
	<a href="<?php echo U('Store/index',array('token'=>$_GET['token'], 'wecha_id'=>$_GET['wecha_id']));?>" class="back">继续购物<i></i></a>
	<a href="<?php echo U('Store/orderCart',array('token'=>$_GET['token'], 'wecha_id'=>$_GET['wecha_id']));?>" class="checkout">下单结算</a>
</p>
</div>
<?php else: ?>
<div class="m-cart-e">
<div class="icon"></div>
<div class="txt">您还没有挑选商品哦</div>
<a href="<?php echo U('Store/index',array('token'=>$_GET['token'],'wecha_id'=>$_GET['wecha_id']));?>" class="gobuy">去挑选商品</a>
</div><?php endif; ?>
<script type="text/javascript">
function full_update(rowid,price) {
    var _this = $('#qty'+rowid);
    var this_val = parseInt($(_this).val());
    if (this_val < 1 || isNaN(this_val)) {
        alert('购买数量不能小于1！');
        $(_this).focus();
        return false;
    }
    update_cart(rowid, this_val,price);
}
//加减
function plus_minus(rowid, number, did) {
    var num = parseInt($('#num_'+rowid + '_' + did).val());
    num = num + number;
    if (num < 1) {
        return false;
    }
     $('#num_'+rowid + '_' + did).attr('value',num);
    update_cart(rowid, num, did);     
}
function change_minus(rowid, did) {
	var num = parseInt($('#num_'+rowid + '_' + did).val());
    if (num < 1) {
        return false;
    }
     $('#num_'+rowid + '_' + did).attr('value',num);
    update_cart(rowid, num, did);
}
//更新购物车
function update_cart(rowid, num, did) {
	if (num > parseInt($("#stock").text())) {
		num = parseInt($("#stock").text());
		$('#num_'+rowid + '_' + did).val(num);
		floatNotify.simple('抱歉，您的购买量超过了库存了');
	}
	$.ajax({
		url: '<?php echo U('Store/ajaxUpdateCart',array('token'=>$_GET['token'],'wecha_id'=>$_GET['wecha_id']));?>&id='+rowid+'&count='+num+'&did='+ did,
		success: function( data ) {
			if(data){
				var datas=data.split('|');
				//$('#p_buy #all_price').html('￥'+datas[1]);
				$('#total_count').html(datas[0]);
				$('#total_price').html('￥'+datas[1]);
			}
		}
	});
}
</script>

<script src="<?php echo $staticFilePath;?>/js/jquery-1.9.1.min.js" type="text/javascript"></script>
<style type="text/css">
  body{max-width: 640px;margin:auto;}
  /*bottom*/

ul.fixed_bottom{ list-style:none;background:#e0e0e0; font-size:1em;  width:100%; overflow:hidden; border-top:#fff 1px solid; padding-bottom:6px; position:fixed; z-index:999; bottom:0; left:0; margin:auto; padding:4px 0; box-shadow:0 0 1px #f3eadb;}

ul.fixed_bottom li.fixed_li{list-style:none; width:25%; text-align:center; float:left; margin:5px 0; cursor:pointer; }

ul.fixed_bottom img.fixed_img{width:30%; max-width:55px;}

ul.fixed_bottom p.fixed_p{ margin:0 auto; font-size:1em;}

/*sub-menu-list width:189px;*/
.sub-menu-list5{width:189px;position:absolute;margin:8px 0 0 4px;background:rgba(0,0,0,0.8);z-index:99;box-shadow:0 0 3px rgba(0, 0, 0, 0.8);display:none;color:#FC0; position: fixed;bottom:15%;left:17%;}
.sub-menu-list5:after{position:absolute;top:178px;left:62px;content:'';width:0;height:0;border:8px solid transparent;border-bottom: 6px solid rgba(0, 0, 0, 0.8);border-top:0;}
.sub-menu-list5 li{float:left;width:94px;line-height:40px;text-align:center;border-right:1px solid #181818;border-bottom:1px solid #181818;margin-right:-1px;font-size:16px;list-style: none;}
.sub-menu-list5 li a{display:block;color:#fff}
</style>
<ul class="fixed_bottom" style="">


  <li class="fixed_li" style="">
        <a href="<?php echo U('Store/index',array('token'=>$_GET['token']));?>" style="color:#000">
            <img class="fixed_img" style="" src="images/zhuye<?php if(($sel) == "1"): ?>_click<?php endif; ?>.png"/>
            <p class="fixed_p" style="">首页</p>
         </a>   
        </li>
        <li class="fixed_li"  style="" id="cat5">
          <a href="javascript:void(0)" style="color:#000" >
            <img class="fixed_img"  style="" src="images/fenlei<?php if(($ss) == "1"): ?>_click<?php endif; ?>.png"/>
            <p class="fixed_p" style="">分类</p>
          </a>  
        </li>
        <li class="fixed_li"  style="">
        <a href="<?php echo U('Store/cart',array('token'=>$_GET['token'],'wecha_id'=>$_GET['wecha_id']));?>" style="color:#000">
            <img class="fixed_img"  style="" src="images/cart<?php if(($cart) == "1"): ?>_click<?php endif; ?>.png"/>
            <p class="fixed_p" style="">&nbsp;&nbsp;购物车</p>
         </a>   
        </li>
        <li class="fixed_li"  style="">
            <a href="<?php echo U('Store/my_s',array('token'=>$_GET['token'],'wecha_id'=>$_GET['wecha_id']));?>" style="color:#000">
            <img class="fixed_img"  style="" src="images/me<?php if(($my) == "1"): ?>_click<?php endif; ?>.png"/>
            <p class="fixed_p" style="">我的</p>
            </a>
        </li> 
    
          
</ul>

<ul class="sub-menu-list5" style="display:none">

<li><a href="<?php echo U('Store/index',array('token' => $_GET['token'], 'catid' => $hostlist['id'], 'wecha_id' => $wecha_id));?>">首页</a></li>
<?php if(is_array($cats)): $i = 0; $__LIST__ = $cats;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$hostlist): $mod = ($i % 2 );++$i;?><li><a href="<?php echo U('Store/products',array('token' => $_GET['token'], 'catid' => $hostlist['id'], 'wecha_id' => $wecha_id));?>"><?php echo (msubstr($hostlist["name"],0,5,'utf-8')); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
<script>


  $('#cat5').click( function() {
      //$('.sub-menu-list2').css('display','block');

       $('.sub-menu-list5').toggle();
    })
 

</script>





</body>
<script type="text/javascript">
window.shareData = {  
            "moduleName":"Store",
            "moduleID":"0",
            "imgUrl": "", 
            "timeLineLink": "<?php echo C('site_url') . U('Store/cart',array('token' => $_GET['token']));?>",
            "sendFriendLink": "<?php echo C('site_url') . U('Store/cart',array('token' => $_GET['token']));?>",
            "weiboLink": "<?php echo C('site_url') . U('Store/cart',array('token' => $_GET['token']));?>",
            "tTitle": "<?php echo ($metaTitle); ?>",
            "tContent": "<?php echo ($metaTitle); ?>"
        };
</script>
<?php echo ($shareScript); ?>
</html>