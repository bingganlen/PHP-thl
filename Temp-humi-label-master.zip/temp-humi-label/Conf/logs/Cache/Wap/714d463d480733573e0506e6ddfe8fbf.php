<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_home_one.css" />
<script type="text/javascript" src="/public/ipublic.js"></script>
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<script type="text/javascript" src="js/jquerysession.js"></script>

<style>
.date_tu{background:url(img/a/home_btn_xz.png) center center no-repeat;}
input:checked+mspan{background:url(img/a/home_btn_xz_pre.png) center center no-repeat;} 
.date_tu{
    position:absolute;
    bottom:0px;
    left:0px;
    width:30px;
    height:30px;
    z-index:1;
    }

.tc_chose_k2 {
  width: 70%;
  height: 250px;
  background: #fff;
  position: fixed;
  left: 15%;
  top: 200px;
  z-index: 999999;
  border-radius: 10px;
  display: none;
  overflow: hidden;
}
.phone_place{
  background: #fff;
  padding:10px 0;
  position: relative;
  overflow: hidden;
}

</style>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
    var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
    if (/Android (\d+\.\d+)/.test(ua)){
        var version = parseFloat(RegExp.$1);
        if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
        }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
    } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
<body>
<!--header-->
<!--弹出
<div class="mc" style=""></div>
<div class="mc_message">
    <div class="font_style1">联系人&nbsp;&nbsp;:&nbsp;&nbsp;<span class="font5b">王冰</span></div>
    <div class="font_style1">电&nbsp;&nbsp&nbsp;&nbsp话&nbsp;&nbsp;:&nbsp;&nbsp;<span class="font5b">13817122949</span></div>
    <div class="font_style1">地&nbsp;&nbsp&nbsp;&nbsp址&nbsp;&nbsp;:&nbsp;&nbsp;<span class="font5b">上海市徐汇区虹梅路2001号5号</span></div>
    <div class="line4 mg_bottom mg_top"></div>
    <div class="font_style3 close">关闭</div>
    
</div>
-->
<!--头部标题-->
<div class="tc_mc"></div>
<div class="tc_chose_k2" style="background:rgba(255,255,255,0.8)!important;
    height:300px;">
    <div class="tip" style="color:#191919;">正在订购请稍后...</div>
     
    <!--<img class="date_close" src="img/gb.png"/>-->
</div>
<div class="header_k">
  <a href="<?php echo U('Store/goodslist',array('bid'=>'bid','FFphone'=>$_GET['FFphone'],'FFtoken'=>$_GET['FFtoken'],'FFqid'=>$_GET['FFqid']));?>">
    <img class="icon_left" src="img/a/nav_fh.jpg"/>
  </a>
    <div class="sz_name"><a href="<?php echo U('Store/intro',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>"><?php echo ($userinfo["Fwatername"]); ?></a></div>
     <!-- <a href="tel:<?php echo ($userinfo["Fphone"]); ?>">
         <img class="icon_right" src="img/a/nav_dh.png"/>
         </a> -->
</div>
<div class="h55"></div>
<marquee scrollAmount=2 onmouseover=stop() onmouseout=start() class="list_info">
<?php if($stinfo["notice"] != ""): echo ($stinfo["notice"]); ?>
<?php else: ?>欢迎光临"码上生活"订水系统<?php endif; ?>
</marquee>
<!--内容-->
<form method="post" action="" id="formid">
<!-- <div class="title_name">配送地址</div> -->
<div class="phone_place_k">
    <div class="slb">
    <div class="list_one">
        <?php if($goodsorder["logourl"] != ''): ?><img src="<?php echo ($goodsorder["logourl"]); ?>" class="picture"/>
        <?php else: ?>
        <img src="img/no.png" class="picture"/><?php endif; ?>        
        <div class="sp_k">
            <div class="sp_name ovfEps">品名：<?php echo ($goodsorder["Fgoodsname"]); ?></div>
            <input type="hidden" name="Fgoodsname" value="<?php echo ($goodsorder["Fgoodsname"]); ?>">
            <input type="hidden" name="Fgoodsid" value="<?php echo ($goodsorder["Fgoodsid"]); ?>">
            <input type="hidden" name="spec" value="<?php echo ($goodsorder["spec"]); ?>">
            <input type="hidden" name="Frice" value="<?php echo ($goodsorder["Frice"]); ?>">
            <!-- 水票订单标志 -->
            <input type="hidden" name="Fticket" value="<?php echo ($goodsorder["Fticket"]); ?>">
            <div class="sp_price">规格：<?php echo ($goodsorder["spec"]); ?></div>
            <div class="sp_exp"><?php echo ($goodsorder["ga_label"]); ?></div>
        </div>
        <div class="shuliang">
          <p ><?php if($goodsorder["Frice"] != '0'): ?>¥<?php echo ($goodsorder["Frice"]); else: ?>单价未知<?php endif; ?></p>
          <p>×<?php echo ($goodsorder["Fnum"]); ?></p>
          <!-- <p>+<?php echo ($goodsorder["Ftotal"]); ?>积分</p> -->
        </div>
         <input type="hidden" name="Fnum" value="<?php echo ($goodsorder["Fnum"]); ?>">
         <input type="hidden" name="Ftotal" value="<?php echo ($goodsorder["Ftotal"]); ?>">
    </div>
    </div>
</div>

<div class="phone_place_ex">
  <?php if($goodsorder["foregift"] > 0): ?><div class="font_ex">
      <p class="fl_l">押金说明:</p>
      <p class="fl_r" style="width:80%">亲爱的顾客，本水品的水桶押金是<?php echo ($goodsorder["foregift"]); ?>元/只，请准备好水桶或押金！</p>
    </div><?php endif; ?>
  <?php if($overhead_cost > 0): ?><div class="font_ex">
      <p class="fl_l">上 楼 费:</p>
      <p class="fl_r" style="width:80%">亲爱的顾客，因<?php if($reason_overhead != ''): echo ($reason_overhead); else: ?>您的楼层过高<?php endif; ?>，请准备<?php echo ($overhead_cost); ?>元上楼费给送水叔叔，谢谢！</p>
      <input type="hidden" name="overhead_cost" value="<?php echo ($overhead_cost); ?>"/>
    </div><?php endif; ?>
</div>
</div>
<!-- <div class="title_name">配送方式及时间</div> -->
<!-- <div class="phone_place_k2">
    <div class="font_style1" style="position:relative;">
        <span style="float:left;">预约时间:&nbsp;</span>
        <label>
        <div class="yy" style="" id="tody">
           <input type="radio" class="check"  name="today" checked="checked" style="display:none;" value="今天"/>
            <mspan class="date_tu"></mspan>
            今天
        </div>
        </label> 
        <label>
        <div class="yy" style="color:#999;" id="tomo">
           <input type="radio" class="check"  name="today" style="display:none;" value="明天"/>
            <mspan class="date_tu"></mspan>
            明天
        </div>
        </label>        
    </div>
</div> 
<div style="width:100%;overflow:hidden;">
    <div class="line"></div>
</div>-->
<!-- <script>
//日期选择
     $(document).ready(function() {
        $(".yy").click(function(){
            $(".yy").css("color","#999")
            $(this).css("color","#fd184e")
            })
        })
</script> -->
<!-- <div class="title_name">水品清单</div> -->
<div class="phone_place">
<div class="font_style1">购水手机:&nbsp;&nbsp;<span class="font5b" id="new_phone"><?php echo ($user["Fusername"]); ?></span><span></span></div>
    <input type="hidden" name="Fusername" id="Fusername" value="<?php echo ($user["Fusername"]); ?>">
    <div class="font_style1">
        <span class="fl_l">送水地址:&nbsp;&nbsp;</span>
        <!-- update by shitao 20161031 start -->
        <?php  if(!empty($user['Faddress'])){ ?>
        <div class="font5b fl_l address_info"><?php echo ($user["Faddress"]); ?> </div>
        <input type="hidden" name="FFqid" value="<?php echo ($_GET['FFqid']); ?>">
        <input type="hidden" name="Faddress" id="Faddress" value="<?php echo ($user["Faddress"]); ?>">
        <?php
 }else{ ?>
        <div class="font5b fl_l address_info">请点击右侧箭头设置收货信息</div>
        <input type="hidden" name="Faddress" id="Faddress" value="<?php echo ($user["Faddress"]); ?>">
        <!-- <input type="text" name="Faddress" id="Faddress"/></div> -->
        <?php } ?>
        <!-- update by shitao 20161031 end -->
    </div>
    <a href="<?php echo U('Store/phone_chose',array('bid'=>'bid','FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid'],'product'=>$goodsorder['Fgoodsid'],'productnum'=>$goodsorder['Fnum']));?>" class="adr_arr"><img src="img/a/rightarr.jpg" height="40px" alt="" id="phone_chose"/></a>
</div>


<!-- <div class="title_name">订单总价</div> -->
<div class="divider"></div>
<div class="phone_place_k3">
  <div class="font_style1"><span>水站营业时间：<?php echo ($stinfo["Fstart_time"]); ?> 至 <?php echo ($stinfo["Fend_time"]); ?></span></div>
  <div class="font_style1">
     <span> 配送时间：&nbsp;</span>
        <span id="get_time" style="margin:0;padding:0">        
       <?php echo ($get_time); ?> 
       </span>  
  </div>
  
</div>
<div class="font_zhifu">
     <span> 支付方式：&nbsp;</span>
        <select name="Fpaytype" id="pay_type">
          <option value="">选择支付方式</option>
          <option value="0">电子水票支付</option>
          <option value="1" selected="selected">线下支付</option>
          <?php if($stinfo["wx_pay"] > 0): ?><option value="2">微信支付</option><?php endif; ?>
          <!-- <option value="3">支付宝支付</option> -->
        </select> 
      <div class="sp_exp" id="ticketinfo"></div>
</div>
<div class="divider"></div>
<div class="phone_place_k4">
    <div class="font_style1" style="margin-top:10px">
        <span class="fl_l">订单总额：</span>
         <span class="right_font r_color">&nbsp;&nbsp;<?php if($goodsorder["Ftotal"] != '0'): ?>￥<?php echo ($goodsorder["Ftotal"]); endif; ?></span>
    </div>
    <?php if($goodsorder['discount'] > 0): ?><div class="font_style1" style="margin-top:10px">
        <span class="fl_l">优惠总额：</span>
         <span class="right_font r_color">&nbsp;&nbsp;￥<?php echo ($goodsorder["discount"]); ?></span>
         <input type="hidden" name="discount" value="<?php echo ($goodsorder["discount"]); ?>"/>
    </div>    
    <div class="font_style1">
        <span class="fl_l">实付金额：</span>
         <span class="right_font r_color">&nbsp;&nbsp;<?php if($goodsorder['paytotal'] > '0'): ?>￥<?php echo ($goodsorder["paytotal"]); else: ?>￥0.00<?php endif; ?></span>
         <input type="hidden" name="paytotal" value="<?php echo ($goodsorder["paytotal"]); ?>"/>
    </div>
    <?php else: ?>
    <div class="font_style1">
        <span class="fl_l">实付金额：</span>
         <span class="right_font r_color">&nbsp;&nbsp;<?php if($goodsorder['Ftotal'] != '0'): ?>￥<?php echo ($goodsorder["Ftotal"]); endif; ?></span>
    </div><?php endif; ?>
    <?php if($goodsorder['discount_reason'] != ''): ?><div class="font_style1" style="margin-top:10px">
        <span class="fl_l">优惠原因：</span>
         <span class="right_font r_color">&nbsp;&nbsp;<?php echo ($goodsorder["discount_reason"]); ?></span>
    </div><?php endif; ?>
    <!-- <?php if($rew == 'rew'): ?>暂不用此优惠功能20180511注释-->
    <!-- <div class="font_style1" style="margin-bottom:10px">
        <span class="fl_l">获得积分：</span>
         <span class="right_font r_color">&nbsp;&nbsp;<if condition="$goodsorder.Ftotal neq '0'"><?php echo ($goodsorder["Ftotal"]); endif; ?></span>
    </div> -->
    <div class="divider"></div>
    <div class="font_style1" style="margin:10px 15px;">
        <p style="float:left;">留言：</p>
        
        <textarea style="width:75%;height:100px;" maxlength="50" name="liuyan"></textarea>
        
    </div>
</div>
</form>
<!--footer-->
<!-- <div class="h100"></div> -->
<div class="pass" id="order"><p class="pass_btn">确认购买</p></div>

</body>
<script type="text/javascript">
//更换手机
$(document).ready(function(){
  var user=$('#new_phone').html();
  var phone=$.session.get('phone');
  if(phone!==''&&phone!==user){
    $('#new_phone').html(phone);
    $('#new_phone').next('span').html('<input type="hidden" name="Fphone" id="Fphone" value="'+phone+'">');
  }
  //水票订单限微信支付  
  var ticketord=$("input[name='Fticket']").val();
      //水票限微信支付
  if(ticketord=='1'){
    $('#pay_type').val('2');
  }
})
//底部按钮切换
    $(document).ready(function() {
        $(".ft_left").click(function(){
            $(".ft_left").css("background","#39436c")
            $(this).css("background","#0b0e1c")
            })
        })
//蒙层不可滑动
        $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.mc').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
//水站联系人信息
     $(document).ready(function() {
        $(".sz_name").click(function(){
            $(".mc").css("display","block")
            $(".mc_message").css("display","block")
            })
        $(".mc").click(function(){
            $(".mc").css("display","none")
            $(".mc_message").css("display","none")
            })
        $(".close").click(function(){
            $(".mc").css("display","none")
            $(".mc_message").css("display","none")
            })
        })
//水票支付
$("#pay_type").change(function(){
  $('#ticketinfo').html('');
  if($(this).val()==0){
    var gid=$("input[name='Fgoodsid']").val();
    var token="<?php echo ($_GET['FFtoken']); ?>";
    var user="<?php echo ($_GET['FFphone']); ?>";
    var Fqid="<?php echo ($_GET['FFqid']); ?>";
    $.post('index.php?g=Wap&m=Store&a=ticketcheck',{gid:gid,token:token,user:user,Fqid:Fqid},function(result){
      var s=result.replace(/\D/g,'');
      console.log(s);      
      if(s>0){
        $('#ticketinfo').html('您还有'+s+'张水票可用');
      }else{
        $('#ticketinfo').html('您暂无本商品的可用水票');
        $('#pay_type').val('');
      }
    })
  }
})


  $('#order').click(function(){

    //add by shitao 20161031 start
    var address = $("#Faddress").val();
    var username=$("#Fusername").val();
    if(address == ""||username==""){
       // alert("联系电话和送水地址不能为空");
        //return false;
        pconfirm.open('提示','联系电话或送水地址不能为空,请先登录',function(){
           window.location.href='<?php echo U("Reg/slogin",array("FFphone"=>$FFphone,"FFtoken"=>$FFtoken,"FFqid"=>$_GET["FFqid"],"product"=>$goodsorder["Fgoodsid"],"productnum"=>$goodsorder["Fnum"]));?>'
        })
        return false;
    }
    //add by shitao 20161031 end
    

     //  var floor="<?php echo ($floor); ?>";
    // var floor="1";
   /*if(floor==''){
      pconfirm.open('码上订水','由于系统升级请重新修改自己地址',function(){
    
        window.location.href="<?php echo U('Store/userset',array('bid'=>'bid','FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>";
    })
     return false;
   }*/
    //判断支付方式
      var pay_type=$('#pay_type option:selected').val();
      var ticketord=$("input[name='Fticket']").val();
      //水票限微信支付
      if(pay_type==''){
        alert('请选择支付方式');
        return false;
      }else if(ticketord=='1'&& pay_type!=='2'){
        alert('水票订单只能选择微信支付');
        return false;        
      }
     
       var Fhours1=parseInt($('#Fhours1').val());
        var Fhours2=parseInt($('#Fhours2').val());
 
       d2=new Date();
       var h2 = d2.getHours();
  

    var timestamp = Date.parse(new Date()); 
    var ordertime=parseInt('<?php echo ($ordertime); ?>');
    var notime=parseInt('<?php echo ($notime); ?>');
     
       if(Fhours1>=Fhours2){
          alert('请选择正确的时间');
          return false;
        }
         var daybegin=parseInt('<?php echo ($daybegin); ?>');
        var dayend=parseInt('<?php echo ($dayend); ?>');
        var orderalltimes=parseInt('<?php echo ($orderalltimes); ?>');
        var settimes=parseInt('<?php echo ($settimes); ?>');
    
      var data=$('#formid').serialize();
 
    /*pconfirm.open('码上订水','物品将在<label style="color:red">' + $('#Fhours1 option:selected').text()+ '－' + $('#Fhours2 option:selected').text() + '</label>送达,请确认有人签收!',function(){*/
    $(".tc_mc").css("display","block");
    $(".tc_chose_k2").css("display","block");
   
    $.post('index.php?g=Wap&m=Store&a=orderdon', data, function(response){
        console.log(response);
        if(response=='success'){
            $.session.clear();
                  
                      /**
                       * update by shitao 20160826 start
                       */
                   // setTimeout(function () { 
                  $(".tc_mc").css("display","none");
                  $(".tc_chose_k2").css("display","none");
                   //   pconfirm.open('码上订水','您已下单，请到订单中心查看 ',function(){
                   //       window.location.href='<?php echo U('Store/orders',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid'],'praisestatuson'=>$praisestatuson));?>';
                   //   })
                   // }, 3000);
            var pay_type=$('#pay_type option:selected').val();
            if(pay_type!=='2'){
                window.location.href='<?php echo U('Store/orderover',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>';
            }else{
                window.location.href='<?php echo U("Store/orderdown1",array("FFphone"=>$FFphone,"FFtoken"=>$FFtoken,"FFqid"=>$_GET["FFqid"]));?>';
            }      
                      /**
                       * update by shitao 20160826 end
                       */
        }else{
            $(".tc_mc").css("display","none");
            $(".tc_chose_k2").css("display","none");
            alert('对不起，下单失败。'+response);
            $.session.clear();                  
        }
    });
   })
  //})

$('#Fhours1').change(function(){
       var today=$("input[name='today']:checked").val();
       var Fhours1=parseInt($(this).val());
       d=new Date();
       var h = d.getHours();
       var Fhours2=parseInt($('#Fhours2').val());

        if(Fhours2<=Fhours1){
          alert('请填写正确的时间');
        }      

    })

    $('#Fhours2').change(function(){
       var Fhours2=$(this).val();
       var Fhours1=$('#Fhours1').val();
       Fhours1=parseInt(Fhours1);
       Fhours2=parseInt(Fhours2);
       if(Fhours2<=Fhours1){
        alert('请填写正确的时间');
        
        }
    })
    $('#phone_chose').click(function(){
      var product=$("input[name='Fgoodsid']").val();
      var productnum=$("input[name='Fnum']").val();
      $.session.set('product',product);
      $.session.set('productnum',productnum);
    })
//       $('#Fhours3').change(function(){
//        var Fhours3=$(this).val();
//        var Fhours4=$('#Fhours4').val();
//        Fhours3=parseInt(Fhours3);
//        Fhours4=parseInt(Fhours4);
//        if(Fhours4<Fhours3+1){
//         alert('请填写正确的时间');
//         }
//     })

//      $('#Fhours4').change(function(){
//        var Fhours4=$(this).val();
//        var Fhours3=$('#Fhours3').val();
//        Fhours3=parseInt(Fhours3);
//        Fhours4=parseInt(Fhours4);
//        if(Fhours4<Fhours3+1){
//         alert('请填写正确的时间');
//         }
//     })

//   $('#tody').click(function(){

//      $('#xuanzhe').css('display','none');
//      $('#get_time').css('display','inline');
//   })


//    $('#tomo').click(function(){
//     $('#xuanzhe').css('display','inline');
//     $('#get_time').css('display','none');
//    })

</script>
</html>