<?php if (!defined('THINK_PATH')) exit();?>
<div class="header_k">
 <!-- <?php if($_GET['bid'] == 'bid' ): ?><img class="icon_left" src="img/back.png" onclick="window.history.back()" />
 
 <?php else: ?>
 
   <img class="icon_left" src="img/chose_user.png"/><?php endif; ?> 头部左侧头像隐藏-->
   
    <div class="sz_name"> <a href="<?php echo U('Store/intro',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>"><?php echo ($userinfo["Fwatername"]); ?></a> <!-- <span><img class="title_d" src="img/a/nav_btn.png" style=""></span>头部点隐藏 --></div>

    <!-- <?php if($bid == 'orders'): ?><a href="<?php echo U('Nativelife/orderlist',array('token'=>$FFtoken));?>">
        <img class="icon_right" src="img/a/nav_fh.png"/>
        </a>
    <?php else: ?>
        <a href="tel:<?php echo ($userinfo["Fphone"]); ?>">
        <img class="icon_right" src="img/dh.png"/>
        </a><?php endif; ?> 头部右侧图标隐藏-->
    <!-- <div style="width:34px;width:100%"><p style="float:left;font-size:28px;">您目前的积分：90</p><img src="img/jifen.gif" style="float:right;"/> </div>积分隐藏-->
    
</div>
<div class="h55"></div>


<!--切换账号-->
<div class="tc_mc"></div>
<div class="tc_chose_k">
    <div class="tip blue_color">您可以切换其他账号登陆！</div>
    <a href="index.php?g=Wap&m=Reg&a=station&token=<?php echo ($FFtoken); ?>"><div class="go_join">切换账号 > ></div></a>
    <img class="date_close" src="img/gb.png"/>
</div>
<script>
//蒙层不可滑动
        $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.tc_mc').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
         $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.tc_chose_k').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
//切换账号
     $(document).ready(function() {
        $(".icon_left").click(function(){
            $(".tc_mc").css("display","block")
            $(".tc_chose_k").css("display","block")
            })
        $(".tc_mc").click(function(){
            $(".tc_mc").css("display","none")
            $(".tc_chose_k").css("display","none")
            })
        $(".date_close").click(function(){
            $(".tc_mc").css("display","none")
            $(".tc_chose_k").css("display","none")
            })
        })
</script>

<form id="search_form" name="search_form" action="" method="post">
	<div class="m-l-search">
		<input type="hidden" name="wecha_id" value="<?php echo ($wecha_id); ?>">
		<input type="hidden" name="token" value="<?php echo ($token); ?>">
		<input id="search_name" class="inp-search" name="search_name" type="search" value="" placeholder="输入关键字搜索">
		<input class="btn-search" name="search-btn" type="submit" value="">
	</div>
</form>

<div class="m-select c666 order_control">
<span><a href="javascript:" order="time" class="arrow-down">时间<i><em></em></i></a></span>
<span><a href="javascript:" order="salecount">销量<i><em></em></i></a></span>
<span><a href="javascript:" order="price">价格<i><em></em></i></a></span>
<span><a href="javascript:" order="discount">折扣<i><em></em></i></a></span>
<input type="hidden" id="view_list" value="">
<!-- <span class="filter"><a href="javascript:;" class="ary li">排列</a><a href="javascript:;" class="flt">筛选</a></span> -->
</div>
<ul id="m_list" class="m-list ">
<?php if(is_array($products)): $i = 0; $__LIST__ = $products;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$hostlist): $mod = ($i % 2 );++$i;?><li>
		<span class="pic">
			<a href="<?php echo U('Store/product',array('token' => $_GET['token'], 'id' => $hostlist['id'], 'wecha_id' => $_GET['wecha_id']));?>">
			<img src="<?php echo ($hostlist["logourl"]); ?>" data-original="<?php echo ($hostlist["logourl"]); ?>">
		</a>
		</span>
		<span class="con">
			<a class="t" href="<?php echo U('Store/product',array('token' => $_GET['token'], 'id' => $hostlist['id'], 'wecha_id' => $_GET['wecha_id']));?>"><?php echo ($hostlist["name"]); ?></a>
			<b>￥<?php echo ($hostlist["price"]); ?></b><del>￥<?php echo ($hostlist["oprice"]); ?></del>
		</span>
	</li><?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
<a class="more" id="show_more" page="2" style="display: none;" href="javascript:void(0);">加载更多</a>
<input type="hidden" value="1" id="pageid" />
<input type="hidden" id="canScroll" value="1" />
<script type="text/javascript">
$(function() {
	$('#search_form').submit(function() {
		var search_name = $('#search_name').val();
		if (search_name == '') {
			return false;
		}
	});

	//点击排序
	var base_url = '<?php echo U('Store/products',array('token'=>$_GET['token'],'catid'=>$thisCat['id'],'wecha_id'=>$_GET['wecha_id']));?>';
	var b_url = '<?php if($isSearch != 1): echo U('Store/ajaxProducts',array('token'=>$_GET['token'],'catid'=>$thisCat['id'],'wecha_id'=>$_GET['wecha_id'])); else: echo U('Store/ajaxProducts',array('token'=>$_GET['token'],'keyword'=>$_GET['keyword'],'wecha_id'=>$_GET['wecha_id'])); endif; ?>'
		method = 'DESC',
		_get_method = '<?php echo ($method); ?>',
		order = '<?php echo ($order); ?>',
		_get_order  = '';
	if (_get_order != '') {
		order = _get_order;
	}
	$('.order_control a').removeClass('arrow-down');
	if (_get_method == 'DESC')  {
		method = 'ASC';
		$('.order_control a[order="' + order + '"]').addClass('arrow-up');
	} else {
		$('.order_control a[order="' + order + '"]').addClass('arrow-down');
	}
	$('.order_control a').click(function() {
		var order = $(this).attr('order');
		var url = base_url + '&order=' + order+'&method='+method;
		location.href = url;
	});

	/*---------------------加载更多--------------------*/
	var total = <?php echo ($count); ?>,
		pagesize = 8,
		pages = Math.ceil(total / pagesize);
	var com_link = '<?php echo U('Store/product',array('token'=>$_GET['token'],'wecha_id'=>$_GET['wecha_id']));?>';
	var label_arr = ["\u8bf7\u9009\u62e9\u6807\u7b7e","\u70ed\u5356","\u7206\u6b3e"];
	if (pages > 1) {
		var _page = $('#show_more').attr('page');
		$(window).bind("scroll",function() {
			if ($(document).scrollTop() + $(window).height() >= $(document).height()) {
				$('#show_more').show().html('加载中...');
				if (_page > pages) {
					$('#show_more').show().html('没有更多了').delay(2300).slideUp(1600);
					return;
				}
				if($('#canScroll').val()==0){//不要重复加载
					return;
				}
				$('#canScroll').attr('value',0);
				$.ajax({
					type : "GET",
					data : {'page' : _page, 'inajax' : 1},
					url :  b_url + '&order=' + order + '&method=' + _get_method + '&pagesize='+pagesize,
					dataType : "json",
					success : function(RES) {
						$('#canScroll').attr('value',1);
						$('#show_more').hide().html('加载更多');
						data = RES.products;
						if(data.length){
							$('#show_more').attr('page',parseInt(_page)+1);
						}
						_page = $('#show_more').attr('page');
						var _tmp_html = '';
						$.each(data, function(x, y) {
							_tmp_html +=    '<li><span class="pic">' +
							'<a href="' + com_link + '&id=' + y.id + '">' +
							'<img src="' +y.logourl + '" />' +
							'</a></span><span class="con"><a class="t" href="' + com_link + '&id=' + y.id + '">' + y.name + '</a><b>￥'+ y.price +'&nbsp;元</b><del>￥' + y.oprice + '</del></span></li>';
						});
						$('#m_list').append(_tmp_html);
					}
				});
			}
		});
	}
});
</script>
<div style="height:100px;"></div>
<script src="<?php echo $staticFilePath;?>/js/jquery-1.9.1.min.js" type="text/javascript"></script>
<style type="text/css">
  body{max-width: 640px;margin:auto;}
  /*bottom*/

ul.fixed_bottom{ list-style:none;background:#e0e0e0; font-size:1em;  width:100%; overflow:hidden; border-top:#fff 1px solid; padding-bottom:6px; position:fixed; z-index:999; bottom:0; left:0; margin:auto; padding:4px 0; box-shadow:0 0 1px #f3eadb;}

ul.fixed_bottom li.fixed_li{list-style:none; width:25%; text-align:center; float:left; margin:5px 0; cursor:pointer; }

ul.fixed_bottom img.fixed_img{width:30%; max-width:55px;}

ul.fixed_bottom p.fixed_p{ margin:0 auto; font-size:1em;}

/*sub-menu-list width:189px;*/
.sub-menu-list5{width:189px;position:absolute;margin:8px 0 0 4px;background:rgba(0,0,0,0.8);z-index:99;box-shadow:0 0 3px rgba(0, 0, 0, 0.8);display:none;color:#FC0; position: fixed;bottom:15%;left:17%;}
.sub-menu-list5:after{position:absolute;top:178px;left:62px;content:'';width:0;height:0;border:8px solid transparent;border-bottom: 6px solid rgba(0, 0, 0, 0.8);border-top:0;}
.sub-menu-list5 li{float:left;width:94px;line-height:40px;text-align:center;border-right:1px solid #181818;border-bottom:1px solid #181818;margin-right:-1px;font-size:16px;list-style: none;}
.sub-menu-list5 li a{display:block;color:#fff}
</style>
<ul class="fixed_bottom" style="">


  <li class="fixed_li" style="">
        <a href="<?php echo U('Store/index',array('token'=>$_GET['token']));?>" style="color:#000">
            <img class="fixed_img" style="" src="images/zhuye<?php if(($sel) == "1"): ?>_click<?php endif; ?>.png"/>
            <p class="fixed_p" style="">首页</p>
         </a>   
        </li>
        <li class="fixed_li"  style="" id="cat5">
          <a href="javascript:void(0)" style="color:#000" >
            <img class="fixed_img"  style="" src="images/fenlei<?php if(($ss) == "1"): ?>_click<?php endif; ?>.png"/>
            <p class="fixed_p" style="">分类</p>
          </a>  
        </li>
        <li class="fixed_li"  style="">
        <a href="<?php echo U('Store/cart',array('token'=>$_GET['token'],'wecha_id'=>$_GET['wecha_id']));?>" style="color:#000">
            <img class="fixed_img"  style="" src="images/cart<?php if(($cart) == "1"): ?>_click<?php endif; ?>.png"/>
            <p class="fixed_p" style="">&nbsp;&nbsp;购物车</p>
         </a>   
        </li>
        <li class="fixed_li"  style="">
            <a href="<?php echo U('Store/my_s',array('token'=>$_GET['token'],'wecha_id'=>$_GET['wecha_id']));?>" style="color:#000">
            <img class="fixed_img"  style="" src="images/me<?php if(($my) == "1"): ?>_click<?php endif; ?>.png"/>
            <p class="fixed_p" style="">我的</p>
            </a>
        </li> 
    
          
</ul>

<ul class="sub-menu-list5" style="display:none">

<li><a href="<?php echo U('Store/index',array('token' => $_GET['token'], 'catid' => $hostlist['id'], 'wecha_id' => $wecha_id));?>">首页</a></li>
<?php if(is_array($cats)): $i = 0; $__LIST__ = $cats;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$hostlist): $mod = ($i % 2 );++$i;?><li><a href="<?php echo U('Store/products',array('token' => $_GET['token'], 'catid' => $hostlist['id'], 'wecha_id' => $wecha_id));?>"><?php echo (msubstr($hostlist["name"],0,5,'utf-8')); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
<script>


  $('#cat5').click( function() {
      //$('.sub-menu-list2').css('display','block');

       $('.sub-menu-list5').toggle();
    })
 

</script>





</body>
<script type="text/javascript">
window.shareData = {  
            "moduleName":"Store",
            "moduleID":"<?php echo ($products[0]['id']); ?>",
            "imgUrl": "<?php echo ($products[0]['logourl']); ?>", 
            "timeLineLink": "<?php echo C('site_url') . U('Store/products',array('token' => $_GET['token']));?>",
            "sendFriendLink": "<?php echo C('site_url') . U('Store/products',array('token' => $_GET['token']));?>",
            "weiboLink": "<?php echo C('site_url') . U('Store/products',array('token' => $_GET['token']));?>",
            "tTitle": "<?php echo ($metaTitle); ?>",
            "tContent": "<?php echo ($metaTitle); ?>"
        };
</script>
<?php echo ($shareScript); ?>
</html>