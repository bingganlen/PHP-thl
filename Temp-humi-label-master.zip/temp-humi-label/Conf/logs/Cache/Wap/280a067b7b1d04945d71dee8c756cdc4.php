<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_home_one.css" />
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<script type="text/javascript" src="/public/ipublic.js"></script>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
	var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
	if (/Android (\d+\.\d+)/.test(ua)){
		var version = parseFloat(RegExp.$1);
		if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
		}else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
	} else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
<body>
<!--头部标题-->
<div class="header_k">
	 <img class="icon_left" src="img/a/nav_fh.png" onclick="window.history.back()">
    <div class="sz_name">订单详情</div>
    <a href="tel:<?php echo ($orderinfo["bossphone"]); ?>">
    <img class="icon_right" src="img/dh.png">
    </a>

   
</div>
<div class="h88"></div>
<!--内容-->
<div class="dd_num">订单号：<?php echo ($orderinfo["ordernum"]); ?></div>

<div class="phone_place_k">
    <div class="font_style1">手机号:&nbsp;&nbsp;<span class="font5b"><?php echo ($orderinfo["userphone"]); ?></span></div>
    <div class="font_style1">
        <span class="fl_l">地址:&nbsp;&nbsp;</span>
        <div class="font5b fl_l" style="width:60%;"><?php echo ($orderinfo["address"]); ?></div>
    </div>
</div>
<div class="title_name">下单时间</div>
<div class="phone_place_k2" style="border-bottom:1px solid #e0e0e0;">
    <div class="font_style1" style="position:relative;">
        <span style="float:left;">下单:&nbsp;<span class="font5b"><?php echo ($orderinfo["createtime"]); ?></span></span>         
    </div>
</div>

<div class="h100"></div>
<div class="cuidan">
 <?php if($orderinfo["status"] != '1'): ?><div class="cui_l" id="cd"><img src="img/a/icon_dh.png" class="cui_tu" />我要催单</div>
    <div class="cui_r" id="cans">取消订单</div><?php endif; ?>
</div>


</body>
<script type="text/javascript">

    $('#cans').click(function(){
    

    pconfirm.open('码上订水','取消下单',function(){
       window.location = "<?php echo U('Nativelife/cancel',array('id'=>$_GET['id'],'userphone'=>$orderinfo['userphone'],'token'=>$token));?>";

    })
   
    })

  $('#cd').click(function(){

        pconfirm.open('码上订水','催单',function(){
             var id=<?php echo ($orderinfo['id']); ?>;
               var token="<?php echo ($_GET['token']); ?>";
               
             $.post('index.php?g=Wap&m=Nativelife&a=cd',{id:id,token:token},function(result){
                
                if(result==1){
                
                  //window.location.href = 'tel:<?php echo ($userinfo["Fphone"]); ?>'; 
                  alert('催单成功');
                }

                if(result==2){
                    alert('您已经催单请一分钟后');
                }

                if(result==3){
                    alert('此订单已发货');
                }
            });

        })
    })
</script>
</html>