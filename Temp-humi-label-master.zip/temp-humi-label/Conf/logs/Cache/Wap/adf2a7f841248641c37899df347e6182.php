<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/> 
    <title>确认支付</title>
    
</head>
<body style="margin:0;padding:0;font-size:22px;background:#f5f5f5">
    <div align="center" style="background:#fff;padding:18px 0;font-size:24px">
        <img src="img/a/paydown1.png" alt="支付" style="width:60%;margin:15px 0">
        <p>订单编号：<?php echo ($orderinfo["Forderid"]); ?></p>
        <?php if($orderinfo['Fpaytotal'] > 0): ?><p style="font-size:34px;color:#eb6100;font-weight:bold;margin:10px 0">￥<?php echo ($orderinfo["Fpaytotal"]); ?>元</p>
        <?php else: ?>
        <p style="font-size:34px;color:#eb6100;font-weight:bold;margin:10px 0">￥<?php echo ($orderinfo["Ftotal"]); ?>元</p><?php endif; ?>
        <div style="border-top:1px solid #ccc;text-align:center"><p>收款方： 码上生活</p></div>
    </div>
    
	<div align="center" style="margin-top:15px">
		<!-- <button style="width:70%; height:50px; border-radius: 5px;background-color:#fff; border:2px #eb6100 solid; cursor: pointer;  color:#eb6100;font-size:22px" type="button" id="down" >立即支付</button> -->
	</div>
</body>
</html>