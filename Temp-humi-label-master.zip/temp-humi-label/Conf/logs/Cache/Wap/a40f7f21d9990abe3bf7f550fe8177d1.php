<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1.0, user-scalabe=0"/>
<meta name="viewport" content="width=640,user-scalable=no,target-densitydpi=device-dpi">
<title>码上订水</title>
<?php if(empty($token)){ echo '<div style="text-align:center;margin-top:100px;font-size:20px;">请联系管理员绑定二维码!</div>'; exit; }?>
<script type="text/javascript" src="js/jquery.min.js"></script>
<style type="text/css">
*{
  margin:0;
  padding:0;
  }
body{
    background:#fff;
    color:#000;
    max-width:1242px;
    min-width:480px;
    margin:auto;
    }
.bgimg{
    background:url(tpl/Wap/default/common/img/lingjiang002.jpg)no-repeat;
    background-size:100%;
    width:100%;
    height:1075px;
    z-index:1;
    position:absolute;
    }
.lingjiang{
    height:245px;
    width:100%;
    margin-top:80%;
    }
.lj-text{
    width:90%;
    margin-left:5%;
    height:70px;
    
    border-radius:35px;
    position:relative;
    background:#fff;    
    z-index:5;}
.lj-text img{
    margin-top:15px;
    margin-left:40px;
    display:block;
    float:left;
    height:40px;
    }
.lj-tel{
    width:80%;  
    height:40px;
    margin-top:15px;
    float:left;
    border:none;
    margin-left:10px;
    font-size:28px;
    } 
.lj-btn{
    width:100%;
    height:75px;
    margin-top:100px;
    text-align:center;
    }
</style>
<script type="text/javascript">
  var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
  if (/Android (\d+\.\d+)/.test(ua)){
    var version = parseFloat(RegExp.$1);
    if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
    }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
  } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
  
</script>
<!--异步加载js-->
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.baidu.com/hm.js?ba88b8e89aed0dab77735e51a3aef67c";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>
</head>

<body>
<div class="bgimg">
    <div class="lingjiang">
    <div class="lj-text">
       <img src="tpl/Wap/default/common/img/lingjiang003.png" alt="telphone"/>
       <form>
        <input style="outline: 0" name="text" type="text" maxlength="11" placeholder="输入手机号码领取奖品" class="lj-tel"/>
       </form>
    </div>
    <div class="lj-btn">
        <a href="javascript:reg();"><img src="tpl/Wap/default/common/img/lingjiang001.png" alt="button" style="width:299px;height:75px"/></a>
    </div>
    </div>
</div><!--背景图-->

<script type="text/javascript">
    function reg(){
        if($(".lj-tel").val().length!=11){
            alert("请输入正确的手机号");
            // alert($(".lj-tel").val);
            // 
        }else{
            // window.location.href="index.php?g=Wap&m=Reg&a=reg&token=<?php echo $token;?>&Fewm_id=<?php  echo $FFqid;?>&phone="+$(".lj-tel").val()+"&jf=200"; 
            window.location.href="index.php?g=Wap&m=Reg&a=lottery_post&token=<?php echo $token;?>&Fewm_id=<?php  echo $FFqid;?>&phone="+$(".lj-tel").val()+"&jf=200"; 
        }
    }
</script>

</body>
</html>