<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>推广统计</title>
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/home_phone.css" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/tg_all.css" />
</head>
<!--手机端自适应js-->
<script type="text/javascript">
    var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
    if (/Android (\d+\.\d+)/.test(ua)){
        var version = parseFloat(RegExp.$1);
        if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
        }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
    } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
<body>
<!--header-->

<!--头部标题-->
<div class="header_k">
    <a href="<?php echo U('Recom/slist',array('token'=>$token));?>"><img class="icon_left" src="<?php echo RES;?>/img/back.png"/></a>
    <div class="sz_name">总推广统计</div>
    <!-- <img class="icon_right" src="<?php echo RES;?>/img/dh.png"/> -->
</div>
<div class="h88"></div>
<div style="width:100%;height:120px;"></div>
<!--内容-->
    <!--切换-->
    <div class="chose">
        <div class="chose_border">
            <div class="wei"><a href="<?php echo U('Recom/wdd',array('token'=>$token));?>">未奖励</a></div>
            <div class="yi"><a href="<?php echo U('Recom/ydd',array('token'=>$token));?>">已奖励</a></div>
        </div>
    </div>
    <!--list-->
    <?php if(isset($res)): if(is_array($res)): $i = 0; $__LIST__ = $res;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$res): $mod = ($i % 2 );++$i;?><div class="list" style="border-top:none;margin-top:10px;">
                
                        <div class="tj">
                            <img style="margin-top:18px;" src="<?php echo RES;?>/img/place.jpg"/>
                            <span class="place" style="margin-left:19px;"><?php echo ($res["Faddress"]); ?></span>
                        </div>
                        <div class="sl" style="margin-left:19px;">
                            <span class="sl_font">注册时间</span>
                            <span class="xg">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                            <span class="sl_num"><?php echo (date("Y-m-d H:i:s",$res["Fcreatetime"])); ?></span>
                        </div>
                        <div class="sl" style="margin-left:19px;">
                            <span class="sl_font">手机号:</span>
                            <span class="xg">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                            <span class="wei_c"><?php echo ($res["Fusername"]); ?></span>
                        </div>
            </div><?php endforeach; endif; else: echo "" ;endif; ?>
               
         <?php else: ?> 
                <div style="text-align:center;margin-top:100px;font-size:20px;">暂无数据!</div><?php endif; ?>
</body>

</html>