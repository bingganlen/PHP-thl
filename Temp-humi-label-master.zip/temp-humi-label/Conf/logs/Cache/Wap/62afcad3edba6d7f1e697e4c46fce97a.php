<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,height=device-height, user-scalable=no,initial-scale=1, minimum-scale=1, maximum-scale=1 ">
<title>码上订水</title>
</head>
<style>
/*************************浏览器通用*/
body{background:#fff; color:#000;}
html{font-size:100%;}
* {
    margin: 0;
    padding: 0;
    color:#000; 

}
img{
    max-width: 100%;
}
a {color:green;
text-decoration: underline;
}
</style>
<body>
<!--header-->
<!--头部标题-->
<div style="width:100%;height:34px;padding-top:10px;background:#59c2e1;position:fixed;top:0;left:0;">
    <img style="width:30px; float:left;margin-left:9.5px;" src="img/back.png" onclick="window.history.back()"/>
    <a href="tel:<?php echo ($userinfo["Fphone"]); ?>">
    <img style="width:30px;float:right;margin-right:9.5px;margin-top:-2px;" src="img/dh.png"/>
    </a>
    <div style="color:#fff;font-size:20px;margin:auto;text-align:center;"><?php echo ($userinfo["Fwatername"]); ?></div>

</div>
<div style="width:100%;height:44px;"></div>
<!--内容-->
<div style="width:94%;margin-left:3%;margin-top:10px;overflow:hidden"><?php echo ($intro); ?></div><!--这里填输入框内容-->

</body>
</html>