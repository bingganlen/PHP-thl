<?php if (!defined('THINK_PATH')) exit();?> <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/huodong.css" />
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>

</head>
<!--手机端自适应js-->
<script type="text/javascript">
	var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
	if (/Android (\d+\.\d+)/.test(ua)){
		var version = parseFloat(RegExp.$1);
		if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
		}else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
	} else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
<body>

<!--头部标题-->
<div class="header_k">
	<img class="icon_left" onclick="javascript:history.go(-1);" src="img/activity/back2.png"/>
    <div class="sz_name">我的卡包</div>
    <a href="<?php echo U('Storeactive/info',array('FFphone'=>$_GET['FFphone'],'FFtoken'=>$_GET['FFtoken'],'FFqid'=>$_GET['FFqid']));?>"><img class="icon_right" src="img/activity/xq_icon.png"/></a>
</div>
<div class="h88"></div>
<!--内容-->
<?php if($bid1 != '' ): ?><div class="card_k">
	<div class="card_tu_k">
    	<img class="card_tu" src="img/activity/c1.png"/>
        <div class="card_font">Surprise</div>
        <div class="card_font">魔幻卡</div>
    </div>
    <div class="card_font1">截止日期：<?php echo (date('Y-m-d H:i:s',$endtime)); ?></div>
    <?php if(is_array($list1)): $i = 0; $__LIST__ = $list1;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><div class="card_font<?php if($item["Fisuse"] == 0): ?>2<?php else: ?>3<?php endif; ?>">兑换码：<?php echo ($item["Fsn"]); if($item["Fisuse"] == 1): ?>&nbsp;&nbsp;&nbsp;&nbsp;已兑换<?php endif; ?></div><?php endforeach; endif; else: echo "" ;endif; ?>
    
</div><?php endif; ?>
<?php if($bid2 != '' ): ?><div class="card_k">
	<div class="card_tu_k1">
    	<img class="card_tu" src="img/activity/c2.png"/>
        <div class="card_font">Lucky</div>
        <div class="card_font">魔幻卡</div>
    </div>
    <div class="card_font1">截止日期：<?php echo (date('Y-m-d H:i:s',$endtime)); ?></div>

        <?php if(is_array($list2)): $i = 0; $__LIST__ = $list2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><div class="card_font<?php if($item["Fisuse"] == 0): ?>22<?php else: ?>3<?php endif; ?>">兑换码：<?php echo ($item["Fsn"]); if($item["Fisuse"] == 1): ?>&nbsp;&nbsp;&nbsp;&nbsp;已兑换<?php endif; ?></div><?php endforeach; endif; else: echo "" ;endif; ?>
</div><?php endif; ?>
<?php if($bid3 != '' ): ?><div class="card_k">
	<div class="card_tu_k2">
    	<img class="card_tu" src="img/activity/c3.png"/>
        <div class="card_font">Happy</div>
        <div class="card_font">魔幻卡</div>
    </div>
    <div class="card_font1">截止日期：<?php echo (date('Y-m-d H:i:s',$endtime)); ?></div>

        <?php if(is_array($list3)): $i = 0; $__LIST__ = $list3;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><div class="card_font<?php if($item["Fisuse"] == 0): ?>222<?php else: ?>3<?php endif; ?>">兑换码：<?php echo ($item["Fsn"]); if($item["Fisuse"] == 1): ?>&nbsp;&nbsp;&nbsp;&nbsp;已兑换<?php endif; ?></div><?php endforeach; endif; else: echo "" ;endif; ?>
</div><?php endif; ?>

<div class="h100"></div>
<div class="cuidan1">
	<div class="cui_l1">您还有<span class="times"><?php if($lasttimes > 0): echo ($lasttimes); else: ?>0<?php endif; ?></span>次抽奖机会</div>
   <a href="<?php echo U('Storeactive/activedo',array('FFphone'=>$_GET['FFphone'],'token'=>$_GET['FFtoken'],'FFqid'=>$_GET['FFqid']));?>"><div class="cui_r1">我要抽奖</div></a>
</div>
</body>

<script>
//活动
$(document).ready(function() {
		$(".activity_mc").click(function(){
			$(".answer_k").css("display","none")
			$(".activity_mc").css("display","none")
			})
		$(".again").click(function(){
			$(".answer_k").css("display","none")
			$(".activity_mc").css("display","none")
			})
})
</script>
</html>