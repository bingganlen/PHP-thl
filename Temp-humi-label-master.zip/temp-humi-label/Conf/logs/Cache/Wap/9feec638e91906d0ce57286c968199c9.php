<?php if (!defined('THINK_PATH')) exit();?>
<form action="<?php echo U('order', $_GET);?>" method="post" id="porder">
    <div class="font_dd ovfEps"><?php echo ($product["name"]); ?></div>
    <div class="line3 mg_top"></div>
    <input type="hidden" value="<?php echo ($product["id"]); ?>" name="pid">
    <?php if($list): ?><div class="do_k" style="">
            <span class="do_bt" style="">套餐选择:</span>
            <select class="downe" style="" name="ticket">
                <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["Fid"]); ?>" price="<?php echo ($vo["Fprice"]); ?>" num="<?php echo ($vo["Fnum"]); ?>"><?php echo ($vo["Fname"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
            </select>
        </div>
        <div class="do_k" style="m">
            <span class="do_bt" style="">实际张数:<span class="pay_money2"><span id="Fnum"><?php echo ($list[0]['Fnum']); ?></span></span></span>
        </div>
        <div class="do_k" style="">
            <span class="do_bt" style="">实际支付:<span class="pay_money">￥<span id="Fprice"><?php echo ($list[0]['Fprice']); ?></span></span></span>
        </div>
        <div class="line4"></div>

        <div class="do_k" style="">
            <span class="do_bt" style="">支付方式:</span>
            <label>
                <div class="p_w" style="font-size:3rem;margin-left:4rem;;float:left;width:25%;height:8rem;line-height:8rem;text-align:left;position:relative;text-indent:4rem;color:#d12b04;">
                    <input type="radio" class="check" value="xianjin" name="sel" checked="checked" style="display:none;"/>
                    <mspan class="date_tu"></mspan>
                    现金
                </div>
            </label> 
            
            <!-- <label>
                <div class="p_w" style="font-size:3rem;float:left;width:25%;height:8rem;line-height:8rem;text-align:left;position:relative;text-indent:4rem;color:#999;">
                    <input type="radio" class="check" value="weixin" name="sel" style="display:none;"/>
                    <mspan class="date_tu"></mspan>
                    微信
                </div>
            </label> -->
        </div>
    <?php else: ?>
        <div style="height: 120px;">
            <div style="text-align: center;width: 100%;" class="do_bt">暂无水票</div>
        </div><?php endif; ?>
</form>

<div class="sure_cz">确认下单</div>
<img src="img/gb.png"/ class="gb_style close"/>
<script type="text/javascript">
    $(".close").click(function(){
        $(".mc").css("display","none")
        $(".mc_message").css("display","none")
    });
    <?php if($list): ?>$(".sure_cz").click(function(){
            $("#porder").submit();
        });<?php endif; ?>
    $('.downe').change(function(){
        $('#Fnum').html($(this).find("option:selected").attr('num'));
        $('#Fprice').html($(this).find("option:selected").attr('price'));
    });
</script>