<?php if (!defined('THINK_PATH')) exit();?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上定水</title>
<link rel="stylesheet" type="text/css" href="css/wcss/home_phone.css" />
<link rel="stylesheet" type="text/css" href="css/wcss/user_dz.css" />
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<script type="text/javascript" src="/public/ipublic.js"></script>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
    var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
    if (/Android (\d+\.\d+)/.test(ua)){
        var version = parseFloat(RegExp.$1);
        if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
        }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
    } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>


<body>
    <div class="name">登录</div>
    <form method="post" action="">
    <div class="phone_k">
        <img class="icon" src="img/a.png" alt="用户名"/>
        <input class="phone_sr" type="text" placeholder="用户名" name="username" id="username"/>
    </div>
    <div class="phone_k">
        <img class="icon" src="img/b.png" alt="密码"/>
        <input class="phone_sr" type="password" placeholder="密码" name="password" id="password"/>
    </div>
    <input type="hidden" name="__hash__" value="506bb118d0003eaeb7573b245046a354_e52aa27b5ea29eeb3786c052769e36d4" /></form>
    <div class="phone_k" style="border:none; margin-top:24px;">
        <input type="button" class="login" value="登&nbsp;录" id="submit"/>
    </div>
</body>
<script type="text/javascript">
    $('#submit').click(function(){
        name = $('#username').val();
        password = $('#password').val();

        if(name == "" || password == ""){
            alert("手机号或密码不能为空");
            return;
        }
        
        $.post("",{username:name, password:password},function(result){
            if(result == "0"){
                alert("您的手机号或密码不正确");
            }else{
                window.location.href = result;
            }
        });
    });
</script>
</html>