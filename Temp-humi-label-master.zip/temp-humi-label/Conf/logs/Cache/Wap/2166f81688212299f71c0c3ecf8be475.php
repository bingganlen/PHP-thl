<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_dz.css" />
<script type="text/javascript" src="/public/ipublic.js"></script>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
  var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
  if (/Android (\d+\.\d+)/.test(ua)){
    var version = parseFloat(RegExp.$1);
    if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
    }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
  } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>


<body>
 <form onsubmit="return onpost()" action="<?php echo U('Reg/login_st_chk');?>" method="post" >
      <input type="hidden" name="token" value="<?php echo ($token); ?>">
      <input type="hidden" name="name" value="<?php echo ($phone); ?>">
  <div class="name">码上订水</div>
    <div class="phone_k" style="margin-top:20px;">
        <img class="icon" src="img/a/login_icon_sjh.png" alt="手机号"/>
        <span class="phone_sr"><?php echo ($phone); ?></span>
    </div>
    <div class="phone_k">
        <img class="icon" src="img/a/login_icon_mm.png" alt="密码"/>
        <span class="test">
            <input class="phone_sr" type="password" placeholder="密码" name="passwd" id="passwd"/>
        </span>
        <img class="icon_e" src="img/eye.png" alt="密码"/>
    </div>

    <input type="submit" class="login" value="登&nbsp;录"/>
    <a href="<?php echo U('Reg/lookcode',array('token'=>$token,'phone'=>$phone,'FFqid'=>$FFqid));?>">
    <div class="tgy_come">忘记密码 > ></div>
    </a>
 <!--  <input type="button" class="login1" value="我要注册"/> -->
 </form>
</body>
<script>
function onpost(){
  // name=document.getElementById('name').value;
  passwd=document.getElementById('passwd').value;

  // var reg=/^0{0,1}(13[0-9]|14[0-9]|16[0-9]|17[0-9]|15[0-9]|18[0-9])[0-9]{8}$/i;
  // if(name=='' || !reg.test(name)){
  //   palert.open('码上订水','请输入正确的手机号！');
  //   return false;
  // }
  
  if(passwd==''){
        palert.open('码上订水','密码不能为空');
        return false;
    }
  return true;
}
</script>
</html>