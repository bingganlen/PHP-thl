<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="css/wcss/home_phone.css" />
<link rel="stylesheet" type="text/css" href="css/wcss/user_dz.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="/public/ipublic.js"></script>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
    var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
    if (/Android (\d+\.\d+)/.test(ua)){
        var version = parseFloat(RegExp.$1);
        if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
        }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
    } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>


<body>
    <div class="name">送水工登录</div>
    <div class="ps"></div>
    <form method="post" action="<?php echo U('Wk/checklogin');?>" onsubmit="return onpost()">
        <div class="phone_k">
            <img class="icon" src="img/a.png" alt="手机号"/>
            <input class="phone_sr" type="text" placeholder="手机号" name="phone" id="phone"/>
        </div>
        <div class="phone_k">
            <img class="icon" src="img/b.png" alt="密码"/>
            <input class="phone_sr" type="password" placeholder="密码" name="pwd" id="pwd"/>
        </div> 
        <div class="phone_k" style="border:none; margin-top:24px;">
            <input type="submit" class="login" value="登&nbsp;录"/>
        </div>
    </form>
</body>


<script>
function onpost(){
          name=document.getElementById('phone').value;
          passwd=document.getElementById('pwd').value;
          var reg=/^0{0,1}(13[0-9]|14[0-9]|16[0-9]|17[0-9]|15[0-9]|18[0-9])[0-9]{8}$/i;
          if(name=='' || !reg.test(name)){
             palert.open('码上订水','请输入正确的手机号！');
            return false;
          }
          if(passwd==''){
              palert.open('码上订水','密码不能为空');
              return false;
                }
          return true;
        }
</script>
</html>