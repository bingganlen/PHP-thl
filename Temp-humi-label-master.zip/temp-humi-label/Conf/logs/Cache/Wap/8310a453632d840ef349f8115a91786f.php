<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_home_one.css" />
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<script type="text/javascript" src="/public/ipublic.js"></script>
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.baidu.com/hm.js?ba88b8e89aed0dab77735e51a3aef67c";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>

<style>
.date_tu{background:url(img/a/home_btn_xz.png) center center no-repeat;}
input:checked+mspan{background:url(img/a/home_btn_xz_pre.png) center center no-repeat;}	
.date_tu{
	position:absolute;
	bottom:0px;
	left:0px;
	width:30px;
	height:30px;
	z-index:1;
	}

  .tc_chose_k2 {
  width: 90%;
  height: 300px;
  background: #fff;
  position: fixed;
  left: 5%;
  top: 200px;
  z-index: 99999999;
  border-radius: 5px;
  display: none;
  overflow: hidden;
}
</style>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
	var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
	if (/Android (\d+\.\d+)/.test(ua)){
		var version = parseFloat(RegExp.$1);
		if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
		}else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
	} else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
<body>
<!--header
style="background:rgba(255,255,255,0.6);width:80%;margin-left:10%;margin-top:250px;
    height:300px; line-height:300px;font-size:32px;text-align:center;color:#191919;"
-->



<!--头部标题-->
<div class="header_k">
  
  <img class="icon_left" src="img/a/nav_fh.png" onclick="window.history.back()">
    <div class="sz_name"> 
      <?php if($info["type"] == 0 ): ?>回收
      <?php elseif($info["type"] == 1): ?>
      清洁
      <?php elseif($info["type"] == 2): ?>
      干洗
      <?php else: ?>
      常用<?php endif; ?>
      <a href="/index.php?g=Wap&amp;m=Store&amp;a=intro&amp;" style="color:#FFF"></a> <span><img class="title_d" src="img/a/nav_btn.png" style=""></span></div>

    
  
    <a href="tel:<?php echo ($info["phone"]); ?>">
    <img class="icon_right" src="img/dh.png">
    </a>
</div>
<!--内容-->
<div style="width:100%;height:44px;"></div>
<div style="width:94%;margin-left:3%;margin-top:98px;overflow:hidden">
 <?php echo ($info["des"]); ?>
</div>
<input type="hidden" name="type" value="<?php echo ($info["type"]); ?>"/>
<input type="hidden" name="token" value="<?php echo ($_GET['token']); ?>"/>
<!--footer-->
<div class="h100"></div>

<div class="pass" id="order">确认下单</div>


</body>
<script>
  $('#order').click(function(){

      pconfirm.open('周边服务','确定下单',function(){

      var type=$('input[name=type]').val();
      var token=$('input[name=token]').val();
      var url="<?php echo U('Nativelife/order');?>";
      var data={'type':type,'token':token};
      $.post(url,data,function(res){

         if(res=='1'){
            pconfirm.open('周边服务','您已下单，请到订单中心查看 ',function(){
                  window.location.href="index.php?g=Wap&m=Nativelife&a=orderlist&token="+token+"&type="+type;
                 
              })

           
         }else if(res=='2'){
           alert('两分钟内重复下单');
         }else{
           alert('失败');
         }
      },'json');
 
    });

  })
</script>
</html>