<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1.0, user-scalabe=0"/>
<meta name="viewport" content="width=640,user-scalable=no,target-densitydpi=device-dpi">
<title>码上订水</title>
<?php if(empty($token)){ echo '<div style="text-align:center;margin-top:100px;font-size:20px;">请联系管理员绑定二维码!</div>'; exit; }?>
<script type="text/javascript" src="js/jquery.min.js"></script>
<style type="text/css">
body{
    background:#fff;
    color:#000;
    max-width:1242px;
    min-width:480px;
    margin:auto;
    }
html{font-size:100%;
   }
* {
  margin:0;
  padding:0;
  list-style:none;
   }
.choujiang{
    width:100%;
    height:590px;
    background:url(tpl/Wap/default/common/img/choujiang002.jpg) no-repeat;
    z-index:1;
    background-size:100%;
}
.yuanpan{
    position:absolute;
    width:80%;
    height:520px;
    margin-left:10%;
    background:url(tpl/Wap/default/common/img/choujiang01.png) no-repeat;
    z-index:5;
    background-size:100%;
    margin-top:40px;
}
@-webkit-keyframes round{
    0%{transform:rotate(0deg)}
    100%{transform:rotate(234deg)}
    }
.yuanpan_round{
    position:absolute;
    width:80%;
    height:520px;
    margin-left:10%;
    background:url(tpl/Wap/default/common/img/choujiang01.png) no-repeat;
    z-index:5;
    background-size:100%;
    margin-top:40px;
    -webkit-animation:round 3s;
    }
.yuanpan_rot{
    position:absolute;
    width:80%;
    height:520px;
    margin-left:10%;
    background:url(tpl/Wap/default/common/img/choujiang01.png) no-repeat;
    z-index:5;
    background-size:100%;
    margin-top:40px;
    transform:rotate(234deg);
    }
.zhizhen{
    position:absolute;
    width:26%;
    height:205px;
    left:50%;
    top:180px;
    margin-left:-13%;
    /*margin-top:-35%;*/
    background:url(tpl/Wap/default/common/img/choujiang003.png) no-repeat;
    z-index:10;
    background-size:100%
}

.neirong{
    background-color:#D5471A;
    width:100%;
    height:920px;
    padding-top:10px;
    }
.jiangpin{
    height:auto;
    width:84%;
    margin-left:8%;
    background-color:#fff;
    font-family:"微软雅黑";
    font-size:22px;
    border-radius:3%;
    padding-top:20px;
    padding-bottom:20px;
    margin-top:30px;
    }
.jiangpin p{
    text-indent:-1.0em;
    line-height:40px;
    padding-left:2.5em;
    }
.jiangpin p span{
    color:#FF0000;
    font-size:30px;
    }
</style>
<!--手机端自适应js-->
<script type="text/javascript">
  var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
  if (/Android (\d+\.\d+)/.test(ua)){
    var version = parseFloat(RegExp.$1);
    if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
    }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
  } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
  
</script>
<!--异步加载js-->
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.baidu.com/hm.js?ba88b8e89aed0dab77735e51a3aef67c";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>
</head>
<body>
    <div class="choujiang">
        <div class="yuanpan" id="rotater">          
        </div>
        <div class="zhizhen" id="pointer">
        </div>
    </div><!--抽奖转盘-->
    <div class="neirong">
        <div class="jiangpin">
          <div style="background:url(tpl/Wap/default/common/img/choujiang004.png)no-repeat;width:100%;height:35px;margin:10px"></div>
          <p>一等奖5名,<span>iphone6s 一台</span></p>
          <p>二等奖50名,美的三开门冰箱一台</p>
          <p>三等奖200名,订水商城1000积分</p>
          <p>四等奖300名,云南佤山土蜂蜜一罐（1kg)</p>
          <p>五等奖400名,10000毫安华为充电宝一个</p>
          <p>六等奖500名,水果锅一个</p>
          <p>七等奖600名,订水商城500积分</p>
          <p>八等奖700名,订水商城300积分</p>
          <p>九等奖800名,订水商城200积分</p>
          <p>参与奖无限额,订水商城100积分</p>
        </div>
        <div class="jiangpin">
          <div style="background:url(tpl/Wap/default/common/img/choujiang005.png)no-repeat;width:100%;height:35px;margin:10px;"></div>
          <p>1. 新用户第一次注册可以领取一次抽奖机会。</p>
          <p>2. 手机号绑定成功后即可获取奖品，积分奖品可以到首页“码上商城”中兑换商品,实物奖品我们会给您快递过来。</p>
          <p>3. 码上订水保留法律范围内允许的对活动的解释权。</p>
        </div>
    </div><!--抽奖规则-->
<script type="text/javascript">
    //定义旋转函数
    function rotate(){
        $("#rotater").attr("class","yuanpan_round");
        $(function () {
            setTimeout(function () {
                $("#rotater").attr("class","yuanpan_rot");
                window.location.href="index.php?g=Wap&m=Reg&a=lottery&FFtoken=<?php echo $token;?>&FFqid=<?php  echo $FFqid;?>"; 
            }, 2900);
        });


    }
    $("#pointer").click(function(){
        rotate();
    });
    
    //定义旋转任意圈
    function rnd(){
    return Math.floor(Math.random()*5);
}
</script>
</body>
</html>