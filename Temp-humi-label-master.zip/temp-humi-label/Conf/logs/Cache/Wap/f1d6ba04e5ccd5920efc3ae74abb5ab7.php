<?php if (!defined('THINK_PATH')) exit();?> <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/huodong.css" />
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<script type="text/javascript" src="/public/ipublic.js"></script>

</head>
<!--手机端自适应js-->
<script type="text/javascript">
	var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
	if (/Android (\d+\.\d+)/.test(ua)){
		var version = parseFloat(RegExp.$1);
		if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
		}else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
	} else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
<body>

<div class="activity_mc" style="display:none"></div>
<!--头部标题-->
<div class="header_k">
	<img class="icon_left" onclick="javascript:history.go(-1);" src="img/activity/back2.png"/>
    <a href="<?php echo U('Storeactive/info',array('FFphone'=>$_GET['FFphone'],'FFtoken'=>$_GET['token'],'FFqid'=>$_GET['FFqid']));?>"><div class="sz_name">活动详情</div></a>
</div>
<div class="h88"></div>
<!--内容-->

<div class="cj_k">
    <img class="xq_tu" src="img/activity/cj_1.jpg"/>
    <div class="cj_but" id="activedo">点击抽奖</div>
</div>


<div class="answer_k" style="display:none" id='price1'>
	<img class="annwer_tu" src="img/activity/oldman.png"/>
    <div class="annswer_font">恭喜 您获得<br/>Surprise魔幻卡</div>
    <div class="again">再来一次</div>
   <a href="<?php echo U('Storeactive/praiseslist',array('FFtoken'=>$_GET['token'],'FFqid'=>$_GET['FFqid'],'FFphone'=>$_GET['FFphone']));?>"> <div class="my_card_but">我的卡包 >></div></a>
</div>
<div class="answer_k" style="display:none" id='price2'>
    <img class="annwer_tu" src="img/activity/oldman.png"/>
    <div class="annswer_font">恭喜 您获得<br/>Lucky魔幻卡</div>
    <div class="again">再来一次</div>
    <a href="<?php echo U('Storeactive/praiseslist',array('FFtoken'=>$_GET['token'],'FFqid'=>$_GET['FFqid'],'FFphone'=>$_GET['FFphone']));?>"><div class="my_card_but">我的卡包 >></div></a>
</div>
<div class="answer_k" style="display:none" id='price3'>
    <img class="annwer_tu" src="img/activity/oldman.png"/>
    <div class="annswer_font">恭喜 您获得<br/>Happy魔幻卡</div>
    <div class="again">再来一次</div>
    <a href="<?php echo U('Storeactive/praiseslist',array('FFtoken'=>$_GET['token'],'FFqid'=>$_GET['FFqid'],'FFphone'=>$_GET['FFphone']));?>"><div class="my_card_but">我的卡包 >></div></a>
</div>



<div class="answer_k" id='price4'  style="display:none">
	<img class="annwer_tu" src="img/activity/cj2.png"/>
    <div class="again">再来一次</div>
      <a href="<?php echo U('Storeactive/praiseslist',array('FFtoken'=>$_GET['token'],'FFqid'=>$_GET['FFqid'],'FFphone'=>$_GET['FFphone']));?>"><div class="my_card_but">我的卡包 >></div></a>
</div>






</body>

<script>
//活动
$(document).ready(function() {
		$(".activity_mc").click(function(){
			$(".answer_k").css("display","none")
			$(".activity_mc").css("display","none")
			})
		$(".again").click(function(){
			$(".answer_k").css("display","none")
			$(".activity_mc").css("display","none")
			})
})


$('#activedo').click(function(){
   var username='<?php echo ($username); ?>';
   var token='<?php echo ($token); ?>';
   var data={'username':username,'token':token};

   $.post('index.php?g=Wap&m=Storeactive&a=activeprocess', data, function(response){

      if(response=='1'){
         $('#price1').css("display","block");
         $(".activity_mc").css("display","block")
      }else if(response=='2'){
         $('#price2').css("display","block");
         $(".activity_mc").css("display","block");
      }else if(response=='3'){
         $('#price3').css("display","block");
         $(".activity_mc").css("display","block");
      }else if(response=='4'){
        $('#price4').css("display","block");
         $(".activity_mc").css("display","block");
      }else if(response=='timesend'){
         alert('您今天抽奖的次数已到');
      }else{
        alert('活动结束'); 
      }
   })   
})

</script>
</html>