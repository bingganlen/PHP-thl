<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_home_one.css" />
<script type="text/javascript" src="/public/ipublic.js"></script>
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<script type="text/javascript" src="js/jquerysession.js"></script>
<style>

.tc_chose_k2 {
  width: 70%;
  height: 250px;
  background: #fff;
  position: fixed;
  left: 15%;
  top: 200px;
  z-index: 999999;
  border-radius: 10px;
  display: none;
  overflow: hidden;
}


</style>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
    var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
    if (/Android (\d+\.\d+)/.test(ua)){
        var version = parseFloat(RegExp.$1);
        if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
        }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
    } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
<body>

<!--头部标题-->

<div class="header_k">
  <!-- <a href="<?php echo U('Store/orderinfo',array('bid'=>'bid','FFphone'=>$_GET['FFphone'],'FFtoken'=>$_GET['FFtoken'],'FFqid'=>$_GET['FFqid']));?>">
    <img class="icon_left" src="img/a/nav_fh.jpg"/>
  </a> -->
    <div class="sz_name"><a href="<?php echo U('Store/intro',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>"><?php echo ($userinfo["Fwatername"]); ?></a></div>
     <!-- <a href="tel:<?php echo ($userinfo["Fphone"]); ?>">
         <img class="icon_right" src="img/a/nav_dh.png"/>
         </a> -->
</div>
<div class="h55"></div>
<div class="divider"></div>
<!--内容-->
<form method="post" action="<?php echo U('Store/phone_chose',array('token'=>$FFtoken));?>" id="formid">
<!-- <div class="title_name">配送地址</div> -->
<div class="phone_place_k">
    
    <div class="font_style1" style="padding:15px 0">
        <input type="text" name="userphone" placeholder="添加联系电话" class="phone_input" id="phone_input"> <a href="javascript:0" class="tel_btn" onclick='phone_input()'>确认添加</a>
        <input type="hidden" name="Fusername" value="<?php echo ($user["Fusername"]); ?>">   
    </div>    
</div>

<div class="slb phone_rec">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
            <th>选择</th>
            <th>联系电话</th>
            <th>编辑</th>
        </tr>
        <tr>
            <td>
                <label class="radio-btn">
                  <input type="radio" name="" value="" checked="checked">
                  <span class="checked"></span>
                </label>
            </td>
            <td><?php echo $_GET['FFphone'] ?></td>
            <!-- <td><a href="" class="tb_btn1">修改</a><a href="" class="tb_btn2">删除</a></td> -->
        </tr>
        <?php if(is_array($phones)): $i = 0; $__LIST__ = $phones;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$ph): $mod = ($i % 2 );++$i;?><tr id="<?php echo ($ph["Fid"]); ?>">
            <td>
                <label class="radio-btn">
                  <input type="radio" name="" value="" checked="">
                  <span class=""></span>
                </label>
            </td>
            <td><?php echo ($ph["Fphone"]); ?></td>
            <td><!-- <a class="tb_btn1">修改</a> --><a href="javascript:0" onclick="phone_del(this)" class="tb_btn2" data-id="<?php echo ($ph["Fid"]); ?>">删除</a></td>
        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
    </table>
</div>
<!-- <div class="title_name">订单总价</div> -->
<div class="divider"></div>
<!-- <div class="phone_place_k3">
  <div class="font_style1"><span> 水站营业时间：8:00 至 18:00</span></div>
  <div class="font_style1">
     <span> 配送时间：&nbsp;</span>
        <span id="get_time" style="margin:0;padding:0">
       <?php echo ($get_time); ?>
       </span>  
    </div>
  
</div> -->
<div class="font_addr">
    <span> 送水地址：</span>
    <span id="Faddr"><?php echo ($address); ?></span>  
</div>
<div class="font_addr">    
    <div class="form-group">
          <label class="control-label">修改地址：</label>
          <select id="city1" name="city1">
          <?php if($address["Fcity1"] == ''): ?><option value="0">省市</option>
          <?php else: ?>
            <option value="<?php echo ($city_name[0]["Fid"]); ?>"><?php echo ($city_name[0]["Fname"]); ?></option><?php endif; ?>
            <?php if(is_array($city1)): $i = 0; $__LIST__ = $city1;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["Fid"]); ?>" <?php if(($vo["Fid"]) == $city1): ?>selected=""<?php endif; ?> ><?php echo ($vo["Fname"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
          </select>
          <select id="city2" name="city2">
            <?php if($address["Fcity2"] == ''): ?><option value="0">城市</option>
          <?php else: ?>
            <option value="<?php echo ($city_name[1]["Fid"]); ?>"><?php echo ($city_name[1]["Fname"]); ?></option><?php endif; ?>
            <?php if(is_array($city2)): $i = 0; $__LIST__ = $city2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["Fid"]); ?>" <?php if(($vo["Fid"]) == $city2): ?>selected=""<?php endif; ?> ><?php echo ($vo["Fname"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
          </select>
          <select id="city3" name="city3" style="width:291px;margin:15px 0 15px 120px;">
            
            <?php if($address["Fcity3"] == ''): ?><option value="0">市辖区</option>
          <?php else: ?>
            <option value="<?php echo ($city_name[2]["Fid"]); ?>"><?php echo ($city_name[2]["Fname"]); ?></option><?php endif; ?>
            <?php if(is_array($city3)): $i = 0; $__LIST__ = $city3;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["Fid"]); ?>" <?php if(($vo["Fid"]) == $city3): ?>selected=""<?php endif; ?> ><?php echo ($vo["Fname"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
          </select>
      </div>      
      <input type="text" name="Faddress" class="phone_input" style="margin:0 0 10px 120px;width:40%" placeholder="详细地址" value="" id="Faddress">
      <a href="javascript:0" class="tel_btn" onclick='address_input()'>保存地址</a>
</div>
</form>
<!--footer-->
<!-- <div class="h100"></div> -->
<div class="pass" id="confirm"><p class="pass_btn">确  认</p></div>

</body>
<script>
//添加电话
function phone_input(){
  var phoneNo=$("#phone_input").val();
  var reg = /^1[0-9]{10}$/;
  if(!phoneNo || !reg.test(phoneNo)){
    alert('请输入正确的手机号码');
    return false;
  }else{
    jQuery.ajax({
      url:"<?php echo U('Store/my_edit');?>",
      type:"get",
      data:{'phoneNo':phoneNo},
      success:function(data){
        var json = eval(data);
        //console.log(json);
        if(json=='true'){
        /*$("#phone_table").append('<tr>'+'<td>'+'<label class="radio-btn">'+'<input type="radio" name="" value="">'+'<span class=""></span>'+'</label>'+'</td>'+'<td>'+phoneNo+'</td>'+'<td>'+'<a class="tb_btn1">修改</a>'+'<a class="tb_btn2">删除</a>'+'</td>'+'</tr>');*/
        window.location.reload();
        }else{
          alert(json);
        }
      },
      error:function(data){
            alert(data);
            }
    })
  }
}
function address_input(){
  var city1=$("#city1").find('option:selected').val();
  var city2=$("#city2").find('option:selected').val();
  var city3=$("#city3").find('option:selected').val();
  var Faddress=$("#Faddress").val();
  var token='<?php echo ($FFtoken); ?>';
  var user='<?php echo ($FFphone); ?>';
  if(Faddress==''){
    alert("请填写详细地址");    
    return false;
  }else{

    jQuery.ajax({
      url:"<?php echo U('Store/phone_chose_addr');?>",
      type:"post",
      data:{'city1':city1,'city2':city2,'city3':city3,'Faddress':Faddress,'token':token,'user':user},
      success:function(response){
      if(response=='success'){
        window.location.reload();
      }else{
        alert("地址更新失败!");
      }
      }
    })
  }
  //alert(city1);
}
//删除
function phone_del(id){
  
  var phoneid=$(id).attr("data-id");
  //console.log(phoneid);
  jQuery.ajax({
      url:"<?php echo U('Store/my_edit');?>",
      type:"get",
      data:{'phoneid':phoneid},
      success:function(data){
        var json = eval(data);
        if(json=='true'){
        $("#"+phoneid).remove();
      }else{
        alert('删除失败');
      }
      },
      error:function(data){
            alert(data);
      }
  })  
}

//选中单选号码
$(document).ready(function(){
  $('input[type="radio"]').click(function(){
    $('input[type="radio"]').each(function(){
      var _this=$(this);
      _this.checked="";
      _this.next().removeClass("checked");
    })
    $(this).checked="checked";
    $(this).next().addClass("checked");    
  })
})
//选手机号后确认
$('#confirm').click(function(){
  var phone=$('.checked').closest('td').next('td').html();
  $.session.set('phone',phone);
  var product=$.session.get('product');
  var productnum=$.session.get('productnum');
  //alert($.session.get('productnum'));
  window.location.href="<?php echo U('Store/orderinfo',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>&product="+product+"&productnum="+productnum+"&FFqid="+"<?php echo ($_GET['FFqid']); ?>";
})
//城市选择
  $('#city1').change(function(){
        jQuery.ajax({
            url:"<?php echo U('Store/get_city2');?>",
            type:"get",
            data:{"city1":$("#city1").val()},
            success:function(data){
              var json = eval(data);
              var a = ''; 
              $("#city2").empty();
              $('#city2').append('<option value="0">请选择市</option>');
              $.each(json, function (index, item) { 
                $("#city2").append('<option value="'+item.Fid+'">'+item.Fname+'</option>')
              });
              },
            error:function(data){
              alert('获取失败');
            }
        });
    });

    $('#city2').change(function(){
        jQuery.ajax({
            url:"<?php echo U('Store/get_city3');?>",
            type:"get",
            data:{"city2":$("#city2").val()},
            success:function(data){
              var json = eval(data);
              var a = ''; 
              $("#city3").empty();
              $('#city3').append('<option value="0">请选择区</option>');
              $.each(json, function (index, item) { 
                $("#city3").append('<option value="'+item.Fid+'">'+item.Fname+'</option>')
              });
              },
            error:function(data){
              alert('获取失败');
            }
        });
    });
</script>
</html>