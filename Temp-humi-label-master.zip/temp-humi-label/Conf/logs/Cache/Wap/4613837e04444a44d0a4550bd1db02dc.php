<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_home _my.css" />
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<!-- Link Swiper's CSS -->
<link rel="stylesheet" href="cssw3/swiper.min.css">
<script src="js/swiper.min.js"></script>
<link rel="stylesheet" type="text/css" href="cssw3/huodong.css" />
<style>	
* {
	margin:0;
	padding:0;
	list-style:none;
}
/*banner*/
/* .sy_ttwill_banner {
  width: 100%;
  overflow: hidden;
  position:relative;
  max-width:640px; 
  margin:auto;
}
.sy_ttwill_banner .swiper-slide {
  position:relative;
  text-align:center;
}
img.sy_bn_tu {
  width: 100%;
}
h2.gallerytitle {
text-align: center;
font-size: 1em;
height: 42px;
line-height: 42px;
color: #fafafa;
position: absolute;
left: 0;
bottom: 0;
right: 0;
font-weight: normal;
text-shadow: 1px 1px 1px #000;
}
.pagination {
  position: absolute;
  z-index: 20;
  bottom: 10px;
  width: 100px;
  text-align: center;
  right:0%;
}
.swiper-pagination-bullet {
  display: inline-block;
  width: 8px;
  height: 8px;
  border-radius:8px;
  background: #fff;
  margin: 0 2px;
  opacity: 0.8;
  cursor: pointer;
}
.swiper-pagination-bullet-active {
  background: #000;
} */

/**
 * Swiper 3.0.3
 * Most modern mobile touch slider and framework with hardware accelerated transitions
 * 
 * http://www.idangero.us/swiper/
 * 
 * Copyright 2015, Vladimir Kharlampidi
 * The iDangero.us
 * http://www.idangero.us/
 * 
 * Licensed under MIT
 * 
 * Released on: March 1, 2015
 */
/* .swiper-slide, .swiper-wrapper {
  height: 100%;
  position: relative;
  transform-style: preserve-3d;
  width: 100%
}
.swiper-wrapper {
  z-index: 1;
  display: -webkit-box;
  display: -moz-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  -webkit-transition-property: -webkit-transform;
  -moz-transition-property: -moz-transform;
  -o-transition-property: -o-transform;
  -ms-transition-property: -ms-transform;
  transition-property: transform;
  -moz-transform: translate3d(0, 0, 0);
  -o-transform: translate(0, 0);
  -ms-transform: translate3d(0, 0, 0);
  transform: translate3d(0, 0, 0);
  -webkit-box-sizing: content-box;
  -moz-box-sizing: content-box;
  box-sizing: content-box
}
.swiper-slide {
  -webkit-flex-shrink: 0;
  -ms-flex: 0 0 auto;
  flex-shrink: 0
} */
/*banner**END*/
</style>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
	var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
	if (/Android (\d+\.\d+)/.test(ua)){
		var version = parseFloat(RegExp.$1);
		if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
		}else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
	} else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
<body>
<!--header-->

<!--头部标题-->

<div class="header_k">
 <!-- <?php if($_GET['bid'] == 'bid' ): ?><img class="icon_left" src="img/back.png" onclick="window.history.back()" />
 
 <?php else: ?>
 
   <img class="icon_left" src="img/chose_user.png"/><?php endif; ?> 头部左侧头像隐藏-->
   
    <div class="sz_name"> <a href="<?php echo U('Store/intro',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>"><?php echo ($userinfo["Fwatername"]); ?></a> <!-- <span><img class="title_d" src="img/a/nav_btn.png" style=""></span>头部点隐藏 --></div>

    <!-- <?php if($bid == 'orders'): ?><a href="<?php echo U('Nativelife/orderlist',array('token'=>$FFtoken));?>">
        <img class="icon_right" src="img/a/nav_fh.png"/>
        </a>
    <?php else: ?>
        <a href="tel:<?php echo ($userinfo["Fphone"]); ?>">
        <img class="icon_right" src="img/dh.png"/>
        </a><?php endif; ?> 头部右侧图标隐藏-->
    <!-- <div style="width:34px;width:100%"><p style="float:left;font-size:28px;">您目前的积分：90</p><img src="img/jifen.gif" style="float:right;"/> </div>积分隐藏-->
    
</div>
<div class="h55"></div>


<!--切换账号-->
<div class="tc_mc"></div>
<div class="tc_chose_k">
    <div class="tip blue_color">您可以切换其他账号登陆！</div>
    <a href="index.php?g=Wap&m=Reg&a=station&token=<?php echo ($FFtoken); ?>"><div class="go_join">切换账号 > ></div></a>
    <img class="date_close" src="img/gb.png"/>
</div>
<script>
//蒙层不可滑动
        $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.tc_mc').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
         $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.tc_chose_k').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
//切换账号
     $(document).ready(function() {
        $(".icon_left").click(function(){
            $(".tc_mc").css("display","block")
            $(".tc_chose_k").css("display","block")
            })
        $(".tc_mc").click(function(){
            $(".tc_mc").css("display","none")
            $(".tc_chose_k").css("display","none")
            })
        $(".date_close").click(function(){
            $(".tc_mc").css("display","none")
            $(".tc_chose_k").css("display","none")
            })
        })
</script>
<!--内容-->
<!--banner-->
    <!-- <div class="sy_ttwill_banner" style="">
      <div class="swiper-wrapper">
         <?php if(is_array($res)): $i = 0; $__LIST__ = $res;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="swiper-slide"><a href="<?php echo ($vo["url"]); ?>"><img class="sy_bn_tu" src="<?php echo ($vo["img"]); ?>" width="640px" height="300px" /></a><h2 class="gallerytitle"></h2></div><?php endforeach; endif; else: echo "" ;endif; ?>
          <?php if(is_array($res2)): $i = 0; $__LIST__ = $res2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="swiper-slide"><a href="<?php echo ($vo["url"]); ?>"><img class="sy_bn_tu" src="<?php echo ($vo["img"]); ?>" width="640px" height="300px"/></a><h2 class="gallerytitle"></h2></div><?php endforeach; endif; else: echo "" ;endif; ?>
      </div>
    <div class="pagination"></div>  
    </div>
    
    <script type="text/javascript">
    window.onload = function() {
      var mySwiper2 = new Swiper('.sy_ttwill_banner',{
          autoplay:3000,
          visibilityFullFit : true,
          loop:true,
          pagination : '.pagination',
      });
     
    }
    </script> 隐藏轮播图 chenyuanyuan 20171225-->
    <!--banner_END-->
    <!-- 个人信息 -->
<div class="my_info">
  <img src="img/a/my_icon.png" width="80px" alt="" />
  <div class="my_num">
    <p><?php echo ($_GET['FFphone']); ?>用户</p><p>欢迎您</p>
  </div>
</div>
<a href="<?php echo U('Store/ticket',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
<div class="my_item">
  <div class="item_list">
    <p class="bdfont"><?php echo ($user["Fwanum"]); ?></p>
    <p>电子水票</p>
  </div></a>
  <a href="<?php echo U('Store/integration',array('q'=>$q,'bid'=>'bid','FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="item_list">
    <p class="bdfont"><?php echo ($user["Fintegration"]); ?></p>
    <p >我的积分</p>
  </div></a>
  <a href="<?php echo U('Store/bottle',array('q'=>$q,'bid'=>'bid','FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="item_list">
    <p class="bdfont"><?php echo ($user["Fmoney"]); ?></p>
    <p>水桶押金</p>
  </div></a>
</div>
<div class="st_anno">
  <div class="announce">
    <img src="img/a/stinfo.png" alt="" width="50px"/><p>水站通知</p>
  </div>
  <?php if($notice != ""): ?><p class="anno_text" style="font-weight:bold"><?php echo ($notice["Ftitle"]); ?></p>
  <p class="anno_text"><?php echo ($notice["Fbody"]); ?></p>
  <?php else: ?>
  <p class="anno_text">暂无新通知！</p><?php endif; ?>
</div>
<div class="divider"></div>
<a href="<?php echo U('Store/my_edit',array('q'=>$q,'bid'=>'bid','FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>"> 
<div class="font_style6"><img src="img/a/personal.png" alt="" />个人信息修改<img style="float:right; margin-right:19px;" src="img/a/rightarr.jpg"/></div>
</a>
<div class="divider"></div>
<a href="#"> 
<div class="font_style6"><img src="img/a/telphone.png" alt="" />联系水站<span style="float:right;margin-right:20px;"><?php echo ($station_phone["phone"]); ?></span><img style="float:right;height:35px;" src="img/a/telcon.png"/></div>
</a>
<div class="divider"></div>
<a href="<?php echo U('Store/notice',array('bid'=>'bid','FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>">  
<div class="font_style6"><img src="img/a/anno.png" alt="" />水站通知<img style="float:right; margin-right:19px;" src="img/a/rightarr.jpg"/></div>
</a>
<!--  <a href="<?php echo U('Store/userinfo',array('bid'=>'bid','FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>">  
<div class="font_style6">水品信息<img style="float:right; margin-right:19px;" src="img/join.png"/></div>
</a>
<a href="<?php echo U('Store/userset',array('q'=>$q,'bid'=>'bid','FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>"> 
<div class="font_style6">修改地址<img style="float:right; margin-right:19px;" src="img/join.png"/></div>
</a>
<a href="<?php echo U('Store/integration',array('q'=>$q,'bid'=>'bid','FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>"> 
<div class="font_style6">我的积分<img style="float:right; margin-right:19px;" src="img/join.png"/></div>
</a>
<a href="#"> 
<div class="font_style6">投诉电话<span style="display:inline-block;float:right;margin-right:30px;font-size:30px;color:#7f7f7f">13916025305</span><img style="float:right; margin-top:3px;" src="tpl/Wap/default/common/img/telicon.png"/></div>
</a> -->
 <?php if($praisestatuson == 1): ?><a href="<?php echo U('Storeactive/praiseslist',array('FFtoken'=>$_GET['FFtoken'],'FFqid'=>$_GET['FFqid'],'FFphone'=>$_GET['FFphone']));?>">
<img src="img/activity/my_list.png" class="my_list"/>
</a><?php endif; ?>


<div class="h100"></div>
<!--footer-->

<div class="footer_k">
<a href="<?php echo U('Store/index',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left">   
      <div>
        <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_sy.jpg" style=""/></div>
        <div class="ft_font" >首页</div>
      </div>   
  </div>
</a>
<a href="<?php echo U('Store/goodslist',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left"> 
    <div>
      <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_sp.jpg" style=""/></div>
      <div class="ft_font">商品列表</div>
    </div>  
  </div>
</a>
<a href="<?php echo U('Store/orders',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left"> 
    <div>
      <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_dd.jpg" style=""/></div>
      <div class="ft_font">我的订单</div>
    </div>  
  </div>
</a>
<a href="<?php echo U('Store/user',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left">
    <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_wd_pre.jpg" style=""/></div>
    <div class="ft_font" style="color:#6283a6">会员中心</div>
  </div>
</a>
</div>
</body>
<script>
//蒙层不可滑动
        $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.mc').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
//水站联系人信息
     $(document).ready(function() {
		$(".sz_name").click(function(){
			$(".mc").css("display","block")
			$(".mc_message").css("display","block")
			})
		$(".mc").click(function(){
			$(".mc").css("display","none")
			$(".mc_message").css("display","none")
			})
		$(".close").click(function(){
			$(".mc").css("display","none")
			$(".mc_message").css("display","none")
			})
		})
</script>
</html>