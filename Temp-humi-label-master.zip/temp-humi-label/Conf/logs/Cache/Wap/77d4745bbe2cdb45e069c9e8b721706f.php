<?php if (!defined('THINK_PATH')) exit();?> <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_home_one.css" />
<link rel="stylesheet" type="text/css" href="cssw3/huodong.css" />
<!-- Link Swiper's CSS -->
<link rel="stylesheet" href="cssw3/swiper.min.css">
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<script type="text/javascript" src="/public/ipublic.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="js/swiper.min.js"></script>

<style type="text/css">
    
      *{
        margin:0;
        padding:0;
      }
      /* #gg {
          background: #222 none repeat scroll 0 0;
          height: 60px;
          line-height: 36px;
          opacity: 0.6;
        margin-top:-60px;
        position:relative;
        z-index:999;
          
          
      }
      #gg a {
          color: #fff;
          letter-spacing: 2px;
      } */
      .close a {
          float: right;
          margin: 0 10px 0 0;
      }
      .bulletin {
          background: rgba(0, 0, 0, 0) url("./img/bulletin.gif") no-repeat scroll 0 7px;
          color: #fff;
          float: left;
          height: 36px;
          margin: 0 0 0 10px;
          min-height: 30px;
          overflow: hidden;
        width:90%;
        margin-top:12px;
        
      }
      .bulletin a {
          float: left;
        font-size:26px;
        line-height:36px;
      }
      .bulletin li {
          height: 36px;
          padding-left: 25px;
        
      }

      a{
        text-decoration:none;
        font-size:25px;
      }
       
      /* .sz_name a{
         font-size:36px;
      } 20171128*/
      /* .sz_name added by chenyuanyuan 20160831 */
      ul li{
        list-style-type:none;
        display:inline-block;
      }
     
      .advertise2{
        background-color: #fff;
        height: 138px;
        border-top: 1px solid #aaa;
        min-height:0;        
      }
      .advertise2 li{
        width: 33.33%;
        height: 100%;
        padding: 10px;
        float: left;
        box-sizing: border-box;
        margin-top: 10px;
      }
      .advertise2 li a{
        display: block;
        width: 100%;
        height: 100%;
        text-align: center;
        padding: 5px;
        border-radius: 5px;
         box-sizing: border-box;
         background: #FFF;
         border:1px solid #aaa;
      }     
      .advertise2 li img{
        width: 80px;
        height: 80px;
        display: block;
        margin: 5px auto;

      }
      .advertise2 li span{
        font-size: 22px;
        color: #000;
      }
      /* .jifen, .jifen p added by chenyuanyuan 20160927 ,.jifen img added by chenyuanyuan 20160929*/
  </style>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
  var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
  if (/Android (\d+\.\d+)/.test(ua)){
    var version = parseFloat(RegExp.$1);
    if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
    }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
  } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>

<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.baidu.com/hm.js?ba88b8e89aed0dab77735e51a3aef67c";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>

<!-- <script src="https://qiyukf.com/script/b194f96bbe3bced956d8f1a70a4f342f.js" defer async></script> 客服隐藏20171129-->

<body>
<div class="mc"></div>
<div class="mc_message">
  <div class="gtitle"><?php echo ($notice["Ftitle"]); ?></div>
  <div class="gcont"><?php echo ($notice["notice"]); ?></div>
  <div class="mc_close">确认</div>
</div>
<!--头部标题-->

<div class="header_k">
 <!-- <?php if($_GET['bid'] == 'bid' ): ?><img class="icon_left" src="img/back.png" onclick="window.history.back()" />
 
 <?php else: ?>
 
   <img class="icon_left" src="img/chose_user.png"/><?php endif; ?> 头部左侧头像隐藏-->
   
    <div class="sz_name"> <a href="<?php echo U('Store/intro',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>"><?php echo ($userinfo["Fwatername"]); ?></a> <!-- <span><img class="title_d" src="img/a/nav_btn.png" style=""></span>头部点隐藏 --></div>

    <!-- <?php if($bid == 'orders'): ?><a href="<?php echo U('Nativelife/orderlist',array('token'=>$FFtoken));?>">
        <img class="icon_right" src="img/a/nav_fh.png"/>
        </a>
    <?php else: ?>
        <a href="tel:<?php echo ($userinfo["Fphone"]); ?>">
        <img class="icon_right" src="img/dh.png"/>
        </a><?php endif; ?> 头部右侧图标隐藏-->
    <!-- <div style="width:34px;width:100%"><p style="float:left;font-size:28px;">您目前的积分：90</p><img src="img/jifen.gif" style="float:right;"/> </div>积分隐藏-->
    
</div>
<div class="h55"></div>


<!--切换账号-->
<div class="tc_mc"></div>
<div class="tc_chose_k">
    <div class="tip blue_color">您可以切换其他账号登陆！</div>
    <a href="index.php?g=Wap&m=Reg&a=station&token=<?php echo ($FFtoken); ?>"><div class="go_join">切换账号 > ></div></a>
    <img class="date_close" src="img/gb.png"/>
</div>
<script>
//蒙层不可滑动
        $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.tc_mc').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
         $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.tc_chose_k').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
//切换账号
     $(document).ready(function() {
        $(".icon_left").click(function(){
            $(".tc_mc").css("display","block")
            $(".tc_chose_k").css("display","block")
            })
        $(".tc_mc").click(function(){
            $(".tc_mc").css("display","none")
            $(".tc_chose_k").css("display","none")
            })
        $(".date_close").click(function(){
            $(".tc_mc").css("display","none")
            $(".tc_chose_k").css("display","none")
            })
        })
</script>

<!--内容-->
<!--活动-->

 
 <!-- <?php if($praisestatuson == 1): ?><div class="activity_mc"></div>
 <?php if($praiselogin == 'true'): ?><div class="activity_k">
  <a href="<?php echo U('Storeactive/info',array('FFphone'=>$_GET['FFphone'],'FFtoken'=>$_GET['FFtoken'],'FFqid'=>$_GET['FFqid']));?>">
  <div class="activity_font"><?php echo ($praisename); ?>抽奖活动，火热进行中...</div>
    <div class="activity_font1">（点击查看活动详情）</div>
    </a>
    <div class="activity">
      <div class="activity_know">知道了</div>
        <a href="<?php echo U('Reg/slogin',array('token'=>$FFtoken,'active'=>'active'));?>"><div class="activity_go">我要参加</div></a>
    </div>
 </div>
 <?php else: ?>
 <div class="activity_k">
  <a href="<?php echo U('Storeactive/info',array('FFphone'=>$_GET['FFphone'],'FFtoken'=>$_GET['FFtoken'],'FFqid'=>$_GET['FFqid']));?>">                         
  <div class="activity_font">您有<?php echo ($lasttimes); ?>次<?php echo ($praisename); ?>抽奖机会...</div>
    <div class="activity_font1">（点击查看活动详情）</div>
    </a>
    <div class="activity">
      <div class="activity_know">知道了</div>
        <a href="<?php echo U('Storeactive/activedo',array('FFphone'=>$_GET['FFphone'],'token'=>$_GET['FFtoken'],'FFqid'=>$_GET['FFqid']));?>"><div class="activity_go">我要抽奖</div></a>
    </div>
 </div><?php endif; endif; ?> 隐藏抽奖 20171221 chenyuanyuan-->
<!-- <div class="jifen" ><p>您目前的积分：<?php echo ($total); ?></p><a href="http://m.cloud315.org/waterapi/login.php?ewm=<?php echo ($_GET['FFqid']); ?>" onclick="_hmt.push(['_trackEvent', 'shop', 'click', 'shop'])" > 
<img src="tpl/Wap/default/common/img/jifen.gif"/></a>
</div> 积分栏隐藏-->
    <!--</div>增加积分和商城入口 Added by Chenyuanyuan 20160927 -->
<!--banner-->
    <div class="sy_ttwill_banner" >
      <div class="swiper-wrapper">

          <?php if(is_array($res2)): $i = 0; $__LIST__ = $res2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="swiper-slide">
            <a href="<?php echo ($vo["url"]); ?>" onclick="_hmt.push(['_trackEvent', '<?php echo ($vo["info"]); ?>', 'click', '<?php echo ($userinfo["Fwatername"]); ?>'])">
              <img class="sy_bn_tu" src="<?php echo ($vo["img"]); ?>" width="640px" height="265px"/>
            </a>
            <h2 class="gallerytitle"></h2>
          </div><?php endforeach; endif; else: echo "" ;endif; ?>
          <!-- <?php if(is_array($res)): $i = 0; $__LIST__ = $res;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="swiper-slide">
            <a href="<?php echo ($vo["url"]); ?>" onclick="_hmt.push(['_trackEvent', '<?php echo ($vo["info"]); ?>', 'click', '<?php echo ($userinfo["Fwatername"]); ?>'])">
              <img class="sy_bn_tu" src="<?php echo ($vo["img"]); ?>" width="640px" height="215px" />
            </a>
            <h2 class="gallerytitle"></h2>
          </div><?php endforeach; endif; else: echo "" ;endif; ?> -->
     
      </div>
    <div class="pagination"></div> 
    </div>
    
    <script type="text/javascript">
    window.onload = function() {
      var mySwiper2 = new Swiper('.sy_ttwill_banner',{
          autoplay:3000,
          visibilityFullFit : true,
          loop:true,
          pagination : '.pagination',
      });
     
    }
    </script>
    <!--banner_END-->
<?php if($order["Fid"] != ''): ?><!-- <div class="title_name1">上次下单:<?php echo (date("Y/m/d H:i:s",$order["Fordertime"])); ?></div> -->
<marquee scrollAmount=2 onmouseover=stop() onmouseout=start() class="list_info">
  <?php if($notice["Ftitle"] != ''): ?><span class="notice"><?php echo ($notice["Ftitle"]); ?></span><?php else: ?>欢迎光临"码上生活"订水系统<?php endif; ?>
  </marquee>
<div class="slb1">
    <div class="list_one1">
       <?php if($logourl != ''): ?><img src="<?php echo ($logourl); ?>" class="picture1"/>
         <?php else: ?>
        <img src="img/no.png" class="picture1"/><?php endif; ?>
        <div class="sp_k1">
            <div class="sp_name1 ovfEps">品名：<?php echo ($goosproname); ?></div>
            <div class="sp_price1">规格：<?php echo ($spec); ?></div>
            <div class="sp_type1"><?php if($price != '0'): ?>价格：<?php echo ($price); ?>元/桶<?php endif; ?></div>
            <div class="sp_type1">上次下单:<?php echo (date("Y/m/d H:i:s",$order["Fordertime"])); ?></div>
            <div class="add_k">
              <input type="button" class="minus"  id="minus<?php echo ($gid); ?>" value="-" ids="<?php echo ($gid); ?>"/>
              <div class="add_num">
                <span id="num<?php echo ($gid); ?>" style="width: 40px; height:58px; font-size:30px;color:#555; text-align:center"><?php echo ($goods["Fnum"]); ?></span>
              </div>              
              
              <input type="button" class="add"  id="add<?php echo ($gid); ?>" value="+" ids="<?php echo ($gid); ?>"/>
              <input type="hidden" name="gid"  id="gid" value="<?php echo ($gid); ?>">
            </div>
        </div>
    </div>
    <a href="javascript:void(0)" id="rebuy">
    <div class="anniu_again">再来一单</div>
    </a>
</div>
<?php else: ?>
<div class="title_name1">上次下单:无记录</div>
<div class="slb1">
    <div style="font-size:24px;line-height:55px;text-align:center;
    margin-top:20px;color:#59c2e1;">这里会显示您上次下单记录<br />赶紧去订水吧~</div>
</div><?php endif; ?>
 <!-- <a href="<?php echo U('Store/goodslist',array('bid'=>'bid','FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="again_list">查看全部水品&nbsp;&nbsp;&nbsp;></div>
  </a> 20171215 chenyuanyuan--> 
<div class="title_name1" style="font-size:24px;font-weight:bold;background:#fff">您的积分：<?php echo ($integration); ?> 
  <span class="jifen-right">每10点积分可以抵扣一元 </span>
</div>

<div class="advertise2">
  <ul>
    <li>
      <a href="https://hqwell.net/index.html?v=654322">
        <img src="tpl/Wap/default/common/img/hq_tab4.jpg">
        <!-- <span>黄雀商城</span> -->
      </a>
    </li>
    <li>
      <a href="https://wechatx.34580.com/home/#/">
        <img src="tpl/Wap/default/common/img/hq_tab5.jpg">
        <!-- <span>食行生鲜</span> -->
      </a>
    </li>
    <li>
      <a href="">
        <img src="tpl/Wap/default/common/img/hq_tab6.jpg">
        <!-- <span>宝燕到家</span> -->
      </a>
    </li>
  </ul>
</div>
<!--滚动结束-->
<div class="h65"></div>

<!--footer-->
<div class="footer_k">
<a href="<?php echo U('Store/index',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left">   
      <div>
        <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_sy_pre.jpg" style=""/></div>
        <div class="ft_font" style="color:#6283a6">首页</div>
      </div>   
  </div>
</a>
<a href="<?php echo U('Store/goodslist',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left"> 
    <div>
      <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_sp.jpg" style=""/></div>
      <div class="ft_font">商品列表</div>
    </div>  
  </div>
</a>
<a href="<?php echo U('Store/orders',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left"> 
    <div>
      <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_dd.jpg" style=""/></div>
      <div class="ft_font">我的订单</div>
    </div>  
  </div>
</a>
<a href="<?php echo U('Store/user',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left">
    <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_wd.jpg" style=""/></div>
    <div class="ft_font">会员中心</div>
  </div>
</a>
</div>

</body>
<script type="text/javascript">
  $(document).ready(function() {        
        $(".notice").click(function(){
            $(".mc").css("display","block");
            $(".mc_message").css("display","block")
        })
        $(".mc").click(function(){
            $(".mc").css("display","none");
            $(".mc_message").css("display","none")
            })
        $(".mc_close").click(function(){
            $(".mc").css("display","none");
            $(".mc_message").css("display","none")
            })    
    })
  //活动
/*$(document).ready(function() {
    $(".activity_know").click(function(){
      $(".activity_k").css("display","none")
      $(".activity_mc").css("display","none")
      })
    $(".activity_mc").click(function(){
      $(".activity_k").css("display","none")
      $(".activity_mc").css("display","none")
      })
})*/
//周边服务

/*$('.ft_left2').click(function(){
     var type=$(this).attr('type');
     var url="<?php echo U('Nativelife/index');?>";
     var token='<?php echo ($FFtoken); ?>';
     var data={'type':type,'token':token};
   
     $.post(
        url,
        data,
        function(res){
          if(res['status']=='0'){
            alert('抱歉，敬请期待');
            return false;
          }else{
            window.location.href="<?php echo U('Nativelife/info',array('token'=>$FFtoken));?>&type="+type;
          }
        },'json'
      )
})*/
$('.minus').click(function(){
  var gid=$(this).attr('ids');
  var numvalue=$('#num'+gid).html();

    if(numvalue!=0 && numvalue !=''){
      $('#num'+gid).html(parseInt(numvalue)-1);      
    }else{
      $('#num'+gid).html(0);
    }
    
});

$('.add').click(function(){
  var gid=$(this).attr('ids');
  var numvalue=$('#num'+gid).html();
  $('#num'+gid).html(parseInt(numvalue)+1);
});
 //再来一单下单
$('#rebuy').click(function(){
    var product=$('#gid').val();
    var productnum=$('#num'+product).html(); 
    if(product=="" || productnum<=0){   
      palert.open('码上订水','请选择水品和数量');     
        return false;
    }
  window.location.href="<?php echo U('Store/orderinfo',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>&product="+product+"&productnum="+productnum+"&FFqid="+"<?php echo ($_GET['FFqid']); ?>";
})

</script>
</html>