<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_home_dd.css" />
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<script type="text/javascript" src="/public/ipublic.js"></script>
<link rel="stylesheet" type="text/css" href="cssw3/huodong.css" />
</head>
<!--手机端自适应js-->
<script type="text/javascript">
    var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
    if (/Android (\d+\.\d+)/.test(ua)){
        var version = parseFloat(RegExp.$1);
        if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
        }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
    } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
<body>
<!--header-->
<div class="header_k">
 <a href="<?php echo U('Store/orders',array('FFphone'=>$FFphone,'FFtoken'=>$_GET['token'],'FFqid'=>$FFqid));?>"> 
  <img class="icon_left" src="img/a/nav_fh.png" >
</a>
    <div class="sz_name"> 
      <?php if($type == 0 ): ?>回收
      <?php elseif($type == 1): ?>
      清洁
      <?php elseif($type == 2): ?>
      干洗
      <?php else: ?>
      常用<?php endif; ?>
      <a href="#" style="color:#FFF"></a> <span><img class="title_d" src="img/a/nav_btn.png" style=""></span></div>
</div>
<!--头部标题-->
<div style="height:100px"></div>
<!--内容-->
<div class="h100" style="height:98px;"></div>
<div class="dd_chose_k">
    <div class="dd_chose_left">未完成</div>
    <div class="dd_chose_right">已完成</div>
</div>
<!--未完成-->
<div class="dd_wwc">
  <div id="conten1">
<?php if(is_array($orderlist)): $i = 0; $__LIST__ = $orderlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><div class="dd_list">

        <img src="img/no.png" class="picture"/>

        <div class="sp_k">
            <div class="sp_name ovfEps"><?php echo ($servername); ?></div>
            <div class="sp_price"><?php echo (date("Y/m/d",$item["createtime"])); ?></div>
           
        </div>
        <a href="<?php echo U('Nativelife/orders_hander',array('type'=>$type,'token'=>$_GET['token'],'id'=>$item['id']));?>">
        
         <div class="dd_zt">操作</div>
       
        </a>
    </div><?php endforeach; endif; else: echo "" ;endif; ?>
  </div>
  <div class="dd_list" style="height:150px;text-align:center;font-size:20px;line-height:20px;padding:30px 0 10px;background:#F5F7FA;" id="loadmore" page="2">加载更多...</div>
</div>

<!--yi完成-->
<div class="dd_ywc">
 <div id="conten2">
    <?php if(is_array($orderlist2)): $i = 0; $__LIST__ = $orderlist2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><div class="dd_list">
    
          <img src="img/no.png" class="picture"  />
  
        <div class="sp_k">
            <div class="sp_name ovfEps"><?php echo ($item["servername"]); ?></div>
            <div class="sp_price"><?php echo (date("Y/m/d",$item["createtime"])); ?></div>
            
        </div>
         <a href="<?php echo U('Nativelife/orders_hander',array('type'=>$type,'token'=>$_GET['token'],'id'=>$item['id']));?>">
        <div class="dd_zt">详情</div>
        </a>
    </div><?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
 <div class="dd_list" style="height:150px;text-align:center;font-size:20px;line-height:20px;padding:30px 0 10px;background:#F5F7FA;" id="loadmore2" pagey="2">加载更多...</div>
</div>
<!--footer-->
</body>
<script>

//订单状态切换
    $(document).ready(function() {

         <?php if($_GET['status']=='1'){ ?>

               $(".dd_chose_right").css('border-bottom',"2px solid #59c2e1")
             $(".dd_chose_right").css("color","#59c2e1")
            $(".dd_chose_left").css('border-bottom',"0px solid #59c2e1")
            $(".dd_chose_left").css("color","#434a54")
            $(".dd_wwc").css("display","none")
            $(".dd_ywc").css("display","block")
        <?php } ?>
     


        $(".dd_chose_left").click(function(){
            <?php $_GET['status']=='0' ?>
            window.location.href = '<?php echo U('', $_GET);?>&status=0';
            $(".dd_chose_left").css('border-bottom',"2px solid #59c2e1")
            $(this).css("color","#59c2e1")
            $(".dd_chose_right").css('border-bottom',"0px solid #59c2e1")
            $(".dd_chose_right").css("color","#434a54")
            //$(".dd_ywc").css("display","none")
            //$(".dd_wwc").css("display","block")
            })
        })
    $(document).ready(function() {
        $(".dd_chose_right").click(function(){

            window.location.href = '<?php echo U('', $_GET);?>&status=1';
            // $(".dd_chose_right").css('border-bottom',"2px solid #59c2e1")
            $(this).css("color","#59c2e1")
            // $(".dd_chose_left").css('border-bottom',"0px solid #59c2e1")
            // $(".dd_chose_left").css("color","#434a54")
            // $(".dd_wwc").css("display","none")
            // $(".dd_ywc").css("display","block")
            })
        })

//活动
    $(".activity_mc").click(function(){
      $(".activity_k").css("display","none")
      $(".activity_mc").css("display","none")
      })
</script>

<script type="text/javascript">
    
/*---------------------加载更多--------------------*/
  $(document).ready(function(){
      //更换文章 加载更多
      var totals=parseInt('<?php echo ($cont); ?>');
      var totals1=parseInt('<?php echo ($cont1); ?>');
      var pagesize=10;
      if(totals<=10){
        $('#loadmore').html('没有更多了');
      }
       if(totals1<=10){
        $('#loadmore2').html('没有更多了');
      }
      //未完成
      $('#loadmore').click(function(){
   
          var total=parseInt('<?php echo ($cont); ?>');
          var pagesize=10;
          var pages = Math.ceil(total / pagesize);
          if (pages > 1) {
          var _page = $('#loadmore').attr('page');
          if (_page > pages) {
            $('#loadmore').html('没有更多了');
            return false;
          }


         }

          var offset=pagesize;
          if(total<=pagesize || (_page*pagesize)>total){
             //第一页或者最后一页
              offset=total;
          }else{
            offset=_page*pagesize;
          }

          var com_link = "<?php echo U('Nativelife/ordersload',array('status'=>$_GET['status'],'token'=>$_GET['token'],'type'=>$_GET['type'],'phone'=>$FFphone));?>";

          $.get(com_link,{'offset':offset},function(result){
                
             
           if(result.length){
                $('#loadmore').attr('page',parseInt(_page)+1);
                
                 _page = $('#loadmore').attr('page');
                 $('#conten1').html(result);
            
              }
         
          }) 
          })  

        //已完成
          $('#loadmore2').click(function(){
        
          var total=parseInt('<?php echo ($cont1); ?>')
          var pagesize=10;

          var pages = Math.ceil(total / pagesize);

          if (pages > 1) {
          var _page2 = $('#loadmore2').attr('pagey');
         

          if (_page2 > pages) {
            $('#loadmore2').html('没有更多了');
            return false;
          }


         }

          var offset=pagesize;
          if(total<=pagesize || (_page2*pagesize)>total){
             //第一页或者最后一页
              offset=total;
          }else{
            offset=_page2*pagesize;
          }
         
         var com_link2 = "<?php echo U('Nativelife/ordersload',array('status'=>$_GET['status'],'token'=>$_GET['token'],'type'=>$_GET['type'],'phone'=>$FFphone));?>";
  
          $.get(com_link2,{offset:offset},function(result){
                
             
           if(result.length){
                $('#loadmore2').attr('pagey',parseInt(_page2)+1);
                
                 _page2 = $('#loadmore2').attr('pagey');

                 $('#conten2').html(result);

            
              }
         
          }) 
          })  

  })
  


</script>
</html>