<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_home_one.css" />
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<script type="text/javascript" src="/public/ipublic.js"></script>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
	var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
	if (/Android (\d+\.\d+)/.test(ua)){
		var version = parseFloat(RegExp.$1);
		if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
		}else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
	} else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
<body>
<!--头部标题-->
<div class="header_k">

	<img class="icon_left" src="img/a/nav_fh.jpg" onclick="window.history.back()"/>
    <div class="sz_name">
    <a href="<?php echo U('Store/intro',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>"><?php echo ($userinfo["Fwatername"]); ?></a>
    </div>
</div>
<div class="h55"></div>
<div class="divider"></div>
<!--内容-->
<!-- <div class="dd_num">订单号：<?php echo ($order["Forderid"]); ?></div>
<div class="title_name">配送地址</div> -->
<div class="phone_place_k">
    <div class="font_style1">购水手机:&nbsp;&nbsp;
    <?php if($order["Fphone"] != '' AND 'undefined'): ?><span class="font5b"><?php echo ($order["Fphone"]); ?></span>
    <?php else: ?>
        <span class="font5b"><?php echo ($order["Fusers"]); ?></span><?php endif; ?>
    </div>
    <div class="font_style1">
        <span class="fl_l">送水地址:&nbsp;&nbsp;</span>
        <div class="font5b fl_l" style="width:60%;"><?php echo ($order["Faddress"]); ?></div>
    </div>
</div>
<div class="slb">
    <div class="list_one">
        <?php if($ordergoods["logourl"] != ''): ?><img src="<?php echo ($ordergoods["logourl"]); ?>" class="picture"/>
        <?php else: ?>
        <img src="img/no.png" class="picture"/><?php endif; ?>        
        <div class="sp_k">
            <div class="sp_name ovfEps">品名：<?php echo ($ordergoods["Fgoodsname"]); ?></div>            
            <div class="sp_price">规格：<?php echo ($ordergoods["Fspec"]); ?></div>
            <div class="sp_exp"><?php echo ($ordergoods["shortname"]); ?></div>
        </div>
        <div class="shuliang">
          <p ><?php if($ordergoods["Frice"] != '0'): ?>¥<?php echo ($ordergoods["Fprice"]); else: ?>单价未知<?php endif; ?></p>
          <p>×<?php echo ($ordergoods["Fnum"]); ?></p>
          <!-- <p>+<?php echo ($ordergoods["total"]); ?>积分</p> -->
        </div>         
    </div>
</div>

<div class="divider"></div>
<div class="phone_place_k3">
    <div class="font_style1">
        <span>配送时间:&nbsp;
            <span class="font5b"><?php echo ($order["Fhours"]); ?></span>
        </span> 
               
    </div>
    <div style="padding:0 10px 10px 100px">
        <?php switch($order["Fstatus"]): case "1": ?><p class="sp_exp">我们将在约定时间内为您派送，请保持手机畅通！</p><?php break;?>
            <?php case "2": ?><p class="sp_exp">您的订单已送出，请保持手机畅通！</p><?php break;?>
            <?php case "3": ?><p class="sp_exp">您的订单已派送完成，感谢您的订购，欢迎再次订购！</p><?php break;?>
            <?php default: ?>订单已取消，欢迎再次下单！<?php endswitch;?>
    </div>
</div>

<!-- <div class="title_name">下单时间</div>
<div class="phone_place_k2" style="border-bottom:1px solid #e0e0e0;">
    <div class="font_style1" style="position:relative;">
        <span style="float:left;">下单时间:&nbsp;<span class="font5b"><?php echo (date("Y/m/d H:i:s",$order["Fordertime"])); ?></span></span>         
    </div>
</div> -->
    <div class="phone_place_k4">
        <div class="font_style1">
        <span> 支付方式：&nbsp;</span>
        <span style="color: #ff0000;margin-right: 30px;float:right;">
            <?php switch($order["Fpaytype"]): case "0": ?>电子水票支付<?php break;?>
                <?php case "1": ?>线下支付<?php break;?>
                <?php case "2": ?>微信支付<?php break;?>
                <?php default: ?>未选择支付方式<?php endswitch;?>
        <?php if($order["Ftype"] == 0): ?>未支付<?php else: ?>已支付<?php endif; ?></span>   
        </div>
    </div>
<div class="divider"></div>
<div class="phone_place_k4">
    <div class="font_style1" style="margin-top:10px">
        <span class="fl_l">订单总额：</span>
         <span class="right_font r_color">&nbsp;&nbsp;<?php if($ordergoods["Ftotal"] != '0'): ?>￥<?php echo ($ordergoods["Ftotal"]); endif; ?></span>
    </div>
    <?php if($order['Fdiscount'] > '0'): ?><div class="font_style1" style="margin-top:10px">
        <span class="fl_l">优惠总额：</span>
         <span class="right_font r_color">&nbsp;&nbsp;￥<?php echo ($order["Fdiscount"]); ?></span>
    </div>
    <div class="font_style1">
        <span class="fl_l">实付金额：</span>
         <span class="right_font r_color">&nbsp;&nbsp;<?php if($order["Fpaytotal"] > '0'): ?>￥<?php echo ($order["Fpaytotal"]); else: ?>￥0<?php endif; ?></span>
    </div>
    <?php else: ?>
    <div class="font_style1">
        <span class="fl_l">实付金额：</span>
         <span class="right_font r_color">&nbsp;&nbsp;<?php if($ordergoods["Ftotal"] != '0'): ?>￥<?php echo ($ordergoods["Ftotal"]); endif; ?></span>
    </div><?php endif; ?>
    <!-- <?php if($discount_reason['Fdiscount_reason'] != ''): ?><div class="font_style1" style="margin-top:10px">
        <span class="fl_l">优惠原因：</span>
         <span class="right_font r_color">&nbsp;&nbsp;<?php echo ($discount_reason["Fdiscount_reason"]); ?></span>
    </div><?php endif; ?> -->
    <!-- <div class="font_style1" style="margin-bottom:10px">
        <span class="fl_l">获得积分：</span>
         <span class="right_font r_color">&nbsp;&nbsp;<?php if($goodsorder["Ftotal"] != '0'): echo ($ordergoods["total"]); endif; ?></span>
    </div> -->
    <div class="divider"></div>
    <div class="font_style1" style="margin:10px 15px;">
        <p style="float:left;">留言：</p>        
        <textarea style="width:75%;height:100px;" maxlength="50" name="liuyan"><?php echo ($order["Fliuyan"]); ?></textarea>        
    </div>
</div>
<div class="pass" id="confirmord" onclick="window.history.back()"><p class="pass_btn">确认订单</p></div>
<!-- <div class="phone_place_k4"  style="border-bottom:1px solid #e0e0e0;">
    <div class="font_style1">
        <span class="fl_l">订单总额:</span>
         <span class="right_font r_color">&nbsp;&nbsp;<?php if($ordergoods["Ftotal"] != '0'): ?>￥<?php echo ($ordergoods["Ftotal"]); endif; ?></span>
    </div>
    <div class="font_style1">
        <span class="fl_l">实付金额:</span>
         <span class="right_font r_color">&nbsp;&nbsp;<?php if($ordergoods["Ftotal"] != '0'): ?>￥<?php echo ($ordergoods["Ftotal"]); endif; ?></span>
    </div>
    <div style="width:100%;overflow:hidden;margin-top:26px;">
        <div class="line"></div>
    </div>
    <div class="font_style1">
        <span class="fl_l">订单状态:</span>
         <?php if($order["Fstatus"] == '1' ): ?><span class="right_font hui_color">&nbsp;&nbsp;未派送&nbsp;&nbsp;</span><?php elseif($order["Fstatus"] == '2'): ?><span class="right_font r_color">已派送</span><?php elseif($order["Fstatus"] == '3'): ?><span class="right_font blue_color">&nbsp;&nbsp;已完成<?php endif; ?>
    </div>
</div> -->
<!-- <?php if($order["Fstatus"] == '1' ): ?><div class="cuidan">
    <div class="cui_l" id="cd"><img src="img/a/icon_dh.png" class="cui_tu" />我要催单</div>
    <div class="cui_r" id="cans">取消订单</div>
</div><?php endif; ?>
<?php if($order["Fstatus"] == '2' ): ?><div class="cuidan">
    <a href="tel:<?php echo ($worker["Fphone"]); ?>">
    <div class="cui_l_2"><img src="img/a/phone.png" class="cui_tu" style="margin-top:20px;"/>&nbsp;&nbsp;呼叫送水工</div>
    </a>
</div><?php endif; ?> -->


</body>
<script type="text/javascript">

    $('#cans').click(function(){
    

    pconfirm.open('码上订水','取消下单',function(){
       window.location = "<?php echo U('Store/cancel',array('Fid'=>$order['Fid'],'Fusers'=>$Fusers,'q'=>$q,'token'=>$token));?>";
    })
   
    })

  $('#cd').click(function(){

        pconfirm.open('码上订水','催单',function(){
             var Fid=<?php echo ($_GET['Fid']); ?>;
               var token="<?php echo ($_GET['FFtoken']); ?>";
               
             $.post('index.php?g=Wap&m=Store&a=cd',{Fid:Fid,token:token},function(result){
                
                if(result==1){
                
                  //window.location.href = 'tel:<?php echo ($userinfo["Fphone"]); ?>'; 
                  alert('催单成功');
                }

                if(result==2){
                    alert('您已经催单请一分钟后');
                }

                if(result==3){
                    alert('此订单已发货');
                }
            });

        })
    })
</script>
</html>