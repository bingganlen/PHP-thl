<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>注册</title>
<link rel="stylesheet" type="text/css" href="css/wcss/home_phone.css" />
<link rel="stylesheet" type="text/css" href="css/wcss/join.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
	var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
	if (/Android (\d+\.\d+)/.test(ua)){
		var version = parseFloat(RegExp.$1);
		if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
		}else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
	} else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>


<body style="background:#297dd4;">
	<img class="big_tu" src="img/login.png"/>

<!--     <div class="phone_k" style="border:none; margin-top:24px;">
       <a href="<?php echo U('Reg/login',array('token'=>$token));?>"> 
          <input type="submit" class="login" style="background:none;color:#d12b04 ;border-radius:5px;border:1px solid #d12b04 ;font-size:3rem;" value="已注册去登录"/>
        </a>
    </div> -->
     <a href="<?php echo U('Reg/slogin',array('token'=>$token));?>">
        <div  style="background:#ddeff4;color:#d12b04 ;border-radius:5px;font-size:3rem; text-align: center; width: 76%;height: 80px; left: 12%; bottom:-40px;position:relative;line-height:80px">
            已注册去登录
        </div>
    </a>

    <a href="<?php echo U('Reg/station',array('token'=>$token));?>">
        <div class="join_k">
        	立即注册
        </div>
    </a>
    <a href="<?php echo U('Store/templatecs',array('token'=>$token,'orderid'=>'H42797742'));?>">
        <div class="join_k">
          测试模板消息
        </div>
    </a>
</body>
</html>