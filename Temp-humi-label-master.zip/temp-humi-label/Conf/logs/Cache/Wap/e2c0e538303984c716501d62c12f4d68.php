<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_home_message.css" />
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
	var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
	if (/Android (\d+\.\d+)/.test(ua)){
		var version = parseFloat(RegExp.$1);
		if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
		}else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
	} else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
<body>
<!--header-->


<!--头部标题-->


<div class="header_k">
	<img class="icon_left" src="img/a/nav_fh.png" onclick="window.history.back()"/>
    <div class="sz_name">水品信息</div>
    
</div>
<div class="h88"></div>
<!--内容-->
<div class="message_tu_k">
	<img src="img/a/message_tu.png"/>
</div>
<div class="font_style1"><?php echo ($_GET['FFphone']); ?></div>

<div class="font_style"><span>水票剩余信息</span></div>
<?php if(is_array($ticket)): $i = 0; $__LIST__ = $ticket;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><div class="font_style2"><?php echo ($item["gname"]); ?><span class="font5b" style="float:right; margin-right:19px;">【&nbsp;剩余<span style="color:#ff5f3e;"><?php echo ($item["Fnum"]); ?>张</span>&nbsp;】</span></div><?php endforeach; endif; else: echo "" ;endif; ?>

<div class="font_style" style="margin-top:20px;"><span>订水信息统计</span></div>

<div class="font_style2">总订桶数:&nbsp;&nbsp;<span class="font5b"><?php echo ($count2); ?>桶</span></div>

<div class="font_style2">欠空桶数:&nbsp;&nbsp;<span class="font5b"><?php if($owtcount == ''): ?>0
<?php else: ?>
<?php echo ($owtcount); endif; ?>个</span></div>

<div class="font_style2">欠款金额:&nbsp;&nbsp;<span class="font5b"><?php echo (($owcount)?($owcount):'0'); ?>元</span></div>
<div class="h100"></div>

</body>
<script>
//底部按钮切换
	$(document).ready(function() {
		$(".ft_left").click(function(){
			$(".ft_left").css("background","#39436c")
			$(this).css("background","#0b0e1c")
			})
		})
//蒙层不可滑动
        $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.mc').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
</script>
</html>