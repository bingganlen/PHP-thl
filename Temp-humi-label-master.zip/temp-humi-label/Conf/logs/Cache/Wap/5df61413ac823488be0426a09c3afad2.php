<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上注册</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_zc.css" />
<script type="text/javascript" src="<?php echo RES;?>/js/jquery.min.js"></script>
<script type="text/javascript" src="/public/ipublic.js"></script>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
  var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
  if (/Android (\d+\.\d+)/.test(ua)){
    var version = parseFloat(RegExp.$1);
    if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
    }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
  } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>


<body>
  <!-- <div class="name">码上订水</div> -->
  <div class="header"><?php echo ($wxuser["wxname"]); ?></div>
  <div class="login_form">
  <img src="img/a/wa_login.png" alt="" class="wa_login" />
  <form onsubmit="return onpost()" action="<?php echo U('Reg/login_schk',array('active'=>'active'));?>" method="post" >
      <input type="hidden" name="token" value="<?php echo ($token); ?>">
    <div class="phone_k1">
        <!-- <img class="icon" src="img/a/login_icon_sjh.png" alt="手机号"/> -->
        <label class="ph_label">手机号码：</label>
        <input class="phone_input" type="text" style="width:68%" placeholder="手机号" name="name"  id="name"/>
    </div>
    <div class="phone_k1">
        <!-- <img class="icon" src="img/a/login_icon_mm.png" alt="密码"/> -->
        <label class="ph_label">登录密码：</label>
        <span class="test">
            <input class="phone_input" type="password" style="width:68%" placeholder="密码" name="passwd" id="passwd"/>
        </span>
        <img class="icon_e" src="img/eye.png" alt="密码"/>
    </div>
    <input type="hidden" name="product" value="<?php echo ($product); ?>" />
    <input type="hidden" name="productnum" value="<?php echo ($productnum); ?>" />
    <input type="submit" class="login" value="登&nbsp;录" style="margin-top:40px"/>
   <a href="<?php echo U('Reg/station',array('token'=>$token,'product'=>$product,'productnum'=>$productnum));?>">
    <div class="login1">立即注册</div>
    </a>
    <a href="<?php echo U('Reg/lookcode',array('token'=>$token));?>">
    <div class="tgy_come">忘记密码</div>
    </a>
</form>
</div>
</body>
<script type="text/javascript">
$('.icon_e').click(function(){
  vale=$('.test').find('input').val(); //将test里的值存起来
  
  if($('.test').find('input').attr('type')=='text'){//如果text里的input的type为text
    $('.test').html("<input type='password' class='phone_input' name='passwd' style='width:68%' id='passwd' value='"+vale+"'>")//输出的input
  }else{
    $('.test').html("<input type='text' class='phone_input' id='passwd' style='width:68%' name='passwd' value='"+vale+"'>")//否则输出的input
  }
})

function onpost(){
  name=document.getElementById('name').value;
  passwd=document.getElementById('passwd').value;

  var reg=/^0{0,1}(13[0-9]|14[0-9]|16[0-9]|17[0-9]|15[0-9]|18[0-9])[0-9]{8}$/i;
  if(name=='' || !reg.test(name)){
    palert.open('码上订水','请输入正确的手机号！');
    return false;
  }
  
  if(passwd==''){
        palert.open('码上订水','密码不能为空');
        return false;
    }
  return true;
}
</script>
</html>