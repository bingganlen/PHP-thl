<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_home_dd.css" />
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<script type="text/javascript" src="/public/ipublic.js"></script>
<link rel="stylesheet" type="text/css" href="cssw3/huodong.css" />
</head>
<!--手机端自适应js-->
<script type="text/javascript">
    var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
    if (/Android (\d+\.\d+)/.test(ua)){
        var version = parseFloat(RegExp.$1);
        if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
        }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
    } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
<body>
<!--header-->
<!--newpage add by Chenyuanyuan,20160826-->
<div class="header_k">
    <!-- <img class="icon_left" src="img/back.png" onclick="window.history.back()" /> -->
   
    <div class="sz_name"> 
        <a href="<?php echo U('Store/goodslist',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>" ><?php echo ($userinfo["Fwatername"]); ?></a>
        <!-- <span><img class="title_d" src="img/a/nav_btn.png" style=""></span> -->
    </div>    
  
    <!-- <a href="tel:<?php echo ($userinfo["Fphone"]); ?>">
    <img class="icon_right" src="img/dh.png"/>
    </a> -->
</div>
<div class="orderover_content"><img src="img/a/orderover.png" alt="下单成功" width="20%" style="margin:15px 0"/>
<p style="color:#eb6100">下单成功！</p><p>请耐心等待配送员送水</p></div>
<div class="orderover_button">
    <a href="<?php echo U('Store/goodslist',array('bid'=>'bid','FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
        <div class="orderover_buttonleft">继续下单</div>
    </a>
    <a href="<?php echo U('Store/index',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
        <div class="orderover_buttonright">返回首页</div>
    </a>
</div>
<?php if(is_array($ads)): $i = 0; $__LIST__ = $ads;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="orderover_img"><a href="<?php echo ($vo["link"]); ?>"><img src="<?php echo ($vo["logourl"]); ?>"/></a></div><?php endforeach; endif; else: echo "" ;endif; ?>
<!-- <div class="orderover_img"><img src="/public/imgs/orderconfirm01.jpg"/></div>
<div class="orderover_img"><img src="/public/imgs/orderconfirm02.jpg"/></div>
<div class="orderover_img"><img src="/public/imgs/orderconfirm03.jpg"/></div> -->
</body>