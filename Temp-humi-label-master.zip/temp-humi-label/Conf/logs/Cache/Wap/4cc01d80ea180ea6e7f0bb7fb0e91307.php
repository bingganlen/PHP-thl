<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<script charset="utf-8" src="http://map.qq.com/api/js?v=2.exp"></script>
<style>
	.header_k {
    width: 100%;
    height: 80px;
    background: #fff;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 999;
    overflow: hidden;}
    .sz_name {
    width: 100%;
    height:80px;
    font-size: 25px;    
    text-align: center;
    color: #333;
    background: #fff;
    padding:10px 0;}

.divider {
    width: 100%;
    height: 15px;
    background: #f5f5f5;
}
.total {
    width: 100%;    
    text-align: center;
    font-size: 24px;
    background: #fff;
    padding: 22px 0;
}
.wa_st{
	background: #fff;
    padding: 20px 50px;
    box-sizing: border-box;
    position: relative;
}
.wa_name{
    font-size: 28px;
    line-height: 50px;
    font-weight: bold;
}
.wa_addr{
	font-size: 24px;
    line-height: 50px;
}
.arr{
   position: absolute;
   top:20px;
   right:45px;
}
.arr img{
	padding:20px;
}
</style>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
	var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
	if (/Android (\d+\.\d+)/.test(ua)){
		var version = parseFloat(RegExp.$1);
		if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
		}else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
	} else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
<body>
<div class="header_k">
	<div class="sz_name"><img src="img/a/title.png" alt="" /></div>
</div>
<div class="h100"></div>
<!--内容-->
<!-- <div class="divider"></div> -->
<div class="total">
    <p>当前位置：<span id="address"></span></p>
	<p>为您推荐附近水站：</p>
</div>
<div class="divider"></div>
<div id="lists">
<!-- <?php if(is_array($lists)): $i = 0; $__LIST__ = $lists;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="wa_st">
    <div class="wa_name"><?php echo ($vo["wxname"]); ?></div>    
    <div class="wa_addr"><?php echo ($vo["waddress"]); ?></div>
    <a href="<?php echo U('Store/goodslist',array('FFtoken'=>$vo['token']));?>" class="arr"><img src="img/a/rightarr.jpg" alt="" /></a>  
  </div>
  <div class="divider"></div><?php endforeach; endif; else: echo "" ;endif; ?> -->
</div>
<div style="height:40px;"></div>
</body>
<script type="text/javascript">
//配置信息验证接口
wx.config({
   debug: false,
   appId: '<?php echo $signPackage["appId"];?>',
   timestamp: '<?php echo $signPackage["timestamp"];?>',
   nonceStr: '<?php echo $signPackage["nonceStr"];?>',
   signature: '<?php echo $signPackage["signature"];?>',
   jsApiList: [
       // 所有要调用的 API 都要加到这个列表中
       'checkJsApi',
       'openLocation',
       'getLocation'
     ]
           });
//验证之后进入该函数，所有需要加载页面时调用的接口都必须写在该里面
wx.ready(function () {
//基础接口判断当前客户端版本是否支持指定JS接口
wx.checkJsApi({
   jsApiList: [
       'getLocation'
   ],
   success: function (res) {
       // alert(JSON.stringify(res));
       // alert(JSON.stringify(res.checkResult.getLocation));
       if (res.checkResult.getLocation == false) {
           alert('你的微信版本太低，不支持微信JS接口，请升级到最新的微信版本！');
           return;
       }
   }
});
    //微信获取地理位置并拉取用户列表（用户允许获取用户的经纬度）
wx.getLocation({
   success: function (res) {
       var latitude = res.latitude; // 纬度，浮点数，范围为90 ~ -90
       var longitude = res.longitude; // 经度，浮点数，范围为180 ~ -180。
       //alert(latitude+"-----"+longitude);
       var geocoder = new qq.maps.Geocoder({
        complete: function(result){
          var address=result.detail.address;
        $("#address").html(address);}
       });
       geocoder.getAddress(new qq.maps.LatLng(latitude,longitude));
        //去数据库查询获取附近的水站        
        $.ajax({
        type: 'GET',
        url: "<?php echo U('Store/wastation');?>",
        dataType: 'json',
        data: {"latitude": latitude,"longitude":longitude},
        success:function(shopInfo){  
            if(shopInfo){
              var json = eval(shopInfo);
              var a = '';               
              $.each(json, function (index, item) { 
                
               // $("#city3").append('<option value="'+item.Fid+'">'+item.Fname+'</option>')
                $("#lists").append('<div class="wa_st"><div class="wa_name">'+item.wxname+'</div><div class="wa_addr">'+item.waddress+'</div><a href="<?php echo U('Store/goodslist');?>&FFtoken='+item.token+'" class="arr"><img src="img/a/rightarr.jpg" alt="" /></a> </div><div class="divider"></div>')
              });
            }else{
               $("#lists").append('<p style="text-align:center;margin-top:80px">您附近暂无推荐水站，<br/>请联系客服13818217471</p>')
            }              
        }
        });
        //index是下表，el是值         
             /*'<div class="item-store"> 
                  <a class="s-top ui-width-100 ui-flex" href="__CONTROLLER__/shopDetail/shop_id/'+el.shop_id+'"> 
                    <img src="'+el.shop_logo.substring(1)+'" class="s-img"/> 
                    <div class="s-message"> 
                      <h4>'+el.shop_name+'</h4> 
                      <div class="s-address">'+el.shop_position+'</div>
                    </div> 
                  </a> 
                  <div class="s-bottom-block ui-width-100"> 
                    <ul> 
                      <li> 
                        <a href="__CONTROLLER__/daohang/shop_id/'+el.shop_id+'" class="db-block"> <i class="icon iconfont">&#xe66c;</i> 一键导航 <span class="kilemiter"> '+el.distance/1000+'km </span> 
                        </a> 
                      </li> 
                    </ul> 
                  </div> 
                </div>');*/
               // })                        
   
          // error:function(res){
          //     alert(res);
          // }
        
   },
   cancel: function(res){
    //$(".city").triggerHandler("focus");
    $("#address").html("定位被取消");
   },
   fail: function(res){$("#address").html("定位失败");}
 });
});
</script>
</html>