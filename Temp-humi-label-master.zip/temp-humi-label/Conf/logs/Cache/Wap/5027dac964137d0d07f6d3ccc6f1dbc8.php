<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上定水</title>
<link rel="stylesheet" type="text/css" href="css/wcss/home_phone.css" />
<link rel="stylesheet" type="text/css" href="css/wcss/user_dz.css" />
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
	var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
	if (/Android (\d+\.\d+)/.test(ua)){
		var version = parseFloat(RegExp.$1);
		if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
		}else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
	} else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>


<body>
	<div class="name">水站管理员登录</div>
    <form method="post" action="<?php echo U('Water_manage/userlogindo');?>">
    <div class="phone_k">
    	<img class="icon" src="img/a.png" alt="用户名"/>
        <input class="phone_sr" type="text" placeholder="用户名" name="username"/>
    </div>
    <div class="phone_k">
    	<img class="icon" src="img/b.png" alt="密码"/>
        <input class="phone_sr" type="password" placeholder="密码" name="password" />
    </div>
    <div class="phone_k" style="border:none; margin-top:24px;">
    
    	<input type="submit" class="login" value="登&nbsp;录"/>
    
    </div>
    </form>
</body>
</html>