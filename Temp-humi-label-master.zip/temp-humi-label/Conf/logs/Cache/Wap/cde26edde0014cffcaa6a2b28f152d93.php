<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_zc.css" />
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<script type="text/javascript" src="/public/ipublic.js"></script>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
    var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
    if (/Android (\d+\.\d+)/.test(ua)){
        var version = parseFloat(RegExp.$1);
        if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
        }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
    } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>


<body>
    <!-- <div class="ps">对不起，您的用户名已被注册</div> -->
<form  action="<?php echo U('Reg/register');?>" method="post" id="formid">
    <input type="hidden" name="Fewm_id" value="<?php echo ($Fewm_id); ?>">
    <input type="hidden" name="token" value="<?php echo ($token); ?>">
    <div class="phone_k" style="margin-top:20px;">
        <img class="icon" src="img/a/login_icon_sjh.png" alt="电话"/>
        <input class="phone_sr" type="text" placeholder="电话" name="name" value="" id="name"/>
        <input type="hidden" name="jf" id="jf" value="<?php echo $jf;?>" />
    </div>
     <div class="phone_k">
        <img class="icon" src="img/a/login_icon_mm.png" alt="密码"/>
        <span class="test">
            <input class="phone_sr" type="password" placeholder="密码" name="passwd" id="passwd"/>
        </span>
        <img class="icon_e" src="img/eye.png" alt="密码"/>
    </div>

  <!--   <div class="phone_k">
        <img class="icon" src="img/a/login_icon_yzm.png" alt="密码"/>
        <input class="yzm_sr" style="" type="text" placeholder="请输入验证码" name="verifyMP" id="verifyMP"/>
        <input class="yzm_get"  id="button" style="" type="button" value="获取验证码"  onclick="javascript:sendMsg();"/>
        <div class="last_time" id="a_verify"></div>
    </div> -->
    
    <!-- <div class="phone_k">
        <img class="icon" src="img/a/login_icon_fwgh.png" alt="服务工号（选填）"/>
        <input class="phone_sr" type="text" placeholder="服务工号（选填）" name="num" id="num"/>
    </div> -->
   
  <?php if($Ftype == '0'): ?><div class="phone_k">
        <!--  <?php if($floor == '' ): ?>请联系管理员增加宿舍楼<?php endif; ?> -->
      
      <select class="chose_lou" name="floorid" style="width:350px">
          <option value="-1">宿舍楼</option>
           <?php if(is_array($floor)): $i = 0; $__LIST__ = $floor;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><option value="<?php echo ($item["Fid"]); ?>"><?php echo ($item["Fname"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
      </select>
       
      <span style="vertical-align:middle;line-height:60px;font-size:36px;color:#59c2e1;font-weight:bold;"> 栋</span>
        <img class="icon" src="img/a/login_icon_dz.png" alt="请输入地址"/>
      
    </div><?php endif; ?>
     <div class="phone_k">
        <textarea class="phone_sr_ex" placeholder="请输入详细地址" style="width:80%;margin-left:10%;" name="address" id="address"></textarea>
        <img class="icon" src="img/a/login_icon_dz.png" alt="请输入地址"/>
    </div>

    <input type="button" class="login" value="注&nbsp;册" onclick="onpost()" />
  <!-- <div class="tgy_come"><a style="float:right;color:#999;" href="<?php echo U('Recom/login',array('token'=>$token));?>">推广员入口 > ></a></div> -->
</form> 
</body>

<!--eye-->
<script language="javascript" type="text/javascript">
// $('.icon_e').click(function(){
//   vale=$('.test').find('input').val(); //将test里的值存起来
  
//   if($('.test').find('input').attr('type')=='text'){//如果text里的input的type为text
//     $('.test').html("<input type='password' class='phone_sr' value='"+vale+"'>")//输出的input
//   }else{
//     $('.test').html("<input type='text' class='phone_sr' value='"+vale+"'>")//否则输出的input
//   }
// })

 $('#verifyImg').click(function(){
            //重载验证码
            var timenow = new Date().getTime();
            var url="<?php echo U('Reg/verify',array('t'=>'"+timenow+"'));?>";
            $('#verifyImg').attr('src',url);
            
        });
function onpost(){
  var name=document.getElementById('name').value;
  // passwd=document.getElementById('passwd').value;
  var address=document.getElementById('address').value;
  // num=document.getElementById('verifyMP').value;
  
  /**
   * update by shitao 2016-04-13 start
   */
   var reg=/^(13[0-9]|14[0-9]|16[0-9]|17[0-9]|15[0-9]|18[0-9])[0-9]{8}$/i;
   if(name=='' || !reg.test(name)){
     alert('请输入正确的手机号！');
     return false;
   }
  //   if(name==''){
  //   alert('电话不能为空');
  //   return false;
  // }
  /**
   * update by shitao 2016-04-13 end
   */
  // if(passwd==''){
  //               alert('密码不能为空');
  //               return false;
  //       }
    if(address==''){
                alert('地址不能为空');
                return false;
        }
    // if( '' === $.trim($('#verifyMP').val())){
    //             //$('#result').html('验证码不能为空!').show();
    //             alert('验证码不能为空!');
    //             return false;
    //         } 
    // if(num==''){
    //             alert('请输入验证码');
    //             return false;
    //     }
  //return true;
     var data=$('#formid').serialize();
   $.post("<?php echo U('Reg/register');?>", data, function(response){
      console.log(response);
      switch (response){
        case 'index1':
          pconfirm.open('码上订水','已为您更新二维码，是否登录？',function(){
          window.location.href="<?php echo U('Store/goodslist',array('FFtoken'=>$token,'Fewm_id'=>$Fewm_id,'FFqid'=>$Fewm_id));?>&FFphone="+name;
          });
        break;
        case 'index2':
          pconfirm.open('码上订水','您已注册过该水站，是否登录？',function(){
          window.location.href="<?php echo U('Store/goodslist',array('FFtoken'=>$token,'Fewm_id'=>$Fewm_id,'FFqid'=>$Fewm_id));?>&FFphone="+name;
          });
        break;
        case 'success':
          pconfirm.open('码上订水','注册成功，是否登录？',function(){
          window.location.href="<?php echo U('Store/goodslist',array('FFtoken'=>$token,'Fewm_id'=>$Fewm_id,'FFqid'=>$Fewm_id));?>&FFphone="+name;
          });
        break;
        default:
        alert(response);
      }
     /* if(response=='index2'){
        pconfirm.open('码上订水','您已注册过该水站，是否登录？',function(){
        window.location.href="<?php echo U('Store/goodslist',array('FFtoken'=>$token,'Fewm_id'=>$Fewm_id,'FFqid'=>$Fewm_id));?>&FFphone="+name;
        });
      }else if(response=='index1'){
        pconfirm.open('码上订水','已为您更新二维码，是否登录？',function(){
        window.location.href="<?php echo U('Store/goodslist',array('FFtoken'=>$token,'Fewm_id'=>$Fewm_id,'FFqid'=>$Fewm_id));?>&FFphone="+name;
        });
      }else{

      }*/
       /*if(response=='sccuess'){
             // pconfirm.open('码上订水','注册成功请选择你的订的水品下次订水使用',function(){
                 window.location.href="<?php echo U('Store/index',array('FFtoken'=>$_GET['token'],'Fewm_id'=>$_GET['Fewm_id'],'FFqid'=>$_GET['Fewm_id']));?>&FFphone="+name;
             // })
          
       }else if(response=='index'){
           // pconfirm.open('码上订水','此用户已注册',function(){
           //       window.location.href="<?php echo U('Store/index',array('FFtoken'=>$_GET['token'],'Fewm_id'=>$_GET['Fewm_id']));?>&FFphone="+name;
           //   })
          alert('此用户已注册');
       }else{
          alert(response);
       }*/
   })


}
    function sendMsg(){
        var num = document.getElementById('name').value;
        var reg=/^0{0,1}(13[0-9]|14[0-9]|16[0-9]|17[0-9]|15[0-9]|18[0-9])[0-9]{8}$/i;
        if( num == '' || !reg.test(num)){
            alert('请输入正确的手机号！');
    //createCode();//刷新验证码
            return false;
        }
   //
       if (confirm("我们会将会发送验证码到 "+num)){
            jQuery(function($) {
                $.ajax({
                    url:"/index.php?m=Users&a=test",
                    type:"post",
                    data:"sms_mp="+num,
                    success:function(data){
                        if(data==1){
                          alert('请稍后再发送');
                        }
                        $("#button").hide();
                        $("#a_verify").show();
                        $("#a_verify").css({"-webkit-appearance":"none","height":"58px","line-height":"58px","width":"30%","text-align":"center","font-size":"26px","float":"right","background":"#59c2e1","color":"#fff","border-radius":"1000px","margin-right":"20px",});
                        fun_timedown(60);

                      }
                });
            });
        }
    }

    function fun_timedown(time){
        if(time=='undefined'){
            time = 60;
        }
        $("#a_verify").html(time+"秒后");

        time = time-1;
        if(time >= 0){
            setTimeout("fun_timedown("+time+")",1000);
        }else{
            $("#button").show();
            $("#a_verify").hide();
            // $("#a_verify").css({"background":"#fff","borderColor":"#007DDB"});
            // $("#a_verify").html('<input class="yzm_get" id="a_verify" style="" type="button" value="获取验证码"  onclick="javascript:sendMsg();"/>');
        }
    }


</script>
</html>