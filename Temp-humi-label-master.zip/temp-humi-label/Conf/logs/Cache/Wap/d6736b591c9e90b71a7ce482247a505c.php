<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_home _my.css" />
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>

<!-- <style>	
* {
	margin:0;
	padding:0;
	list-style:none;
}

</style> -->
</head>
<!--手机端自适应js-->
<script type="text/javascript">
	var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
	if (/Android (\d+\.\d+)/.test(ua)){
		var version = parseFloat(RegExp.$1);
		if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
		}else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
	} else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
<body>
<!--header-->

<!--头部标题-->

<div class="header_k">
 <!-- <?php if($_GET['bid'] == 'bid' ): ?><img class="icon_left" src="img/back.png" onclick="window.history.back()" />
 
 <?php else: ?>
 
   <img class="icon_left" src="img/chose_user.png"/><?php endif; ?> 头部左侧头像隐藏-->
   
    <div class="sz_name"> <a href="<?php echo U('Store/intro',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>"><?php echo ($userinfo["Fwatername"]); ?></a> <!-- <span><img class="title_d" src="img/a/nav_btn.png" style=""></span>头部点隐藏 --></div>

    <!-- <?php if($bid == 'orders'): ?><a href="<?php echo U('Nativelife/orderlist',array('token'=>$FFtoken));?>">
        <img class="icon_right" src="img/a/nav_fh.png"/>
        </a>
    <?php else: ?>
        <a href="tel:<?php echo ($userinfo["Fphone"]); ?>">
        <img class="icon_right" src="img/dh.png"/>
        </a><?php endif; ?> 头部右侧图标隐藏-->
    <!-- <div style="width:34px;width:100%"><p style="float:left;font-size:28px;">您目前的积分：90</p><img src="img/jifen.gif" style="float:right;"/> </div>积分隐藏-->
    
</div>
<div class="h55"></div>


<!--切换账号-->
<div class="tc_mc"></div>
<div class="tc_chose_k">
    <div class="tip blue_color">您可以切换其他账号登陆！</div>
    <a href="index.php?g=Wap&m=Reg&a=station&token=<?php echo ($FFtoken); ?>"><div class="go_join">切换账号 > ></div></a>
    <img class="date_close" src="img/gb.png"/>
</div>
<script>
//蒙层不可滑动
        $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.tc_mc').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
         $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.tc_chose_k').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
//切换账号
     $(document).ready(function() {
        $(".icon_left").click(function(){
            $(".tc_mc").css("display","block")
            $(".tc_chose_k").css("display","block")
            })
        $(".tc_mc").click(function(){
            $(".tc_mc").css("display","none")
            $(".tc_chose_k").css("display","none")
            })
        $(".date_close").click(function(){
            $(".tc_mc").css("display","none")
            $(".tc_chose_k").css("display","none")
            })
        })
</script>
<!--内容-->
<div class="divider"></div>
<div class="jftotal">
	<p>我当前的积分</p><p class="font_jf"><?php echo ($total); ?></p>
</div>
<div class="divider"></div>
<div class="divider"></div>
<?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><div class="font_style6">
		<div style="position: relative;margin-top: 20px;float: right;margin-right: 30px;color: green;"><?php if(intval($v['Ftotal'])>0){ ?>+<?php } echo ($v['Ftotal']); ?><span style="color:#555;font-size:20px;"> 积分</span></div>
		<div><?php if(intval($v['Fproductid'])>0){ ?>购买<?php }else if($v['Fproductid']=='-2'){ ?>商城购物抵扣<?php }else if($v['Fproductid']=='-3'){ ?> 抽奖获得 <?php } echo ($v['name']); ?></div>
		<div style="margin-top: 10px;"><?php echo date('Y-m-d H:i:s', $v['Fcreatetime']) ?></div>
	</div>
	<div class="divider"></div><?php endforeach; endif; else: echo "" ;endif; ?>
	<div>
	<?php if($_GET['p'] > 1){ ?>
		<a href="<?php echo U('Store/integration',array('q'=>$q,'bid'=>'bid','FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid'],'p'=>$_GET['p']-1));?>">
			<div class="font_style6" style="text-align: center;width: 50%;float: left;">
				上一页
			</div>
		</a>
	<?php } ?>
	<?php if(count($data)>=10){ ?>
		<a href="<?php echo U('Store/integration',array('q'=>$q,'bid'=>'bid','FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid'],'p'=>$_GET['p']+1));?>">
			<div class="font_style6" style="text-align: center;width: 50%;float: right;">
				下一页
			</div>
		</a>
	<?php } ?>
	</div>
<div style="height:40px;"></div>
 <?php if($praisestatuson == 1): ?><a href="<?php echo U('Storeactive/praiseslist',array('FFtoken'=>$_GET['FFtoken'],'FFqid'=>$_GET['FFqid'],'FFphone'=>$_GET['FFphone']));?>">
<img src="img/activity/my_list.png" class="my_list"/>
</a><?php endif; ?>


<div class="h100"></div>
<!--footer-->
<div class="footer_k">
<a href="<?php echo U('Store/index',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left">   
      <div>
        <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_sy.jpg" style=""/></div>
        <div class="ft_font" >首页</div>
      </div>
  </div>
</a>
<a href="<?php echo U('Store/goodslist',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left"> 
    <div>
      <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_sp.jpg" style=""/></div>
      <div class="ft_font">商品列表</div>
    </div>  
  </div>
</a>
<a href="<?php echo U('Store/orders',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left"> 
    <div>
      <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_dd.jpg" style=""/></div>
      <div class="ft_font">我的订单</div>
    </div>  
  </div>
</a>
<a href="<?php echo U('Store/user',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left">
    <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_wd_pre.jpg" style=""/></div>
    <div class="ft_font" style="color:#6283a6">会员中心</div>
  </div>
</a>
</div>

</body>
<script>
//蒙层不可滑动
        $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.mc').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 

</script>
</html>