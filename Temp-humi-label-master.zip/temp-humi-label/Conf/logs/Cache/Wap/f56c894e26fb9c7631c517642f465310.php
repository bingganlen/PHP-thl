<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_home_dd.css" />
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<script type="text/javascript" src="/public/ipublic.js"></script>
<script src="js/swiper.min.js"></script>
<link rel="stylesheet" href="cssw3/swiper.min.css">
<link rel="stylesheet" type="text/css" href="cssw3/huodong.css" />
</head>
<!--手机端自适应js-->
<script type="text/javascript">
    var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
    if (/Android (\d+\.\d+)/.test(ua)){
        var version = parseFloat(RegExp.$1);
        if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
        }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
    } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
<body>
<!--header-->
<!-- <?php if($_GET['praisestatuson'] == '1' ): ?><div class="activity_mc"></div>
<div class="activity_k">
<a href="<?php echo U('Storeactive/info',array('FFphone'=>$_GET['FFphone'],'FFtoken'=>$_GET['FFtoken'],'FFqid'=>$_GET['FFqid']));?>">
  <div class="activity_font">获得2次抽奖机会！</div>
    <div class="activity_font1">（点击查看活动详情）</div>
    </a>
    <div class="activity">
    <a href="<?php echo U('Storeactive/praiseslist',array('FFtoken'=>$_GET['FFtoken'],'FFqid'=>$_GET['FFqid'],'FFphone'=>$_GET['FFphone']));?>">

      <div class="activity_know">我的卡包</div>
      </a>
         <a href="<?php echo U('Storeactive/activedo',array('FFphone'=>$_GET['FFphone'],'token'=>$_GET['FFtoken'],'FFqid'=>$_GET['FFqid']));?>"><div class="activity_go">立即抽奖</div></a>
    </div>
</div><?php endif; ?>隐藏抽奖 20171221 Chenyuanyuan-->
<!--头部标题-->

<div class="header_k">
 <!-- <?php if($_GET['bid'] == 'bid' ): ?><img class="icon_left" src="img/back.png" onclick="window.history.back()" />
 
 <?php else: ?>
 
   <img class="icon_left" src="img/chose_user.png"/><?php endif; ?> 头部左侧头像隐藏-->
   
    <div class="sz_name"> <a href="<?php echo U('Store/intro',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>"><?php echo ($userinfo["Fwatername"]); ?></a> <!-- <span><img class="title_d" src="img/a/nav_btn.png" style=""></span>头部点隐藏 --></div>

    <!-- <?php if($bid == 'orders'): ?><a href="<?php echo U('Nativelife/orderlist',array('token'=>$FFtoken));?>">
        <img class="icon_right" src="img/a/nav_fh.png"/>
        </a>
    <?php else: ?>
        <a href="tel:<?php echo ($userinfo["Fphone"]); ?>">
        <img class="icon_right" src="img/dh.png"/>
        </a><?php endif; ?> 头部右侧图标隐藏-->
    <!-- <div style="width:34px;width:100%"><p style="float:left;font-size:28px;">您目前的积分：90</p><img src="img/jifen.gif" style="float:right;"/> </div>积分隐藏-->
    
</div>
<div class="h55"></div>


<!--切换账号-->
<div class="tc_mc"></div>
<div class="tc_chose_k">
    <div class="tip blue_color">您可以切换其他账号登陆！</div>
    <a href="index.php?g=Wap&m=Reg&a=station&token=<?php echo ($FFtoken); ?>"><div class="go_join">切换账号 > ></div></a>
    <img class="date_close" src="img/gb.png"/>
</div>
<script>
//蒙层不可滑动
        $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.tc_mc').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
         $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.tc_chose_k').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
//切换账号
     $(document).ready(function() {
        $(".icon_left").click(function(){
            $(".tc_mc").css("display","block")
            $(".tc_chose_k").css("display","block")
            })
        $(".tc_mc").click(function(){
            $(".tc_mc").css("display","none")
            $(".tc_chose_k").css("display","none")
            })
        $(".date_close").click(function(){
            $(".tc_mc").css("display","none")
            $(".tc_chose_k").css("display","none")
            })
        })
</script>
<!--内容-->
<!-- 幻灯片 -->
<div class="sy_ttwill_banner" >
      <div class="swiper-wrapper">

          <?php if(is_array($res2)): $i = 0; $__LIST__ = $res2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="swiper-slide">
            <a href="<?php echo ($vo["url"]); ?>" onclick="_hmt.push(['_trackEvent', '<?php echo ($vo["info"]); ?>', 'click', '<?php echo ($userinfo["Fwatername"]); ?>'])">
              <img class="sy_bn_tu" src="<?php echo ($vo["img"]); ?>" width="640px" height="265px"/>
            </a>
            <h2 class="gallerytitle"></h2>
          </div><?php endforeach; endif; else: echo "" ;endif; ?>
      </div>
    <div class="pagination"></div> 
    </div>
    
    <script type="text/javascript">
    window.onload = function() {
      var mySwiper2 = new Swiper('.sy_ttwill_banner',{
          autoplay:3000,
          visibilityFullFit : true,
          loop:true,
          pagination : '.pagination',
      });
     
    }
    </script>

<div class="dd_chose_k">
    <div class="dd_chose_left" id="allorders" ><img src="img/a/all_a.jpg" alt="" /><p class="ordactive">全部订单</p></div>
    <div class="dd_chose_left" id="orders1" ><img src="img/a/wps_b.jpg" alt="" /><p>未派送</p></div>
    <div class="dd_chose_left" id="orders2" ><img src="img/a/ps_b.jpg" alt="" /><p>派送中</p></div>
    <div class="dd_chose_left" id="orders3"><img src="img/a/finish_b.jpg" alt="" /><p>已完成</p></div>
</div>
<!--全部订单-->
<div class="dd_wwc" id="dd_qb">
  <div class="content1">
<?php if(is_array($allorders)): $i = 0; $__LIST__ = $allorders;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><div class="dd_list">
      <?php if($item["logourl"] != ''): ?><img src="<?php echo ($item["logourl"]); ?>" class="picture"/>
      <?php else: ?>
        <img src="img/no.png" class="picture"/><?php endif; ?>
        <div class="sp_k">
            <div class="sp_name ovfEps">品名：<?php echo ($item["Fgoodsname"]); ?><!-- <?php if($item[Fticket] == "1"): ?><span class="blue_color">【水票】</span><?php endif; ?> --></div>
            <div class="sp_price">下单时间：<?php echo (date("Y/m/d",$item["Fordertime"])); ?></div>
            <div class="sp_type"><?php if($item[Fticket] == "1"): ?>水票：<?php echo ($item["Fnum"]); ?>张/<?php endif; if($item['Fdiscount'] > '0'): ?>金额:<?php echo ($item["Fpaytotal"]); else: ?>金额:<?php echo ($item["Ftotal"]); endif; ?></div>
            <div class="paystyle">            
            <?php switch($item["Fpaytype"]): case "0": ?>电子水票支付<?php break;?>
              <?php case "1": ?>线下支付<?php break;?>
              <?php case "2": ?>微信支付<?php break;?>
              <?php default: ?>支付宝支付<?php endswitch;?>
            </div>
            <a href="<?php echo U('Store/orders_detail',array('Fid'=>$item['Fid'],'FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>" class="odetail"><img src="img/a/rightarr.jpg" alt="" height="38px"/></a>
        </div>
      </div>
      
      <?php if($item["Fstatus"] != '3'): ?><div class="operate_btn">
        <hr class="hrdivider"/>
          <?php if($item["Fstatus"] == '1' ): if(($item["Fpaytype"] == '2') AND ($item["Ftype"] == '0')): ?><div class="dd_zt" onclick="repay(<?php echo ($item["Fid"]); ?>)" data-id="" style="width:140px">未付款请支付</div>
              <div class="dd_zt" onclick="cancel(<?php echo ($item["Fid"]); ?>)" data-id="">取消订单</div>
            <?php else: ?>
            <div class="dd_zt" onclick="cancel(<?php echo ($item["Fid"]); ?>)" data-id="">取消订单</div>
            <div class="dd_zt" onclick="quick(<?php echo ($item["Fid"]); ?>)" data-id="">催单</div><?php endif; ?>       
          <?php elseif($item["Fstatus"] == '2' ): ?>
            <div class="dd_zt" onclick="quick(<?php echo ($item["Fid"]); ?>)" data-id="">催单</div>
          <?php else: ?>
            <div class="dd_zt">已取消</div><?php endif; ?>
          </a>
      </div><?php endif; endforeach; endif; else: echo "" ;endif; ?>
  <div id="conten1"></div>
  </div>
  
  <div class="h100" style="text-align:center;font-size:20px;" id="loadmoreall" page="2">加载更多...</div>
</div>

<!--未派送-->
<div class="dd_wwc" id="dd_wps" style="display:none">
  <div class="content1">
<?php if(is_array($orders1)): $i = 0; $__LIST__ = $orders1;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><div class="dd_list">
      <?php if($item["logourl"] != ''): ?><img src="<?php echo ($item["logourl"]); ?>" class="picture"/>
      <?php else: ?>
        <img src="img/no.png" class="picture"/><?php endif; ?>
        <div class="sp_k">
            <div class="sp_name ovfEps">品名：<?php echo ($item["Fgoodsname"]); if($item[Fticket] == "1"): ?><span class="blue_color">【水票】</span><?php endif; ?></div>
            <div class="sp_price">下单时间：<?php echo (date("Y/m/d",$item["Fordertime"])); ?></div>
            <div class="sp_type"><?php if($item[Fticket] == "1"): ?>水票：<?php echo ($item["Fnum"]); ?>张/<?php endif; if($item['Fdiscount'] > '0'): ?>金额:<?php echo ($item["Fpaytotal"]); else: ?>金额:<?php echo ($item["Ftotal"]); endif; ?></div>
            <div class="paystyle">
            <?php switch($item["Fpaytype"]): case "0": ?>电子水票支付<?php break;?>
              <?php case "1": ?>线下支付<?php break;?>
              <?php case "2": ?>微信支付<?php break;?>
              <?php default: ?>支付宝支付<?php endswitch;?>
            </div>
            <a href="<?php echo U('Store/orders_detail',array('Fid'=>$item['Fid'],'FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>" class="odetail"><img src="img/a/rightarr.jpg" alt="" height="38px"/></a>
        </div>
      </div>      
      <div class="operate_btn">
        <hr class="hrdivider"/>                     
            <div class="dd_zt" onclick="cancel(<?php echo ($item["Fid"]); ?>)" data-id="">取消订单</div>
            <div class="dd_zt" onclick="quick(<?php echo ($item["Fid"]); ?>)" data-id="">催单</div>           
      </div><?php endforeach; endif; else: echo "" ;endif; ?>
  </div>
  <div class="h100" style="text-align:center;font-size:20px;" id="loadmore1" page="2"></div>
</div>

<!--在派送-->
<div class="dd_wwc" id="dd_zps" style="display:none">
  <div class="content1">
<?php if(is_array($orders2)): $i = 0; $__LIST__ = $orders2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><div class="dd_list">
      <?php if($item["logourl"] != ''): ?><img src="<?php echo ($item["logourl"]); ?>" class="picture"/>
      <?php else: ?>
        <img src="img/no.png" class="picture"/><?php endif; ?>
        <div class="sp_k">
            <div class="sp_name ovfEps">品名：<?php echo ($item["Fgoodsname"]); if($item[Fticket] == "1"): ?><span class="blue_color">【水票】</span><?php endif; ?></div>
            <div class="sp_price">下单时间：<?php echo (date("Y/m/d",$item["Fordertime"])); ?></div>
            <div class="sp_type"><?php if($item[Fticket] == "1"): ?>水票：<?php echo ($item["Fnum"]); ?>张/<?php endif; if($item['Fdiscount'] > '0'): ?>金额:<?php echo ($item["Fpaytotal"]); else: ?>金额:<?php echo ($item["Ftotal"]); endif; ?></div>
            <div class="paystyle">
            <?php switch($item["Fpaytype"]): case "0": ?>电子水票支付<?php break;?>
              <?php case "1": ?>线下支付<?php break;?>
              <?php case "2": ?>微信支付<?php break;?>
              <?php default: ?>支付宝支付<?php endswitch;?>
            </div>
            <a href="<?php echo U('Store/orders_detail',array('Fid'=>$item['Fid'],'FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>" class="odetail"><img src="img/a/rightarr.jpg" alt="" height="38px"/></a>
        </div>
      </div>      
      <div class="operate_btn">
        <hr class="hrdivider"/>
        <div class="dd_zt" onclick="quick(<?php echo ($item["Fid"]); ?>)" data-id="">催单</div>           
      </div><?php endforeach; endif; else: echo "" ;endif; ?>
  </div>
  <div class="h100" style="text-align:center;font-size:20px;" id="loadmore2" page="2"></div>
</div>
<!-- 已完成 -->
<div class="dd_ywc" id="dd_wc" style="display:none">
  <div class="content1">
    <?php if(is_array($orders3)): $i = 0; $__LIST__ = $orders3;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><div class="dd_list">
      <?php if($item["logourl"] != ''): ?><img src="<?php echo ($item["logourl"]); ?>" class="picture"/>
      <?php else: ?>
        <img src="img/no.png" class="picture"/><?php endif; ?>
        <div class="sp_k">
            <div class="sp_name ovfEps">品名：<?php echo ($item["Fgoodsname"]); ?><!-- <?php if($item[Fticket] == "1"): ?><span class="blue_color">【水票】</span><?php endif; ?> --></div>
            <div class="sp_price">下单时间：<?php echo (date("Y/m/d",$item["Fordertime"])); ?></div>
            <div class="sp_type"><?php if($item["Fticket"] == "1"): ?>水票：<?php echo ($item["Fnum"]); ?>张/<?php endif; if($item['Fdiscount'] > '0'): ?>金额:<?php echo ($item["Fpaytotal"]); else: ?>金额:<?php echo ($item["Ftotal"]); endif; ?></div>
            <div class="paystyle">
            <?php switch($item["Fpaytype"]): case "0": ?>电子水票支付<?php break;?>
              <?php case "1": ?>线下支付<?php break;?>
              <?php case "2": ?>微信支付<?php break;?>
              <?php default: ?>支付宝支付<?php endswitch;?>
            </div>
            <a href="<?php echo U('Store/orders_detail',array('Fid'=>$item['Fid'],'FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>" class="odetail"><img src="img/a/rightarr.jpg" alt="" height="38px"/></a>
        </div>
      </div><?php endforeach; endif; else: echo "" ;endif; ?>
    <div id="conten2"></div>
    </div>
 <div class="h100" style="text-align:center;font-size:20px" id="loadmore3" page="2">加载更多...</div>
</div>
<!--footer-->

<div class="footer_k">
<a href="<?php echo U('Store/index',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left">   
      <div>
        <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_sy.jpg" style=""/></div>
        <div class="ft_font" >首页</div>
      </div>   
  </div>
</a>
<a href="<?php echo U('Store/goodslist',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left"> 
    <div>
      <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_sp.jpg" style=""/></div>
      <div class="ft_font">商品列表</div>
    </div>  
  </div>
</a>
<a href="<?php echo U('Store/orders',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left"> 
    <div>
      <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_dd_pre.jpg" style=""/></div>
      <div class="ft_font" style="color:#6283a6">我的订单</div>
    </div>  
  </div>
</a>
<a href="<?php echo U('Store/user',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left">
    <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_wd.jpg" style=""/></div>
    <div class="ft_font">会员中心</div>
  </div>
</a>
</div>
</body>
<script type="text/javascript">

   //切换订单状态  不能调试
    
    $(document).ready(function() {
        $("#allorders").click(function(){
          //菜单处理
          $(".dd_chose_left").each(function(){
            var _this=$(this);
            var olsrc=_this.find("img").attr("src");
            var nlsrc=olsrc.replace("a.jpg","b.jpg");
            _this.find("img").attr("src",nlsrc);
            _this.find("p").removeClass("ordactive");
           });           
           var src=$(this).find("img").attr("src");
           nsrc=src.replace("b.jpg","a.jpg");
           $(this).find("img").attr("src",nsrc);
           $(this).find("p").addClass("ordactive");
           //内容切换
           $("#dd_wps").hide();
           $("#dd_zps").hide();
           $("#dd_wc").hide();
           $("#dd_qb").show();
        })
    })

    $(document).ready(function() {
        $("#orders1").click(function(){
           $(".dd_chose_left").each(function(){
            var _this=$(this);
            var olsrc=_this.find("img").attr("src");
            var nlsrc=olsrc.replace("a.jpg","b.jpg");
            _this.find("img").attr("src",nlsrc);
            _this.find("p").removeClass("ordactive");
           });           
           var src=$(this).find("img").attr("src");
           nsrc=src.replace("b.jpg","a.jpg");
           $(this).find("img").attr("src",nsrc);
           $(this).find("p").addClass("ordactive");
           //内容切换           
           $("#dd_zps").hide();
           $("#dd_wc").hide();
           $("#dd_qb").hide();
           $("#dd_wps").show();     
        })
    })
    $(document).ready(function() {
        $("#orders2").click(function(){
          $(".dd_chose_left").each(function(){
            var _this=$(this);
            var olsrc=_this.find("img").attr("src");
            var nlsrc=olsrc.replace("a.jpg","b.jpg");
            _this.find("img").attr("src",nlsrc);
            _this.find("p").removeClass("ordactive");
           });           
           var src=$(this).find("img").attr("src");
           nsrc=src.replace("b.jpg","a.jpg");
           $(this).find("img").attr("src",nsrc);
           $(this).find("p").addClass("ordactive");
           //内容切换          
           
           $("#dd_wc").hide();
           $("#dd_qb").hide();
           $("#dd_wps").hide();
           $("#dd_zps").show();
        })
    })
    $(document).ready(function() {
        $("#orders3").click(function(){
           $(".dd_chose_left").each(function(){
            var _this=$(this);
            var olsrc=_this.find("img").attr("src");
            var nlsrc=olsrc.replace("a.jpg","b.jpg");
            _this.find("img").attr("src",nlsrc);
            _this.find("p").removeClass("ordactive");
           });           
           var src=$(this).find("img").attr("src");
           nsrc=src.replace("b.jpg","a.jpg");
           $(this).find("img").attr("src",nsrc);
           $(this).find("p").addClass("ordactive");
           //内容切换           
           $("#dd_zps").hide();           
           $("#dd_qb").hide();
           $("#dd_wps").hide();
           $("#dd_wc").show();
        })
    })
// 催单和取消订单
  /*$('#cans').click(function(){    

    pconfirm.open('码上订水','取消下单',function(){
       window.location = "<?php echo U('Store/cancel',array('Fid'=>$order['Fid'],'Fusers'=>$Fusers,'q'=>$q,'token'=>$token));?>";
    })
   
    })*/
  function cancel(id){
    var oid=id;
    var token="<?php echo ($_GET['FFtoken']); ?>";    
    pconfirm.open('码上订水','取消下单',function(){
      $.get('index.php?g=Wap&m=Store&a=cancel',{Fid:oid,FFtoken:token},function(result){
        console.log(result);
        if(result=='1'){          
         alert('订单已取消,请查看微信退款');
         location.reload();
        }else{
          alert('订单取消失败');
        }
      })
      //window.location = "<?php echo U('Store/cancel',array('FFphone'=>$Fusers,'FFtoken'=>$token));?>&Fid="+oid;
    })
  }

 function quick(id){
    
    pconfirm.open('码上订水','催单',function(){
      var Fid=id;
      var token="<?php echo ($_GET['FFtoken']); ?>";
           
      $.post('index.php?g=Wap&m=Store&a=cd',{Fid:Fid,token:token},function(result){
            
        if(result==1){
        
          //window.location.href = 'tel:<?php echo ($userinfo["Fphone"]); ?>'; 
          alert('催单成功');
        }

        if(result==2){
            alert('您的催单已收到，请稍等');
        }

        if(result==3){
            alert('此订单已发货');
        }
      });

    })
    }
function repay(id){
  var oid=id;
  window.location.href="<?php echo U('Store/orderdown',array('FFphone'=>$_GET['FFphone'],'FFtoken'=>$_GET['FFtoken'],'FFqid'=>$_GET['FFqid']));?>&oid="+oid;
}
//活动
    $(".activity_mc").click(function(){
      $(".activity_k").css("display","none")
      $(".activity_mc").css("display","none")
      })
</script>

<script type="text/javascript">
    
/*---------------------加载更多--------------------*/
  $(document).ready(function(){
      //更换文章 加载更多
      var totals1=parseInt('<?php echo ($cont1); ?>');
      var totals2=parseInt('<?php echo ($cont2); ?>');
      var totals3=parseInt('<?php echo ($cont3); ?>');
      var totalsall=parseInt('<?php echo ($allcont); ?>');
      var pagesize=8;
      //全部订单   

      if(!totalsall || totalsall<=pagesize){
        $('#loadmoreall').html('没有更多了');
      }else{
        //有分页
        $('#loadmoreall').html('加载更多');
        $('#loadmoreall').click(function(){          
          var pages = Math.ceil(totalsall / pagesize);          
          var _page = $(this).attr('page');
            if (_page > pages) {
            $(this).html('没有更多了');
            return false;
            }          
          //var offset=pagesize;
          //中间页
          if(_page*pagesize<totalsall){
            var offset=(_page-1)*pagesize;
          }else{
            //最后页
            var offset=(_page-1)*pagesize;
            pagesize=totalsall-(offset);
            $(this).html('没有更多了');
          }
          //加载更多数据
          var com_link = "<?php echo U('Store/ordersload',array('FFphone'=>$_GET['FFphone'],'FFtoken'=>$_GET['FFtoken'],'FFqid'=>$_GET['FFqid']));?>";
          $.get(com_link,{offset:offset,pagesize:pagesize},function(result){
          
           if(result.length){
                $('#loadmoreall').attr('page',parseInt(_page)+1);                
                 _page = $('#loadmoreall').attr('page');
                $('#conten1').html(result);            
            }         
          }) 
        })
      }
      //未派送
      if(!totals1 ||totals1<=0){
        $('#loadmore1').html('没有未派送订单了');
      }
      //已派单
      if(!totals2 ||totals2<=0){
        $('#loadmore2').html('没有正在派送的订单了');
      }
      //已完成
      if(!totals3 || totals3<=pagesize){
        $('#loadmore3').html('没有更多了');
      }else{
        //有分页
        $('#loadmore3').html('加载更多');
        $('#loadmore3').click(function(){          
          var pages = Math.ceil(totals3 / pagesize);          
          var _page = $(this).attr('page');
            if (_page > pages) {
            $(this).html('没有更多了');
            return false;
            }         
          //中间页
          if(_page*pagesize<totals3){
            var offset=(_page-1)*pagesize;
          }else{
            //最后页
            var offset=(_page-1)*pagesize;
            pagesize=totals3-(offset);
            $(this).html('没有更多了');
          }
         //加载更多数据
          var com_link3 = "<?php echo U('Store/ordersload2',array('FFphone'=>$_GET['FFphone'],'FFtoken'=>$_GET['FFtoken'],'FFqid'=>$_GET['FFqid']));?>";
          $.get(com_link3,{offset:offset,pagesize:pagesize},function(result){          
           if(result.length){
                $('#loadmore3').attr('page',parseInt(_page)+1);                
                 _page = $('#loadmore3').attr('page');
                $('#conten2').html(result);            
            }         
          })
          })      
        }         

  })

</script>
</html>