<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css"/>
<link rel="stylesheet" type="text/css" href="cssw3/user_home_message.css" />
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<title>码上订水</title>
<!--手机端自适应js-->
<script type="text/javascript">
	var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
	if (/Android (\d+\.\d+)/.test(ua)){
		var version = parseFloat(RegExp.$1);
		if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
		}else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
	} else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
<style>



 
</style>
</head>
<body>
<!--header-->

<!--弹出
<div class="mc" style=""></div>
<div class="mc_message">
	<div class="font_style1">联系人&nbsp;&nbsp;:&nbsp;&nbsp;<span class="font5b">王冰</span></div>
    <div class="font_style1">电&nbsp;&nbsp&nbsp;&nbsp话&nbsp;&nbsp;:&nbsp;&nbsp;<span class="font5b">13817122949</span></div>
    <div class="font_style1">地&nbsp;&nbsp&nbsp;&nbsp址&nbsp;&nbsp;:&nbsp;&nbsp;<span class="font5b">上海市徐汇区虹梅路2001号5号</span></div>
    <div class="line4 mg_bottom mg_top"></div>
    <div class="font_style3 close">关闭</div>
    
</div>
-->
<div class="header_k">
	<img class="icon_left" src="img/a/nav_fh.png" onclick="window.history.back()"/>
    <div class="sz_name">修改地址</div>
    
</div>
<div class="h88"></div>


<!--收货地址---------------------------------------------------------------------->

<div class="shouhuo_place_bt" style=" ">修改您的收货地址</div>
<form method="post" action="<?php echo U('Store/usersetdo',array('token'=>$_GET['FFtoken'],'FFphone'=>$_GET['FFphone']));?>">
<!--收货人信息-->
<div class="font_style_place"><img class="icon_new" src="img/a/login_icon_sjh.png"/>购水手机:&nbsp;&nbsp;<span class="font5b"><?php echo ($Fuser); ?></span></div>
<input type="hidden" name="Fuser" value="<?php echo ($Fuser); ?>">
<div class="phone_k">
    <img  class="icon_new" src="img/a/login_icon_dz.png" alt="请输入地址"/>
    <span style="font-size:36px;line-height:90px;"> <?php if($Ftype == '0'): ?>宿&nbsp;舍&nbsp;楼：&nbsp;<?php else: ?>购水地址:&nbsp;&nbsp;<?php endif; ?></span>
   <?php if($Ftype == '0'): ?><select class="chose_lou" name="floorid" style="width:60%">
       <?php if(is_array($floor)): $i = 0; $__LIST__ = $floor;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><option value="<?php echo ($item["Fid"]); ?>" <?php if($item["Fid"] == $address['Ffloorid']): ?>selected="selected"<?php endif; ?>><?php echo ($item["Fname"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>

    </select>
    <?php else: ?>
    <input type="hidden" name="floorid" value="1"><?php endif; ?>
    <span style="vertical-align:middle;line-height:60px;font-size:36px;font-weight:bold;"></span>
    <textarea class="phone_sr_ex"  name="address" id="address" width="90%!important;"><?php echo ($address["Fremark"]); ?></textarea>
</div>

<!--按钮--确认付款页面的---------------------------------------------------------------------->
<div class="line4"></div>
<div class="querenfukuanyemian">
<!--按钮-->
<input type="submit" class="anniu" value="确认修改地址" style=" ">
</div>
</form>

</body>
<script>

//蒙层不可滑动
        $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.mc').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
//水站联系人信息
     $(document).ready(function() {
		$(".sz_name").click(function(){
			$(".mc").css("display","block")
			$(".mc_message").css("display","block")
			})
		$(".mc").click(function(){
			$(".mc").css("display","none")
			$(".mc_message").css("display","none")
			})
		$(".close").click(function(){
			$(".mc").css("display","none")
			$(".mc_message").css("display","none")
			})
		})
</script>
</html>