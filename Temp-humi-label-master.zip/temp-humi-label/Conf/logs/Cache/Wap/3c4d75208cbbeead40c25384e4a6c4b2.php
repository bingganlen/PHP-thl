<?php if (!defined('THINK_PATH')) exit(); if(is_array($orders)): $i = 0; $__LIST__ = $orders;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><div class="dd_list">
         <img src="img/no.png" class="picture"/>
        <div class="sp_k">
            <div class="sp_name ovfEps"><?php echo ($item["servername"]); ?></div>
            <div class="sp_price"><?php echo (date("Y/m/d",$item["createtime"])); ?></div>
          
        </div>
         <a href="<?php echo U('Nativelife/orders_hander',array('type'=>$_GET['type'],'token'=>$_GET['token'],'id'=>$item['id']));?>">
        <?php if($item["status"] == '0'): ?><div class="dd_zt">操作</div>
         <?php else: ?>
          <div class="dd_zt">详情</div><?php endif; ?>
  
        </a>
    </div><?php endforeach; endif; else: echo "" ;endif; ?>