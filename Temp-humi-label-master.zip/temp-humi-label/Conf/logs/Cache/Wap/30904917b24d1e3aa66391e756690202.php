<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>水站推广</title>
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/home_phone.css" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/tg_all.css" />
<!--手机端自适应js-->
<script type="text/javascript">
    var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
    if (/Android (\d+\.\d+)/.test(ua)){
        var version = parseFloat(RegExp.$1);
        if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
        }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
    } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
</head>
<body>
<!--header-->

<!--头部标题-->
<div class="header_k">
    <!-- <img class="icon_left" src="<?php echo RES;?>/img/gz.png"/> -->
    <div class="sz_name">推广信息<!-- <img src="<?php echo RES;?>/img/more.title.png" style="margin-top:38px;margin-left:15px;opacity:1;"/> --></div>
    <!-- <img class="icon_right" src="<?php echo RES;?>/img/dh.png"/> -->
</div>
<div class="h88"></div>
<!--内容-->
    <!--money-->
    <div class="money"><?php echo (($res1['money'])?($res1['money']):'0'); ?><span class="small_f" style="">元</span></div>
    <div class="tip">每月推广客户越多收益越高</div>
    <div class="num">编&nbsp;&nbsp;号&nbsp;&nbsp;<span class="big_f" style=""><?php echo ($res['Fid']); ?></span></div>
    <!--bt-->
    <div class="bt">我的推广信息</div>
    <!--list-->
    <div class="list">
        <div class="tj">
            <span class="tj_f">总推广统计</span>
            <span class="tj_r"><a href="<?php echo U('Recom/wdd',array('token'=>$res['Ftoken']));?>">查看详情 </a></span>
        </div>
        <div class="sl">
            <span class="sl_font">推广数量</span>
            <span class="xg">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
            <span class="sl_num"><?php echo ($res['Fnum']); ?></span>
            <span class="sl_font">个</span>
        </div>
        <div class="sl">
            <span class="sl_font">下单数量</span>
            <span class="xg">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
            <span class="sl_num"><?php echo ($res1['num']); ?></span>
            <span class="sl_font">个</span>
        </div>
    </div>
    <!-- <div class="list">
        <div class="tj">
            <span class="tj_f" style="color:#ff8208;">总推广统计</span>
            <span class="tj_r"><a href="<?php echo U('Recom/login',array('token'=>$token));?>">查看详情 </a></span>
        </div>
        <div class="sl">
            <span class="sl_font">推广数量</span>
            <span class="xg">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
            <span class="sl_num">2122</span>
            <span class="sl_font">个</span>
        </div>
        <div class="sl">
            <span class="sl_font">下单数量</span>
            <span class="xg">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
            <span class="sl_num">22</span>
            <span class="sl_font">个</span>
        </div>
    </div> -->
</body>

</html>