<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>密码找回</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_zc.css" />
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
    var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
    if (/Android (\d+\.\d+)/.test(ua)){
        var version = parseFloat(RegExp.$1);
        if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
        }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
    } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>


<body>
    <!-- <div class="ps">对不起，您的用户名已被注册</div> -->
<form onsubmit="return onpost()" action="<?php echo U('Reg/registercode');?>" method="post" >
    <input type="hidden" name="token" value="<?php echo ($token); ?>">
    <input type="hidden" name="Fewm_id" value="<?php echo ($_GET['FFqid']); ?>">
    <div class="phone_k" style="margin-top:20px;">
        <img class="icon" src="img/a/login_icon_sjh.png" alt="手机号"/>
        <input class="phone_sr" type="text" placeholder="手机号" name="name"  id="name" value="<?php echo ($phone); ?>" />
    </div>

    <div class="phone_k">
        <img class="icon" src="img/a/login_icon_yzm.png" alt="密码"/>
        <input class="yzm_sr" style="" type="text" placeholder="请输入验证码" name="verifyMP" id="verifyMP"/>
        <input class="yzm_get"  id="button" style="" type="button" value="获取验证码"  onclick="javascript:sendMsg();"/>
        <div class="last_time" id="a_verify"></div>
    </div>    
    <div class="phone_k">
        <img class="icon" src="img/a/login_icon_mm.png" alt="密码"/>
        <span class="test">
            <input class="phone_sr" type="password" placeholder="新密码" name="passwd" id="passwd"/>
        </span>
        <img class="icon_e" src="img/eye.png" alt="密码"/>
    </div>
	
    <input type="submit" class="login" value="确认密码"/>

   
</form> 
</body>

<!--eye-->
<script language="javascript" type="text/javascript">
$('.icon_e').click(function(){
  vale=$('.test').find('input').val(); //将test里的值存起来
  
  if($('.test').find('input').attr('type')=='text'){//如果text里的input的type为text
    $('.test').html("<input type='password' class='phone_sr' value='"+vale+"'>")//输出的input
  }else{
    $('.test').html("<input type='text' class='phone_sr' value='"+vale+"'>")//否则输出的input
  }
})
</script>


<script>
 $('#verifyImg').click(function(){
            //重载验证码
            var timenow = new Date().getTime();
            var url="<?php echo U('Reg/verify',array('t'=>'"+timenow+"'));?>";
            $('#verifyImg').attr('src',url);
            
        });
function onpost(){
  name=document.getElementById('name').value;
  passwd=document.getElementById('passwd').value;

  num=document.getElementById('verifyMP').value;
  var reg=/^0{0,1}(13[0-9]|14[0-9]|16[0-9]|17[0-9]|15[0-9]|18[0-9])[0-9]{8}$/i;

  if(name=='' || !reg.test(name)){
    alert('请输入正确的手机号！');
    return false;
  }
  
  if(passwd==''){
                alert('密码不能为空');
                return false;
        }
 
  
    if(num==''){
                alert('请输入验证码');
                return false;
        }
  return true;
}
    function sendMsg(){
        var num = document.getElementById('name').value;
        var reg=/^0{0,1}(13[0-9]|14[0-9]|16[0-9]|17[0-9]|15[0-9]|18[0-9])[0-9]{8}$/i;
        if( num == '' || !reg.test(num)){
            alert('请输入正确的手机号！');
    //createCode();//刷新验证码
            return false;
        }

       if (confirm("我们会将会发送验证码到 "+num)){
            jQuery(function($) {
                $.ajax({
                    url:"/index.php?m=Users&a=test",
                    type:"post",
                    data:"sms_mp="+num,
                    success:function(data){
                        if(data==1){
                          alert('请稍后再发送');
                        }
                        $("#button").hide();
                        $("#a_verify").show();
                        $("#a_verify").css({"background":"#ccc","borderColor":"#ccc","text-align":"center"});
                        fun_timedown(60);

                      }
                });
            });
        }
    }

    function fun_timedown(time){
        if(time=='undefined'){
            time = 60;
        }
        $("#a_verify").html(time+"秒后");

        time = time-1;
        if(time >= 0){
            setTimeout("fun_timedown("+time+")",1000);
        }else{
            $("#button").show();
            $("#a_verify").hide();
            // $("#a_verify").css({"background":"#fff","borderColor":"#007DDB"});
            // $("#a_verify").html('<input class="yzm_get" id="a_verify" style="" type="button" value="获取验证码"  onclick="javascript:sendMsg();"/>');
        }
    }


</script>
</html>