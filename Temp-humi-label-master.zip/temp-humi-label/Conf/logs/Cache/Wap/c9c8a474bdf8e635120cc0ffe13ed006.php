<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_home_one.css" />
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<script type="text/javascript" src="/public/ipublic.js"></script>
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.baidu.com/hm.js?ba88b8e89aed0dab77735e51a3aef67c";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>

<style>
/* .date_tu{background:url(img/a/home_btn_xz.png) center center no-repeat;}
input:checked+mspan{background:url(img/a/home_btn_xz_pre.png) center center no-repeat;}  
.date_tu{
  position:absolute;
  bottom:0px;
  left:0px;
  width:30px;
  height:30px;
  z-index:1;
  } */

  .tc_chose_k2 {
  width: 70%;
  height: 250px;
  background: #fff;
  position: fixed;
  left: 15%;
  top: 200px;
  z-index: 999;
  border-radius: 10px;
  display: none;
  overflow: hidden;
}
</style>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
	var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
	if (/Android (\d+\.\d+)/.test(ua)){
		var version = parseFloat(RegExp.$1);
		if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
		}else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
	} else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
<body>

<div class="tc_mc"></div>
<div class="tc_chose_k2" style="background:rgba(255,255,255,0.8)!important;
    height:300px;">
    <div class="tip" style="color:#191919;">正在订购请稍后...</div>
   
</div>

<!--头部标题-->

<div class="header_k">
  <a href="<?php echo U('Store/index',array('FFphone'=>$_GET['FFphone'],'FFtoken'=>$_GET['FFtoken'],'FFqid'=>$_GET['FFqid']));?>">
    <img class="icon_left" src="img/a/nav_fh.jpg"/>
  </a>
    <div class="sz_name"><a href="<?php echo U('Store/intro',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>"><?php echo ($userinfo["Fwatername"]); ?></a></div> 
</div>
<div class="h55"></div>
<marquee scrollAmount=2 onmouseover=stop() onmouseout=start() class="list_info">
<?php if($stinfo["notice"] != ""): echo ($stinfo["notice"]); ?>
<?php else: ?>欢迎光临"码上生活"订水系统<?php endif; ?>
</marquee>
<!--内容-->
<form method="post" action="<?php echo U('Store/orderdon',array('q'=>$q,'token'=>$token));?>" id="formid">
<div class="phone_place_k">
    <div class="font_style1">购水手机:&nbsp;&nbsp;<span class="font5b"><?php echo ($phone); ?></span></div>
    <input type="hidden" name="Fusername" value="<?php echo ($phone); ?>">    
    <div class="font_style1">
        <span class="fl_l">送水地址:&nbsp;&nbsp;</span>
         <!-- update by shitao 20161031 start -->
        <?php  if(!empty($address)){ ?>
        <div class="font5b fl_l address_info"><?php echo ($address); ?></div>
        <input type="hidden" name="Faddress" id="Faddress" value="<?php echo ($address); ?>">
        <?php
 }else{ ?>
        <div class="font5b fl_l" style="width:60%;"><input type="text" name="Faddress" id="Faddress"/></div>
        <?php } ?>
        <!-- update by shitao 20161031 end -->
    </div>
    <a href="<?php echo U('Store/phone_chose',array('bid'=>'bid','FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>" class="adr_arr"><img src="img/a/rightarr.jpg" height="40px" alt="" /><a/>
</div>
<div class="slb">
    <div class="list_one">
        <?php if($logourl != ''): ?><img src="<?php echo ($logourl); ?>" class="picture"/>
        <?php else: ?>
        <img src="img/no.png" class="picture"/><?php endif; ?>
        <div class="sp_k">
            <div class="sp_name ovfEps"><?php echo ($goosproname); ?></div>
            <div class="sp_price"><?php echo ($spec); ?></div>
            <div class="sp_exp">买30张娃哈哈水票=赠送台式饮水机一台，满100元赠水票一张。</div>
            <!-- <div class="sp_type"><?php if($price != '0'): echo ($price); ?>元/桶<?php endif; ?></div> -->
        </div>
        <div class="shuliang">
          <p ><?php if($goodsorder["Frice"] != '0'): ?>¥<?php echo ($price); else: ?>单价未知<?php endif; ?></p>
          <p>×<?php echo ($goods["Fnum"]); ?></p>
          <p>+24积分</p>
        </div>
        <!-- <div class="add_k">
            <input type="button" class="minus"  id="minus809" value="-" ids="809"/>
            <div class="add_num">
           <span id="iFnum" style="width: 40px; height:58px; font-size:30px;color:#434a54; text-align:center"><?php echo ($goods["Fnum"]); ?></span>
            </div>
            <input type="button" class="add"  id="add809" value="+" ids="809"/>
            <input type="hidden" name="Fnums"  id="Fnum">
        </div> -->
          <input type="hidden" name="Fgoodsname" value="<?php echo ($goosproname); ?>">
          <input type="hidden" name="Fgoodsid" value="<?php echo ($goods["Fgoodsid"]); ?>">
          <input type="hidden" name="spec" value="<?php echo ($goods["Fspec"]); ?>">
          <input type="hidden" name="Frice" value="<?php echo ($goods["Fprice"]); ?>">
          <input type="hidden" name="ordertime" value="<?php echo ($ordertime); ?>');">   
          <input type="hidden" name="Fnum" value="<?php echo ($goods["Fnum"]); ?>" id="Fnumber">
    </div>
</div>
<div class="divider"></div>
<div class="phone_place_k3">
    <div class="font_style1">
        <span>水站营业时间：<?php echo ($stinfo["Fstart_time"]); ?> 至 <?php echo ($stinfo["Fend_time"]); ?></span>
         
         <!-- <?php if($goods["Ftotals"] != '0'): ?><span class="right_font r_color" id="iFrice2"><?php echo ($goods["Ftotals"]); ?></span><span class="right_font">&nbsp;&nbsp;￥</span><?php endif; ?> -->
    </div>

    <div class="font_style1">
       <span> 配送时间:&nbsp;</span>
        <span id="get_time" style="margin:0;padding:0">
       <?php echo ($get_time); ?>
       </span>         
    </div>
</div>
<div class="font_zhifu">
     <span> 支付方式：&nbsp;</span>
        <select name="" id="">
          <option value="">微信支付</option>
          <option value="">支付宝支付</option>
        </select>  
</div>
<div class="divider"></div>
<div class="phone_place_k4">
    <div class="font_style1" style="margin-top:10px">
        <span class="fl_l">订单总额：</span>
         <span class="right_font r_color">&nbsp;&nbsp;<?php if($goods["Ftotal"] != '0'): ?>￥<?php echo ($goods["Ftotal"]); endif; ?></span>
    </div>
    <?php if($rew == 'rew'): ?><div class="font_style1">
        <span class="fl_l">实付金额:</span>
        <span class="right_font r_color">￥<?php echo ($goods["Ftotals"]); ?></span>
    </div>
    <?php else: ?>
      <div class="font_style1">
        <span class="fl_l">实付金额:</span>
        <span class="right_font r_color">
          <?php if($goods["Ftotal"] != '0'): echo ($goods["Ftotal"]); endif; ?></span>
    </div><?php endif; ?>
    <div class="font_style1" style="margin-bottom:10px">
        <span class="fl_l">获得积分：</span>
         <span class="right_font r_color">&nbsp;&nbsp;<?php if($goods["Ftotal"] != '0'): echo ($goods["Ftotal"]); endif; ?></span>
    </div>

<div class="divider"></div>
<div class="font_style1" style="margin:10px 15px;">
	<p style="float:left;">留言：</p>
  <textarea style="width:75%;height:100px;" placeholder="少于50字" maxlength="50" name="liuyan"></textarea>
</div>
</div>
</form>
<div class="pass" id="order"><p class="pass_btn">确认购买</p></div>

<!--footer-->
<!-- <div class="footer_k">
<a href="<?php echo U('Store/index',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>">
  <div class="ft_left">
   
      <div style="width:100%;height:98px;border-right:1px solid #e0e0e0;">
            <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_sy_pre.png" style=""/></div>
            <div class="ft_font" style="color:#59c2e1;">订水</div>
        </div>
   
    </div>
   </a>
     <a href="<?php echo U('Store/orders',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
    <div class="ft_left">
   
        <div style="width:100%;height:98px;border-right:1px solid #e0e0e0;">
            <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_dd.png" style=""/></div>
            <div class="ft_font">订单</div>
        </div>
    
    </div>
    </a>
     <a href="<?php echo U('Store/user',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
    <div class="ft_left">

      <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_wd.png" style=""/></div>
        <div class="ft_font">我的</div>
    </div>
    </a>
</div>
</form>
footer
<div class="pass" id="order">确认下单</div> -->


</body>
<script>

 $('#order').click(function(){
  
  //数据包
  var data=$('#formid').serialize();

//  var floor="<?php echo ($floor); ?>";
  var floor="1"; 
   if(floor==''){
      pconfirm.open('码上订水','由于系统升级请重新修改自己地址',function(){
    
        window.location.href="<?php echo U('Store/userset',array('bid'=>'bid','FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>";
    })
     return false;
   }
       var num=$('#Fnumber').val();
      

     if(num<=0){
        palert.open('码上订水','请选择数量');
        return false;
     }


    var today=$("input[name='today']:checked").val();
       var Fhours1=parseInt($('#Fhours1').val());
        var Fhours2=parseInt($('#Fhours2').val());

       d2=new Date();
       var h2 = d2.getHours();

        if(Fhours1>=Fhours2){
          alert('请选择正确的时间');
          return false;
        }



    var timestamp = Date.parse(new Date()); 
  var ordertime=parseInt('<?php echo ($ordertime); ?>');
  var notime=parseInt('<?php echo ($notime); ?>');

  var daybegin=parseInt('<?php echo ($daybegin); ?>');
  var dayend=parseInt('<?php echo ($dayend); ?>');
  var settimes=parseInt('<?php echo ($settimes); ?>');
  var orderalltimes=parseInt('<?php echo ($orderalltimes); ?>');
  var settimes=parseInt('<?php echo ($settimes); ?>');
  if(settimes<=orderalltimes){
  
     alert('您今天已经订水'+orderalltimes+'次');
  }else{
     if(done='true'){
           pconfirm.open('码上订水','物品将在<label style="color:red">' + $('#Fhours1 option:selected').text()+ '－' + $('#Fhours2 option:selected').text() + '</label>送达,请确认有人签收!',function(){
           //$('#formid').submit();
            $(".tc_mc").css("display","block")
            $(".tc_chose_k2").css("display","block")

           $.post('index.php?g=Wap&m=Store&a=orderdon', data, function(response){
          
               if(response=='sccuess'){
                      
                      /**
                       * update by shitao 20160826 start
                       */
                     // setTimeout(function () { 
                     //  $(".tc_mc").css("display","none")
                     //  $(".tc_chose_k2").css("display","none")
                     //     pconfirm.open('码上订水','您已下单，请到订单中心查看 ',function(){
                     //     window.location.href='<?php echo U('Store/orders',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid'],'praisestatuson'=>$praisestatuson));?>';
                     // })
                     // }, 3000);
                    
                  window.location.href='<?php echo U('Store/orderover',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid'],'praisestatuson'=>$praisestatuson));?>';

                      /**
                       * update by shitao 20160826 end
                       */
                  
               }else{
                 $(".tc_mc").css("display","none")
                      $(".tc_chose_k2").css("display","none")
                  alert('对不起，下单失败'+response);
               }
           })

        })
    }
  }

    


  })


//数量加减
$('.minus').click(function(){
     var num = document.getElementsByName("Fnum")[0].value;
        var Frice = document.getElementsByName("Frice")[0].value;
        Frice = parseInt(Frice)
        num = parseInt(num)
        if(num>1){
            num -= 1
            document.getElementsByName("Fnum")[0].value = num
            document.getElementById("iFnum").innerHTML = num
           if(document.getElementById("iFrice")){
            document.getElementById("iFrice").innerHTML = num*Frice 
        }else{
           document.getElementById("iFrice3").innerHTML = (num-1)*Frice
       
        }
            document.getElementById("iFrice2").innerHTML = num*Frice
            
            $('#Fnum').val(num);
         
        }

});


$('.add').click(function(){

   var num = document.getElementsByName("Fnum")[0].value;
        var Frice = document.getElementsByName("Frice")[0].value;
        Frice = parseInt(Frice)
        num = parseInt(num)
        num += 1
        document.getElementsByName("Fnum")[0].value = num
        document.getElementById("iFnum").innerHTML = num
        if(document.getElementById("iFrice")){
            document.getElementById("iFrice").innerHTML = num*Frice 
        }else{
           document.getElementById("iFrice3").innerHTML = (num-1)*Frice
       
        }
        document.getElementById("iFrice2").innerHTML = num*Frice
        
       
        $('#Fnum').val(num);

});


$('#Fhours1').change(function(){
       var today=$("input[name='today']:checked").val();
       var Fhours1=parseInt($(this).val());
       d=new Date();
       var h = d.getHours();
       

   
       var Fhours2=parseInt($('#Fhours2').val());

        if(Fhours2<=Fhours1){
          alert('请填写正确的时间');

        
        }
      

    })

    $('#Fhours2').change(function(){
       var Fhours2=$(this).val();
       var Fhours1=$('#Fhours1').val();
       Fhours1=parseInt(Fhours1);
       Fhours2=parseInt(Fhours2);
       if(Fhours2<=Fhours1){
        alert('请填写正确的时间');
        
        }
    })

//       $('#Fhours3').change(function(){
//        var Fhours3=$(this).val();
//        var Fhours4=$('#Fhours4').val();
//        Fhours3=parseInt(Fhours3);
//        Fhours4=parseInt(Fhours4);
//        if(Fhours4<Fhours3+1){
//         alert('请填写正确的时间');
//         }
//     })

//      $('#Fhours4').change(function(){
//        var Fhours4=$(this).val();
//        var Fhours3=$('#Fhours3').val();
//        Fhours3=parseInt(Fhours3);
//        Fhours4=parseInt(Fhours4);
//        if(Fhours4<Fhours3+1){
//         alert('请填写正确的时间');
//         }
//     })



//   $('#tody').click(function(){

//      $('#xuanzhe').css('display','none');
//      $('#get_time').css('display','inline');
//   })


//    $('#tomo').click(function(){
//     $('#xuanzhe').css('display','inline');
//     $('#get_time').css('display','none');
//    })

</script>
</html>