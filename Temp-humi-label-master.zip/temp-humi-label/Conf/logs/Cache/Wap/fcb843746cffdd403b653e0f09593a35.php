<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_home_list.css" />
<link rel="stylesheet" type="text/css" href="cssw3/sp_tc.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_home_one1.css" />
<link rel="stylesheet" href="cssw3/swiper.min.css">
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<script type="text/javascript" src="/public/ipublic.js"></script>
<script src="js/swiper.min.js"></script>
<style>

.clckClass {
        background:#e0e0e0;
    }
.gtitle{color: #eb6100;
    border-bottom: 1px solid #eb6100;
    text-align: center;
    padding: 6px 15px;
    line-height: 30px;
    font-size: 22px;}
.gcont{font-size: 20px;
    padding: 15px 35px;
    line-height: 30px;
    border-bottom: 1px solid #555;}
.mc_close{  text-align: center;
    font-size: 22px;
    line-height: 30px;
    margin-top: 10px;}
</style>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
  var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
  if (/Android (\d+\.\d+)/.test(ua)){
    var version = parseFloat(RegExp.$1);
    if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
    }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
  } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>
<body>
<!--header-->
<!--弹出-->
<div class="mc"></div>
<div class="mc_message">
  <div class="gtitle"><?php echo ($notice["Ftitle"]); ?></div>
  <div class="gcont"><?php echo ($notice["notice"]); ?></div>
  <div class="mc_close">确认</div>
</div>

<!-- <script>
//水站联系人信息
     $(document).ready(function() {
    $(".p_w").click(function(){
      $(".p_w").css("color","#999")
      $(this).css("color","#d12b04")
      })
    })
</script> -->
<!--头部标题-->
<!-- <div class="header_k">
  <?php if($_GET['bid'] == 'bid' ): ?><a href="<?php echo U('Store/index',array('FFtoken'=>$_GET['FFtoken'],'FFphone'=>$_GET['FFphone'],'FFqid'=>$_GET['FFqid']));?>">
  <img class="icon_left" src="img/a/nav_fh.png"/>
  </a>
      <a href="<?php echo U('Store/intro',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>">
    <div class="sz_name"><?php echo ($userinfo["Fwatername"]); ?> <span><img src="img/a/nav_btn.png" style=""></span></div>

    </a><?php endif; ?>
    <div class="sz_name">水品列表</div>
    <a href="tel:<?php echo ($userinfo["Fphone"]); ?>">
    <img class="icon_right" src="img/dh.png"/>
    </a>
</div> -->

<div class="header_k">
 <!-- <?php if($_GET['bid'] == 'bid' ): ?><img class="icon_left" src="img/back.png" onclick="window.history.back()" />
 
 <?php else: ?>
 
   <img class="icon_left" src="img/chose_user.png"/><?php endif; ?> 头部左侧头像隐藏-->
   
    <div class="sz_name"> <a href="<?php echo U('Store/intro',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>"><?php echo ($userinfo["Fwatername"]); ?></a> <!-- <span><img class="title_d" src="img/a/nav_btn.png" style=""></span>头部点隐藏 --></div>

    <!-- <?php if($bid == 'orders'): ?><a href="<?php echo U('Nativelife/orderlist',array('token'=>$FFtoken));?>">
        <img class="icon_right" src="img/a/nav_fh.png"/>
        </a>
    <?php else: ?>
        <a href="tel:<?php echo ($userinfo["Fphone"]); ?>">
        <img class="icon_right" src="img/dh.png"/>
        </a><?php endif; ?> 头部右侧图标隐藏-->
    <!-- <div style="width:34px;width:100%"><p style="float:left;font-size:28px;">您目前的积分：90</p><img src="img/jifen.gif" style="float:right;"/> </div>积分隐藏-->
    
</div>
<div class="h55"></div>


<!--切换账号-->
<div class="tc_mc"></div>
<div class="tc_chose_k">
    <div class="tip blue_color">您可以切换其他账号登陆！</div>
    <a href="index.php?g=Wap&m=Reg&a=station&token=<?php echo ($FFtoken); ?>"><div class="go_join">切换账号 > ></div></a>
    <img class="date_close" src="img/gb.png"/>
</div>
<script>
//蒙层不可滑动
        $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.tc_mc').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
         $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.tc_chose_k').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
//切换账号
     $(document).ready(function() {
        $(".icon_left").click(function(){
            $(".tc_mc").css("display","block")
            $(".tc_chose_k").css("display","block")
            })
        $(".tc_mc").click(function(){
            $(".tc_mc").css("display","none")
            $(".tc_chose_k").css("display","none")
            })
        $(".date_close").click(function(){
            $(".tc_mc").css("display","none")
            $(".tc_chose_k").css("display","none")
            })
        })
</script>
<!--内容-->
<div style="overflow:hidden;">
    <!--内容-->
  <div class="sy_ttwill_banner" >
      <div class="swiper-wrapper">

          <?php if(is_array($res2)): $i = 0; $__LIST__ = $res2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="swiper-slide">
            <a href="<?php echo ($vo["url"]); ?>" onclick="_hmt.push(['_trackEvent', '<?php echo ($vo["info"]); ?>', 'click', '<?php echo ($userinfo["Fwatername"]); ?>'])">
              <img class="sy_bn_tu" src="<?php echo ($vo["img"]); ?>" width="640px" height="265px"/>
            </a>
            <h2 class="gallerytitle"></h2>
          </div><?php endforeach; endif; else: echo "" ;endif; ?>
          
      </div>
    <div class="pagination"></div> 
    </div>
    
    <script type="text/javascript">
    window.onload = function() {
      var mySwiper2 = new Swiper('.sy_ttwill_banner',{
          autoplay:3000,
          visibilityFullFit : true,
          loop:true,
          pagination : '.pagination',
      });
     
    }
    </script>
  <!-- <div class="list_img"><img src="img/a/list_img.jpeg" alt="" width="100%" height="200px"/></div> -->
  <marquee scrollAmount=2 onmouseover=stop() onmouseout=start() class="list_info">
  <?php if($notice["Ftitle"] != ''): ?><span class="notice"><?php echo ($notice["Ftitle"]); ?></span><?php else: ?>欢迎光临"码上生活"订水系统<?php endif; ?>
  </marquee>
  <div class="gslist">
    <div class="list_left">
      <ul>
        <li class="list_type active" id="barrel">桶装水</li>
        <li class="list_type" id="bottle">瓶装水</li>
        <?php if($notice["wx_pay"] > 0): ?><li class="list_type" id="ticket">水票</li><?php endif; ?>
        <li class="list_type" id="other">其他</li>
      </ul>
    </div>
    <div class="list_right" id="barrel_list">
      <!-- <div class="list_tt">桶装水<span class="list_exp">即定即送，快速到家，安全可靠</span></div> -->
      <?php if(empty($product_bar)): ?><p class="sp_name" style="color:#ff0000;text-align:center;margin-top:10px">老板还没上货呢！</p>
      <?php else: ?>
      <?php if(is_array($product_bar)): $i = 0; $__LIST__ = $product_bar;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i; if($item["id"] == ''): ?><p class="sp_name">老板还没上货呢！</p><?php endif; ?>
        <div class="list_one">
          <!-- <div class="gsp" p="<?php echo ($item["id"]); ?>">购水票</div> -->
          <?php if($item["logourl"] != '' ): ?><img src="<?php echo ($item["logourl"]); ?>" class="picture"  />
          <?php else: ?>
          <img src="img/no.png" class="picture"  /><?php endif; ?>
          <div class="sp_k">
              <div class="sp_name ovfEps">
                <?php if($item["gb_label"] != ''): ?><span>[<?php echo ($item["gb_label"]); ?>]</span><?php endif; ?>
                <?php echo ($item["name"]); ?>
                <?php if($item["ga_label"] != ''): ?><p>(<?php echo ($item["ga_label"]); ?>)</p><?php endif; ?>
              </div>
              <div class="sp_type"><?php echo ($item["spec"]); ?><!-- <span>赠送:<?php echo ($item["price"]); ?>积分</span> --></div>
              <div class="sp_price" style="height:50px"><?php if($item["price"] != '0'): ?>￥<?php echo ($item["price"]); endif; ?></div>
              <input type="hidden" value="<?php echo ($item["price"]); ?>" id="price<?php echo ($item["id"]); ?>">
              <div class="add_k">
                  <input type="button" class="minus"  id="minus<?php echo ($item["id"]); ?>" value="-" ids="<?php echo ($item["id"]); ?>"/>
                  <div class="add_num">
                      <input type="text" class="number"  style="width:45px;height:55px;text-align:center"  value="0" id="num<?php echo ($item["id"]); ?>" name="num" idsn="<?php echo ($item["id"]); ?>" readonly="readonly">              
                  </div>
                  <input type="button" class="add"  id="add<?php echo ($item["id"]); ?>" value="+" ids="<?php echo ($item["id"]); ?>"/>
              </div>
          </div>         
        </div>
        <hr class="hrline"><?php endforeach; endif; else: echo "" ;endif; endif; ?>
    </div>

    <div class="list_right" id="bottle_list" style="display:none">
      <!-- <div class="list_tt">瓶装水<span class="list_exp">即定即送，快速到家，安全可靠</span></div> -->
      <?php if(empty($product_bot)): ?><p class="sp_name" style="color:#ff0000;text-align:center;margin-top:10px">老板还没上货呢！</p>
      <?php else: ?>
      <?php if(is_array($product_bot)): $i = 0; $__LIST__ = $product_bot;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><div class="list_one">
          <!-- <div class="gsp" p="<?php echo ($item["id"]); ?>">购水票</div> -->
          <?php if($item["logourl"] != ''): ?><img src="<?php echo ($item["logourl"]); ?>" class="picture"  />
          <?php else: ?>
          <img src="img/no.png" class="picture"  /><?php endif; ?>
          <div class="sp_k">
               <div class="sp_name ovfEps">
                <?php if($item["gb_label"] != ''): ?><span>[<?php echo ($item["gb_label"]); ?>]</span><?php endif; ?>
                <?php echo ($item["name"]); ?>
                <?php if($item["ga_label"] != ''): ?><p>(<?php echo ($item["ga_label"]); ?>)</p><?php endif; ?>
               </div>
              <div class="sp_type"><?php echo ($item["spec"]); ?><!-- <span>赠送:<?php echo ($item["price"]); ?>积分</span> --></div>
              <div class="sp_price" style="height:50px"><?php if($item["price"] != '0'): ?>￥<?php echo ($item["price"]); endif; ?></div>
              <input type="hidden" value="<?php echo ($item["price"]); ?>" id="price<?php echo ($item["id"]); ?>">
              <div class="add_k">
                  <input type="button" class="minus"  id="minus<?php echo ($item["id"]); ?>" value="-" ids="<?php echo ($item["id"]); ?>"/>
                  <div class="add_num">
                  <input type="text" class="number"  style="width:45px;height:55px;text-align:center"  value="0" id="num<?php echo ($item["id"]); ?>" name="num" idsn="<?php echo ($item["id"]); ?>" readonly="readonly">
                  
              </div>
              <input type="button" class="add"  id="add<?php echo ($item["id"]); ?>" value="+" ids="<?php echo ($item["id"]); ?>"/>
              </div>
          </div>         
        </div>
        <hr class="hrline"><?php endforeach; endif; else: echo "" ;endif; endif; ?>
    </div>

    <div class="list_right" id="ticket_list" style="display:none">
      <!-- <div class="list_tt">水票<span class="list_exp">即定即送，快速到家，安全可靠</span></div> -->
      <?php if(empty($product_tic)): ?><p class="sp_name" style="color:#ff0000;text-align:center;margin-top:10px">老板还没上货呢！</p>
      <?php else: ?>
      <?php if(is_array($product_tic)): $i = 0; $__LIST__ = $product_tic;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i; if($item["id"] == '' ): ?><p class="sp_name">老板还没上货呢！</p><?php endif; ?>
        <div class="list_one">
          <!-- <div class="gsp" p="<?php echo ($item["id"]); ?>">购水票</div> -->
          <?php if($item["logourl"] != ''): ?><img src="<?php echo ($item["logourl"]); ?>" class="picture"/>
          <?php else: ?>
          <img src="img/no.png" class="picture"/><?php endif; ?>
          <div class="sp_k">
              <div class="sp_name ovfEps"><?php echo ($item["pname"]); ?></div>
              <!-- <div class="sp_type"><?php echo ($item["tname"]); ?></div> -->
              <div class="sp_type"><?php echo ($item["spec"]); ?> X <?php echo ($item["num"]); ?>张<!-- <span>赠送:<?php echo ($item["price"]); ?>积分</span> --></div>
              <div class="sp_type" style="color:#ccc;font-size:19px"><?php echo ($item["remarks"]); ?></div>
              <div class="sp_price" style="height:50px"><?php if($item["price"] != '0'): ?>￥<?php echo ($item["price"]); endif; ?></div>
              <input type="hidden" value="<?php echo ($item["price"]); ?>" id="price<?php echo ($item["id"]); ?>">
              <div class="add_k">
                  <input type="button" class="minus"  id="minus<?php echo ($item["id"]); ?>" value="-" ids="<?php echo ($item["id"]); ?>+'ticket'"/>
                  <div class="add_num">
                  <input type="text" class="number"  style="width:45px;height:55px;text-align:center"  value="0" id="num<?php echo ($item["id"]); ?>" name="num" idsn="<?php echo ($item["id"]); ?>" readonly="readonly">
                  
              </div>
              <input type="button" class="add"  id="add<?php echo ($item["id"]); ?>" value="+" ids="<?php echo ($item["id"]); ?>+'ticket'"/>
              </div>
          </div>         
        </div>
        <hr class="hrline"><?php endforeach; endif; else: echo "" ;endif; endif; ?>
    </div>

    <div class="list_right" id="other_list" style="display:none">
      <!-- <div class="list_tt">其他<span class="list_exp">即定即送，快速到家，安全可靠</span></div> -->
      <?php if(empty($product_oth)): ?><p class="sp_name" style="color:#ff0000;text-align:center;margin-top:10px">老板还没上货呢！</p>
      <?php else: ?>
      <?php if(is_array($product_oth)): $i = 0; $__LIST__ = $product_oth;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i; if($item["id"] == '' ): ?><p class="sp_name">老板还没上货呢！</p><?php endif; ?>
        <div class="list_one">
          <!-- <div class="gsp" p="<?php echo ($item["id"]); ?>">购水票</div> -->
          <?php if($item["logourl"] != ''): ?><img src="<?php echo ($item["logourl"]); ?>" class="picture"/>
          <?php else: ?>
          <img src="img/no.png" class="picture"/><?php endif; ?>
          <div class="sp_k">
              <div class="sp_name ovfEps">
                <?php if($item["gb_label"] != ''): ?><span>[<?php echo ($item["gb_label"]); ?>]</span><?php endif; ?>
                <?php echo ($item["name"]); ?>
                <?php if($item["ga_label"] != ''): ?><p>(<?php echo ($item["ga_label"]); ?>)</p><?php endif; ?>
              </div> 
              <div class="sp_type"><?php echo ($item["spec"]); ?><!-- <span>赠送：<?php echo ($item["price"]); ?>点积分</span> --></div>
              <div class="sp_price" style="height:50px"><?php if($item["price"] != '0'): ?>￥<?php echo ($item["price"]); endif; ?></div>
              <input type="hidden" value="<?php echo ($item["price"]); ?>" id="price<?php echo ($item["id"]); ?>">
              <div class="add_k">
                  <input type="button" class="minus"  id="minus<?php echo ($item["id"]); ?>" value="-" ids="<?php echo ($item["id"]); ?>"/>
                  <div class="add_num">
                  <input type="text" class="number"  style="width:45px;height:55px;text-align:center"  value="0" id="num<?php echo ($item["id"]); ?>" name="num" idsn="<?php echo ($item["id"]); ?>" readonly="readonly">
                  </div>
                  
              <input type="button" class="add"  id="add<?php echo ($item["id"]); ?>" value="+" ids="<?php echo ($item["id"]); ?>"/>
              </div>
          </div>
        </div>
        <hr class="hrline"><?php endforeach; endif; else: echo "" ;endif; endif; ?>
    </div>
  <input type="hidden" name="product" value="" id="product">
  <input type="hidden" name="productnum" value="" id="productnum">  
  </div>
</div>
<!--footer-->

<div class="h150"></div>
<!-- <div style="height:100px"></div> -->
<div class="pass" style="bottom:72px">
    <div class="totalsum" >
      <img src="img/a/jiaru1.png" alt="" />
      <p id="priceall" class="totalp">未选购商品</p>
      <p class="totalp" style="font-size:20px">总计获得积分<span id="scoreall" style="color:#fff"> 0</span> &nbsp;&nbsp;&nbsp;&nbsp;配送费0元</p>
    </div>

    <a href="javascript:void(0)" id="pass" class="sure_down">

    <div style="float:right;"><img src="img/a/jiesuan1.png" alt="" height="75px"/></div>
    </a>
</div>
<div class="footer_k">
<a href="<?php echo U('Store/index',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left">   
      <div>
        <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_sy.jpg" style=""/></div>
        <div class="ft_font" >首页</div>
      </div>   
  </div>
</a>
<a href="<?php echo U('Store/goodslist',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left"> 
    <div>
      <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_sp_pre.jpg" style=""/></div>
      <div class="ft_font" style="color:#6283a6">商品列表</div>
    </div>  
  </div>
</a>

<a href="<?php echo U('Store/orders',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left"> 
    <div>
      <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_dd.jpg" style=""/></div>
      <div class="ft_font">我的订单</div>
    </div>  
  </div>
</a>
<a href="<?php echo U('Store/user',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken,'FFqid'=>$_GET['FFqid']));?>">
  <div class="ft_left">
    <div class="ft_icon_k"><img class="ft_icon" src="img/a/tab_wd.jpg" style=""/></div>
    <div class="ft_font">会员中心</div>
  </div>
</a>
</div>

</body>
<script language="javascript" type="text/javascript">
//数量加减
$('.minus').click(function(){
    var thisids=parseInt($(this).attr('ids'));
    if($('#num'+thisids).val()!=0 && $('#num'+thisids).val()!=''){
     $('#num'+thisids).val(parseInt($('#num'+thisids).val())-1)
     $('#product').val($(this).attr('ids'));
    $('#productnum').val($('#num'+thisids).val());

    //计算合计
    var price=$('#price'+thisids).val();
    var productnum2=$('#num'+thisids).val();
    var tos=price*productnum2;
    $('#priceall').html(tos);
    $('#scoreall').html(tos*0);
    }
});

$('.add').click(function(){
var noid=parseInt($(this).attr('ids'));
$("input[name='num']").each(function(){

  if($(this).attr('idsn')!=noid){
     $(this).val('0');
  }
})
if($('#num'+noid).val()=='')
$('#num'+noid).val('0')
$('#num'+noid).val(parseInt($('#num'+noid).val())+1)
if($('#num'+noid).val()>0){
  $('#list_'+noid).addClass('clckClass');
  $('#product').val($(this).attr('ids'));
  $('#productnum').val($('#num'+noid).val());

}
var price=$('#price'+noid).val();
    var productnum2=$('#num'+noid).val();
    var tos=price*productnum2;
    $('#priceall').html(tos);
    $('#scoreall').html(tos*0);
});

//菜单切换
$('.list_type').click(function(){
    var cid=this.id;
    var id=cid+'_list';
    //console.log(id);
    $('.list_type').removeClass("active");
    $(this).addClass("active");
    $(".list_right").hide();
    $("#"+id).show();

})
</script>
<script>
//蒙层不可滑动
        $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.mc').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
     $('html,body').animate({scrollTop: '0px'}, 100);//因为页面很长，有纵向滚动条，先让页面滚动到最顶端，然后禁止滑动事件，这样可以使遮罩层锁住整个屏幕  
        $('.mc_message').bind("touchmove",function(e){  
                e.preventDefault();  
        }); 
//弹出
  $(document).ready(function() {

        /*$(".gsp").click(function(){
            htmlobj=$.ajax({url:"<?php echo U('ticket/buy', $_GET);?>&id="+$(this).attr("p"),async:false});
            $(".mc_message").html(htmlobj.responseText);
            $(".mc").css("display","block")
            $(".mc_message").css("display","block")
            })*/
        $(".notice").click(function(){
            $(".mc").css("display","block");
            $(".mc_message").css("display","block")
        })
        $(".mc").click(function(){
            $(".mc").css("display","none");
            $(".mc_message").css("display","none")
            })
        $(".mc_close").click(function(){
            $(".mc").css("display","none");
            $(".mc_message").css("display","none")
            })    
    })
</script>

<script>
//弹出勾选框
/* $(document).ready(function() {
   $(".way_pay_s").click(function(){
     $(".way_pay_s").css('background','none')
     $(".way_pay_s").css('border','1px solid #999')
     $(".way_pay_s").css('color','#999')
     
     $(this).css({border:'none',background:'#d12b04',color:'#fff'})
     })  
});*/

 //下单
 $('#pass').click(function(){
   var product=$('#product').val();
   var productnum=$('#productnum').val();

 
   if(product=="" || productnum<=0){
   
      palert.open('码上订水','请选择水品和数量');
     
       return false;
   }
  window.location.href="<?php echo U('Store/orderinfo',array('FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>&product="+product+"&productnum="+productnum+"&FFqid="+"<?php echo ($_GET['FFqid']); ?>";
})
 
</script>
</html>