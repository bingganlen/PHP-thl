<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>码上订水</title>
<link rel="stylesheet" type="text/css" href="cssw3/home_phone.css" />
<link rel="stylesheet" type="text/css" href="cssw3/user_zc.css" />
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<script type="text/javascript" src="/public/ipublic.js"></script>
<style type="text/css">
  input, textarea{
    background-color: #fff;
    -webkit-autofill:none;
  }
  .citysel{ font-size: 28px;
    background: url(../../img/a/downarr.png) no-repeat right;
    background-size: 30px;    
    padding: 5px 25px 5px 10px;
    border: 2px solid #ccc;
    border-radius: 5px;
    width:40%;
    margin-top:22px;}
  
</style>
</head>
<!--手机端自适应js-->
<script type="text/javascript">
    var phoneW =  parseInt(window.screen.width),phoneScale = phoneW/640,ua = navigator.userAgent;
    if (/Android (\d+\.\d+)/.test(ua)){
        var version = parseFloat(RegExp.$1);
        if(version>2.3){document.write('<meta name="viewport" content="width=640, initial-scale='+phoneScale+', minimum-scale = '+phoneScale+', maximum-scale = '+phoneScale+', target-densitydpi=device-dpi">');
        }else{document.write('<meta name="viewport" content="width=640, target-densitydpi=device-dpi">');}
    } else {document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');}
</script>


<body>
  <div class="header"><?php echo ($wxuser["wxname"]); ?></div>
    <!-- <div class="ps">对不起，您的用户名已被注册</div> -->
<form action="<?php echo U('Reg/register');?>" method="post" id="formid" >
    <!-- <input type="hidden" name="token" value="<?php echo ($_GET['token']); ?>"> -->
    <input type="hidden" name="token" value="<?php echo ($token); ?>">
    <input type="hidden" name="Fewm_id" value="<?php echo ($Fewm_id); ?>">
    <div class="login_phone">
      <div class="phone_k1" style="margin-top:20px;">
        <!-- <img class="icon" src="img/a/login_icon_sjh.png" alt="手机号"/> -->
        <label class="ph_label">手机号码：</label>
        <input class="phone_input" type="text" placeholder="手机号" name="name"  id="name"/>
      </div>
      <div class="phone_k1">
        <!-- <img class="icon" src="img/a/login_icon_mm.png" alt="密码"/> -->
        <label class="ph_label">验证码：</label>
        <input class="yzm_get"  id="button" style="" type="button" value="获取验证码"  onclick="javascript:sendMsg();"/>
        <div class="yzm_get" style="display:none" id="a_verify"></div>
        <input class="phone_input" style="width:40%" type="text" placeholder="请输入验证码" name="verifyMP" id="verifyMP"/>
        
      </div>
      <div class="phone_k1">
        <!-- <img class="icon" src="img/a/login_icon_yzm.png" alt="密码"/> -->
        <label class="ph_label">登录密码：</label>
        <span class="test">
            <input class="phone_input" type="text" placeholder="密码" name="passwd" id="passwd" value="123456"/>
        </span>
        <img class="icon_e" src="img/eye.png" alt="密码"/>       
      </div>
      <div class="phone_k1" style="height:68px"><span style="font-size:22px;color:#eb6100;line-height:68px">提示：密码默认123456，您可以不必填写，也可以点击修改！</span></div>
    </div>
   <!--  <div class="phone_k">
        <img class="icon" src="img/a/login_icon_fwgh.png" alt="服务工号（选填）"/>
        <input class="phone_sr" type="text" placeholder="服务工号（选填）" name="num" id="num"/>
    </div> -->
     <!--社会水站不用宿舍楼2018-4-2改 <?php if($Ftype == '0'): ?><div class="phone_k">    
     <select class="chose_lou" name="floorid" >
     <option value="-1">宿舍楼</option>
           <?php if(is_array($floor)): $i = 0; $__LIST__ = $floor;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><option value="<?php echo ($item["Fid"]); ?>"><?php echo ($item["Fname"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
      </select>
      <span style="vertical-align:middle;line-height:60px;font-size:36px;color:#59c2e1;font-weight:bold;">栋</span>     
        <img class="icon" src="img/a/login_icon_dz.png" alt="请输入地址"/>       
         </div><?php endif; ?> -->
    <div class="login_phone">
     <div class="phone_k1">
     <!-- <img class="icon" src="img/a/login_icon_dz.png" alt="请输入地址"/> -->
        <label class="ph_label">送水地址：</label>
        <span><?php echo ($province); ?></span>
        <input type="hidden" name="city1" value="<?php echo ($wxuser["province"]); ?>"/>
        
        <span><?php echo ($city); ?></span>
        <input type="hidden" name="city2" id="city2" value="<?php echo ($wxuser["city"]); ?>"/>        
           
      <select id="city3" name="city3" class="citysel">          
        <option value="<?php echo ($wxuser["country"]); ?>"><?php echo ($country); ?></option>  
        <?php if(is_array($counties)): $i = 0; $__LIST__ = $counties;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["Fid"]); ?>" <?php if(($vo["Fid"]) == $city3): ?>selected=""<?php endif; ?> ><?php echo ($vo["Fname"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
      </select>
      </div>    
      <div class="phone_k1">  
        <textarea placeholder="请输入详细地址" class="phone_input" name="address" id="address"></textarea>
      </div>   
    </div>
    <input type="hidden" name="product" value="<?php echo ($product); ?>" id="product"/>
    <input type="hidden" name="productnum" value="<?php echo ($productnum); ?>" id="productnum"/>
    <input type="button" class="login" value="确认注册" id="onpost" />
    <a href="<?php echo U('Reg/slogin',array('token'=>$token,'product'=>$product,'productnum'=>$productnum));?>"> 
  <input type="button" class="login1" value="已注册去登陆"/>
  </a>
   
</form> 
</body>

<!--eye-->
<script language="javascript" type="text/javascript">
$('.icon_e').click(function(){
  vale=$('.test').find('input').val(); //将test里的值存起来
  
  if($('.test').find('input').attr('type')=='text'){//如果text里的input的type为text
    $('.test').html("<input type='password' class='phone_input' name='passwd' id='passwd' value='"+vale+"'>")//输出的input
  }else{
    $('.test').html("<input type='text' class='phone_input' id='passwd' name='passwd' value='"+vale+"'>")//否则输出的input
  }
})

$('#verifyImg').click(function(){
            //重载验证码
            var timenow = new Date().getTime();
            var url="<?php echo U('Reg/verify',array('t'=>'"+timenow+"'));?>";
            $('#verifyImg').attr('src',url);
            
        });
$('#onpost').click(function(){
  name=document.getElementById('name').value;
  passwd=document.getElementById('passwd').value;
  address=document.getElementById('address').value;
  num=document.getElementById('verifyMP').value;
  var product=document.getElementById('product').value;
  var productnum=document.getElementById('productnum').value;
  var reg=/^0{0,1}(13[0-9]|14[0-9]|16[0-9]|17[0-9]|15[0-9]|18[0-9])[0-9]{8}$/i;
  if(name=='' || !reg.test(name)){
    alert('请输入正确的手机号！');
    return false;
  }
  
  if(passwd==''){
                alert('密码不能为空');
                return false;
        }
    if(address==''){
                alert('地址不能为空');
                return false;
        }
    if( '' === $.trim($('#verifyMP').val())){
                //$('#result').html('验证码不能为空!').show();
                alert('验证码不能为空!');
                return false;
            } 
    if(num==''){
                alert('请输入验证码');
                return false;
        }
  //return true;
   var data=$('#formid').serialize();
  /* $.post("<?php echo U('Reg/pbcheck');?>", data, function(response){

               if(response=='sccuess'){
                     // pconfirm.open('码上订水','注册成功请选择你的订的水品下次订水使用',function(){
                         window.location.href="<?php echo U('Store/goodslist',array('FFtoken'=>$_GET['token']));?>&FFphone="+name;
                     // })
                  
               }else{
                  alert(response);
               }
           })*/
  $.post("<?php echo U('Reg/register');?>", data, function(response){
      //console.log(response);
      switch (response){
        case 'index1':
          pconfirm.open('码上订水','已为您更新二维码，是否登录？',function(){
            if(product&&productnum){
              window.location.href="<?php echo U('Store/orderinfo',array('FFtoken'=>$token,'Fewm_id'=>$Fewm_id,'FFqid'=>$Fewm_id,'product'=>$product,'productnum'=>$productnum));?>&FFphone="+name;
            }else{
              window.location.href="<?php echo U('Store/goodslist',array('FFtoken'=>$token,'Fewm_id'=>$Fewm_id,'FFqid'=>$Fewm_id));?>&FFphone="+name;
            }
         
          });
        break;
        case 'index2':
          pconfirm.open('码上订水','您已注册过该水站，是否登录？',function(){
            if(product&&productnum){
              window.location.href="<?php echo U('Store/orderinfo',array('FFtoken'=>$token,'Fewm_id'=>$Fewm_id,'FFqid'=>$Fewm_id,'product'=>$product,'productnum'=>$productnum));?>&FFphone="+name;
            }else{
          window.location.href="<?php echo U('Store/goodslist',array('FFtoken'=>$token,'Fewm_id'=>$Fewm_id,'FFqid'=>$Fewm_id));?>&FFphone="+name;
            }
          });
        break;
        case 'success':
          pconfirm.open('码上订水','注册成功，是否登录？',function(){
            if(product&&productnum){
              window.location.href="<?php echo U('Store/orderinfo',array('FFtoken'=>$token,'Fewm_id'=>$Fewm_id,'FFqid'=>$Fewm_id,'product'=>$product,'productnum'=>$productnum));?>&FFphone="+name;
            }else{
          window.location.href="<?php echo U('Store/goodslist',array('FFtoken'=>$token,'Fewm_id'=>$Fewm_id,'FFqid'=>$Fewm_id));?>&FFphone="+name;
            }
          });
        break;
        default:
        alert(response);
      }
    })
});
    function sendMsg(){
        var num = document.getElementById('name').value;
        var reg=/^0{0,1}(13[0-9]|14[0-9]|16[0-9]|17[0-9]|15[0-9]|18[0-9])[0-9]{8}$/i;
        if( num == '' || !reg.test(num)){
            alert('请输入正确的手机号！');
    //createCode();//刷新验证码
            return false;
        }

       if (confirm("我们会将会发送验证码到 "+num)){
            jQuery(function($) {
                $.ajax({
                    url:"/index.php?m=Users&a=test",
                    type:"post",
                    data:"sms_mp="+num,
                    success:function(data){
                        if(data==1){
                          alert('请稍后再发送');
                        }
                        $("#button").hide();
                        $("#a_verify").show();
                       $("#a_verify").css({"line-height":"52px","text-align":"center",});
                        fun_timedown(60);

                      }
                });
            });
        }
    }

    function fun_timedown(time){
        if(time=='undefined'){
            time = 60;
        }
        $("#a_verify").html(time+"秒后");

        time = time-1;
        if(time >= 0){
            setTimeout("fun_timedown("+time+")",1000);
        }else{
            $("#button").show();
            $("#a_verify").hide();
            // $("#a_verify").css({"background":"#fff","borderColor":"#007DDB"});
            // $("#a_verify").html('<input class="yzm_get" id="a_verify" style="" type="button" value="获取验证码"  onclick="javascript:sendMsg();"/>');
        }
    }
  

</script>
</html>