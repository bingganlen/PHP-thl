<?php if (!defined('THINK_PATH')) exit(); if(is_array($orders2)): $i = 0; $__LIST__ = $orders2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><div class="dd_list">
      <?php if($item["logourl"] != ''): ?><img src="<?php echo ($item["logourl"]); ?>" class="picture"/>
      <?php else: ?>
        <img src="img/no.png" class="picture"/><?php endif; ?>
        <div class="sp_k">
            <div class="sp_name ovfEps">品名：<?php echo ($item["Fgoodsname"]); ?><!-- <?php if($item[Fticket] == "1"): ?><span class="blue_color">【水票】</span><?php endif; ?> --></div>
            <div class="sp_price">下单时间：<?php echo (date("Y/m/d",$item["Fordertime"])); ?></div>
            <div class="sp_type"><?php if($item[Fticket] == "1"): ?>水票：<?php echo ($item["Fnum"]); ?>张/<?php endif; if($item['Fdiscount'] > '0'): ?>金额:<?php echo ($item["Fpaytotal"]); else: ?>金额:<?php echo ($item["Ftotal"]); endif; ?></div>
            <div class="paystyle">            
            <?php switch($item["Fpaytype"]): case "0": ?>电子水票支付<?php break;?>
              <?php case "1": ?>线下支付<?php break;?>
              <?php case "2": ?>微信支付<?php break;?>
              <?php default: ?>支付宝支付<?php endswitch;?>
            </div>
            <a href="<?php echo U('Store/orders_detail',array('Fid'=>$item['Fid'],'FFphone'=>$FFphone,'FFtoken'=>$FFtoken));?>" class="odetail"><img src="img/a/rightarr.jpg" alt="" height="38px"/></a>
        </div>
      </div>
      
      <?php if($item["Fstatus"] != '3'): ?><div class="operate_btn">
        <hr class="hrdivider"/>
          <?php if($item["Fstatus"] == '1' ): ?><div class="dd_zt" onclick="cancel(<?php echo ($item["Fid"]); ?>)" data-id="">取消订单</div>
            <div class="dd_zt" onclick="quick(<?php echo ($item["Fid"]); ?>)" data-id="">催单</div>        
          <?php elseif($item["Fstatus"] == '2' ): ?>
            <div class="dd_zt" onclick="quick(<?php echo ($item["Fid"]); ?>)" data-id="">催单</div>
          <?php else: ?>
            <div class="dd_zt">已取消</div><?php endif; ?>
          </a>
      </div><?php endif; endforeach; endif; else: echo "" ;endif; ?>