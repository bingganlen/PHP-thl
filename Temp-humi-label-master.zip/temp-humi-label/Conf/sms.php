<?php 
return array (
  'sms_url' => 'http://api.sms.cn/mtutf8/',
  'uid' => 'weiqianlong',
  'pwd' => 'weiqianlong',
  'sms_price' => '10',
);